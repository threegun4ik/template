import sys, os
from __Kompas import *
from collections import OrderedDict
from win32com.client import VARIANT
from pythoncom import VT_DISPATCH, VT_ARRAY
from shapely.geometry import box
from shapely.affinity import translate
from shapely.ops import unary_union
from shapely.geometry import Point

import logging
from collections import OrderedDict

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


def visualize_work_area_with_insertion(
    combined_zone,
    occupied_boxes=None,
    insert_boxes=None,
    try_box=None,
    group_box=None,
    start_point=None,
    title="Рабочая зона"
):
    import matplotlib.pyplot as plt
    from shapely.geometry import box, Polygon
    from matplotlib.patches import Polygon as MplPolygon

    fig, ax = plt.subplots(figsize=(10, 8))

    # Рабочие зоны
    patches = []
    if combined_zone.geom_type in ("Polygon", "MultiPolygon"):
        patches = list(combined_zone.geoms) if hasattr(combined_zone, "geoms") else [combined_zone]
        patches = [p for p in patches if isinstance(p, Polygon) and not p.is_empty and p.exterior]

    for poly in patches:
        coords = list(poly.exterior.coords)
        patch = MplPolygon(coords, closed=True, facecolor="lightgreen", edgecolor="green", alpha=0.5)
        ax.add_patch(patch)

    # 🟢 Визуализация точки начала размещения
    if start_point:
        sx, sy = start_point
        ax.plot(sx, sy, 'go', markersize=8, label="start_point")  # зелёная точка
        ax.text(sx + 3, sy + 3, "start", color="green", fontsize=10)

    # 🔴 Пользовательские занятые прямоугольники
    if occupied_boxes:
        for x1, y1, x2, y2 in occupied_boxes:
            rect = box(x1, y1, x2, y2)
            coords = list(rect.exterior.coords)
            patch = MplPolygon(coords, closed=True, facecolor="red", edgecolor="darkred", alpha=0.4)
            ax.add_patch(patch)

    # 🔷 Вставляемые прямоугольники (пунктир)
    if insert_boxes:
        for b in insert_boxes:
            coords = list(b.exterior.coords)
            patch = MplPolygon(coords, closed=True, facecolor="none", edgecolor="blue", linewidth=2, linestyle='--')
            ax.add_patch(patch)

    # 🟨 Попытка вставки области
    if try_box:
        coords = list(try_box.exterior.coords)
        patch = MplPolygon(coords, closed=True, facecolor="none", edgecolor="gold", linewidth=2, linestyle=':')
        ax.add_patch(patch)

    # 🔵 Прямоугольник самой группы
    if group_box:
        coords = list(group_box.exterior.coords)
        patch = MplPolygon(coords, closed=True, facecolor="lightblue", edgecolor="blue", alpha=0.7)
        ax.add_patch(patch)

    # 📐 Установка границ
    if not combined_zone.is_empty:
        minx, miny, maxx, maxy = combined_zone.bounds
        ax.set_xlim(minx - 20, maxx + 20)
        ax.set_ylim(miny - 20, maxy + 20)
    else:
        ax.set_xlim(0, 100)
        ax.set_ylim(0, 100)

    ax.set_aspect("equal")
    ax.set_title(title)
    plt.grid(True)
    plt.show()

def find_nearest_in_direction(source, candidates, direction, eps=1.0):
    # Используем действительный центр, если доступен
    scx = source.get("center_x", (source["x1"] + source["x2"]) / 2)
    scy = source.get("center_y", (source["y1"] + source["y2"]) / 2)

    nearest = None
    min_dist = float("inf")

    print(f"    🔍 Центр текущего вида: {scx:.2f}, {scy:.2f}")

    for v in candidates:
        if v == source:
            continue
        vcx = v.get("center_x", (v["x1"] + v["x2"]) / 2)
        vcy = v.get("center_y", (v["y1"] + v["y2"]) / 2)

        print(f"      ↳ Кандидат {v['name']} центр: {vcx:.2f}, {vcy:.2f}")

        dist = None
        if direction == "top" and vcy < scy - eps:
            dist = scy - vcy
        elif direction == "bottom" and vcy > scy + eps:
            dist = vcy - scy
        elif direction == "left" and vcx < scx - eps:
            dist = scx - vcx
        elif direction == "right" and vcx > scx + eps:
            dist = vcx - scx
        else:
            continue

        if dist < min_dist:
            min_dist = dist
            nearest = v

    if nearest:
        print(f"    ✅ Ближайший в направлении {direction}: {nearest['name']} на расстоянии {min_dist:.2f}")
    else:
        print(f"  ⚠ Не найден вид в направлении {direction}")

    return nearest

import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


def move_view(view, dx, dy, eps=1e-3):
    """Сдвигает вид и обновляет его координаты."""
    if abs(dx) > eps or abs(dy) > eps:
        obj = view["obj"]
        obj.X += dx
        obj.Y += dy
        obj.Update()

        view["x1"] += dx
        view["x2"] += dx
        view["y1"] += dy
        view["y2"] += dy
        return True
    return False

def get_distance_and_shift(base_geom, geom, max_d=None):
    """
    Возвращает (distance, shift_x, shift_y) между базовой и текущей геометрией.
    Если max_d указан, вычисляет смещение для выравнивания по отступу max_d.
    """
    shift_x = shift_y = 0

    # Определяем относительное положение
    if geom["y2"] <= base_geom["y1"]:  # выше
        d = base_geom["y1"] - geom["y2"]
        if max_d is not None:
            shift_y = base_geom["y1"] - max_d - geom["height"] - geom["y1"]
    elif geom["y1"] >= base_geom["y2"]:  # ниже
        d = geom["y1"] - base_geom["y2"]
        if max_d is not None:
            shift_y = base_geom["y2"] + max_d - geom["y1"]
    elif geom["x2"] <= base_geom["x1"]:  # слева
        d = base_geom["x1"] - geom["x2"]
        if max_d is not None:
            shift_x = base_geom["x1"] - max_d - geom["width"] - geom["x1"]
    elif geom["x1"] >= base_geom["x2"]:  # справа
        d = geom["x1"] - base_geom["x2"]
        if max_d is not None:
            shift_x = base_geom["x2"] + max_d - geom["x1"]
    else:
        d = 0

    return d, shift_x, shift_y

def align_views_from_base(group, iKompasDocument2D1, eps=1.0, target_gap=10.0):
    all_views = group["views"]
    base = next((v for v in all_views if v["type"] == "base"), None)
    if not base:
        logging.warning("⚠ Опорный вид не найден")
        return

    logging.info(f"\n📌 Выравнивание группы: {base['name']}")

    # --- Шаг 1: начальная раскладка по target_gap ---
    processed = set()
    queue = [base]
    while queue:
        current = queue.pop(0)
        logging.info(f"  ▶ Обрабатывается вид: {current['name']}")

        for direction in ["top", "bottom", "left", "right"]:
            neighbor = find_nearest_in_direction(current, all_views, direction, eps)
            if not neighbor or id(neighbor) in processed:
                continue

            dx = dy = 0
            if direction == "top":
                dy = current["y1"] - neighbor["height"] - target_gap - neighbor["y1"]
            elif direction == "bottom":
                dy = current["y2"] + target_gap - neighbor["y1"]
            elif direction == "left":
                dx = current["x1"] - neighbor["width"] - target_gap - neighbor["x1"]
            elif direction == "right":
                dx = current["x2"] + target_gap - neighbor["x1"]

            if move_view(neighbor, dx, dy, eps):
                logging.info(f"    ↻ Смещение {neighbor['name']}: ΔX={dx:.2f}, ΔY={dy:.2f}")

            processed.add(id(neighbor))
            queue.append(neighbor)

        processed.add(id(current))

    # --- Шаг 2: получаем габариты проекционных видов ---
    projections = [v for v in all_views if v["type"] == "projected"]
    geom_data = [{"view": v, "geom": get_gabarit_geom(v["obj"], iKompasDocument2D1)} for v in projections]
    base_geom = get_gabarit_geom(base["obj"], iKompasDocument2D1)

    # --- Шаг 3: определяем максимальное расстояние ---
    max_d = max((get_distance_and_shift(base_geom, g["geom"])[0] for g in geom_data), default=0)
    logging.info(f"🔍 Максимальное расстояние до опорного вида: {max_d:.2f}")

    # --- Шаг 4: финальное выравнивание по max_d ---
    for item in geom_data:
        v = item["view"]
        geom = item["geom"]
        _, shift_x, shift_y = get_distance_and_shift(base_geom, geom, max_d)
        if move_view(v, shift_x, shift_y, eps):
            logging.info(f"  ↻ {v['name']} → ΔX={shift_x:.2f}, ΔY={shift_y:.2f}")

def get_combined_bounding_box(iKompasDocument2D1, views_group):
    """
    Вычисляет объединённый габарит для группы объектов (видов) для Компас 3D v21.
    :param views_group: список объектов (например, видов)
    :return: (width, height, minx, miny, maxx, maxy)
    """
    union_box = None

    for iView in views_group:
        obg_X, obg_Y, x1, y1, x2, y2 = get_gabarit_object(iView, iKompasDocument2D1)
        view_box = box(x1, y1, x2, y2)

        if union_box is None:
            union_box = view_box
        else:
            union_box = union_box.union(view_box)

    if union_box is None:
        raise ValueError("Не удалось определить габариты: пустой список объектов или ошибка в данных")

    minx, miny, maxx, maxy = union_box.bounds
    width = maxx - minx
    height = maxy - miny

    return width, height, minx, miny, maxx, maxy

def arrange_groups_to_grid(iView_system, iKompasDocument2D1, groups, iKompasDocument):

    def add_sheet(iKompasDocument):
        iLayoutSheets = iKompasDocument.LayoutSheets
        iLayoutSheet_last = iLayoutSheets.Item(iLayoutSheets.Count - 1)
        iSheetFormat_last = iLayoutSheet_last.Format
        format_last = iSheetFormat_last.Format

        iLayoutSheet = iLayoutSheets.Add()
        iSheetFormat = iLayoutSheet.Format
        iSheetFormat.Format = format_last
        iLayoutSheet.Update()
        return iLayoutSheet, format_last

    def get_work_areas(iKompasDocument, sheet_index, offset_x):
        iLayoutSheets = iKompasDocument.LayoutSheets
        if sheet_index >= iLayoutSheets.Count:
            return [], 0, None

        iLayoutSheet = iLayoutSheets.Item(sheet_index)
        width = iLayoutSheet.Format.FormatWidth
        height = iLayoutSheet.Format.FormatHeight

        frame_left = 25
        frame_top = 5
        frame_right = 5
        frame_bottom = 5

        # Рабочее поле без рамок
        work_x1 = offset_x + frame_left
        work_y1 = frame_bottom
        work_x2 = offset_x + width - frame_right
        work_y2 = height - frame_top

        # Основная надпись
        on_width = 185
        on_height = 55
        on_x2 = work_x2
        on_y1 = work_y1
        on_x1 = on_x2 - on_width
        on_y2 = on_y1 + on_height

        sheet_area = []

        # Зона слева от основной надписи
        if on_x1 > work_x1:
            sheet_area.append((work_x1, work_y1, on_x1, on_y2))

        # Зона над основной надписью
        if on_y2 < work_y2:
            sheet_area.append((work_x1, on_y2, work_x2, work_y2))

        # 🔹 Построение объединённого полигона рабочей зоны
        available_rects = [box(*rect) for rect in sheet_area]
        combined_zone = unary_union(available_rects)

        # 🔻 Вычитание отчётных таблиц
        iSymbols2DContainer = API7.ISymbols2DContainer(iView_system)
        iAssociationTables = iSymbols2DContainer.AssociationTables

        for i in range(iAssociationTables.Count):
            iAssociationTable = iAssociationTables.AssociationTable(i)
            _, _, x1, y1, x2, y2 = get_gabarit_object(iAssociationTable, iKompasDocument2D1)
            report_poly = box(x1, y1, x2, y2)
            combined_zone = combined_zone.difference(report_poly)

        return [sheet_area], width, combined_zone

    sheet_index = 0
    offset_x = 0

    while groups:
        # Проверка наличия листа и создание, если необходимо
        iLayoutSheets = iKompasDocument.LayoutSheets
        if sheet_index >= iLayoutSheets.Count:
            _, _ = add_sheet(iKompasDocument)

        # Получение рабочих зон текущего листа
        sheet_areas, sheet_width, combined_zone = get_work_areas(iKompasDocument, sheet_index, offset_x)
        # available_rects = [box(*rect) for sheet in sheet_areas for rect in sheet]
        # combined_zone = unary_union(available_rects)

        padding_x = 15  # Отступы между группами видов по X
        padding_y = 15  # Отступы между группами видов по Y
        # Определяем Y для первой строки
        cursor_y = find_cursor_y_for_row(combined_zone, groups, iKompasDocument2D1, padding_y)

        if cursor_y is None:
            print("⚠️ Не удалось найти уровень для первой строки.")
            break

        # Теперь получаем стартовую точку по этому Y
        # start_x, start_y = get_start_point(combined_zone)
        # visualize_work_area_with_insertion(
        #     combined_zone,
        #     occupied_boxes=None,
        #     insert_boxes=None,
        #     try_box=None,
        #     group_box=None,
        #     start_point=(start_x, start_y),
        #     title="Рабочая зона"
        # )

        i = 0
        first_row = True  # Флаг первого ряда

        while i < len(groups):
            row = []
            row_width = 0
            row_height = 0
            j = i

            start_x = get_start_point_for_row(combined_zone, cursor_y, row_height, padding_x)

            if start_x is None:
                print(f"⚠️ Не удалось найти стартовую X в полосе на Y={cursor_y:.2f}")
                break

            # Получаем реальные границы рабочей зоны на этом уровне
            row_bounds = get_row_bounds(combined_zone, cursor_y, row_height)
            if not row_bounds:
                print(f"⚠️ Недостаточно ширины на уровне Y={cursor_y:.2f}")
                break

            row_minx, _, row_maxx, _ = row_bounds

            # Сначала формируем ряд
            while j < len(groups):
                views_group = groups[j]
                if KompasVersion <= 21:
                    group_w, group_h, group_x1, group_y1, group_x2, group_y2 = get_combined_bounding_box(iKompasDocument2D1, views_group)
                else:
                    safe_group_array = VARIANT(VT_ARRAY | VT_DISPATCH, views_group)
                    group_w, group_h, group_x1, group_y1, group_x2, group_y2 = get_gabarit_object(safe_group_array, iKompasDocument2D1)

                if row and (start_x + row_width + group_w + padding_x > row_maxx):
                    break  # следующая группа не влезает в ряд

                row.append({
                    "group": views_group,
                    "width": group_w,
                    "height": group_h,
                    "x1": group_x1,
                    "y2": group_y2
                })
                row_width += group_w + (padding_x if row else 0)
                row_height = max(row_height, group_h)
                j += 1

            # Устанавливаем начальную координату Y для первого ряда
            # if first_row:
            #     cursor_y = maxy - start_y
            #     first_row = False

            while row:
                cursor_x = start_x
                success = True
                temp_boxes = []

                for item in row:
                    group_box = box(
                        cursor_x,
                        cursor_y - row_height,
                        cursor_x + item["width"],
                        cursor_y
                    )
                    if not combined_zone.buffer(-0.1).contains(group_box):
                        success = False
                        print("❗ Не удалось разместить группу в доступной зоне.")
                        print(f"   Попытка вставки прямоугольника: {group_box.bounds}")
                        print(f"   Область рабочей зоны: {combined_zone.bounds}")
                        print(f"   Размеры группы: width={item['width']:.2f}, height={item['height']:.2f}")
                        base_view = item["group"][0]
                        print(f"   Имя опорного вида: {getattr(base_view, 'Name', '?')}")
                        break
                    temp_boxes.append((item, group_box))
                    cursor_x += item["width"] + padding_x

                if success:
                    for item, gbox in temp_boxes:
                        dx = gbox.bounds[0] - item["x1"]
                        dy = gbox.bounds[3] - item["y2"]
                        iView = item["group"][0]
                        iView.X += dx
                        iView.Y += dy
                        iView.Update()

                    total_row_box = box(start_x, cursor_y - row_height, start_x + row_width, cursor_y)

                    combined_zone = combined_zone.difference(total_row_box)

                    i += len(row)
                    # ⬇️ Пересчитываем Y и X для нового ряда
                    cursor_y -= row_height + padding_y
                    start_x = get_start_point_for_row(combined_zone, cursor_y, row_height, padding_x)

                    if start_x is None:
                        print(f"⚠️ Не удалось найти стартовую X в полосе на Y={cursor_y:.2f}")
                        break

                    break
                else:
                    row.pop()
                    if row:
                        row_width = sum(item["width"] + padding_x for item in row[:-1]) + row[-1]["width"]
                        row_height = max(item["height"] for item in row)
                    else:
                        print("❗ Ни одна группа не может быть размещена в текущем ряду. Переход на новый лист.")
                        break

            if not row:
                break

        if i == 0:
            print("⚠️ Ни одна группа не может быть размещена на новом листе. Прерывание.")
            break

        groups = groups[i:]
        offset_x += sheet_width
        sheet_index += 1

def find_cursor_y_for_row(combined_zone, groups, iKompasDocument2D1, padding_y=15, margin=0.2):
    """
    Находит координату Y, на которой можно начать размещать ряд.
    """

    # Предполагаем, что ряд будет примерно как у первой группы
    sample_group = groups[0]

    if KompasVersion <= 21:
        union_box = None

        for iView in sample_group:
            obg_X, obg_Y, x1, y1, x2, y2 = get_gabarit_object(iView, iKompasDocument2D1)
            view_box = box(x1, y1, x2, y2)

            if union_box is None:
                union_box = view_box
            else:
                union_box = union_box.union(view_box)

        if union_box is None:
            raise ValueError("Не удалось определить габариты для видов в группе")

        minx, miny, maxx, maxy = union_box.bounds
        group_w = maxx - minx
        group_h = maxy - miny

        _, _, _, maxy_zone = combined_zone.bounds
        cursor_y = maxy_zone - padding_y

    else:
        safe_group_array = VARIANT(VT_ARRAY | VT_DISPATCH, sample_group)
        group_w, group_h, *_ = get_gabarit_object(safe_group_array, iKompasDocument2D1)
        _, _, _, maxy = combined_zone.bounds
        cursor_y = maxy - padding_y

    row_height = group_h




    while cursor_y > 0:
        bounds = get_row_bounds(combined_zone, cursor_y, row_height, margin)
        if bounds:
            row_minx, _, row_maxx, _ = bounds
            if (row_maxx - row_minx) > group_w + padding_y:
                return cursor_y
        cursor_y -= row_height + padding_y

    return None

def get_start_point(combined_zone, padding_x=10, padding_y=10):
    """
    Возвращает точку начала размещения (x, y) — с отступом от самой верхней и самой левой точки рабочей зоны.
    """
    if combined_zone.is_empty:
        return 0, 0

    # Собираем все координаты внешней границы
    coords = []
    if combined_zone.geom_type == 'Polygon':
        coords = list(combined_zone.exterior.coords)
    elif combined_zone.geom_type == 'MultiPolygon':
        coords = [pt for poly in combined_zone.geoms for pt in poly.exterior.coords]

    # 🔼 Сначала ищем максимальный Y — самую верхнюю точку
    max_y = max(y for x, y in coords)
    top_edge_points = [Point(x, y) for x, y in coords if abs(y - max_y) < 1e-3]

    # ⬅️ Среди них — минимальный X (левее всех на этом уровне)
    top_left = min(top_edge_points, key=lambda p: p.x)

    # Смещаемся чуть внутрь
    start_x = top_left.x# + padding_x
    start_y = top_left.y# - padding_y  # вниз, т.к. ось Y идёт вверх

    return start_x, start_y

def get_start_point_for_row(combined_zone, cursor_y, row_height, padding_x=10, margin=0.2):
    """
    Возвращает стартовую точку в пределах горизонтальной полосы на высоте cursor_y.
    """
    from shapely.geometry import box, Point

    # Определяем полосу по Y
    row_band = box(-1e6, cursor_y - row_height - margin, 1e6, cursor_y + margin)
    slice_zone = combined_zone.intersection(row_band)

    if slice_zone.is_empty:
        return None

    coords = []
    if slice_zone.geom_type == 'Polygon':
        coords = list(slice_zone.exterior.coords)
    elif slice_zone.geom_type == 'MultiPolygon':
        coords = [pt for poly in slice_zone.geoms for pt in poly.exterior.coords]

    max_y = max(y for x, y in coords)
    top_edge_points = [Point(x, y) for x, y in coords if abs(y - max_y) < 1e-3]
    top_left = min(top_edge_points, key=lambda p: p.x)

    start_x = top_left.x + padding_x - 5
    return start_x

def get_row_bounds(combined_zone, cursor_y, row_height, margin=0.2):
    """
    Возвращает minx, maxx, miny, maxy доступной зоны на уровне текущего ряда.
    """
    from shapely.geometry import box

    # Создаём горизонтальную полосу высотой под один ряд
    row_band = box(-1e6, cursor_y - row_height - margin, 1e6, cursor_y + margin)

    # Пересекаем с рабочей зоной
    slice_zone = combined_zone.intersection(row_band)

    if slice_zone.is_empty:
        return None  # Невозможно разместить

    return slice_zone.bounds  # (minx, miny, maxx, maxy)

def process_view_label(iView, iKompasDocument2D1):
    """
    Обрабатывает текстовую маркировку вида (с "Дет.") и позиционирует её.
    """
    iDrawingContainer = API7.IDrawingContainer(iView)
    iDrawingTexts = iDrawingContainer.DrawingTexts

    # Ищем текст с "Дет."
    iDrawingText = next(
        (iDrawingTexts.DrawingText(i) for i in range(iDrawingTexts.Count)
         if "Дет." in API7.IText(iDrawingTexts.DrawingText(i)).Str),
        None
    )

    if not iDrawingText:
        return  # Ничего не делаем, если текст отсутствует

    iText = API7.IText(iDrawingText)
    _, iText_Y, *_ = get_gabarit_object(iText, iKompasDocument2D1)
    scale = iView.Scale

    # Контейнеры для анализа геометрии
    iSymbols2DContainer = API7.ISymbols2DContainer(iView)

    # Максимальное Y среди размеров
    y_max = max(
        (iSymbols2DContainer.LineDimensions.LineDimension(i).Y3
         for i in range(iSymbols2DContainer.LineDimensions.Count)),
        default=0
    )

    # Минимальный X среди сегментов и окружностей
    min_x_segments = [
        min(seg.X1, seg.X2)
        for seg in (iDrawingContainer.LineSegments.LineSegment(i)
                    for i in range(iDrawingContainer.LineSegments.Count))
    ]
    min_x_circles = [
        circ.Xc - circ.Radius
        for circ in (iDrawingContainer.Circles.Circle(i)
                     for i in range(iDrawingContainer.Circles.Count))
    ]
    x_min = min([*min_x_segments, *min_x_circles], default=0)

    # Перемещаем текст
    iDrawingText.X = x_min
    iDrawingText.Y = y_max + (4 + iText_Y) / scale
    iDrawingText.Update()

def build_views_dict(iViews, iKompasDocument2D1):
    """
    Собирает словарь всех видов с их габаритами и типами (base/projected).
    """
    views_dict = {}

    for i in range(iViews.Count):
        iView = iViews.View(i)
        if iView.Type != 10032:  # Пропускаем неассоциативные виды
            continue

        if not iView.Visible: # Пропускаем скрытые виды
            continue

        # Обрабатываем маркировку вида
        process_view_label(iView, iKompasDocument2D1)

        # Данные вида
        iAssociationView = API7.IAssociationView(iView)
        # obg_X, obg_Y, x1, y1, x2, y2 = get_gabarit_object(iView, iKompasDocument2D1)
        g_view_geom_and_dims = get_gabarit_geom_and_dimension(iView, iKompasDocument2D1)

        g_view_geom = get_gabarit_geom(iView, iKompasDocument2D1)

        view_data = {
            "number": i,
            "name": iView.Name,
            "type": "base" if not iAssociationView.BaseView else "projected",
            "center_x": (g_view_geom["x1"] + g_view_geom["x2"]) / 2,
            "center_y": (g_view_geom["y1"] + g_view_geom["y2"]) / 2,
            "x1": g_view_geom_and_dims["x1"],
            "y1": g_view_geom_and_dims["y1"],
            "x2": g_view_geom_and_dims["x2"],
            "y2": g_view_geom_and_dims["y2"],
            "width": g_view_geom_and_dims["width"],
            "height": g_view_geom_and_dims["height"],
            "obj": iView
        }

        # view_data = {
        #     "number": i,
        #     "name": iView.Name,
        #     "type": "base" if not iAssociationView.BaseView else "projected",
        #     "center_x": (g_view_geom["x1"] + g_view_geom["x2"]) / 2,
        #     "center_y": (g_view_geom["y1"] + g_view_geom["y2"]) / 2,
        #     "x1": x1,
        #     "y1": y1,
        #     "x2": x2,
        #     "y2": y2,
        #     "width": obg_X,
        #     "height": obg_Y,
        #     "obj": iView
        # }
        # view_data = {
        #     "number": i,
        #     "name": iView.Name,
        #     "type": "base" if not iAssociationView.BaseView else "projected",
        #     "center_x": (g_view_geom["x1"] + g_view_geom["x2"]) / 2,
        #     "center_y": (g_view_geom["y1"] + g_view_geom["y2"]) / 2,
        #     "x1": g_view_geom["x1"],
        #     "y1": g_view_geom["y1"],
        #     "x2": g_view_geom["x2"],
        #     "y2": g_view_geom["y2"],
        #     "width": obg_X,
        #     "height": obg_Y,
        #     "obj": iView
        # }

        # Группируем по базовому виду
        if view_data["type"] == "base":
            views_dict[iView.Name] = {"views": [view_data]}
        else:
            base_name = iAssociationView.BaseView.Name
            if base_name not in views_dict:
                views_dict[base_name] = {"views": []}
            views_dict[base_name]["views"].append(view_data)

    # Сортировка по имени опорного вида
    return OrderedDict(sorted(views_dict.items(), key=lambda item: item[0]))


def main():
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    iViews = iKompasDocument2D.ViewsAndLayersManager.Views
    iView_system = iViews.View(0)

    # --- Шаг 1: Собираем словарь видов ---
    views_dict = build_views_dict(iViews, iKompasDocument2D1)

    # --- Шаг 2: Выравнивание внутри каждой группы ---
    logging.info("📌 Расставляем виды внутри группы")
    view_groups = []
    for base_name, group in views_dict.items():
        align_views_from_base(group, iKompasDocument2D1)
        view_groups.append([v["obj"] for v in group["views"]])

    # --- Шаг 3: Раскладка групп на листе ---
    logging.info("📌 Расставляем группы видов по листам")
    arrange_groups_to_grid(iView_system, iKompasDocument2D1, view_groups, iKompasDocument)

    logging.info("✅ Группы выравнены и расставлены по сетке")

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    script = os.path.basename(__file__)

    if not check_access(script):
        input(f"Похоже вы не оплатили! '{script.split('.')[0]}', пропускаем...")
        sys.exit()

    iKompasDocument = iApplication.ActiveDocument
    main()
