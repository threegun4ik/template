from __Kompas import *
from __ExcelHandler import ExcelHandler
import re, easygui
from pathlib import Path
import pandas as pd
from _Config import path_to_scripts

KompasObject, iApplication, KompasVersion = get_kompas()
def for_cnc_a3d(xlsx):

    """Получение df из xlsx."""
    path_m3d = Path(xlsx).parent / '3d parts' / 'm3d'
    path_a3d = Path(xlsx).parent / '3d parts' / 'a3d' # Путь куда сохраняем a3d
    path_a3d.mkdir(parents=True, exist_ok=True)
    excel_handler = ExcelHandler(xlsx)
    df = excel_handler.read_excel()
    df = df[['#', 'длина', 'Материалы', 'Количество', 'Карта']].copy()

    def extract_paths_and_coords(map_str):
        matches = re.findall(r'\((\d+)\s+(\d+)\)', map_str)
        file_paths = []
        insert_coords_y = []
        accumulated_length = 0.0

        for i, (length_str, elem_id_str) in enumerate(matches):
            length = float(length_str)
            elem_id = int(elem_id_str)

            pattern = f"{elem_id}_*.m3d"
            files = list(path_m3d.glob(pattern))
            if files:
                file_paths.append(str(files[0]))
            else:
                print(f"[⚠️] Файл не найден для элемента {elem_id}")
                continue

            y_coord = accumulated_length + length / 2
            insert_coords_y.append(y_coord)
            accumulated_length += length

        return pd.Series([file_paths, insert_coords_y])

    df[['Файлы для вставки', 'Координаты вставки Y']] = df['Карта'].fillna('').apply(extract_paths_and_coords)

    def build_assembly_path(row):
        filename = f"{row['#']}_{row['Материалы']}_{row['длина']} - {row['Количество']} компл.a3d"
        return str(path_a3d / filename)

    df['Путь до сборки'] = df.apply(build_assembly_path, axis=1)

    for idx, row in df.iterrows():
        path_a3d = Path(row['Путь до сборки'])
        m3d_list = row['Файлы для вставки']
        lengths_list = row['Координаты вставки Y']

        if path_a3d.exists() and path_a3d.is_file():
            path_a3d.unlink()

        if not m3d_list:
            print(f"[❌] Строка {idx}: нет файлов для вставки, сборка не создаётся.")
            continue
        print(f"Создание сборки: {path_a3d}")
        create_a3d(path_a3d, m3d_list, lengths_list)

    return df

def create_a3d(path_a3d, m3d_list, lengths_list):
    template_file_name = Path(path_to_scripts) / "Template" / "Марка.a3t"
    # template_file_name = r"I:\Documents\LIBRARY\01 _ Share\KOMPAS 3d\Template\Марка.a3t"
    iDocuments = iApplication.Documents
    # iKompasDocument = documents.AddNewDocumentFromTemplateEx(template_file_name, False)
    iKompasDocument = iDocuments.Open(template_file_name, False, False)


    iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
    iPart7_a3d = iKompasDocument3D.TopPart
    iParts7 = iPart7_a3d.Parts
    shift = 30.0
    for m3d, length in zip(m3d_list, lengths_list):
        iPart7 = iParts7.AddFromFile(m3d, True)
        X1, Y1, Z1, X2, Y2, Z2 = 0, 0, 0, 0, 0, 0
        ##
        iFeature7 = API7.IFeature7(iPart7)
        iBody7 = iFeature7.ResultBodies
        iBody7.GetGabarit(X1, Y1, Z1, X2, Y2, Z2)
        ##
        # iPart7.GetGabarit(False, False, X1, Y1, Z1, X2, Y2, Z2)

        iPlacement3D = iPart7.Placement
        iPlacement3D.InitByMatrix3D((1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, length, 0.0, 1.0))
        iPart7.UpdatePlacement(True)
        iPart7.Fixed = True
        iKompasDocument3D.RebuildDocument()

    iKompasDocument.SaveAs(path_a3d) #  Сохрани документ под другим именем
    iKompasDocument.Close(1)


if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    # xlsx = r'C:\Users\ik\Desktop\КМД\20250220-КМ _ Здание\01 _ CAD\Материалы\чпу.xlsx'
    path = get_active_doc_path(iApplication)

    xlsx = easygui.fileopenbox(msg="Укажите файл 1.2 _ Ведомость элементов.xlsx", title="", default=f"{path}/*чпу.xlsx")  # Путь до файла отчёта
    df_elements = for_cnc_a3d(xlsx)
    input('\n\rРабота завершена.	\n')




