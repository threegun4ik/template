import os, easygui, re, sys

from __ExcelHandler import ExcelHandler
from __Kompas import *
import pandas as pd

import openpyxl
from openpyxl.styles import Font, Alignment

import xlwings as xw
import numpy as np
import _Config

'''2.1 _ Пластины.xlsx'''

def sheet2_1(xls, format_cnc, code_project=""):
    log_message(f"Подготавливаю отдельную ведомость по пластинам", "title")
    xlsx = os.path.dirname(xls) + '\\2.1 _ Пластины.xlsx'

    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
    df = excel_handler.read_excel(header_row=1)  # Читаем таблицу в dataframe

    if _Config.dxf_stripe: #Нарезать ли полосы
        df = df.loc[df['Эскиз сечения'].isin(['@016', '@137'])]
    else:
        df = df.loc[df['Эскиз сечения'].isin(['@016'])]

    if df.shape[0] < 1:  # Если кол-во строк меньше 1
        print("Пластин в отчёте не найдено")
        return

    # df = df.drop(['Сечение', 'Кол-во, шт.'], axis=1) #Удалим ненужные столбцы
    df.insert(2, "Гнутые и рифленые", '', True) #Добавим столбец для гнутых и рифленых
###

    df = df[['№ элемента', 'Наименование', 'Так', 'Наоборот', 'Марка стали', 'Толщина, мм',
             'Ширина, мм', 'Длина, мм', 'Рифление', 'Гнутость', 'Гнутые и рифленые', 'Масса элемента, кг',
             'Масса элементов, кг', 'Элемент марки', 'Тип объекта', 'Эскиз сечения', 'Примечание', 'Полное имя файла']] # Отсортируем таблицу

    invalid_chars = r'[<>:"/\\|?*]' # Список недопустимых символов для пути

    if df["Марка стали"].astype(str).str.contains(invalid_chars, regex=True).any() or df["Марка стали"].isna().any() or \
            df["Марка стали"].eq("").any():
        log_message(f"Ошибка: В столбце 'Марка стали' есть недопустимые символы или пустые значения!", "error")
        sys.exit(1)

    # Удаляем значения в столбце 'Полное имя файла', которые заканчиваются на '.a3d'
    # df['Полное имя файла'] = df['Полное имя файла'].where(~df['Полное имя файла'].str.endswith('.a3d'), '')
    df['Полное имя файла'] = df['Полное имя файла'].astype(str).where(~df['Полное имя файла'].astype(str).str.endswith('.a3d'), '')

    df.loc[df['Тип объекта'] == 'Тело', 'Наименование'] = df.apply(
        lambda row: (
                f"{row['Эскиз сечения']}{round(float(row['Толщина, мм']), 1):.1f}".replace('.', ',') +
                f"x{round(float(row['Ширина, мм'])):.0f}".replace('.', ',') +
                f"x{round(float(row['Длина, мм'])):.0f}".replace('.', ',')
        ) if pd.notna(row['Толщина, мм']) and pd.notna(row['Ширина, мм']) and pd.notna(row['Длина, мм']) and pd.notna(
            row['Эскиз сечения'])
        else '',
        axis=1)

    excel_handler.data = df # Обновляем данные в ExcelHandler перед вызовом
    df = excel_handler.replace_symbols('Наименование')# Применяем функцию к столбцу 'Сечение'
    df.to_excel(xlsx, sheet_name="Пластины", index=True) # Создадим файл отчета и запишем данные в него

    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Пластины']  # Выбираем лист по имени

    excel_handler.check_empty_rows_in_cell_column(ws, 2, 'E, J, K, L, R') # Проверка пустых ячеек и выделение цветом
    excel_handler.compare_columns(ws, 'B', 'C', 'F')  # Сравниваем значения в столбце A и проверяем столбцы B, C, D

    ###Название таблицы
    ws.insert_rows(1) #Вставим строку
    ws["A1"] = f'{code_project}. Ведомость пластин'

    # Оформление заголовков
    headers = {
        "A2": "№",
        "D2": "Кол-во, шт.",
        "G2": "Толщина, мм",
        "T2": "Наименование для почты",
        "U2": "Наименование для dxf"
    }
    for cell, value in headers.items():
        ws[cell] = value

    # Готовим доп наименование для имени файла для гнутых и рифленых пластин
    for row in range(3, ws.max_row + 1):
        if ws[f"J{row}"].value == 1 and ws[f"K{row}"].value == 1:
            form = "(рифленая_гнутая)"
        elif ws[f"J{row}"].value == 0 and ws[f"K{row}"].value == 1:
            form = "(гнутая)"
        elif ws[f"J{row}"].value == 1 and ws[f"K{row}"].value == 0:
            form = "(рифленая)"
        else:
            form = ""

        # Пропишем формулы на все строки
        ws[f"L{row}"] = form  # Впишем форму листа (гнутая, рифленая)
        ws[f"A{row}"] = '=row()-2'  # Впишем номера строк в первый столбец формулой
        ws[f"N{row}"] = f'=(D{row}*M{row})'
        # =СЦЕПИТЬ(A3;") ";B3;" _ ";(ЛЕВСИМВ(C3;ПОИСК(" ";C3)));G3;"x";H3;"x";I3;" ";F3;" - ";D3;" шт.")
        ws[f"T{row}"] = f'=CONCATENATE(A{row}, ") ", B{row}, " _ ", LEFT(C{row}, SEARCH(" ", C{row})), G{row}, "x", H{row}, "x", I{row}, L{row}, " ", F{row}, " - ", D{row}, " шт.")'
        ws[f"U{row}"] = f'=CONCATENATE(B{row}, "_", G{row},"мм",L{row},"_", F{row},"_", D{row}, "шт")'

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов
    excel_handler.fix_dimensions(ws, ['A', 'D', 'E'], width=10)  #Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['B', 'G','H', 'I', 'J', 'K', 'L', 'M', 'N'], width=12)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['O', 'R', 'S', 'T', 'U'], width=45)  #Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 20  # Измените высоту первой строки
    ws.row_dimensions[2].height = 30  # Измените высоту второй строки

    # Создаем маппинг выравниваний для столбцов
    alignment_map = {
        **{letter: Alignment(horizontal='center', vertical="center") for letter in 'ABDEFGHIJKLPQ'},
        **{letter: Alignment(horizontal='left', vertical="center") for letter in 'CORSU'},
        **{letter: Alignment(horizontal='right', vertical="center") for letter in 'MN'}
    }

    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=2):  # Начинаем с второй строки, чтобы пропустить заголовки
        for cell in row:
            column_letter = openpyxl.utils.get_column_letter(cell.column)
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    # Включите перенос текста по словам и выравнивание по центру для ячеек во второй строке
    for cell in ws[2]:  # Итерируем по ячейкам в первой строке
        cell.alignment = Alignment(wrapText=True, horizontal="center",  vertical="center")

    # Скроем ненужные столбцы
    for col in ['E', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'S', 'Q', 'U', 'V', 'W']:
        ws.column_dimensions[col].hidden = True

    ws.auto_filter.ref = 'A2:{}'.format(openpyxl.utils.get_column_letter(ws.max_column) + '2')#Автофильтр на вторую строку

    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column) #Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = openpyxl.styles.Alignment(horizontal='left', vertical='center')

    excel_handler.format_columns(ws, ['L', 'M'], n=1, start_row=3)  # Округление до n знаков после запятой

    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()

    # Открываем книгу через Excel
    with xw.App(visible=False) as app:  # Создаём приложение и делаем его невидимым
        wb = xw.Book(xlsx)  # Открываем файл
        app.calculate()  # Пересчёт всех формул
        wb.save()  # Сохраняем файл
        wb.close()  # Закрываем книгу

    log_message('Ведомость пластин металлоконстркции - создана', 'ok')
    return xlsx

if __name__ == "__main__":
    # xls = r'C:\Users\ik\Desktop\Primer\Холодильник\Материалы\1.2 _ Ведомость элементов.xlsx'
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xls = easygui.fileopenbox(msg="Укажите файл 1.1 _ Ведомость элементов.xlsx", title="", default=f"{path}/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
    sheet2_1(xls, _Config.format_cnc)
    input('\n\rРабота завершена.	\n')
