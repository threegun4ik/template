'''Скрипт проходит по всем вложенным сборкам и подсборкам и в случае если находить стандартные детали из 'name.startswith'
присваивает им в переменную "исключить из расчета" переменную varname, и делает ее внешней.
'''

from __Kompas import *

# Имя переменной для исключения из расчета
varname = 'usl'

# Вывод версии скрипта
print('Внешняя переменная v1.3 от 14.08.2024')

# Получаем доступ к объектам Kompas
KompasObject, iApplication, KompasVersion = get_kompas()

# Получаем текущий активный документ
iKompasDocument = iApplication.ActiveDocument
if not iKompasDocument or iKompasDocument.DocumentType not in (5, 7):
    input('Требуется сборка.')
    exit()

# Получаем все открытые документы и доступ к свойствам текущего документа
iDocuments = iApplication.Documents
iPropertySect = API7.IPropertyMng(iApplication).GetProperty(iKompasDocument, 20.0) #Получить свойство "Раздел спецификации"

# Множество для хранения обработанных файлов и список для закрытия
filenames = set()
needclose = list()

# Рекурсивная функция для обхода всех сборок
def recursion(assembly, level):
    oboz = assembly.Marking
    name = assembly.Name.replace('@/', ' ')
    # Выводим информацию о текущей сборке
    print('\n' + (level-1)*'   ' + (oboz + ' ').lstrip() + name, end='', flush=True)

    # Извлекаем имя файла и индекс воплощения
    FilePart = assembly.FileName
    cei = API7.IEmbodimentsManager(assembly).CurrentEmbodimentIndex  # Индекс текущего исполнения
    if (FilePart, cei) in filenames:
        print(' - Обработано ранее', end='', flush=True)
        # return
    else:
        filenames.add((FilePart, cei))

    if level > 1:
        # Обрабатываем вложенные сборки
        iDocSb = iDocuments.Item(FilePart)
        if not iDocSb:
            iDocSb = iDocuments.Open(FilePart, False, False)
            needclose.append(iDocSb)
        iTopSb = API7.IEmbodimentsManager(iDocSb).Embodiment(cei).Part
    else:
        # Обрабатываем главную сборку
        iDocSb = iKompasDocument
        iTopSb = assembly

    # Список для деталей, которым нужно присвоить переменную
    ivarparts = list()
    iParts7 = iTopSb.Parts
    for i in range(iParts7.Count):
        iPart7 = iParts7.Part(i)
        # Пропускаем элементы с геометрией макета
        if iPart7.IsLayoutGeometry:
            continue

        # Проверяем, является ли деталь стандартной
        if iPart7.Detail or iPart7.Standard or API7.IPropertyKeeper(iPart7).GetPropertyValue(iPropertySect, 0, True)[1] in ('Стандартные изделия', 'Прочие изделия'):
            name = iPart7.Name
            if name.startswith(('Болт', 'Гайка', 'Шпилька', 'Шайба', 'Заклепка', 'Винт')):
                print('\n' + level*'   ' + name, end='', flush=True)
                # Присваиваем переменной "исключить из расчета" значение
                API7.IFeature7(iPart7).Variable(False, False, 0).Expression = varname
        else:
            # Рекурсивно обрабатываем вложенные части
            ret = recursion(iPart7, level + 1)
            if ret == 2:
                ivarparts.append(iPart7)

    # Если были найдены детали для присвоения переменной, создаем переменную
    if ivarparts:
        iVariable7 = iTopSb.AddVariable(varname, 0, '')
        # Присваиваем переменную usl во вложенных сборках
        for iPart7 in ivarparts:
            iFeature7 = API7.IFeature7(iPart7)
            iVariable7 = iFeature7.Variable(False, False, varname) #Получить параметрическую переменную по имени, индексу
            if iVariable7:
                iVariable7.Expression = varname
        # Перестроить документ после изменений
        API7.IKompasDocument3D(iDocSb).RebuildDocument()
        return 1
    else:
        # Если переменная уже была присвоена, делаем ее внешней
        iVariable7 = API7.IFeature7(iTopSb).Variable(False, False, varname)
        if iVariable7:
            iVariable7.Value = 1
            iVariable7.External = True
            # Перестроить документ после изменений
            API7.IKompasDocument3D(iDocSb).RebuildDocument()
            return 2
        else:
            return 0

# Получаем доступ к 3D документу сборки
iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)

# Запускаем рекурсивную обработку для главной сборки
ret = recursion(iKompasDocument3D.TopPart, 1)

# Закрываем документы, если они были открыты
if needclose:
    print('\n\nСохранение моделей')
    for iDocSb in reversed(needclose):
        iDocSb.Close(1)
else:
    print()

# Если переменная не была присвоена, перестроим документ
if ret == 0:
    iKompasDocument3D.RebuildDocument()

# Завершаем выполнение
input('\nЗавершено.')
