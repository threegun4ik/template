# -*- coding: utf-8 -*-
from __Kompas import *
import os, re, sys
from win32com.client import VARIANT
import pythoncom
from loguru import logger

# ================ НАСТРОЙКА LOGURU ================
# Один sink в stdout, можно менять level на "DEBUG"/"INFO"/"WARNING"/"ERROR"
logger.remove()
logger.add(sys.stdout, level="INFO", format="{level: <8} | {message}")

# =================== НАСТРОЙКИ КЛАССИФИКАТОРА ===================

# Сколько первых символов исходного обозначения брать как базу
BASE_CHAR_COUNT = 3
# Добавлять ли точку после базовой части (если её там нет)
BASE_APPEND_DOT = True  # True -> "АБВ ГД" -> "АБВ ГД." перед блоками

# Формирование "короткого" обозначения:
# False -> АБВ.01.01.01.01.001
# True  -> группировка короткая: АБВ.11.11.001
USE_SHORT_ASM_FORMAT = False

# Формат блоков
ASM_BLOCK_PATTERN    = "00"   # блоки уровней сборок ("00", "000", ...)
DETAIL_BLOCK_PATTERN = "000"  # блок деталей/тел

# Фильтры при обходе дерева
SKIP_STANDARD        = True   # пропускать стандартные изделия
SKIP_LOCAL           = True   # пропускать локальные детали
SKIP_LAYOUT_GEOMETRY = True   # пропускать компоновочную геометрию

# Включать ли "по источнику" для вложенных компонентов (через IPropertyKeeper)
ENABLE_SOURCE_FOR_COMPONENTS = False  # False -> enable_source_for_all_components ничего не делает

# Максимальная глубина вывода дерева (None = без ограничения)
# 0  - только корневая сборка
# 1  - корень + его дети
# 2  - до внуков и т.д.
PRINT_MAX_DEPTH = None

# Вывод дерева
STRIP_DOLLAR_IN_PRINT = True  # обрезать текст между $...$ при печати
PRINT_SHOW_FILE       = True  # выводить в конце строки имя файла в скобках


# =================== ВСПОМОГАТЕЛЬНЫЕ УТИЛИТЫ ===================

def _get_part_props(iPart7):
    return {
        "file": getattr(iPart7, "FileName", None),
        "name": getattr(iPart7, "Name", None),
        "marking": getattr(iPart7, "Marking", None),
        "standard": bool(getattr(iPart7, "Standard", False)),
        "is_detail": bool(getattr(iPart7, "Detail", False)),
        "is_local": bool(getattr(iPart7, "IsLocal", False)),
        "is_layout_geometry": bool(getattr(iPart7, "IsLayoutGeometry", False)),
        "is_reveal_composition": bool(getattr(iPart7, "RevealComposition", False)),
    }


def enable_source_for_all_components(top_part, iPropertyOboz, iPropertyNaim):
    """
    Делает «по источнику» ТОЛЬКО для компонентов внутри top_part,
    НЕ трогая сам top_part (TopPart текущей сборки).
    Работает только если ENABLE_SOURCE_FOR_COMPONENTS = True.
    """
    if top_part is None:
        return
    if iPropertyOboz is None or iPropertyNaim is None:
        return
    if not ENABLE_SOURCE_FOR_COMPONENTS:
        return

    def _process_part(iPart7):
        # включаем «Источник» у обозначения и наименования у КОМПОНЕНТА
        try:
            iPropertyKeeper = API7.IPropertyKeeper(iPart7)
        except Exception:
            iPropertyKeeper = None

        if iPropertyKeeper is not None:
            try:
                iPropertyKeeper.SetPropertyValue(iPropertyOboz, VARIANT(pythoncom.VT_EMPTY, None), True)
            except Exception:
                pass
            try:
                iPropertyKeeper.SetPropertyValue(iPropertyNaim, VARIANT(pythoncom.VT_EMPTY, None), True)
            except Exception:
                pass

        # рекурсивно обходим вложенные компоненты
        iParts7 = getattr(iPart7, "Parts", None)
        if iParts7 is not None:
            try:
                count = iParts7.Count
            except Exception:
                count = 0
            for i in range(count):
                try:
                    child_iPart7 = API7.IPart7(iParts7.Item(i))
                except Exception:
                    continue
                _process_part(child_iPart7)

    # Важно: top_part НЕ обрабатываем как объект свойств.
    iParts7 = getattr(top_part, "Parts", None)
    if iParts7 is None:
        return

    try:
        count = iParts7.Count
    except Exception:
        count = 0

    for i in range(count):
        try:
            child_iPart7 = API7.IPart7(iParts7.Item(i))
        except Exception:
            continue
        _process_part(child_iPart7)

def _same_path(a: str, b: str) -> bool:
    if not a or not b:
        return False
    return os.path.normcase(os.path.normpath(a)) == os.path.normcase(os.path.normpath(b))


def get_base_designation(marking: str, char_count: int) -> str:
    """
    Возвращает базовую часть обозначения по количеству символов (включая пробелы).
    Пример:
      marking    = "АБВ ГД000.010.000"
      char_count = 6
      -> "АБВ ГД"
    """
    if not marking or char_count <= 0:
        return ""
    return marking[:char_count]


# =================== ПРИСВОЕНИЕ В ДОКУМЕНТЫ ===================

def apply_class_codes_by_documents(iApplication, nodes, depth_by_file, root_file):
    """
    Присваивает class_code в исходные файлы .a3d/.m3d:
      • идём от максимальной глубины к меньшей (листья → корень);
      • для активной сборки (root_file) используем ActiveDocument и НЕ закрываем её;
      • остальные документы открываем, обновляем, сохраняем и закрываем;
      • включаем «Источник» у обозначения/наименования для компонентов через IPropertyKeeper;
      • ОБОЗНАЧЕНИЕ пишем и в TopPart.Marking, и в свойство документа «Обозначение»,
        НО только если свойство "Комментарий" (ID = 13) у TopPart считается пустым.
      • если в старом Marking есть суффикс исполнения вида -01, -02, -10 (-{2}),
        он добавляется в конец нового обозначения: new_code + "-NN".
      • если замену обозначения пропускаем (по комментарию), в дереве print_tree
        выводим фактическое обозначение (Marking/исходное node["marking"]) вместо
        сгенерированного class_code.
    """
    iDocuments = iApplication.Documents

    # менеджер свойств приложения
    try:
        iPropertyMng = API7.IPropertyMng(iApplication)
    except Exception:
        iPropertyMng = None

    def _key_path(p: str) -> str:
        return os.path.normcase(os.path.normpath(p))

    def _is_comment_meaningful(text: str | None) -> bool:
        """
        Комментарий считаем "значимым", если он не пустой и не равен "0".
        Всё остальное (пусто, пробелы, "0") -> можно менять обозначение.
        """
        if text is None:
            return False
        s = str(text).strip()
        if s == "":
            return False
        if s == "0":
            return False
        return True

    def _extract_execution_suffix(mark: str | None) -> tuple[str, str]:
        """
        Делит обозначение на базу и суффикс исполнения.
        Возвращает (base, suffix), где suffix = '-NN' или ''.

        Примеры:
            'ABC.10.00-01' -> ('ABC.10.00', '-01')
            'АБВ.01.02-10' -> ('АБВ.01.02', '-10')
            'XYZ.01.02'    -> ('XYZ.01.02', '')
        """
        if not mark:
            return "", ""
        s = str(mark).strip()
        m = re.search(r"-(\d{2})$", s)
        if not m:
            return s, ""
        idx = m.start()
        return s[:idx], s[idx:]

    root_norm = _key_path(root_file) if root_file else None
    processed: set[str] = set()

    def _depth_for_node(node) -> int:
        f = node.get("file")
        if not f:
            return 0
        return depth_by_file.get(_key_path(f), 0)

    sorted_nodes = sorted(nodes, key=_depth_for_node, reverse=True)

    for node in sorted_nodes:
        code = node.get("class_code")
        file_path = node.get("file")
        if not code or not file_path:
            continue

        norm_path = _key_path(file_path)
        if norm_path in processed:
            continue
        processed.add(norm_path)

        use_active = (root_norm is not None and norm_path == root_norm)

        if use_active:
            iKompasDocument = iApplication.ActiveDocument
            if iKompasDocument is None:
                logger.error("Активный документ не найден для '{}'", file_path)
                continue
        else:
            try:
                iKompasDocument = iDocuments.Open(file_path, False, False)
            except Exception as ex:
                logger.error("Не удалось открыть '{}': {}", file_path, ex)
                continue

        try:
            try:
                iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
            except Exception as ex:
                logger.error("Не удалось получить IKompasDocument3D для '{}': {}", file_path, ex)
                continue

            top_part = getattr(iKompasDocument3D, "TopPart", None)
            if top_part is None:
                logger.warning("У документа '{}' нет TopPart.", file_path)
                continue

            # --- свойства Обозначение / Наименование / Комментарий (по документу) ---
            iPropertyOboz = None
            iPropertyNaim = None
            iPropertyComment = None

            if iPropertyMng is not None:
                try:
                    iPropertyOboz    = iPropertyMng.GetProperty(iKompasDocument, 4.0)    # Обозначение
                    iPropertyNaim    = iPropertyMng.GetProperty(iKompasDocument, 5.0)    # Наименование
                    iPropertyComment = iPropertyMng.GetProperty(iKompasDocument, 13.0)   # Комментарий
                except Exception as ex:
                    logger.warning("Не удалось получить свойства для '{}': {}", file_path, ex)
                    iPropertyOboz = None
                    iPropertyNaim = None
                    iPropertyComment = None

            # --- PropertyKeeper документа (для записи обозначения в свойства документа) ---
            pk_doc = None
            try:
                pk_doc = API7.IPropertyKeeper(iKompasDocument)
            except Exception as ex:
                logger.warning("Не удалось получить IPropertyKeeper(iKompasDocument) для '{}': {}", file_path, ex)
                pk_doc = None

            # --- PropertyKeeper TopPart (читаем Комментарий и Marking оттуда) ---
            pk_top = None
            try:
                pk_top = API7.IPropertyKeeper(top_part)
            except Exception as ex:
                logger.warning("Не удалось получить IPropertyKeeper(TopPart) для '{}': {}", file_path, ex)
                pk_top = None

            # --- читаем 'Комментарий' и решаем, можно ли трогать обозначение ---
            skip_assign = False
            comment_text = ""

            if pk_top is not None and iPropertyComment is not None:
                try:
                    res = pk_top.GetPropertyValue(iPropertyComment, 0, True)
                    if isinstance(res, (list, tuple)) and len(res) >= 2:
                        val = res[1]
                    else:
                        val = res

                    comment_text = "" if val is None else str(val).strip()

                    if _is_comment_meaningful(comment_text):
                        skip_assign = True
                        logger.info(
                            "[SKIP] '{}': комментарий не пустой ('{}') → обозначение НЕ изменяем",
                            file_path, comment_text
                        )
                except Exception as ex:
                    logger.warning("Ошибка чтения комментария для '{}': {}", file_path, ex)

            # текущее обозначение TopPart (для суффикса исполнения)
            try:
                existing_marking = (getattr(top_part, "Marking", "") or "").strip()
            except Exception:
                existing_marking = (node.get("marking") or "").strip()

            _, exec_suffix = _extract_execution_suffix(existing_marking)

            # --- включаем «Источник» ТОЛЬКО у компонентов (TopPart не трогаем) ---
            try:
                enable_source_for_all_components(
                    top_part,
                    iPropertyOboz,
                    iPropertyNaim,
                )
            except Exception as ex:
                logger.warning("Не удалось обновить источник свойств в '{}': {}", file_path, ex)

            # --- присваиваем обозначение, если можно ---
            if not skip_assign:
                # итоговое обозначение с учётом исполнения
                new_marking = code + exec_suffix

                # обновляем дерево для print_tree
                node["class_code"] = new_marking
                node["marking"] = new_marking

                # TopPart.Marking
                try:
                    top_part.Marking = new_marking
                    top_part.Update()
                except Exception as ex:
                    logger.error("Не удалось присвоить Marking для '{}': {}", file_path, ex)

                # Свойство документа «Обозначение»
                try:
                    if iPropertyMng is not None and iPropertyOboz is not None and pk_doc is not None:
                        pk_doc.SetPropertyValue(
                            iPropertyOboz,
                            VARIANT(pythoncom.VT_BSTR, new_marking),
                            True if use_active else False
                        )
                except Exception as ex:
                    logger.error("Не удалось записать обозначение в свойства документа '{}': {}", file_path, ex)
            else:
                # skip_assign по комментарию → в дереве показываем фактическое обозначение
                if existing_marking:
                    node["class_code"] = existing_marking
                    node["marking"] = existing_marking
                else:
                    # если Marking пустой, но в node["marking"] что-то есть — синхронизируемся с ним
                    fallback_mark = (node.get("marking") or "").strip()
                    if fallback_mark:
                        node["class_code"] = fallback_mark

            # Обновление документа (если есть метод)
            try:
                iKompasDocument3D.RebuildDocument()
            except Exception as ex:
                logger.warning("Ошибка UpdateDocument для '{}': {}", file_path, ex)

            # Сохранение
            try:
                iKompasDocument.Save()
            except Exception as ex:
                logger.error("Не удалось сохранить '{}': {}", file_path, ex)

        finally:
            if not use_active:
                try:
                    iKompasDocument.Close(1)
                except Exception:
                    pass


def compute_depth_by_file(root_node, nodes_by_file) -> dict[str, int]:
    # """
    # Возвращает: нормализованный путь файла -> глубина (0 для корня).
    # Глубина увеличивается на 1 при спуске к каждому ребёнку.
    # """
    depth_by_file: dict[str, int] = {}

    def _key(file_name: str) -> str:
        return os.path.normcase(os.path.normpath(file_name))

    def _walk(node, depth: int):
        file_name = node.get("file")
        if not file_name:
            return
        k = _key(file_name)
        prev = depth_by_file.get(k)
        if prev is None or depth > prev:
            depth_by_file[k] = depth

        for cf in node.get("children", []):
            ch = get_node(nodes_by_file, cf)
            if ch is not None:
                _walk(ch, depth + 1)

    _walk(root_node, 0)
    return depth_by_file


# =================== СБОР УЗЛОВ ===================

def collect_parts_and_assemblies(
    iPart7,
    result=None,
    index_by_file=None,
    *,
    skip_standard=True,
    skip_local=True,
    _parent_file=None,
):
    if result is None:
        result = []
    if index_by_file is None:
        index_by_file = {}

    props = _get_part_props(iPart7)
    file_name = props["file"]
    if not file_name:
        return result, index_by_file

    if skip_standard and props["standard"]:
        return result, index_by_file
    if skip_local and props["is_local"]:
        return result, index_by_file
    if SKIP_LAYOUT_GEOMETRY and props["is_layout_geometry"]:
        return result, index_by_file

    key = os.path.normcase(os.path.normpath(file_name))
    node = index_by_file.get(key)

    if node is None:
        node = {
            "file": file_name,
            "type": "part" if props["is_detail"] else "assembly",
            "name": props["name"],
            "marking": props["marking"],
            "standard": props["standard"],
            "is_local": props["is_local"],
            "children": [],
            "parents": [] if _parent_file is None else [_parent_file],
            "part_refs": [iPart7],
        }
        result.append(node)
        index_by_file[key] = node
    else:
        if _parent_file and all(not _same_path(_parent_file, p) for p in node["parents"]):
            node["parents"].append(_parent_file)
        node.setdefault("part_refs", []).append(iPart7)

    if not props["is_detail"]:
        parts = getattr(iPart7, "Parts", None)
        if parts is not None:
            try:
                count = parts.Count
            except Exception:
                count = 0
            for i in range(count):
                child = API7.IPart7(parts.Item(i))
                child_props = _get_part_props(child)

                if SKIP_LAYOUT_GEOMETRY and child_props["is_layout_geometry"]:
                    continue
                if skip_standard and child_props["standard"]:
                    continue
                if skip_local and child_props["is_local"]:
                    continue

                child_file = child_props["file"]
                if child_file and all(not _same_path(child_file, c) for c in node["children"]):
                    node["children"].append(child_file)

                result, index_by_file = collect_parts_and_assemblies(
                    child,
                    result,
                    index_by_file,
                    skip_standard=skip_standard,
                    skip_local=skip_local,
                    _parent_file=file_name,
                )

    return result, index_by_file


# =================== ПОСТРОЕНИЕ ДЕРЕВА ===================

def build_index_by_file(nodes):
    return {os.path.normcase(os.path.normpath(n["file"])): n for n in nodes}


def get_node(nodes_by_file, file_name):
    key = os.path.normcase(os.path.normpath(file_name))
    return nodes_by_file.get(key)


# =================== ГЛУБИНА И КЛАССИФИКАЦИОННЫЕ КОДЫ ===================

def _calc_max_asm_depth(root_node, nodes_by_file) -> int:
    max_depth = 1

    def _dfs(node, depth: int):
        nonlocal max_depth
        if node.get("type") == "assembly" and depth > max_depth:
            max_depth = depth

        child_files = node.get("children", [])
        for cf in child_files:
            ch = get_node(nodes_by_file, cf)
            if ch is None:
                continue
            if ch.get("type") == "assembly":
                _dfs(ch, depth + 1)
            else:
                _dfs(ch, depth)

    _dfs(root_node, 1)
    return max_depth


def assign_class_codes(
    root_node,
    nodes_by_file,
    base_designation: str,
    *,
    asm_block_count: int | None = None,
    asm_block_pattern: str = ASM_BLOCK_PATTERN,
    detail_block_pattern: str = DETAIL_BLOCK_PATTERN,
):
    asm_block_width = len(asm_block_pattern)
    detail_block_width = len(detail_block_pattern)

    if asm_block_count is None:
        max_depth = _calc_max_asm_depth(root_node, nodes_by_file)
        # минимум 1 блок, даже если глубина всего 1
        asm_block_count = max(1, max_depth - 1)

    total_blocks = asm_block_count + 1  # k сборочных + 1 детальный

    def _key(node) -> str:
        return os.path.normcase(os.path.normpath(node["file"]))

    def _format_code(codes: list[int]) -> str:
        asm_codes = codes[:-1]
        det_code = codes[-1]

        # ---------- Сборочная часть ----------
        if not USE_SHORT_ASM_FORMAT:
            asm_str = ".".join(f"{c:0{asm_block_width}d}" for c in asm_codes)
        else:
            # группируем уровни по два в один блок
            short_blocks: list[str] = []
            for i in range(0, len(asm_codes), 2):
                d1 = asm_codes[i]
                d2 = asm_codes[i + 1] if i + 1 < len(asm_codes) else 0
                pair = d1 * 10 + d2
                short_blocks.append(f"{pair:0{asm_block_width}d}")
            asm_str = ".".join(short_blocks)

        # ---------- Детальный блок ----------
        det_str = f"{det_code:0{detail_block_width}d}"

        base_local = base_designation or ""

        if BASE_APPEND_DOT and base_local and not base_local.endswith('.'):
            base_local = base_local + '.'

        return f"{base_local}{asm_str}.{det_str}"

    assigned_codes: dict[str, list[int]] = {}
    visited: set[str] = set()

    def _walk(node, depth: int):
        key = _key(node)
        if key in visited:
            return
        visited.add(key)

        codes = assigned_codes[key]
        node["class_code"] = _format_code(codes)

        child_files = node.get("children", [])
        child_nodes = []
        for cf in child_files:
            ch = get_node(nodes_by_file, cf)
            if ch is not None:
                child_nodes.append(ch)

        def sort_key(ch):
            t = ch.get("type")
            kind = 0 if t == "assembly" else 1  # сборка раньше, деталь позже
            name = (ch.get("name") or "").lower()
            return (kind, name)

        child_nodes.sort(key=sort_key)

        asm_idx = 0
        det_idx = 0

        for ch in child_nodes:
            ckey = _key(ch)
            if ckey not in assigned_codes:
                child_codes = codes.copy()
                if ch.get("type") == "assembly":
                    level_idx = min(depth, asm_block_count - 1)
                    asm_idx += 1
                    child_codes[level_idx] = asm_idx
                    for j in range(level_idx + 1, total_blocks):
                        child_codes[j] = 0
                else:
                    det_idx += 1
                    child_codes[-1] = det_idx

                assigned_codes[ckey] = child_codes

            _walk(ch, depth + (1 if ch.get("type") == "assembly" else 0))

    root_key = _key(root_node)
    assigned_codes[root_key] = [0] * total_blocks
    _walk(root_node, depth=0)


def apply_class_codes_to_model(nodes):
    """
    Берёт node["class_code"] и пишет его в Marking всех IPart7, которые мы
    запомнили в node["part_refs"] на шаге сбора структуры.
    """
    for node in nodes:
        code = node.get("class_code")
        if not code:
            continue
        for part in node.get("part_refs", []):
            try:
                part.Marking = code
                part.Update()
            except Exception:
                pass


# =================== ПЕЧАТЬ ДЕРЕВА ===================

def print_tree(
    root_node,
    nodes_by_file,
    *,
    strip_dollar: bool = STRIP_DOLLAR_IN_PRINT,
    max_depth: int | None = None,
    show_file: bool = PRINT_SHOW_FILE,
):
    """
    Печатает дерево узлов.

    max_depth:
        None  -> без ограничения
        0     -> только корень
        1     -> корень + дети
        2     -> до внуков и т.д.

    show_file:
        True  -> в конце строки добавляется "(имя_файла)"
        False -> печатается только код + наименование
    """
    lines: list[tuple[str, str]] = []

    def _clean_name(name: str) -> str:
        if not name:
            return ""
        if not strip_dollar:
            return name
        cleaned = re.sub(r"\$.*?\$", "", name)
        return " ".join(cleaned.split())

    def _walk(node, prefix: str, is_last: bool, is_root: bool, depth: int):
        code = node.get("class_code", "????")
        raw_name = node.get("name") or ""
        name = _clean_name(raw_name)
        file_short = os.path.basename(node.get("file") or "")

        connector = "" if is_root else ("└─ " if is_last else "├─ ")
        left = f"{prefix}{connector}{code} - {name}"
        lines.append((left, file_short))

        if max_depth is not None and depth >= max_depth:
            return

        if is_root:
            child_prefix = ""
        else:
            child_prefix = prefix + ("   " if is_last else "│  ")

        child_files = node.get("children", [])
        child_nodes = []
        for cf in child_files:
            ch = get_node(nodes_by_file, cf)
            if ch is not None:
                child_nodes.append(ch)

        def sort_key(ch):
            t = ch.get("type")
            kind = 0 if t == "assembly" else 1
            name = _clean_name(ch.get("name") or "").lower()
            return (kind, name)

        child_nodes.sort(key=sort_key)

        for idx, ch in enumerate(child_nodes):
            last_child = (idx == len(child_nodes) - 1)
            _walk(ch, child_prefix, last_child, False, depth + 1)

    _walk(root_node, prefix="", is_last=True, is_root=True, depth=0)

    if not lines:
        return

    max_left_len = max(len(left) for left, _ in lines)
    for left, file_short in lines:
        pad = " " * (max_left_len - len(left) + 1)
        if show_file and file_short:
            print(f"{left}{pad}({file_short})")
        else:
            print(left)


# =================== ОСНОВНАЯ ФУНКЦИЯ ===================

def run_classifier(base_char_count: int = BASE_CHAR_COUNT):
    script = os.path.basename(__file__)
    if not check_access(script):
        input(f"❌ Похоже кто-то не задонатил за {script.split('.')[0]}, пропускаем...")
        sys.exit()
        
    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    if iKompasDocument is None:
        logger.error("Нет активного документа.")
        return

    try:
        iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
        iPart7 = iKompasDocument3D.TopPart
    except Exception as ex:
        logger.error("Не удалось получить IPart7 для активного документа: {}", ex)
        return

    nodes, nodes_by_file = collect_parts_and_assemblies(
        iPart7,
        result=None,
        index_by_file=None,
        skip_standard=SKIP_STANDARD,
        skip_local=SKIP_LOCAL,
    )

    if not nodes:
        logger.error("Не удалось собрать дерево компонентов.")
        return

    root_file = getattr(iPart7, "FileName", None)
    if not root_file:
        logger.error("У активной сборки нет имени файла (FileName).")
        return

    root_node = get_node(nodes_by_file, root_file)
    if root_node is None:
        logger.error("Корневая сборка не найдена в собранном списке узлов.")
        return

    root_marking = root_node.get("marking") or ""
    base_designation = get_base_designation(root_marking, base_char_count)

    logger.info("Базовое обозначение (первые {} символов): {}", base_char_count, base_designation)

    assign_class_codes(
        root_node,
        nodes_by_file,
        base_designation,
        asm_block_count=None,
        asm_block_pattern=ASM_BLOCK_PATTERN,
        detail_block_pattern=DETAIL_BLOCK_PATTERN,
    )

    depth_by_file = compute_depth_by_file(root_node, nodes_by_file)

    apply_class_codes_by_documents(
        iApplication,
        nodes,
        depth_by_file,
        root_file,
    )

    print("\nДерево классификатора:")
    print_tree(
        root_node,
        nodes_by_file,
        max_depth=PRINT_MAX_DEPTH,
        show_file=PRINT_SHOW_FILE,
    )


if __name__ == "__main__":
    run_classifier()
    input('Готово!')
