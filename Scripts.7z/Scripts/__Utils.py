import os, zipfile

import time

def pluralize(value, singular, plural_2_4, plural_5_0):
    """Возвращает слово в правильной форме в зависимости от числа."""
    if 11 <= value % 100 <= 19:
        return plural_5_0
    elif value % 10 == 1:
        return singular
    elif 2 <= value % 10 <= 4:
        return plural_2_4
    else:
        return plural_5_0

class Timer:
    def __init__(self):
        self.start_time = None

    def start(self):
        """Запускает таймер."""
        self.start_time = time.time()

    def stop(self):
        """Останавливает таймер и возвращает затраченное время в удобочитаемом формате."""
        if self.start_time is None:
            raise ValueError("Таймер не был запущен. Используйте метод start().")

        elapsed_time = time.time() - self.start_time
        self.start_time = None

        seconds = int(elapsed_time % 60)
        minutes = int((elapsed_time // 60) % 60)
        hours = int(elapsed_time // 3600)

        hours_word = pluralize(hours, "час", "часа", "часов")
        minutes_word = pluralize(minutes, "минута", "минуты", "минут")
        seconds_word = pluralize(seconds, "секунда", "секунды", "секунд")

        if elapsed_time >= 3600:
            return f"Время выполнения скрипта: {hours} {hours_word} {minutes} {minutes_word} {seconds} {seconds_word}"
        elif elapsed_time >= 60:
            return f"Время выполнения скрипта: {minutes} {minutes_word} {seconds} {seconds_word}"
        else:
            return f"Время выполнения скрипта: {seconds} {seconds_word}"


def zip_folder(path, output_filename):
    """
    Архивирует содержимое папки в ZIP-файл.
    Args:
        path: Путь к папке, которую нужно архивировать.
        output_filename: Имя выходного ZIP-файла (включая расширение ".zip").
    """
    # Создаем ZIP-архив
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(path):
            for file in files:
                file_path = os.path.join(root, file)
                # Добавляем файл в архив с корректным путем
                arcname = os.path.relpath(file_path, path)
                zipf.write(file_path, arcname)

if __name__ == "__main__":
    print('Это служебный скрипт, сам по себе он ничего не делает')

    timer = Timer()
    timer.start()
    time.sleep(5)  # Симуляция выполнения скрипта
    print(timer.stop())
