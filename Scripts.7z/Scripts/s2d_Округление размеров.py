from win32com.client import gencache
import pythoncom

con2 = gencache.EnsureModule('{75C9F5D0-B5B8-4526-8681-9903C567D2ED}', 0, 1, 0).constants
api5 = gencache.EnsureModule('{0422828C-F174-495E-AC5D-D31014DBBE87}', 0, 1, 0)
api7 = gencache.EnsureModule('{69AC2981-37C0-4379-84FD-5DD2F3C0A520}', 0, 1, 0)

KompasObject = api5.KompasObject(pythoncom.connect('Kompas.Application.5'))
iApplication = api7.IApplication(pythoncom.connect('Kompas.Application.7'))

ksIterator = KompasObject.GetIterator()

def mathround(x, n = 0):														# Нормальное арифметическое округление или кратно float
	if n:
		if isinstance(n, int):													# Если указано int количество знаков после запятой
			p = 10.0 ** n
			return int(x * p + 0.5 if x > 0 else x * p - 0.5) / p
		else:																	# Иначе указан float, кратно которому нужно округлить
			return mathround(x / n) * n
	else:
		return int(x + 0.5 if x > 0 else x - 0.5)

def doDimensionText(iDimension, k, n):
	iDimensionText = api7.IDimensionText(iDimension)
	if n:
		iDimensionText.NominalValue = mathround(iDimensionText.NominalValue * k, n)
	elif k == 1:
		iDimensionText.AutoNominalValue = True
	else:
		iDimensionText.NominalValue = iDimensionText.NominalValue * k
	iDimension.Update()

def doDimensions(iView, k, n):
	refview = iView.Reference
	for objtype in (con2.ksDrLDimension, con2.ksDrOrdinateDimension):
		ksIterator.ksCreateIterator(objtype, refview)
		refobj = ksIterator.ksMoveIterator('F')
		while refobj:
			iDimension = KompasObject.TransferReference(refobj, 0)
			doDimensionText(iDimension, k, n)
			refobj = ksIterator.ksMoveIterator('N')
		ksIterator.ksDeleteIterator()

	# iSymbols2DContainer = api7.ISymbols2DContainer(iView)

	# iLineDimensions = iSymbols2DContainer.LineDimensions
	# for i in range(iLineDimensions.Count):
		# doDimensionText(iLineDimensions.LineDimension(i), k, n)

	# iHeightDimensions = iSymbols2DContainer.HeightDimensions
	# for i in range(iHeightDimensions.Count):
		# doDimensionText(iHeightDimensions.HeightDimension(i), k, n)

iKompasDocument = iApplication.ActiveDocument
if iKompasDocument and iKompasDocument.DocumentType in (con2.ksDocumentDrawing, con2.ksDocumentFragment):

	answer = input(
'Округление выделенных размеров и размеров в выделенных видах, в текущем виде или во всех видах.\n\n\
Введите кратность округления размеров. Пустой ввод - включить авторазмер.\n\
* в ответе умножает значения размеров на коэффициент изометрии sqrt(3/2).\n')

	k = 1.5 ** 0.5 if '*' in answer else 1
	z = answer.replace(',', '.').replace('*', '')
	n = float(z) if z else 0

	so = api7.IKompasDocument2D1(iKompasDocument).SelectionManager.SelectedObjects
	if so:
		sotuple = so if isinstance(so, tuple) else (so,)

		for iView in filter(lambda v: api7.IKompasAPIObject(v).Type in (10031, 10032), sotuple):
			doDimensions(iView, k, n)

		# for iDim  in filter(lambda v: api7.IKompasAPIObject(v).Type in (13041, 13045), sotuple):
		for iDim in filter(lambda v: api7.IKompasAPIObject(v).Type in (13041), sotuple): #, 13045 - высотные отметки
			doDimensionText(iDim, k, n)
	else:
		iKompasDocument2D = api7.IKompasDocument2D(iKompasDocument)
		iViews = iKompasDocument2D.ViewsAndLayersManager.Views

		answer = input('Обработать только текущий вид - пустой ввод.\nОбработать все виды документа - любой текст.\n')
		if answer:
			for index in range(iViews.Count):
				doDimensions(iViews.View(index), k, n)
		else:
			doDimensions(iViews.ActiveView, k, n)

	iApplication.MessageBoxEx('Готово', 'Округление', 64)
else:
	input('Должен быть открыт чертеж или фрагмент.\n')