import sys
import os

from __Kompas import *
from _Config import *
from __ExcelHandler import ExcelHandler
from pathlib import Path
import pandas as pd
from __Debug import *
from win32com.client import VARIANT
import easygui, re
import pythoncom
import numpy as np
import math

from collections import defaultdict
from __Utils import Timer
from __K_autorupture import *
from __K_autodimensions import add_linear_dimensions
from __K_autoscale import auto_scale

# --- Tuning / defaults ---
DEFAULT_SCALE = 1 / 10
AUTORUPTURE_GAP_X = 15
AUTORUPTURE_GAP_Y = 20
TITLE_TEXT_HEIGHT = 3.5
VIEW_SHIFT_K = 3  # сдвиг = VIEW_SHIFT_K / scale
FLAT_SURFACE = 2
CYL_OR_CONE = {3, 4}


def extract_number(value):
    """
    Возвращает сортировочный ключ для разнородных строк с числами:
      - (первое_число, второе_число_или_+inf)
    Примеры: "1011-02" -> (1011.0, 2.0), "Г.001.115" -> (1.0, 115.0)
    Если чисел нет — уходит в конец.
    Поддерживает запятую как десятичный разделитель.
    """
    s = str(value).replace(',', '.')
    nums = re.findall(r'\d+(?:\.\d+)?', s)
    if not nums:
        return (float('inf'), float('inf'))
    first = float(nums[0])
    second = float(nums[1]) if len(nums) > 1 else float('inf')
    return (first, second)

def _coll_count(coll):
    try:
        return int(getattr(coll, "Count"))
    except Exception:
        try:
            return len(coll)
        except Exception:
            return 0

def _coll_item(coll, idx):
    try:
        return coll.Item(idx)
    except Exception:
        try:
            return coll[idx]
        except Exception:
            return None

def _norm_path(p):
    try:
        return os.path.normcase(os.path.normpath(p))
    except Exception:
        return str(p or "")

def search_body(dict_a3d, dict_element_info):
    """Ищет нужное тело (включая исполнения) и готовит данные для вставки видов."""
    file_a3d, dict_list = next(iter(dict_a3d.items()))
    log_message(f'Работаем с файлом  {file_a3d}', 'how')

    # строим mapping: маркировка -> список check_dict
    by_marking = {}
    for cd in dict_list:
        m = next(iter(cd.values()))
        by_marking.setdefault(m, []).append(cd)

    result_dict = {}
    processed_markings = set()

    if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
        iPart7 = iKompasDocument3D.TopPart

        iEmbodimentsManager = API7.IEmbodimentsManager(iPart7)
        iEmbodimentsManager.SetCurrentEmbodiment(0)
        API7.IModelObject(iPart7).Update()

        for i in range(iEmbodimentsManager.EmbodimentCount):
            iEmbodimentsManager.SetCurrentEmbodiment(i)
            emb = iEmbodimentsManager.Embodiment(i)

            iFeature7 = API7.IFeature7(emb.Part)
            result_bodies = iFeature7.ResultBodies

            for marking, checks in by_marking.items():
                if marking in processed_markings:
                    continue
                for check_dict in checks:
                    iBody7 = check_bodies(iKompasDocument_a3d, result_bodies, check_dict)
                    if iBody7:
                        log_message(f'Элемент с номером {marking} найден в исполнении {emb.GetMarking(-1, 0)}')
                        insert_view_orientation(marking, iKompasDocument3D.TopPart, iBody7)
                        arr = (iBody7,)
                        safe_array = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_DISPATCH, arr)
                        text = dict_element_info.get(marking, "")
                        result_dict[marking] = [safe_array, text, i]
                        processed_markings.add(marking)
                        break  # к следующей маркировке

        iEmbodimentsManager.SetCurrentEmbodiment(0)
        iKompasDocument_a3d.Save()

    if KompasVersion == 21 or iKompasDocument_a3d.DocumentType == 4.0:
        for marking in by_marking.keys():
            safe_array = ''
            text = dict_element_info.get(marking, "")
            result_dict[marking] = [safe_array, text, 0]
            processed_markings.add(marking)

    return result_dict

def check_bodies(iKompasDocument, result_bodies, check_dict):
    """Проверяет свойства тел и возвращает подходящее тело (кэш свойств, устойчивое сравнение)."""
    # подготовим проверки и кэш свойств
    checks = [(float(k), str(v).strip()) for k, v in check_dict.items()]
    iPropertyMng = API7.IPropertyMng(iApplication)
    prop_cache = {k: iPropertyMng.GetProperty(iKompasDocument, k) for k, _ in checks}

    def matches_body_properties(iBody7):
        iPropertyKeeper = API7.IPropertyKeeper(iBody7)
        for key, expected in checks:
            try:
                _, val = iPropertyKeeper.GetPropertyValue(prop_cache[key], 0, 1, 1)
            except Exception:
                return False
            if str(val).strip() != expected:
                return False
        return True

    iterable = result_bodies if isinstance(result_bodies, tuple) else [result_bodies]
    for body in iterable:
        if matches_body_properties(body):
            return body
    return None

def insert_view_orientation(marking, iPart7, iBody7):
    elem = []  # Список для удаления временных объектов
    iFeature7 = API7.IFeature7(iBody7)
    iFaces = iFeature7.ModelObjects(con3.o3d_face)
    iAxes3D = API7.IAuxiliaryGeomContainer(iPart7).Axes3D

    largest_area_sum, largest_face_sum = -1, None  # для цилиндров/конусов
    largest_plane_area, largest_plane_face = -1, None  # для плоских граней
    longest_length, longest_edge = -1, None  # для самой длинной прямой ребра
    surface3D_type2 = False  # флаг — найдена ли хотя бы одна плоская грань

    # --- Анализ всех граней тела ---
    for iFace in iFaces:
        try:
            iMathSurface3D = iFace.MathSurface
            st = iMathSurface3D.Surface3DType
        except Exception:
            continue

        if st in CYL_OR_CONE:  # Конус или цилиндр
            # Создаём ось для конус/цилиндр (для OY)
            try:
                iAxis3D = iAxes3D.Add(con3.o3d_axisConeFace)
                API7.IAxis3DByConeface(iAxis3D).Face = iFace
                iAxis3D.Update()
                elem.append(iAxis3D)
            except Exception:
                pass

            try:
                area_cone = iFace.GetArea(3)
                connected_faces = iFace.ConnectedFaces
                flat_faces = [f for f in connected_faces if f.MathSurface.Surface3DType == FLAT_SURFACE]
            except Exception:
                flat_faces = []

            if not flat_faces:
                flat_faces = [iFace]  # fallback

            try:
                total_area_flats = sum(f.GetArea(3) for f in flat_faces)
            except Exception:
                total_area_flats = 0.0
            total_area = (area_cone if 'area_cone' in locals() else 0.0) + total_area_flats

            if total_area > largest_area_sum:
                largest_area_sum = total_area
                try:
                    max_face = max(flat_faces, key=lambda f: f.GetArea(3))
                    if max_face.GetArea(3) > area_cone:
                        largest_face_sum = max_face
                    else:
                        largest_face_sum = iFace
                except Exception:
                    largest_face_sum = iFace

        elif st == FLAT_SURFACE:  # плоская грань
            surface3D_type2 = True
            try:
                area = iFace.GetArea(3)
            except Exception:
                area = -1
            if area > largest_plane_area:
                largest_plane_area = area
                largest_plane_face = iFace

    # --- Выбор итоговой "лучшей" плоскости ---
    largest_face = None
    if largest_plane_area > largest_area_sum:
        largest_face = largest_plane_face
    else:
        largest_face = largest_face_sum

    for iEdge in iFeature7.ModelObjects(con3.o3d_edge):
        try:
            L = iEdge.GetLength(3)
        except Exception:
            continue
        if L > longest_length:
            longest_length, longest_edge = L, iEdge

    iMassInertiaParam7 = API7.IMassInertiaParam7(iBody7)
    Xc, Yc, Zc = iMassInertiaParam7.Xc * 10, iMassInertiaParam7.Yc * 10, iMassInertiaParam7.Zc * 10
    iLocalCoordinateSystems = API7.IAuxiliaryGeomContainer(iPart7).LocalCoordinateSystems
    iKompasDocument1 = API7.IKompasDocument1(iKompasDocument_a3d)

    # Удаляем старые ЛСК с таким именем
    for i in range(iLocalCoordinateSystems.Count):
        iLocalCoordinateSystem = iLocalCoordinateSystems.LocalCoordinateSystem(i)
        if iLocalCoordinateSystem and iLocalCoordinateSystem.Name == marking:
            iKompasDocument1.Delete(iLocalCoordinateSystem)

    # Создание ЛСК
    iLocalCoordinateSystem = iLocalCoordinateSystems.Add()
    iLocalCoordinateSystem.Name = marking
    iLocalCoordinateSystem.X, iLocalCoordinateSystem.Y, iLocalCoordinateSystem.Z = Xc, Yc, Zc
    iLocalCoordinateSystem.Current, iLocalCoordinateSystem.OrientationType = 1, con3.ksAxisOrientation
    iLocalCSAxesDirectionParam = API7.ILocalCSAxesDirectionParam(iLocalCoordinateSystem.LocalCSParameters)

    if longest_edge and largest_face:
        iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, longest_edge)

    if surface3D_type2 and largest_face:
        iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOY, largest_face)

    iLocalCoordinateSystem.Update()

    for el in elem:  # Удаляем временные объекты
        try:
            API7.IFeature7(el).Delete()
        except Exception:
            pass

    iKompasDocument3D1 = API7.IKompasDocument3D1(iKompasDocument_a3d)
    iViewProjectionManager = iKompasDocument3D1.ViewProjectionManager

    # Установка нового вида ориентации
    iModelObject_1 = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeXOZ)
    iPlane3D = API7.IPlane3D(iModelObject_1)
    iMathSurface3D = iPlane3D.Surface
    iPlacement3D = iMathSurface3D.Placement
    matrix3D = iPlacement3D.GetMatrix3D()

    iViewProjection7 = iViewProjectionManager.Add()
    iViewProjection7.SetMatrix3D(matrix3D)
    iViewProjection7.Name = marking
    iViewProjection7.Update()

    # Удаляем ЛСК
    iKompasDocument1.Delete(iLocalCoordinateSystem)

    # Надёжная перестройка документа 3D
    try:
        API7.IKompasDocument3D(iKompasDocument_a3d).RebuildDocument()
    except Exception:
        pass

    # Возвращаем изометрию
    try:
        iViewProjection7 = iViewProjectionManager.ViewProjection(7)
        iViewProjection7.Current = True
    except Exception:
        pass

    return True

def del_orientation(iKompasDocument_a3d, markings, file_a3d):
    for marking in markings:
        iKompasDocument3D1 = API7.IKompasDocument3D1(iKompasDocument_a3d)
        iViewProjectionManager = iKompasDocument3D1.ViewProjectionManager

        # Удаляем старую ориентацию с конца
        for i in reversed(range(iViewProjectionManager.Count)):
            iViewProjection7 = iViewProjectionManager.ViewProjection(i)
            if iViewProjection7:
                name_ViewProjection = iViewProjection7.Name
                if name_ViewProjection == marking:
                    if iViewProjection7.Delete():
                        log_message(f'Удалили ориентацию {marking} в {file_a3d}')
                    iViewProjection7.Update()
                    iKompasDocument_a3d.Save()
                    iKompasDocument_a3d.Close(1)
                    iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)

    return iKompasDocument_a3d

def create_cdw(path, file_template=None):
    # Создаёт чертеж
    file_name = os.path.basename(path)

    iKompasDocument = iDocuments.Open(file_template, False, True)
    iLayoutSheets = iKompasDocument.LayoutSheets
    iLayoutSheet = iLayoutSheets.Item(0)
    iSheetFormat = iLayoutSheet.Format

    if one_sheet:
        iSheetFormat.Format = con0.ksFormatA2
        vertical_orientation = False
    else:
        iSheetFormat.Format = con0.ksFormatA4
        vertical_orientation = True

    iSheetFormat.FormatMultiplicity = 1
    iSheetFormat.VerticalOrientation = vertical_orientation
    iLayoutSheet.SheetType = con0.ksDocumentSheet
    iLayoutSheet.Update()

    iKompasDocument.SaveAs(path)  # сохраняем по path
    iKompasDocument.Close(0)
    log_message(f'Создали файл {file_name}')

    return path, True

def insert_view(marking, text, safe_array=None, one_sheet=None,
                insert_dimensions=True, edit_scale=True, iView=None,
                embodiement=0, source_a3d_path=None):

    iView_top = None
    iView_left = None

    if iView:
        iView_base = iView
        iView_base.Current = True
        iView_base.Update()
        iAssociationView_base = API7.IAssociationView(iView_base)

    if not iView:
        if one_sheet:
            view_X = 0.0
            view_Y = 0.0
        else:
            view_X = 112.5
            view_Y = 150.0

        scale = DEFAULT_SCALE
        shift = VIEW_SHIFT_K / scale
        iAssociationViews = []

        iView_base = iViews.Add(con0.vt_Standart)  # Создаём графический объект "Вид"
        iView_base.X, iView_base.Y, iView_base.Scale = view_X, view_Y, scale
        iViewDesignation = API7.IViewDesignation(iView_base)
        iViewDesignation.ShowScale = False
        iViewDesignation.ShowName = False

        iAssociationView_base = API7.IAssociationView(iView_base)
        # ВАЖНО: опциональный путь, иначе — глобальная file_a3d (обратная совместимость)
        iAssociationView_base.SourceFileName = source_a3d_path or file_a3d

        iAssociationViews.append(iAssociationView_base)

        iEmbodimentsManager_cdw = API7.IEmbodimentsManager(iAssociationView_base)
        iEmbodimentsManager_cdw.SetCurrentEmbodiment(embodiement)

        if KompasVersion > 21:
            iAssociationView_base.SetProjectionObjects(safe_array)

        iAssociationView_base.ProjectionName = marking
        iAssociationView_base.VisibleLinesStyle = con0.ksCSNormal
        iAssociationView_base.BreakLinesVisible = False
        iAssociationView_base.HiddenLines = True
        iAssociationView_base.HiddenLinesVisible = True
        iAssociationView_base.Update()

        additional_view = not ('@016' in text or '@137' in text)

        if additional_view:
            log_message(f'Для {marking} вставили вид сверху {marking}')
            iView_top = iViews.Add(con0.vt_Projected)
            iView_top.Name = f"{marking} Сверху"
            iView_top.X, iView_top.Y, iView_top.Scale = view_X, view_Y - (2 / scale), scale

            iViewDesignation = API7.IViewDesignation(iView_top)
            iViewDesignation.ShowScale = False
            iViewDesignation.ShowName = False

            iAssociationView_top = API7.IAssociationView(iView_top)
            iAssociationView_top.ProjectionLink = True
            iAssociationView_top.VisibleLinesStyle = con0.ksCSNormal
            iAssociationView_top.BaseView = iView_base
            iAssociationView_top.BreakLinesVisible = False
            iAssociationView_top.HiddenLines = True
            iAssociationView_top.HiddenLinesVisible = True
            iView_top.Update()

            iAssociationViews.append(iAssociationView_top)

        script = os.path.basename('_autorupture.pyw')
        if not check_access(script):
            log_message(f"❌Похоже кто-то не задонатил за {'Авторазрывы'}, пропускаем...", "error")
        else:
            autorupture(iAssociationViews, iKompasDocument2D1, iView_base, AUTORUPTURE_GAP_X, AUTORUPTURE_GAP_Y)

        gabarit_base_view = get_gabarit_object(iView_base, iKompasDocument2D1)

        if iView_top:
            gabarit_view_top = get_gabarit_object(iView_top, iKompasDocument2D1)
            iView_top.X = view_X
            iView_top.Y = view_Y - (shift + (gabarit_base_view[1] + gabarit_view_top[1]) / 2)
            iView_top.Update()

        if left_view:
            log_message(f'Для элемента {marking} вставили вид слева')
            iView_left = iViews.Add(con0.vt_Projected)
            iView_left.Name = f"{marking} Слева"

            iView_left.X = view_X + shift
            iView_left.Y = view_Y
            iView_left.Scale = scale

            iViewDesignation = API7.IViewDesignation(iView_left)
            iViewDesignation.ShowScale = False
            iViewDesignation.ShowName = False

            iAssociationView_left = API7.IAssociationView(iView_left)
            iAssociationView_left.ProjectionLink = True
            iAssociationView_left.VisibleLinesStyle = con0.ksCSNormal
            iAssociationView_left.BaseView = iView_base
            iView_left.Update()

            gabarit_view_left = get_gabarit_object(iView_left, iKompasDocument2D1)
            iView_left.X = view_X + (shift + (gabarit_base_view[0] + gabarit_view_left[0]) / 2)
            iView_left.Y = view_Y
            iView_left.Update()

        script = os.path.basename('__K_autoscale.py')
        if not check_access(script):
            log_message(f"Похоже кто-то не задонатил за {'Автомасштабы'}, пропускаем...", "error")
            edit_scale = False

        if edit_scale:
            gabarit_geom = get_gabarit_geom(iView_base, iKompasDocument2D1)
            scale = auto_scale(gabarit_geom)
            if iView_top:
                iView_top.Name = f"{marking} Сверху"
                iView_top.Scale = scale
                iView_top.Update()
            if iView_left:
                iView_left.Name = f"{marking} Слева"
                iView_left.Scale = scale
                iView_left.Update()
            iView_base.Name = f"{marking}"
            iView_base.Scale = scale
            iView_base.Update()
            for iAssociationView in iAssociationViews:
                del_BreakLines(iAssociationView)
            autorupture(iAssociationViews, iKompasDocument2D1, iView_base, AUTORUPTURE_GAP_X, AUTORUPTURE_GAP_Y)  # Повторно устанавливаем разрыв

        script = os.path.basename('_K_autodimensions.pyw')
        if not check_access(script):
            log_message(f"Похоже кто-то не задонатил за {'Авторазмеры'}, пропускаем...", "error")
            insert_dimensions = False

        if insert_dimensions:
            try:
                add_linear_dimensions(iView_base, iKompasDocument_cdw, True)
                log_message('Образмерили базовый вид')
            except Exception:
                log_message(f'Не удалось образмерить', 'warn')
            if iView_top:
                try:
                    add_linear_dimensions(iView_top, iKompasDocument_cdw, True)
                    print("Образмерили вид сверху")
                except Exception:
                    log_message(f'Не удалось образмерить', 'warn')
            if left_view:
                try:
                    add_linear_dimensions(iView_left, iKompasDocument_cdw, False)
                    print("Образмерили вид слева")
                except Exception:
                    log_message(f'Не удалось образмерить', 'warn')

    if one_sheet:
        iDrawingContainer = API7.IDrawingContainer(iView_base)
        iDrawingTexts = iDrawingContainer.DrawingTexts

        iDrawingText = next(
            (iDrawingTexts.DrawingText(i) for i in range(iDrawingTexts.Count)
             if "Дет." in API7.IText(iDrawingTexts.DrawingText(i)).Str),
            None
        )

        if not iDrawingText:
            iDrawingText = iDrawingTexts.Add()
            iDrawingText.Allocation = con0.ksAlLeft

        iText = API7.IText(iDrawingText)
        iText.Style = con0.ksTSDrawingAnnotation
        iText.Str = text
        for i in range(iText.Count):
            iTextLine = iText.TextLine(i)
            iTextLine.LeftEdge = 0.0
            iTextItem = iTextLine.TextItem(0)

            iTextFont = API7.ITextFont(iTextItem)
            iTextFont.Height = TITLE_TEXT_HEIGHT
            if i == 0:
                iTextFont.Underline = True
            iTextItem.Update()

        _, iText_Y, *_ = get_gabarit_object(iText, iKompasDocument2D1)

        scale = iView_base.Scale
        iSymbols2DContainer = API7.ISymbols2DContainer(iView_base)

        # Максимальное значение Y из размеров
        y = max(
            (iSymbols2DContainer.LineDimensions.LineDimension(i).Y3
             for i in range(iSymbols2DContainer.LineDimensions.Count)),
            default=0
        )

        # Минимальный X из отрезков и окружностей
        min_x_segments = [
            min(seg.X1, seg.X2)
            for seg in (iDrawingContainer.LineSegments.LineSegment(i)
                        for i in range(iDrawingContainer.LineSegments.Count))
        ]

        min_x_circles = [
            circ.Xc - circ.Radius
            for circ in (iDrawingContainer.Circles.Circle(i)
                         for i in range(iDrawingContainer.Circles.Count))
        ]

        x = min([*min_x_segments, *min_x_circles], default=0)

        iDrawingText.X = x
        iDrawingText.Y = y + (4 + iText_Y) / scale
        iDrawingText.Update()

    # Возвращаем путь активного чертежа (устойчиво вместо глобального path_cdw)
    try:
        return iKompasDocument_cdw.PathName
    except Exception:
        # на всякий случай
        return ""

def edit_view(view_association_dict):
    if KompasVersion >= 23:
        updated_views = {}  # сюда будем записывать успешно обработанные

        for iView_number in list(view_association_dict.keys()):
            iView_name, iView, iAssociationView = view_association_dict[iView_number]
            iKompasDocument_cdw_a3d = iDocuments.Open(iAssociationView.SourceFileName, False, False)
            iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_cdw_a3d)
            iKompasDocument_cdw.Active = True

            iBody7 = None
            if not iAssociationView.SourceFileName.lower().endswith('.m3d'):  # Пропускаем m3d
                bodies = iAssociationView.GetProjectionObjects(iKompasDocument3D)
                if bodies:
                    iBody7 = bodies[0]
                if not iBody7:
                    iKompasDocument_cdw_a3d.Close(0)
                    continue

                if iBody7.Marking != iView.Name:
                    log_message(f'Меняем имя сущ вида {iView.Name} на {iBody7.Marking}')
                    iView.Name = iBody7.Marking
                    iView.Update()
                    iKompasDocument2D1.RebuildDocument()

                    updated_views[iView_number] = (iView.Name, iView, iAssociationView)
                    del view_association_dict[iView_number]

                if iBody7.Marking != Path(iKompasDocument_cdw.PathName).stem and not one_sheet:
                    log_message(f'Чертеж {iKompasDocument_cdw.PathName} для элемента {iBody7.Marking} имеет не верное имя')

            if iAssociationView.SourceFileName.lower().endswith('.m3d'):
                iPart7 = iKompasDocument3D.TopPart
                marking = iPart7.Marking
                if marking != iView.Name:
                    log_message(f'Меняем имя сущ вида {iView.Name} на {marking}')
                    iView.Name = marking
                    iView.Update()
                    iKompasDocument2D1.RebuildDocument()

                    updated_views[iView_number] = (iView.Name, iView, iAssociationView)
                    del view_association_dict[iView_number]

                if Path(iAssociationView.SourceFileName).stem != iView.Name:
                    log_message(f'Чертеж {iKompasDocument_cdw.PathName} для элемента {marking} имеет не верное имя', 'error')

            iKompasDocument_cdw_a3d.Close(0)

    print(f'Виды обработаны')
    return updated_views

def _spec_attach_in_doc(doc, marking, cdw_path):
    """Привязка cdw к ОДНОМУ документу спецификации (doc). Возвращает True, если были изменения."""
    dt = getattr(doc, "DocumentType", None)
    if KompasVersion < 23 or dt not in (5, 5.0):
        return False

    target_marking = str(marking).strip()
    target_path_norm = _norm_path(cdw_path)

    try:
        spec_desc = doc.SpecificationDescriptions.Active
        base_objects = spec_desc.BaseObjects
    except Exception:
        return False

    any_updated = False

    for i in range(_coll_count(base_objects)):
        base_obj = _coll_item(base_objects, i)
        if not base_obj:
            continue

        geom = getattr(base_obj, "Geometry", None)
        if not geom or _coll_count(geom) == 0:
            continue

        matched = False
        for gi in range(_coll_count(geom)):
            body = _coll_item(geom, gi)
            if not body:
                continue
            try:
                if str(getattr(body, "Marking", "")).strip() == target_marking:
                    matched = True
                    break
            except Exception:
                pass
        if not matched:
            continue

        attached = getattr(base_obj, "AttachedDocuments", None)
        if attached is None:
            continue

        already_has = False
        for di in range(_coll_count(attached) - 1, -1, -1):
            adoc = _coll_item(attached, di)
            if not adoc:
                continue
            try:
                name = str(getattr(adoc, "Name", "")).strip()
            except Exception:
                name = ""
            if not name or not os.path.isfile(name):
                try:
                    adoc.Delete()
                    any_updated = True
                except Exception:
                    pass
                continue
            if _norm_path(name) == target_path_norm:
                already_has = True

        if not already_has:
            try:
                attached.Add(cdw_path, True)
                any_updated = True
            except Exception:
                pass

        try:
            base_obj.Update()
        except Exception:
            pass

    if any_updated:
        try:
            doc.Save()
        except Exception:
            pass

    return any_updated

def spec_attach_to_all_a3d(marking, cdw_path, paths_tuple, skip_path=None):
    """
    Привязать cdw ко ВСЕМ *.a3d из набора paths_tuple.
    - Не использует уже открытый документ.
    - Каждый файл открывается/сохраняется/закрывается внутри функции.
    - Если передан skip_path, этот путь будет пропущен.
    Возвращает True, если хотя бы в одном документе были изменения.
    """
    # нормализуем список путей: убираем '*', берём только .a3d, убираем дубли, исключаем skip_path
    skip_norm = _norm_path(skip_path) if skip_path else None
    seen = set()
    a3d_list = []
    for p in paths_tuple:
        p_clean = p.rstrip('*')
        if not p_clean.lower().endswith('.a3d'):
            continue
        n = _norm_path(p_clean)
        if skip_norm and n == skip_norm:
            continue
        if n in seen:
            continue
        seen.add(n)
        a3d_list.append(p_clean)

    any_updated = False
    for a3d_path in a3d_list:
        try:
            doc = iDocuments.Open(a3d_path, False, False)
            changed = _spec_attach_in_doc(doc, marking, cdw_path)
            any_updated = changed or any_updated
        except Exception as e:
            log_message(f"Не удалось привязать {Path(cdw_path).name} к {a3d_path}: {e}", "warn")
        finally:
            try:
                doc.Close(1)
            except Exception:
                pass

    return any_updated

def spec_del_iAttachedDocuments(markings):
    changed = False
    if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
        for marking in markings:
            print(f'Ищем файл чертежа {marking} в объектах спецификации: {file_a3d}')
            iSpecificationDescriptions = iKompasDocument_a3d.SpecificationDescriptions
            iSpecificationDescription = iSpecificationDescriptions.Active
            iSpecificationBaseObjects = iSpecificationDescription.BaseObjects

            for i in range(iSpecificationBaseObjects.Count):
                iSpecificationBaseObject = iSpecificationBaseObjects.Item(i)

                # защита от пустой геометрии
                geom = getattr(iSpecificationBaseObject, "Geometry", None)
                if not geom or getattr(geom, "Count", 0) <= 0:
                    continue
                try:
                    iBody7 = geom[0]
                except Exception:
                    continue
                if not iBody7:
                    continue

                if iBody7.Marking == marking:
                    print(f'В объекте спецификации элемент {marking} - найден')
                    iAttachedDocuments = iSpecificationBaseObject.AttachedDocuments

                    for j in range(iAttachedDocuments.Count):
                        iAttachedDocument = iAttachedDocuments.Item(j)
                        if iAttachedDocument:
                            cdw_path = Path(iAttachedDocument.Name)
                            if Path(cdw_path).stem not in {'Детали', 'Пластины', marking} and Path(cdw_path).is_file():
                                print(f'Чертеж с именем файла {cdw_path} следует переименовать в {marking}')
                                iAttachedDocument.Delete()
                                iSpecificationBaseObject.Update()
                                changed = True

                        if iAttachedDocument and not os.path.isfile(iAttachedDocument.Name):
                            print(f'Удалили ссылку на чертеж {iAttachedDocument.Name}, так как он не существует')
                            iAttachedDocument.Delete()
                            iSpecificationBaseObject.Update()
                            changed = True
                    break

                    iSpecificationBaseObject.Update()
                    iKompasDocument_a3d.Save()
    if changed:
        try:
            iKompasDocument_a3d.Save()
        except Exception:
            pass
    return

def extract_file_paths(raw: str) -> list[str]:
    r"""
    Извлекает пути к *.a3d|*.m3d (поддержка дисков C:\ и UNC \\server\share).
    Не ломается на запятых и точках в пути. Поддерживает кавычки и удаляет дубли.
    """
    if not isinstance(raw, str):
        return []
    pattern = r'(?:"|\')?(?:[A-Za-z]:\\|\\\\)[^:*?"<>|\r\n]+?\.(?:a3d|m3d)(?:"|\')?'
    found = re.findall(pattern, raw, flags=re.IGNORECASE)
    norm = []
    seen = set()
    for p in found:
        pp = os.path.normcase(os.path.normpath(p.strip('"\'')))
        if pp not in seen:
            seen.add(pp)
            norm.append(pp)
    return norm

def df_read(xls, one_sheet, filter_column=None, filter_value=None, exclude=False):
    excel_handler = ExcelHandler(xls)
    df = excel_handler.read_excel(header_row=1)

    if filter_column and filter_value is not None:
        if isinstance(filter_value, list):
            filter_value = [str(val) for val in filter_value]
            if exclude:
                df = df[~df[filter_column].isin(filter_value)]
            else:
                df = df[df[filter_column].isin(filter_value)]
        else:
            filter_value = str(filter_value)
            if exclude:
                df = df[~df[filter_column].str.contains(filter_value, na=False)]
            else:
                df = df[df[filter_column] == filter_value]

    df = df[df['№ элемента'].notna()]

    # восстанавливаем символы только в нужной колонке
    excel_handler.data = df
    if 'Наименование' in df.columns:
        df['Наименование'] = df['Наименование'].astype(str)
    df = excel_handler.restore_symbols('Наименование')

    dict_a3d = {}
    dict_element_info = {}

    for _, row in df.iterrows():
        # Извлекаем пути в зависимости от условий
        obj_type = str(row.get('Тип объекта', '')).strip()
        if KompasVersion >= 23 and obj_type == 'Тело':
            paths = extract_file_paths(row.get('Путь до марки', ''))
        else:
            paths = extract_file_paths(row.get('Полное имя файла', ''))
            # только .m3d
            m3d_paths = [p for p in paths if p.lower().endswith('.m3d')]
            if not m3d_paths:
                print(f'Пропускаем файл: {paths} (так как нет пути в столбце "Полное имя файла")')
                continue
            paths = m3d_paths

        # Номер элемента
        x = row['№ элемента']
        try:
            element_num = str(int(float(x)))  # 1011.0 -> '1011'
        except (ValueError, TypeError):
            element_num = str(x).strip()

        temp_items = []

        # Корректно читаем длину как число
        length_val = pd.to_numeric(row.get('Длина, мм', None), errors='coerce')
        if pd.isna(length_val):
            log_message(f"[!] Пропущена строка с № элемента: {row['№ элемента']} — отсутствует значение 'Длина, мм'", 'error')
            continue
        length_mm = int(round(float(length_val)))

        val_tak = pd.to_numeric(row.get('Так'), errors='coerce')
        tak = int(round(float(val_tak))) if pd.notna(val_tak) else 0

        val_naob = pd.to_numeric(row.get('Наоборот'), errors='coerce')
        naob = int(round(float(val_naob))) if pd.notna(val_naob) else 0

        if tak:
            temp_items.append({4.0: element_num, 238175427236.0: "1"})
        if naob:
            temp_items.append({4.0: element_num, 255901398516.0: "1"})

        if tak and not naob:
            info_str = f"Дет.{element_num} - {tak} шт.&/{row['Наименование']} L={length_mm} мм"
        elif naob and not tak:
            info_str = f"Дет.{element_num} - {naob} шт.&/{row['Наименование']} L={length_mm} мм"
        elif tak and naob:
            info_str = (
                f"Дет.{element_num}(т) - {tak} шт.&/"
                f"Дет.{element_num}(н) - {naob} шт.&/"
                f"{row['Наименование']}&/L={length_mm} мм"
            )
        else:
            info_str = None

        if info_str:
            dict_element_info[element_num] = info_str

        if temp_items:
            key = tuple(paths)
            if not one_sheet:
                while key in dict_a3d:
                    if len(key) > 1:
                        key = key[:-1] + (key[-1] + '*',)
                    else:
                        key = (key[0] + '*',)

            if key not in dict_a3d:
                dict_a3d[key] = []
            dict_a3d[key].extend(temp_items)

    return dict_a3d, dict_element_info

def collect_existing_association_views(iViews, *, only_base=True):
    """
    Возвращает {view_number: (name, view, assoc_view)} для видов типа 10032.
    only_base=True — брать только главные (без BaseView).
    """
    out = {}
    for idx in range(iViews.Count):
        iView = iViews.View(idx)
        if iView.Type != 10032:
            continue
        assoc = API7.IAssociationView(iView)
        if only_base and assoc.BaseView:
            continue
        out[idx] = (iView.Name, iView, assoc)
    return out

if __name__ == "__main__":
    print("Версия от 20.11.2025")
    global iKompasDocument2D, iKompasDocument2D1, file_a3d  # file_a3d глобальная: insert_view читает её

    KompasObject, iApplication, KompasVersion = get_kompas()
    iDocuments = iApplication.Documents

    # Подготавливаем путь до обрабатываемой папки
    path = get_active_doc_path(iApplication)

    script = os.path.basename(__file__)
    if not check_access(script):
        input(f"❌ Похоже кто-то не задонатил за {script.split('.')[0]}, пропускаем...")
        sys.exit()

    ###
    xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/Материалы/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
    path_folder_cdw = easygui.diropenbox("Укажите папку для сохранения чертежей", default=path)
    file_template = easygui.fileopenbox(msg="Укажите файл шаблона *.cdt", title="", default=f"{path}/*.cdt")
    if not file_template:
        print(f'Файл шаблона не указан, выбран шаблон по умолчанию')
        file_template = f'{path_to_scripts}\\Template\\03 _ СПДС Для деталей.cdt'

    mode_plate = None
    mode = input(f'Создать проекции элемента в отдельных файлах чертежей, или на одном?'
                 f'\n(На отдельных - любой текст, На одном - без текста)? > ')
    if not mode:
        mode_plate = input(f'Для пластин создать отдельный файл чертежа (Да - любой текст, Нет - без текста)? >')
    if mode:
        one_sheet = False
    else:
        one_sheet = True

    left_view = None
    left_view = input(f'Добавить третий проекционный вид слева?'
                      f'\n(Добавить - любой текст, Нет - без текста)? > ')

    edit_scale = ""
    edit_scale = input(f'Подобрать масштаб?'
                       f'\n(Да - любой текст, Нет - без текста)? > ')

    insert_dimensions = ""
    if KompasVersion > 21:
        insert_dimensions = input(f'Добавить размеры?'
                                  f'\n(Да - любой текст, Нет - без текста)? > ')
    ###

    results = []

    if not mode_plate:
        dict_a3d_exclude, dict_element_info_exclude = df_read(xls, one_sheet)
        results.append((dict_a3d_exclude, dict_element_info_exclude, 'Детали.cdw'))

    if mode_plate:
        dict_a3d_exclude, dict_element_info_exclude = df_read(
            xls, one_sheet, 'Эскиз сечения', ['@016', '@137'], exclude=True
        )
        results.append((dict_a3d_exclude, dict_element_info_exclude, 'Детали.cdw'))

        dict_a3d_include, dict_element_info_include = df_read(
            xls, one_sheet, 'Эскиз сечения', ['@016', '@137'], exclude=False
        )
        results.append((dict_a3d_include, dict_element_info_include, 'Пластины.cdw'))

    if not results:
        print(f'В словаре элементов для создания чертежа - пусто')
        input('\n\rРабота завершена.\t\n')
        sys.exit()

    timer = Timer()
    timer.start()  # Запускаем таймер

    iApplication.HideMessage = con0.ksHideMessageYes

    print(f'Проверяем ссылки на чертежи в объектах спецификации и удаляем предыдущие ориентации...')
    spec_dict = defaultdict(set)
    for dict_a3d_exclude, _, _ in results:
        for paths_tuple, data_list in dict_a3d_exclude.items():
            numbers = [d[4.0] for d in data_list if 4.0 in d]  # только значения по ключу 4.0

            for raw_path in paths_tuple:
                clean_path = raw_path.rstrip('*')  # удаляем *, если есть
                spec_dict[clean_path].update(numbers)  # добавляем уникальные значения

    spec_dict = {k: sorted(v, key=extract_number) for k, v in spec_dict.items()}  # Преобразуем множества в списки

    for file_a3d, markings in spec_dict.items():
        if file_a3d.lower().endswith('.m3d'):
            continue  # Пропускаем файлы с расширением m3d
        iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)  # a3d

        spec_del_iAttachedDocuments(markings)
        iKompasDocument_a3d = del_orientation(iKompasDocument_a3d, markings, file_a3d)
        iKompasDocument_a3d.Save()
        iKompasDocument_a3d.Close(1)

    for dict_a3d, dict_element_info, name_cdw in results:
        # Работаем с чертежом
        if one_sheet:
            print(f'\nВставляем все виды в один файл чертежа')

            path_cdw = os.path.join(path_folder_cdw, name_cdw)
            check = None  # Новый файл чертежа не создавали
            if not os.path.isfile(path_cdw):
                _, check = create_cdw(path_cdw, file_template)

            # Анализируем чертёж
            print(f'Собираем информацию о существующих видах')
            iKompasDocument_cdw = iDocuments.Open(path_cdw, False, False)
            iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument_cdw)
            iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
            iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
            iViews = iViewsAndLayersManager.Views

            view_association_dict = {}
            final_view_association_dict = {}

            if KompasVersion > 21:
                if not check:
                    view_association_dict = collect_existing_association_views(iViews, only_base=True)
                    for _, (iView_name, _, __) in view_association_dict.items():
                        print(f'Ассоциативный главный вид {iView_name} найден')

                    # Редактируем существующие виды
                    print(f'Проверяем имена видов и при необходимости редактируем')
                    updated = edit_view(view_association_dict)
                    final_view_association_dict.update(updated)
                    final_view_association_dict.update(view_association_dict)

            print(f'\nНаходим элемент и вставляем ЛСК для вставки элемента в чертеж')
            for paths_tuple, item_list in dict_a3d.items():
                cleaned_paths = [p.rstrip('*') for p in paths_tuple]
                first_a3d = cleaned_paths[0]  # только с ним работаем геометрически

                iKompasDocument_a3d = iDocuments.Open(first_a3d, False, False)
                iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)

                dict_a3d_elem = {first_a3d: item_list}

                # Находим тела/ЛСК и т.д.
                iKompasDocument_a3d.Active = True
                dict_2d = search_body(dict_a3d_elem, dict_element_info)

                existing_markings = {data[0]: key for key, data in final_view_association_dict.items()}

                attachments = []  # сюда сложим (marking, path_cdw) для последующей привязки

                for marking, (safe_array, text, embodiement) in dict_2d.items():
                    iKompasDocument_cdw.Active = True

                    # ВАЖНО: передать исходный a3d во вставку (insert_view читает глобальную file_a3d)
                    file_a3d = first_a3d

                    print(f'Обрабатываем элемент {marking}')
                    if marking in existing_markings:
                        print(f'{marking} - вид вставлен ранее')
                        key_in_dict = existing_markings[marking]
                        iView = final_view_association_dict[key_in_dict][1]
                        path_cdw = insert_view(marking, text, safe_array, one_sheet,
                                               insert_dimensions, edit_scale, iView,
                                               embodiement, source_a3d_path=first_a3d)
                    else:
                        path_cdw = insert_view(marking, text, safe_array, one_sheet,
                                               insert_dimensions, edit_scale, None,
                                               embodiement, source_a3d_path=first_a3d)
                        print(f'{marking} - Готово')

                    iKompasDocument_cdw.Save()
                    attachments.append((marking, path_cdw))  # копим для дальнейшей привязки

                # Закрываем первый a3d, чтобы функция могла сама его открыть при необходимости
                iKompasDocument_a3d.Close(1)

                # Привязка cdw ко всем .a3d из набора (включая первый)
                for marking, cdw_path in attachments:
                    spec_attach_to_all_a3d(marking, cdw_path, paths_tuple)

            iKompasDocument_cdw.Close(1)

        if not one_sheet:
            print(f'\nВставляем виды в отдельные файлы чертежей')
            for paths_tuple, item_list in dict_a3d.items():
                cleaned_paths = [p.rstrip('*') for p in paths_tuple]
                first_a3d = cleaned_paths[0]  # только с ним строим вид/чертёж

                item = item_list[0]
                marking = item.get(4.0)
                path_cdw = os.path.join(path_folder_cdw, marking + '.cdw')
                check = False

                if not os.path.isfile(path_cdw):
                    path_cdw, check = create_cdw(path_cdw, file_template)

                print(f'Анализируем существующий чертеж для {marking}')
                iKompasDocument_cdw = iDocuments.Open(path_cdw, False, False)
                iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument_cdw)
                iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
                iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
                iViews = iViewsAndLayersManager.Views

                view_association_dict = {}
                final_view_association_dict = {}

                if KompasVersion >= 23:
                    view_association_dict = collect_existing_association_views(iViews, only_base=True)
                    for _, (iView_name, _, __) in view_association_dict.items():
                        print(f'Ассоциативный главный вид {iView_name} найден')

                    updated = edit_view(view_association_dict)
                    final_view_association_dict.update(updated)
                    final_view_association_dict.update(view_association_dict)

                iKompasDocument_a3d = iDocuments.Open(first_a3d, False, False)
                iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)

                dict_a3d_elem = {first_a3d: item_list}

                iKompasDocument_a3d.Active = True
                dict_2d = search_body(dict_a3d_elem, dict_element_info)
                existing_markings = {data[0]: data[1] for data in final_view_association_dict.values()}

                for marking, (safe_array, text, embodiement) in dict_2d.items():
                    iKompasDocument_cdw.Active = True

                    # ВАЖНО: передать исходный a3d во вставку
                    file_a3d = first_a3d

                    print(f'Обрабатываем элемент {marking}')
                    if marking in existing_markings:
                        iView = existing_markings[marking]
                        path_cdw = insert_view(marking, text, safe_array, one_sheet,
                                               insert_dimensions, edit_scale, iView,
                                               embodiement, source_a3d_path=first_a3d)
                    else:
                        path_cdw = insert_view(marking, text, safe_array, one_sheet,
                                               insert_dimensions, edit_scale, None,
                                               embodiement, source_a3d_path=first_a3d)

                    # Закрываем чертёж и первый a3d
                    iKompasDocument_cdw.Close(1)
                    iKompasDocument_a3d.Active = True
                    iKompasDocument_a3d.Save()
                    iKompasDocument_a3d.Close(1)

                    # Привязываем cdw ко всем .a3d из набора (включая первый)
                    spec_attach_to_all_a3d(marking, path_cdw, paths_tuple)

                    print(f'{marking} - Готово\n')

    iApplication.HideMessage = con0.ksShowMessage
    print(f'\n{timer.stop()}')
    input('\rРабота завершена.  \n')

# import sys
#
# from __Kompas import *
# from _Config import *
# from __ExcelHandler import ExcelHandler
# from pathlib import Path
# import pandas as pd
# from __Debug import *
# from win32com.client import VARIANT
# import easygui, re
# import pythoncom
# import numpy as np
# import math
#
# from collections import defaultdict
# from __Utils import Timer
# from __K_autorupture import *
# from __K_autodimensions import add_linear_dimensions
# from __K_autoscale import auto_scale
#
# def extract_number(value):
#     try:
#         # Попробуем напрямую преобразовать к числу
#         return float(value)
#     except (ValueError, TypeError):
#         # Если не получилось — ищем первое число в строке (целое или с точкой)
#         match = re.search(r'\d+(?:\.\d+)?', str(value))
#         return float(match.group()) if match else float('inf')  # если нет цифр — в конец
#
# def _coll_count(coll):
#     try:
#         return int(getattr(coll, "Count"))
#     except Exception:
#         try:
#             return len(coll)
#         except Exception:
#             return 0
#
# def _coll_item(coll, idx):
#     try:
#         return coll.Item(idx)
#     except Exception:
#         try:
#             return coll[idx]
#         except Exception:
#             return None
#
# def _norm_path(p):
#     try:
#         return os.path.normcase(os.path.normpath(p))
#     except Exception:
#         return str(p or "")
#
# def search_body(dict_a3d, dict_element_info):
#     '''Функция ищет нужное тело в том числе в исполнении'''
#     file_a3d, dict_list = next(iter(dict_a3d.items()))
#     log_message(f'Работаем с файлом  {file_a3d}', 'how')
#
#     result_dict = {}
#     processed_markings = set()
#
#     if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
#         iPart7 = iKompasDocument3D.TopPart
#
#         iEmbodimentsManager = API7.IEmbodimentsManager(iPart7)
#         iEmbodimentsManager.SetCurrentEmbodiment(0)
#         iModelObject = API7.IModelObject(iPart7)
#         iModelObject.Update()
#
#         for i in range(iEmbodimentsManager.EmbodimentCount):
#             for check_dict in dict_list:
#                 marking = next(iter(check_dict.values()))
#
#                 if marking in processed_markings:
#                     continue  # уже нашли, пропускаем
#
#                 iEmbodiment = iEmbodimentsManager.Embodiment(i)
#                 iEmbodimentsManager.SetCurrentEmbodiment(i)
#
#                 iFeature7 = API7.IFeature7(iEmbodiment.Part)
#                 result_bodies = iFeature7.ResultBodies
#
#                 iBody7 = check_bodies(iKompasDocument_a3d, result_bodies, check_dict)
#                 if iBody7:
#                     log_message(f'Элемент с номером {marking} найден в исполнении {iEmbodiment.GetMarking(-1, 0)}')
#                     iPart7 = iKompasDocument3D.TopPart
#                     lsk_check = insert_view_orientation(marking, iPart7, iBody7)
#                     arr = (iBody7,)
#                     safe_array = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_DISPATCH, arr)
#                     text = dict_element_info.get(marking, "")
#                     result_dict[marking] = [safe_array, text, i]
#
#                     processed_markings.add(marking)  # отметим, что уже обработан
#
#         iEmbodimentsManager.SetCurrentEmbodiment(0)
#         iKompasDocument_a3d.Save()
#
#     if KompasVersion == 21 or iKompasDocument_a3d.DocumentType == 4.0:
#         for check_dict in dict_list:
#             marking = next(iter(check_dict.values()))
#             safe_array = ''
#             text = dict_element_info.get(marking, "")
#             result_dict[marking] = [safe_array, text, 0]
#             processed_markings.add(marking)
#
#     return result_dict
#
# def check_bodies(iKompasDocument, result_bodies, check_dict):
#     """Проверяет свойства тел и возвращает подходящее тело"""
#     result = [(float(k), v) for k, v in check_dict.items()]
#     iPropertyMng = API7.IPropertyMng(iApplication)
#
#     def matches_body_properties(iBody7):
#         """Сравнивает свойства тела с искомыми значениями"""
#         iPropertyKeeper = API7.IPropertyKeeper(iBody7)
#         for key, value in result:
#             val = iPropertyKeeper.GetPropertyValue(iPropertyMng.GetProperty(iKompasDocument, key), 0, 1, 1)[1]
#             if str(val) != str(value):
#                 return False
#         return True
#
#     iBody7 = next((body for body in (result_bodies if isinstance(result_bodies, tuple) else [result_bodies])
#                    if matches_body_properties(body)), None)
#     return iBody7
#
# def insert_view_orientation(marking, iPart7, iBody7):
#
#     elem = []  # Список для удаления временных объектов
#     iFeature7 = API7.IFeature7(iBody7)
#     iFaces = iFeature7.ModelObjects(con3.o3d_face)
#     iAxes3D = API7.IAuxiliaryGeomContainer(iPart7).Axes3D
#
#     largest_area_sum, largest_face_sum = -1, None  # для цилиндров/конусов
#     largest_plane_area, largest_plane_face = -1, None  # для плоских граней
#     longest_length, longest_edge = -1, None  # для самой длинной прямой ребра
#     surface3D_type2 = False  # флаг — найдена ли хотя бы одна плоская грань
#
#     # --- Анализ всех граней тела ---
#     for iFace in iFaces:
#         iMathSurface3D = iFace.MathSurface
#         if iMathSurface3D.Surface3DType in {3, 4}:  # Конус или цилиндр
#             # Создаём оси-ребра для скруглений для оси Y
#             iAxis3D = iAxes3D.Add(con3.o3d_axisConeFace)
#             API7.IAxis3DByConeface(iAxis3D).Face = iFace
#             iAxis3D.Update()
#             elem.append(iAxis3D)
#
#             area_cone = iFace.GetArea(3)  # Площадь цилиндрической грани
#             connected_faces = iFace.ConnectedFaces  # Стыкуемые грани
#
#             flat_faces = [f for f in connected_faces if
#                           f.MathSurface.Surface3DType == 2]  # Получаем только плоские грани
#
#             if not flat_faces:
#                 flat_faces = [iFace]  # Если плоских граней нет используем найденную
#
#             total_area_flats = sum(f.GetArea(3) for f in flat_faces)  # Площади стыкуемых плоских граней
#             total_area = area_cone + total_area_flats  # Суммарная площадь цилиндра и плоскостей
#
#             # Запоминаем набор с максимальной суммарной площадью
#             if total_area > largest_area_sum:
#                 largest_area_sum = total_area
#
#                 max_face = max(flat_faces, key=lambda f: f.GetArea(3))
#                 if max_face.GetArea(3) > area_cone:
#                     largest_face_sum = max_face
#                 else:
#                     largest_face_sum = iFace  # цилиндрическая грань крупнее — выбираем её
#
#         elif iMathSurface3D.Surface3DType == 2:  # плоская грань
#             surface3D_type2 = True
#             area = iFace.GetArea(3)
#             if area > largest_plane_area:
#                 largest_plane_area = area
#                 largest_plane_face = iFace
#
#     # --- Выбор итоговой "лучшей" плоскости для оси X ---
#     if largest_plane_area > largest_area_sum:
#         largest_area = largest_plane_area
#         largest_face = largest_plane_face
#     else:
#         largest_area = largest_area_sum
#         largest_face = largest_face_sum
#
#     for iEdge in iFeature7.ModelObjects(con3.o3d_edge):
#         if iEdge.GetLength(3) > longest_length:
#             longest_length, longest_edge = iEdge.GetLength(3), iEdge
#
#     iMassInertiaParam7 = API7.IMassInertiaParam7(iBody7)
#     Xc, Yc, Zc = iMassInertiaParam7.Xc * 10, iMassInertiaParam7.Yc * 10, iMassInertiaParam7.Zc * 10
#     iLocalCoordinateSystems = API7.IAuxiliaryGeomContainer(iPart7).LocalCoordinateSystems
#     iKompasDocument1 = API7.IKompasDocument1(iKompasDocument_a3d)
#
#     # Удаляем старые ЛСК
#     for i in range(iLocalCoordinateSystems.Count):
#         iLocalCoordinateSystem = iLocalCoordinateSystems.LocalCoordinateSystem(i)
#         if iLocalCoordinateSystem:
#             name_lsk = iLocalCoordinateSystem.Name
#             if name_lsk == marking:
#                 iKompasDocument1.Delete(iLocalCoordinateSystem)
#
#     # Создание ЛСК
#     iLocalCoordinateSystem = iLocalCoordinateSystems.Add()
#     iLocalCoordinateSystem.Name = marking
#     iLocalCoordinateSystem.X, iLocalCoordinateSystem.Y, iLocalCoordinateSystem.Z = Xc, Yc, Zc
#     iLocalCoordinateSystem.Current, iLocalCoordinateSystem.OrientationType = 1, con3.ksAxisOrientation
#     iLocalCSAxesDirectionParam = API7.ILocalCSAxesDirectionParam(iLocalCoordinateSystem.LocalCSParameters)
#
#     if longest_edge:
#         iMathSurface3D = largest_face.MathSurface
#         iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, longest_edge)
#
#     if surface3D_type2:
#         iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOY, largest_face)
#
#     iLocalCoordinateSystem.Update()
#
#     for el in elem:  # Удаляем временные объекты
#         API7.IFeature7(el).Delete()
#
#     iKompasDocument3D1 = API7.IKompasDocument3D1(iKompasDocument_a3d)
#     iViewProjectionManager = iKompasDocument3D1.ViewProjectionManager
#
#     # Установка нового вида ориентации
#     iModelObject_1 = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeXOZ)
#
#     iPlane3D = API7.IPlane3D(iModelObject_1)
#     iMathSurface3D = iPlane3D.Surface
#     iPlacement3D = iMathSurface3D.Placement
#
#     matrix3D = iPlacement3D.GetMatrix3D()
#
#     iViewProjection7 = iViewProjectionManager.Add()
#     iViewProjection7.SetMatrix3D(matrix3D)
#     iViewProjection7.Name = marking
#     iViewProjection7.Update()
#
#     # Удаляем ЛСК
#     iKompasDocument1.Delete(iLocalCoordinateSystem)
#     iKompasDocument3D.RebuildDocument()
#
#     # Возвращаем изометрию
#     iViewProjection7 = iViewProjectionManager.ViewProjection(7)
#     iViewProjection7.Current = True
#
#     return True
#
# def del_orientation(iKompasDocument_a3d, markings, file_a3d):
#     for marking in markings:
#         iKompasDocument3D1 = API7.IKompasDocument3D1(iKompasDocument_a3d)
#         iViewProjectionManager = iKompasDocument3D1.ViewProjectionManager
#
#         # Удаляем старую ориентацию с конца
#         for i in reversed(range(iViewProjectionManager.Count)):
#             iViewProjection7 = iViewProjectionManager.ViewProjection(i)
#             if iViewProjection7:
#                 name_ViewProjection = iViewProjection7.Name
#                 if name_ViewProjection == marking:
#                     if iViewProjection7.Delete():
#                         log_message(f'Удалили ориентацию {marking} в {file_a3d}')
#                     iViewProjection7.Update()
#                     iKompasDocument_a3d.Save()
#                     iKompasDocument_a3d.Close(1)
#                     iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)
#
#     return iKompasDocument_a3d
#
# def create_cdw(path, file_template = None):
#     # Создаёт чертеж
#     file_name = os.path.basename(path)
#
#     iKompasDocument = iDocuments.Open(file_template, False, True)
#     iLayoutSheets = iKompasDocument.LayoutSheets
#     iLayoutSheet = iLayoutSheets.Item(0)
#     iSheetFormat = iLayoutSheet.Format
#
#     if one_sheet:
#         iSheetFormat.Format = con0.ksFormatA2
#         vertical_orientation = False
#     else:
#         iSheetFormat.Format = con0.ksFormatA4
#         vertical_orientation = True
#
#     iSheetFormat.FormatMultiplicity = 1
#     iSheetFormat.VerticalOrientation = vertical_orientation
#     iLayoutSheet.SheetType = con0.ksDocumentSheet
#     iLayoutSheet.Update()
#
#     iKompasDocument.SaveAs(path)  # <— фикc: сохраняем по path
#     iKompasDocument.Close(0)
#     log_message(f'Создали файл {file_name}')
#
#     return path, True
#
# def insert_view(marking, text, safe_array=None, one_sheet=None, insert_dimensions=True, edit_scale=True, iView = None, embodiement = 0):
#
#     iView_top = None
#     iView_left = None
#
#     if iView:
#         iView_base = iView
#         iView_base.Current = True
#         iView_base.Update()
#         iAssociationView_base = API7.IAssociationView(iView_base)
#
#     if not iView:
#         if one_sheet:
#             view_X = 0.0
#             view_Y = 0.0
#         else:
#             view_X = 112.5
#             view_Y = 150.0
#
#         scale = 1 / 10
#         shift = 3 / scale
#         iAssociationViews = []
#         iView_base = iViews.Add(con0.vt_Standart) # Создаём графический объект "Вид"
#         iView_base.X, iView_base.Y, iView_base.Scale = view_X, view_Y, scale
#         iViewDesignation = API7.IViewDesignation(iView_base)
#         iViewDesignation.ShowScale = False # Масштаб
#         iViewDesignation.ShowName = False # Масштаб
#
#         iAssociationView_base = API7.IAssociationView(iView_base)
#         iAssociationView_base.SourceFileName = file_a3d  # использует глобальную переменную
#
#         iAssociationViews.append(iAssociationView_base)
#
#         iEmbodimentsManager_cdw = API7.IEmbodimentsManager(iAssociationView_base)
#         iEmbodimentsManager_cdw.SetCurrentEmbodiment(embodiement)
#
#         if KompasVersion > 21:
#             iAssociationView_base.SetProjectionObjects(safe_array)
#
#         iAssociationView_base.ProjectionName = marking
#         iAssociationView_base.VisibleLinesStyle = con0.ksCSNormal
#         iAssociationView_base.BreakLinesVisible = False  # линии переходов
#         iAssociationView_base.HiddenLines = True # передать невидимые линии
#         iAssociationView_base.HiddenLinesVisible = True # невидимые линии
#         iAssociationView_base.Update()
#
#         additional_view = not ('@016' in text or '@137' in text)
#
#         if additional_view:
#             log_message(f'Для {marking} вставили вид сверху {marking}')
#             iView_top = iViews.Add(con0.vt_Projected)
#             iView_top.Name = f"{marking} Сверху"
#             iView_top.X, iView_top.Y, iView_top.Scale = view_X, view_Y - (2/scale), scale
#
#             iViewDesignation = API7.IViewDesignation(iView_top)
#             iViewDesignation.ShowScale = False
#             iViewDesignation.ShowName = False
#
#             iAssociationView_top = API7.IAssociationView(iView_top)
#             iAssociationView_top.ProjectionLink = True
#             iAssociationView_top.VisibleLinesStyle = con0.ksCSNormal
#             iAssociationView_top.BaseView = iView_base
#             iAssociationView_top.BreakLinesVisible = False
#             iAssociationView_top.HiddenLines = True
#             iAssociationView_top.HiddenLinesVisible = True
#             iView_top.Update()
#
#             iAssociationViews.append(iAssociationView_top)
#
#         script = os.path.basename('_autorupture.pyw')
#         if not check_access(script):
#             log_message(f"❌Похоже кто-то не задонатил за {'Авторазрывы'}, пропускаем...", "error")
#         else:
#             autorupture(iAssociationViews, iKompasDocument2D1, iView_base, 15, 20)
#
#         gabarit_base_view = get_gabarit_object(iView_base, iKompasDocument2D1)
#
#         if iView_top:
#             gabarit_view_top = get_gabarit_object(iView_top, iKompasDocument2D1)
#             iView_top.X = view_X
#             iView_top.Y = view_Y - (shift + (gabarit_base_view[1] + gabarit_view_top[1])/2)
#             iView_top.Update()
#
#         if left_view:
#             log_message(f'Для элемента {marking} вставили вид слева')
#             iView_left = iViews.Add(con0.vt_Projected)
#             iView_left.Name = f"{marking} Слева"
#
#             iView_left.X = view_X + shift
#             iView_left.Y = view_Y
#             iView_left.Scale = scale
#
#             iViewDesignation = API7.IViewDesignation(iView_left)
#             iViewDesignation.ShowScale = False
#             iViewDesignation.ShowName = False
#
#             iAssociationView_left = API7.IAssociationView(iView_left)
#             iAssociationView_left.ProjectionLink = True
#             iAssociationView_left.VisibleLinesStyle = con0.ksCSNormal
#             iAssociationView_left.BaseView = iView_base
#             iView_left.Update()
#
#             gabarit_view_left = get_gabarit_object(iView_left, iKompasDocument2D1)
#             iView_left.X = view_X + (shift + (gabarit_base_view[0] + gabarit_view_left[0])/2)
#             iView_left.Y = view_Y
#             iView_left.Update()
#
#         script = os.path.basename('__K_autoscale.py')
#         if not check_access(script):
#             log_message(f"Похоже кто-то не задонатил за {'Автомасштабы'}, пропускаем...", "error")
#             edit_scale = False
#
#         if edit_scale:
#             gabarit_geom = get_gabarit_geom(iView_base, iKompasDocument2D1)
#             scale = auto_scale(gabarit_geom)
#             if iView_top:
#                 iView_top.Name = f"{marking} Сверху"
#                 iView_top.Scale = scale
#                 iView_top.Update()
#             if iView_left:
#                 iView_left.Name = f"{marking} Слева"
#                 iView_left.Scale = scale
#                 iView_left.Update()
#             iView_base.Name = f"{marking}"
#             iView_base.Scale = scale
#             iView_base.Update()
#             for iAssociationView in iAssociationViews:
#                 del_BreakLines(iAssociationView)
#             autorupture(iAssociationViews, iKompasDocument2D1, iView_base, 15, 20) # Повторно устанавливаем разрыв
#
#         script = os.path.basename('_K_autodimensions.pyw')
#         if not check_access(script):
#             log_message(f"Похоже кто-то не задонатил за {'Авторазмеры'}, пропускаем...", "error")
#             insert_dimensions = False
#
#         if insert_dimensions:
#             try:
#                 add_linear_dimensions(iView_base, iKompasDocument_cdw, True)
#                 log_message('Образмерили базовый вид')
#             except:
#                 log_message(f'Не удалось образмерить', 'warn')
#             if iView_top:
#                 try:
#                     add_linear_dimensions(iView_top, iKompasDocument_cdw, True)
#                     print("Образмерили вид сверху")
#                 except:
#                     log_message(f'Не удалось образмерить', 'warn')
#             if left_view:
#                 try:
#                     add_linear_dimensions(iView_left, iKompasDocument_cdw, False)
#                     print("Образмерили вид слева")
#                 except:
#                     log_message(f'Не удалось образмерить', 'warn')
#
#     if one_sheet:
#         iDrawingContainer = API7.IDrawingContainer(iView_base)
#         iDrawingTexts = iDrawingContainer.DrawingTexts
#
#         iDrawingText = next(
#             (iDrawingTexts.DrawingText(i) for i in range(iDrawingTexts.Count)
#              if "Дет." in API7.IText(iDrawingTexts.DrawingText(i)).Str),
#             None
#         )
#
#         if not iDrawingText:
#             iDrawingText = iDrawingTexts.Add()
#             iDrawingText.Allocation = con0.ksAlLeft
#
#         iText = API7.IText(iDrawingText)
#         iText.Style = con0.ksTSDrawingAnnotation
#         iText.Str = text
#         for i in range(iText.Count):
#             iTextLine = iText.TextLine(i)
#             iTextLine.LeftEdge = 0.0
#             iTextItem = iTextLine.TextItem(0)
#
#             iTextFont = API7.ITextFont(iTextItem)
#             iTextFont.Height = 3.5
#             if i == 0:
#                 iTextFont.Underline = True
#             iTextItem.Update()
#
#         _, iText_Y, *_ = get_gabarit_object(iText, iKompasDocument2D1)
#
#         scale = iView_base.Scale
#         iSymbols2DContainer = API7.ISymbols2DContainer(iView_base)
#
#         # Максимальное значение Y из размеров
#         y = max(
#             ( iSymbols2DContainer.LineDimensions.LineDimension(i).Y3
#              for i in range( iSymbols2DContainer.LineDimensions.Count)),
#             default=0
#         )
#
#         # Минимальный X из отрезков и окружностей
#         min_x_segments = [
#             min(seg.X1, seg.X2)
#             for seg in (iDrawingContainer.LineSegments.LineSegment(i)
#                         for i in range(iDrawingContainer.LineSegments.Count))
#         ]
#
#         min_x_circles = [
#             circ.Xc - circ.Radius
#             for circ in (iDrawingContainer.Circles.Circle(i)
#                          for i in range(iDrawingContainer.Circles.Count))
#         ]
#
#         x = min([*min_x_segments, *min_x_circles], default=0)
#
#         iDrawingText.X = x
#         iDrawingText.Y = y + (4 + iText_Y) / scale
#         iDrawingText.Update()
#
#     return path_cdw
#
# def edit_view(view_association_dict):
#
#     if KompasVersion >= 23:
#         updated_views = {}  # сюда будем записывать успешно обработанные
#
#         for iView_number in list(view_association_dict.keys()):
#             iView_name, iView, iAssociationView = view_association_dict[iView_number]
#             iKompasDocument_cdw_a3d = iDocuments.Open(iAssociationView.SourceFileName, False, False)
#             iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_cdw_a3d)
#             iKompasDocument_cdw.Active = True
#
#             iBody7 = None
#             if not iAssociationView.SourceFileName.lower().endswith('.m3d'): #Пропускаем m3d
#                 bodies = iAssociationView.GetProjectionObjects(iKompasDocument3D)
#                 if bodies:
#                     iBody7 = bodies[0]
#                 if not iBody7:
#                     continue
#
#                 if iBody7.Marking != iView.Name:
#                     log_message(f'Меняем имя сущ вида {iView.Name} на {iBody7.Marking}')
#                     iView.Name = iBody7.Marking
#                     iView.Update()
#                     iKompasDocument2D1.RebuildDocument()
#
#                     updated_views[iView_number] = (iView.Name, iView, iAssociationView)
#                     del view_association_dict[iView_number]
#
#                 if iBody7.Marking != Path(iKompasDocument_cdw.PathName).stem and not one_sheet:
#                     log_message(f'Чертеж {iKompasDocument_cdw.PathName} для элемента {iBody7.Marking} имеет не верное имя')
#
#             if iAssociationView.SourceFileName.lower().endswith('.m3d'):
#                 iPart7 = iKompasDocument3D.TopPart
#                 marking = iPart7.Marking
#                 if marking != iView.Name:
#                     log_message(f'Меняем имя сущ вида {iView.Name} на {marking}')
#                     iView.Name = marking
#                     iView.Update()
#                     iKompasDocument2D1.RebuildDocument()
#
#                     updated_views[iView_number] = (iView.Name, iView, iAssociationView)
#                     del view_association_dict[iView_number]
#
#                 if Path(iAssociationView.SourceFileName).stem != iView.Name:
#                     log_message(f'Чертеж {iKompasDocument_cdw.PathName} для элемента {marking} имеет не верное имя', 'error')
#
#             iKompasDocument_cdw_a3d.Close(0)
#
#     print(f'Виды обработаны')
#     return updated_views
#
# def _spec_attach_in_doc(doc, marking, cdw_path):
#     """Привязка cdw к ОДНОМУ документу спецификации (doc). Возвращает True, если были изменения."""
#     dt = getattr(doc, "DocumentType", None)
#     if KompasVersion < 23 or dt not in (5, 5.0):
#         return False
#
#     target_marking = str(marking).strip()
#     target_path_norm = _norm_path(cdw_path)
#
#     try:
#         spec_desc = doc.SpecificationDescriptions.Active
#         base_objects = spec_desc.BaseObjects
#     except Exception:
#         return False
#
#     any_updated = False
#
#     for i in range(_coll_count(base_objects)):
#         base_obj = _coll_item(base_objects, i)
#         if not base_obj:
#             continue
#
#         geom = getattr(base_obj, "Geometry", None)
#         if not geom or _coll_count(geom) == 0:
#             continue
#
#         matched = False
#         for gi in range(_coll_count(geom)):
#             body = _coll_item(geom, gi)
#             if not body:
#                 continue
#             try:
#                 if str(getattr(body, "Marking", "")).strip() == target_marking:
#                     matched = True
#                     break
#             except Exception:
#                 pass
#         if not matched:
#             continue
#
#         attached = getattr(base_obj, "AttachedDocuments", None)
#         if attached is None:
#             continue
#
#         already_has = False
#         for di in range(_coll_count(attached) - 1, -1, -1):
#             adoc = _coll_item(attached, di)
#             if not adoc:
#                 continue
#             try:
#                 name = str(getattr(adoc, "Name", "")).strip()
#             except Exception:
#                 name = ""
#             if not name or not os.path.isfile(name):
#                 try:
#                     adoc.Delete()
#                     any_updated = True
#                 except Exception:
#                     pass
#                 continue
#             if _norm_path(name) == target_path_norm:
#                 already_has = True
#
#         if not already_has:
#             try:
#                 attached.Add(cdw_path, True)
#                 any_updated = True
#             except Exception:
#                 pass
#
#         try:
#             base_obj.Update()
#         except Exception:
#             pass
#
#     if any_updated:
#         try:
#             doc.Save()
#         except Exception:
#             pass
#
#     return any_updated
#
# def spec_attach_to_all_a3d(marking, cdw_path, paths_tuple, skip_path=None):
#     """
#     Привязать cdw ко ВСЕМ *.a3d из набора paths_tuple.
#     - Не использует уже открытый документ.
#     - Каждый файл открывается/сохраняется/закрывается внутри функции.
#     - Если передан skip_path, этот путь будет пропущен.
#     Возвращает True, если хотя бы в одном документе были изменения.
#     """
#     # нормализуем список путей: убираем '*', берём только .a3d, убираем дубли, исключаем skip_path
#     skip_norm = _norm_path(skip_path) if skip_path else None
#     seen = set()
#     a3d_list = []
#     for p in paths_tuple:
#         p_clean = p.rstrip('*')
#         if not p_clean.lower().endswith('.a3d'):
#             continue
#         n = _norm_path(p_clean)
#         if skip_norm and n == skip_norm:
#             continue
#         if n in seen:
#             continue
#         seen.add(n)
#         a3d_list.append(p_clean)
#
#     any_updated = False
#     for a3d_path in a3d_list:
#         try:
#             doc = iDocuments.Open(a3d_path, False, False)
#             changed = _spec_attach_in_doc(doc, marking, cdw_path)
#             any_updated = changed or any_updated
#         except Exception as e:
#             log_message(f"Не удалось привязать {Path(cdw_path).name} к {a3d_path}: {e}", "warn")
#         finally:
#             try:
#                 doc.Close(1)
#             except Exception:
#                 pass
#
#     return any_updated
#
# def spec_del_iAttachedDocuments(markings):
#     if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
#         for marking in markings:
#             print(f'Ищем файл чертежа {marking} в объектах спецификации: {file_a3d}')
#             iSpecificationDescriptions = iKompasDocument_a3d.SpecificationDescriptions
#             iSpecificationDescription = iSpecificationDescriptions.Active
#             iSpecificationBaseObjects = iSpecificationDescription.BaseObjects
#
#             for i in range(iSpecificationBaseObjects.Count):
#                 iSpecificationBaseObject = iSpecificationBaseObjects.Item(i)
#                 iBody7 = iSpecificationBaseObject.Geometry[0]
#                 if iBody7.Marking == marking:
#                     print(f'В объекте спецификации элемент {marking} - найден')
#                     iAttachedDocuments = iSpecificationBaseObject.AttachedDocuments
#
#                     for i in range(iAttachedDocuments.Count):
#                         iAttachedDocument = iAttachedDocuments.Item(i)
#                         if iAttachedDocument:
#                             cdw_path = Path(iAttachedDocument.Name)
#                             if Path(cdw_path).stem not in {'Детали', 'Пластины', marking} and Path(cdw_path).is_file():
#                                 print(f'Чертеж с именем файла {cdw_path} следует переименовать в {marking}')
#                                 iAttachedDocument.Delete()
#                                 iSpecificationBaseObject.Update()
#
#                         if iAttachedDocument and not os.path.isfile(iAttachedDocument.Name):
#                             print(f'Удалили ссылку на чертеж {iAttachedDocument.Name}, так как он не существует')
#                             iAttachedDocument.Delete()
#                             iSpecificationBaseObject.Update()
#                     break
#
#                     iSpecificationBaseObject.Update()
#                     iKompasDocument_a3d.Save()
#     return
#
# def extract_file_paths(raw: str) -> list[str]:
#     """Извлекает .a3d и .m3d пути из строки, даже если в путях есть запятые и точки"""
#     if isinstance(raw, str):
#         return re.findall(r"[A-Z]:\\.*?\.(?:a3d|m3d)", raw, flags=re.IGNORECASE)
#     return []
#
# def df_read(xls, one_sheet, filter_column=None, filter_value=None, exclude=False):
#
#     excel_handler = ExcelHandler(xls)
#     df = excel_handler.read_excel(header_row=1)
#
#     if filter_column and filter_value is not None:
#         if isinstance(filter_value, list):
#             filter_value = [str(val) for val in filter_value]
#             if exclude:
#                 df = df[~df[filter_column].isin(filter_value)]
#             else:
#                 df = df[df[filter_column].isin(filter_value)]
#         else:
#             filter_value = str(filter_value)
#             if exclude:
#                 df = df[~df[filter_column].str.contains(filter_value, na=False)]
#             else:
#                 df = df[df[filter_column] == filter_value]
#
#     df = df[df['№ элемента'].notna()]
#
#     excel_handler.data = df
#     df = df.astype(str)
#     df = excel_handler.restore_symbols('Наименование')
#
#     dict_a3d = {}
#     dict_element_info = {}
#
#     for _, row in df.iterrows():
#         # Извлекаем пути в зависимости от условий
#         if KompasVersion >= 23 and row['Тип объекта'] == 'Тело':
#             paths = extract_file_paths(row.get('Путь до марки', ''))
#         else:
#             paths = extract_file_paths(row.get('Полное имя файла', ''))
#
#             m3d_paths = [p for p in paths if p.lower().endswith('.m3d')] # Фильтрация путей только с .m3d
#             if not m3d_paths:
#                 print(f'Пропускаем файл: {paths} (так как нет пути в столбце "Полное имя файла")')
#                 continue
#             paths = m3d_paths
#
#         # Номер элемента
#         x = row['№ элемента']
#         try:
#             element_num = str(int(float(x)))  # 1011.0 -> '1011'
#         except (ValueError, TypeError):
#             element_num = str(x).strip()
#
#         temp_items = []
#
#         # Корректно читаем длину как число
#         length_val = pd.to_numeric(row.get('Длина, мм', None), errors='coerce')
#         if pd.isna(length_val):
#             log_message(f"[!] Пропущена строка с № элемента: {row['№ элемента']} — отсутствует значение 'Длина, мм'", 'error')
#             continue
#         length_mm = int(round(float(length_val)))
#
#         has_tak = pd.notna(row['Так']) and pd.to_numeric(row['Так'], errors='coerce') > 0
#         has_naoborot = pd.notna(row['Наоборот']) and pd.to_numeric(row['Наоборот'], errors='coerce') > 0
#
#         if has_tak:
#             temp_items.append({4.0: element_num, 238175427236.0: "1"})
#         if has_naoborot:
#             temp_items.append({4.0: element_num, 255901398516.0: "1"})
#
#         if has_tak and not has_naoborot:
#             info_str = (
#                 f"Дет.{element_num} - "
#                 f"{int(round(float(pd.to_numeric(row['Так'], errors='coerce'))))} шт."
#                 f"&/{row['Наименование']} L={length_mm} мм"
#             )
#         elif has_naoborot and not has_tak:
#             info_str = (
#                 f"Дет.{element_num} - "
#                 f"{int(round(float(pd.to_numeric(row['Наоборот'], errors='coerce'))))} шт."
#                 f"&/{row['Наименование']} L={length_mm} мм"
#             )
#         elif has_tak and has_naoborot:
#             info_str = (
#                 f"Дет.{element_num}(т) - {int(float(pd.to_numeric(row['Так'], errors='coerce')))} шт.&/"
#                 f"Дет.{element_num}(н) - {int(float(pd.to_numeric(row['Наоборот'], errors='coerce')))} шт.&/"
#                 f"{row['Наименование']}&/L={length_mm} мм"
#             )
#         else:
#             info_str = None
#
#         if info_str:
#             dict_element_info[element_num] = info_str
#
#         if temp_items:
#             key = tuple(paths)
#             if not one_sheet:
#                 while key in dict_a3d:
#                     if len(key) > 1:
#                         key = key[:-1] + (key[-1] + '*',)
#                     else:
#                         key = (key[0] + '*',)
#
#             if key not in dict_a3d:
#                 dict_a3d[key] = []
#             dict_a3d[key].extend(temp_items)
#
#     return dict_a3d, dict_element_info
#
# if __name__ == "__main__":
#     global iKompasDocument2D, iKompasDocument2D1, file_a3d  # <— file_a3d как глобальная, т.к. insert_view читает её
#
#     KompasObject, iApplication, KompasVersion = get_kompas()
#     iDocuments = iApplication.Documents
#
#     #Подготавливаем путь до обрабатываемой папки
#     path = get_active_doc_path(iApplication)
#
#     script = os.path.basename(__file__)
#     if not check_access(script):
#         input(f"❌ Похоже кто-то не задонатил за {script.split('.')[0]}, пропускаем...")
#         sys.exit()
#
# ###
#     xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/Материалы/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
#     path_folder_cdw = easygui.diropenbox("Укажите папку для сохранения чертежей", default=path)
#     file_template = easygui.fileopenbox(msg="Укажите файл шаблона *.cdt", title="",default=f"{path}/*.cdt")
#     if not file_template:
#         print(f'Файл шаблона не указан, выбран шаблон по умолчанию')
#         file_template = f'{path_to_scripts}\\Template\\03 _ СПДС Для деталей.cdt'
#
#     mode_plate = None
#     mode = input(f'Создать проекции элемента в отдельных файлах чертежей, или на одном?'
#                  f'\n(На отдельных - любой текст, На одном - без текста)? > ')
#     if not mode:
#         mode_plate = input(f'Для пластин создать отдельный файл чертежа (Да - любой текст, Нет - без текста)? >')
#     if mode:
#         one_sheet = False
#     else:
#         one_sheet = True
#
#     left_view = None
#     left_view = input(f'Добавить третий проекционный вид слева?'
#                  f'\n(Добавить - любой текст, Нет - без текста)? > ')
#
#     edit_scale = ""
#     edit_scale = input(f'Подобрать масштаб?'
#                  f'\n(Да - любой текст, Нет - без текста)? > ')
#
#     insert_dimensions = ""
#     if KompasVersion > 21:
#         insert_dimensions = input(f'Добавить размеры?'
#                                 f'\n(Да - любой текст, Нет - без текста)? > ')
# ###
#
#     results = []
#
#     if not mode_plate:
#         dict_a3d_exclude, dict_element_info_exclude = df_read(xls, one_sheet)
#         results.append((dict_a3d_exclude, dict_element_info_exclude, 'Детали.cdw'))
#
#     if mode_plate:
#         dict_a3d_exclude, dict_element_info_exclude = df_read(xls, one_sheet, 'Эскиз сечения', ['@016', '@137'], exclude=True)
#         results.append((dict_a3d_exclude, dict_element_info_exclude, 'Детали.cdw'))
#
#         dict_a3d_include, dict_element_info_include = df_read(xls, one_sheet, 'Эскиз сечения', ['@016', '@137'], exclude=False)
#         results.append((dict_a3d_include, dict_element_info_include, 'Пластины.cdw'))
#
#     if not results:
#         print(f'В словаре элементов для создания чертежа - пусто')
#         input('\n\rРабота завершена.\t\n')
#         sys.exit()
#
#     timer = Timer()
#     timer.start()  # Запускаем таймер
#
#     iApplication.HideMessage = con0.ksHideMessageYes
#
#     print(f'Проверяем ссылки на чертежи в объектах спецификации и удаляем предыдущие ориентации...')
#     spec_dict = defaultdict(set)
#     for dict_a3d_exclude, _, _ in results:
#         for paths_tuple, data_list in dict_a3d_exclude.items():
#             numbers = [d[4.0] for d in data_list if 4.0 in d]  # только значения по ключу 4.0
#
#             for raw_path in paths_tuple:
#                 clean_path = raw_path.rstrip('*')  # удаляем *, если есть
#                 spec_dict[clean_path].update(numbers)  # добавляем уникальные значения
#
#     spec_dict = {k: sorted(v, key=extract_number) for k, v in spec_dict.items()} # Преобразуем множества в списки
#
#     for file_a3d, markings in spec_dict.items():
#         if file_a3d.lower().endswith('.m3d'):
#             continue  # Пропускаем файлы с расширением m3d
#         iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)  # a3d
#
#         spec_del_iAttachedDocuments(markings)
#         iKompasDocument_a3d = del_orientation(iKompasDocument_a3d, markings, file_a3d)
#         iKompasDocument_a3d.Save()
#         iKompasDocument_a3d.Close(1)
#
#     for dict_a3d, dict_element_info, name_cdw in results:
#     ### Работаем с чертежом
#         if one_sheet:
#             print(f'\nВставляем все виды в один файл чертежа')
#
#             path_cdw = os.path.join(path_folder_cdw, name_cdw)
#             check = None # Новый файл чертежа не создавали
#             if not os.path.isfile(path_cdw):
#                 _, check = create_cdw(path_cdw, file_template)
#
#     ### Анализируем чертёж
#             print(f'Собираем информацию о существующих видах')
#             iKompasDocument_cdw = iDocuments.Open(path_cdw, False, False)
#             iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument_cdw)
#             iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
#             iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
#             iViews = iViewsAndLayersManager.Views
#
#             view_association_dict = {}
#             final_view_association_dict = {}
#
#             if KompasVersion > 21:
#                 if not check:
#                     for i in range(iViews.Count):
#                         iView = iViews.View(i)
#                         if iView.Type == 10032:
#                             iAssociationView = API7.IAssociationView(iView)
#                             if not iAssociationView.BaseView:
#                                 iView_name = iView.Name
#                                 iView_number = iView.Number
#                                 print(f'Ассоциативный главный вид {iView_name} найден')
#                                 view_association_dict[iView_number] = (iView_name, iView, iAssociationView)
#
#                     ### Редактируем существующие виды
#                     print(f'Проверяем имена видов и при необходимости редактируем')
#                     updated = edit_view(view_association_dict)
#                     final_view_association_dict.update(updated)
#                     final_view_association_dict.update(view_association_dict)
#
#             print(f'\nНаходим элемент и вставляем ЛСК для вставки элемента в чертеж')
#             for paths_tuple, item_list in dict_a3d.items():
#                 cleaned_paths = [p.rstrip('*') for p in paths_tuple]
#                 first_a3d = cleaned_paths[0]  # только с ним работаем геометрически
#
#                 iKompasDocument_a3d = iDocuments.Open(first_a3d, False, False)
#                 iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)
#
#                 dict_a3d_elem = {first_a3d: item_list}
#
#                 # Находим тела/ЛСК и т.д.
#                 iKompasDocument_a3d.Active = True
#                 dict_2d = search_body(dict_a3d_elem, dict_element_info)
#
#                 existing_markings = {data[0]: key for key, data in final_view_association_dict.items()}
#
#                 attachments = []  # сюда сложим (marking, path_cdw) для последующей привязки
#
#                 for marking, (safe_array, text, embodiement) in dict_2d.items():
#                     iKompasDocument_cdw.Active = True
#
#                     # ВАЖНО: передать исходный a3d во вставку (insert_view читает глобальную file_a3d)
#                     file_a3d = first_a3d
#
#                     print(f'Обрабатываем элемент {marking}')
#                     if marking in existing_markings:
#                         print(f'{marking} - вид вставлен ранее')
#                         key_in_dict = existing_markings[marking]
#                         iView = final_view_association_dict[key_in_dict][1]
#                         path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale,
#                                                iView, embodiement)
#                     else:
#                         path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale,
#                                                None, embodiement)
#                         print(f'{marking} - Готово')
#
#                     iKompasDocument_cdw.Save()
#                     attachments.append((marking, path_cdw))  # копим для дальнейшей привязки
#
#                 # Закрываем первый a3d, чтобы функция могла сама его открыть при необходимости
#                 iKompasDocument_a3d.Close(1)
#
#                 # Привязка cdw ко всем .a3d из набора (включая первый)
#                 for marking, cdw_path in attachments:
#                     spec_attach_to_all_a3d(marking, cdw_path, paths_tuple)
#
#             iKompasDocument_cdw.Close(1)
#
#         if not one_sheet:
#
#             print(f'\nВставляем виды в отдельные файлы чертежей')
#             for paths_tuple, item_list in dict_a3d.items():
#                 cleaned_paths = [p.rstrip('*') for p in paths_tuple]
#                 first_a3d = cleaned_paths[0]  # только с ним строим вид/чертёж
#
#                 item = item_list[0]
#                 marking = item.get(4.0)
#                 path_cdw = os.path.join(path_folder_cdw, marking + '.cdw')
#                 check = False
#
#                 if not os.path.isfile(path_cdw):
#                     path_cdw, check = create_cdw(path_cdw, file_template)
#
#                 print(f'Анализируем существующий чертеж для {marking}')
#                 iKompasDocument_cdw = iDocuments.Open(path_cdw, False, False)
#                 iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument_cdw)
#                 iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
#                 iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
#                 iViews = iViewsAndLayersManager.Views
#
#                 view_association_dict = {}
#                 final_view_association_dict = {}
#
#                 if KompasVersion >= 23:
#                     for i in range(iViews.Count):
#                         iView = iViews.View(i)
#                         if iView.Type == 10032:
#                             iView_name = iView.Name
#                             iView_number = iView.Number
#                             iAssociationView = API7.IAssociationView(iView)
#                             if not iAssociationView.BaseView:
#                                 print(f'Ассоциативный главный вид {iView_name} найден')
#                                 view_association_dict[iView_number] = (iView_name, iView, iAssociationView)
#
#                     updated = edit_view(view_association_dict)
#                     final_view_association_dict.update(updated)
#                     final_view_association_dict.update(view_association_dict)
#
#                 iKompasDocument_a3d = iDocuments.Open(first_a3d, False, False)
#                 iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)
#
#                 dict_a3d_elem = {first_a3d: item_list}
#
#                 iKompasDocument_a3d.Active = True
#                 dict_2d = search_body(dict_a3d_elem, dict_element_info)
#                 existing_markings = {data[0]: data[1] for data in final_view_association_dict.values()}
#
#                 for marking, (safe_array, text, embodiement) in dict_2d.items():
#                     iKompasDocument_cdw.Active = True
#
#                     # ВАЖНО: передать исходный a3d во вставку
#                     file_a3d = first_a3d
#
#                     print(f'Обрабатываем элемент {marking}')
#                     if marking in existing_markings:
#                         iView = existing_markings[marking]
#                         path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale,
#                                                iView, embodiement)
#                     else:
#                         path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale,
#                                                None, embodiement)
#
#                     # Закрываем чертёж и первый a3d
#                     iKompasDocument_cdw.Close(1)
#                     iKompasDocument_a3d.Active = True
#                     iKompasDocument_a3d.Save()
#                     iKompasDocument_a3d.Close(1)
#
#                     # Привязываем cdw ко всем .a3d из набора (включая первый)
#                     spec_attach_to_all_a3d(marking, path_cdw, paths_tuple)
#
#                     print(f'{marking} - Готово\n')
#
#     iApplication.HideMessage = con0.ksShowMessage
#     print(f'\n{timer.stop()}')
#     input('\rРабота завершена.  \n')


# import sys
#
# from __Kompas import *
# from _Config import *
# from __ExcelHandler import ExcelHandler
# from pathlib import Path
# import pandas as pd
# from __Debug import *
# from win32com.client import VARIANT
# import easygui, re
# import pythoncom
# import numpy as np
# import math
#
# from collections import defaultdict
# from __Utils import Timer
# from __K_autorupture import *
# from __K_autodimensions import add_linear_dimensions
# from __K_autoscale import auto_scale
#
# def extract_coords(obj):
#     type_name = type(obj).__name__
#     if type_name == "ILineSegment":
#         return (obj.X1, obj.Y1, obj.X2, obj.Y2)
#     elif type_name == "ICircle":
#         return (obj.X, obj.Y, obj.Radius)
#     if type_name == "ILineDimension":
#         return (obj.X3, obj.Y3)
#     else:
#         return ()
#
# def extract_number(value):
#     try:
#         # Попробуем напрямую преобразовать к числу
#         return float(value)
#     except (ValueError, TypeError):
#         # Если не получилось — ищем первое число в строке (целое или с точкой)
#         match = re.search(r'\d+(?:\.\d+)?', str(value))
#         return float(match.group()) if match else float('inf')  # если нет цифр — в конец
#
# def _coll_count(coll):
#     try:
#         return int(getattr(coll, "Count"))
#     except Exception:
#         try:
#             return len(coll)
#         except Exception:
#             return 0
#
# def _coll_item(coll, idx):
#     try:
#         return coll.Item(idx)
#     except Exception:
#         try:
#             return coll[idx]
#         except Exception:
#             return None
#
# def _norm_path(p):
#     try:
#         return os.path.normcase(os.path.normpath(p))
#     except Exception:
#         return str(p or "")
#
# def search_body(dict_a3d, dict_element_info):
#     '''Функция ищет нужное тело в том числе в исполнении'''
#     file_a3d, dict_list = next(iter(dict_a3d.items()))
#     log_message(f'Работаем с файлом  {file_a3d}', 'how')
#
#     result_dict = {}
#     processed_markings = set()
#
#     if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
#         iPart7 = iKompasDocument3D.TopPart
#
#         iEmbodimentsManager = API7.IEmbodimentsManager(iPart7)
#         iEmbodimentsManager.SetCurrentEmbodiment(0)
#         iModelObject = API7.IModelObject(iPart7)
#         iModelObject.Update()
#         # iEmbodiment = iEmbodimentsManager.TopEmbodiment
#         # iEmbodiment.IsCurrent = True
#
#         for i in range(iEmbodimentsManager.EmbodimentCount):
#             for check_dict in dict_list:
#                 marking = next(iter(check_dict.values()))
#
#                 if marking in processed_markings:
#                     # print('Элемент уже был - пропускаем')
#                     continue  # уже нашли, пропускаем
#
#                 iEmbodiment = iEmbodimentsManager.Embodiment(i)
#                 iEmbodimentsManager.SetCurrentEmbodiment(i)
#                 # iModelObject.Update()
#
#                 # iEmbodimentsManager.CurrentEmbodiment
#                 # iEmbodiment.IsCurrent = True
#                 # print(f'iEmbodiment.IsCurrent:{iEmbodiment.IsCurrent}')
#                 # print(f'iEmbodiment.Name:{iEmbodiment.GetMarking(-1, 0)}')
#
#                 iFeature7 = API7.IFeature7(iEmbodiment.Part)
#                 result_bodies = iFeature7.ResultBodies
#                 # print(f'result_bodies:{result_bodies}')
#
#                 iBody7 = check_bodies(iKompasDocument_a3d, result_bodies, check_dict)
#                 # print(f'iBody7:{iBody7}')
#                 if iBody7:
#                     log_message(f'Элемент с номером {marking} найден в исполнении {iEmbodiment.GetMarking(-1, 0)}')
#                     iPart7 = iKompasDocument3D.TopPart
#                     lsk_check = insert_view_orientation(marking, iPart7, iBody7)
#                     # print(f'{cyan}Вставили ЛСК - {lsk_check}{default}')
#                     arr = (iBody7,)
#                     safe_array = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_DISPATCH, arr)
#                     text = dict_element_info.get(marking, "")
#                     result_dict[marking] = [safe_array, text, i]
#
#                     processed_markings.add(marking)  # отметим, что уже обработан
#
#         # iEmbodiment = iEmbodimentsManager.TopEmbodiment
#         iEmbodimentsManager.SetCurrentEmbodiment(0)
#         # iEmbodiment.IsCurrent = True
#         iKompasDocument_a3d.Save()
#
#     if KompasVersion == 21 or iKompasDocument_a3d.DocumentType == 4.0:
#         for check_dict in dict_list:
#             marking = next(iter(check_dict.values()))
#             safe_array = ''
#             text = dict_element_info.get(marking, "")
#             result_dict[marking] = [safe_array, text, 0]
#
#             processed_markings.add(marking)  # отметим, что уже обработан
#
#     return result_dict
#
# def check_bodies(iKompasDocument, result_bodies, check_dict):
#     """Проверяет свойства тел и возвращает подходящее тело"""
#     result = [(float(k), v) for k, v in check_dict.items()]
#     iPropertyMng = API7.IPropertyMng(iApplication)
#
#     def matches_body_properties(iBody7):
#         """Сравнивает свойства тела с искомыми значениями"""
#         iPropertyKeeper = API7.IPropertyKeeper(iBody7)
#         for key, value in result:
#             val = iPropertyKeeper.GetPropertyValue(iPropertyMng.GetProperty(iKompasDocument, key), 0, 1, 1)[1]
#             if str(val) != str(value):
#                 return False
#         return True
#
#     iBody7 = next((body for body in (result_bodies if isinstance(result_bodies, tuple) else [result_bodies])
#                    if matches_body_properties(body)), None)
#     return iBody7
#
# def insert_view_orientation(marking, iPart7, iBody7):
#
#     elem = []  # Список для удаления временных объектов
#     iFeature7 = API7.IFeature7(iBody7)
#     iFaces = iFeature7.ModelObjects(con3.o3d_face)
#     iAxes3D = API7.IAuxiliaryGeomContainer(iPart7).Axes3D
#
#     largest_area_sum, largest_face_sum = -1, None  # для цилиндров/конусов
#     largest_plane_area, largest_plane_face = -1, None  # для плоских граней
#     longest_length, longest_edge = -1, None  # для самой длинной прямой ребра
#     surface3D_type2 = False  # флаг — найдена ли хотя бы одна плоская грань
#
#     # --- Анализ всех граней тела ---
#     for iFace in iFaces:
#         iMathSurface3D = iFace.MathSurface
#         if iMathSurface3D.Surface3DType in {3, 4}:  # Конус или цилиндр
#             # Создаём оси-ребра для скруглений для оси Y
#             iAxis3D = iAxes3D.Add(con3.o3d_axisConeFace)
#             API7.IAxis3DByConeface(iAxis3D).Face = iFace
#             iAxis3D.Update()
#             elem.append(iAxis3D)
#
#             area_cone = iFace.GetArea(3)  # Площадь цилиндрической грани
#             connected_faces = iFace.ConnectedFaces  # Стыкуемые грани
#
#             flat_faces = [f for f in connected_faces if
#                           f.MathSurface.Surface3DType == 2]  # Получаем только плоские грани
#
#             if not flat_faces:
#                 flat_faces = [iFace]  # Если плоских граней нет используем найденную
#
#             total_area_flats = sum(f.GetArea(3) for f in flat_faces)  # Получаем площади стыкуемых плоских граней
#             total_area = area_cone + total_area_flats  # Суммарная площадь цилиндра и прилегающих плоскостей
#
#             # Запоминаем набор с максимальной суммарной площадью
#             if total_area > largest_area_sum:
#                 largest_area_sum = total_area
#
#                 max_face = max(flat_faces, key=lambda f: f.GetArea(3))  # среди плоских выбираем с наибольшей площадью
#                 if max_face.GetArea(3) > area_cone:  # сравниваем: плоская грань или цилиндрическая больше по площади
#                     largest_face_sum = max_face
#                 else:
#                     # print('труба')
#                     largest_face_sum = iFace  # цилиндрическая грань крупнее — выбираем её
#
#         elif iMathSurface3D.Surface3DType == 2:  # Если цилиндрических нет работаем с плоской гранью
#             surface3D_type2 = True
#             area = iFace.GetArea(3)
#             if area > largest_plane_area:
#                 largest_plane_area = area
#                 largest_plane_face = iFace
#
#     # --- Выбор итоговой "лучшей" плоскости для оси X ---
#     if largest_plane_area > largest_area_sum:
#         largest_area = largest_plane_area
#         largest_face = largest_plane_face
#     else:
#         largest_area = largest_area_sum
#         largest_face = largest_face_sum
#
#     for iEdge in iFeature7.ModelObjects(con3.o3d_edge):
#         if iEdge.GetLength(3) > longest_length:
#             longest_length, longest_edge = iEdge.GetLength(3), iEdge
#
#     iMassInertiaParam7 = API7.IMassInertiaParam7(iBody7)
#     Xc, Yc, Zc = iMassInertiaParam7.Xc * 10, iMassInertiaParam7.Yc * 10, iMassInertiaParam7.Zc * 10
#     iLocalCoordinateSystems = API7.IAuxiliaryGeomContainer(iPart7).LocalCoordinateSystems
#     iKompasDocument1 = API7.IKompasDocument1(iKompasDocument_a3d)
#
#     # Удаляем старые ЛСК
#     for i in range(iLocalCoordinateSystems.Count):
#         iLocalCoordinateSystem = iLocalCoordinateSystems.LocalCoordinateSystem(i)
#         if iLocalCoordinateSystem:
#             name_lsk = iLocalCoordinateSystem.Name
#             if name_lsk == marking:
#                 iKompasDocument1.Delete(iLocalCoordinateSystem)
#
#     # Создание ЛСК
#     iLocalCoordinateSystem = iLocalCoordinateSystems.Add()
#     iLocalCoordinateSystem.Name = marking
#     iLocalCoordinateSystem.X, iLocalCoordinateSystem.Y, iLocalCoordinateSystem.Z = Xc, Yc, Zc
#     iLocalCoordinateSystem.Current, iLocalCoordinateSystem.OrientationType = 1, con3.ksAxisOrientation#0
#     iLocalCSAxesDirectionParam = API7.ILocalCSAxesDirectionParam(iLocalCoordinateSystem.LocalCSParameters)
#
#     if longest_edge:
#         iMathSurface3D = largest_face.MathSurface
#         if iMathSurface3D.Surface3DType in {3, 4}:  # Конус или цилиндр
#             # print(f'Большая плоскость конус longest_edge:{longest_edge}')
#             iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, longest_edge)
#         else:
#             # print(f'Большая плоскость не конус longest_edge:{longest_edge}')
#             iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, longest_edge)
#
#     if surface3D_type2:
#         # print(f'largest_face:{largest_face}')
#         iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOY, largest_face)
#
#     iLocalCoordinateSystem.Update()
#
#     for el in elem:  # Удаляем временные объекты
#         # print(f'Удалили {el}')
#         API7.IFeature7(el).Delete()
#
#     # iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)
#     iKompasDocument3D1 = API7.IKompasDocument3D1(iKompasDocument_a3d)
#     iViewProjectionManager = iKompasDocument3D1.ViewProjectionManager
#
#     # Установка нового вида ориентации
#     iModelObject_1 = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeXOZ)
#
#     iPlane3D = API7.IPlane3D(iModelObject_1)
#     iMathSurface3D = iPlane3D.Surface
#     iPlacement3D = iMathSurface3D.Placement
#
#     matrix3D = iPlacement3D.GetMatrix3D()
#
#     iViewProjection7 = iViewProjectionManager.Add()
#     iViewProjection7.SetMatrix3D(matrix3D)
#     iViewProjection7.Name = marking
#     iViewProjection7.Update()
#     # print(f'{cyan}Ориентация {marking} с помощью iViewProjection7.SetMatrix3D')
# ####
#     # Удаляем ЛСК
#     iKompasDocument1.Delete(iLocalCoordinateSystem)
#     iKompasDocument3D.RebuildDocument()
#
#     # Возвращаем изометрию
#     iViewProjection7 = iViewProjectionManager.ViewProjection(7)
#     iViewProjection7.Current = True
#
#     # Показать все
#     # iViewProjectionManager.Scale = iViewProjectionManager_Scale
#     # iDocument3D = KompasObject.ActiveDocument3D()
#     # iDocument3D.ZoomPrevNextOrAll(2)
#     # iDocumentFrames = iKompasDocument_a3d.DocumentFrames
#     # for i in range(iDocumentFrames.Count):
#     #     iDocumentFrame = iDocumentFrames.Item(i)
#     #     if iDocumentFrame.Active:
#     #         iDocumentFrame.ZoomPrevNextOrAll(2)
#     # iDoc = ksDocument2D(iKompasDocument);
#     # iDoc = KompasObject.TransferInterface(iKompasDocument3D, 1, 0)
#     # iDoc.ksZoomPrevNextOrAll(2)
#     # iApplication.ExecuteKompasCommand(con0.ksCMZoomEntireDocument)
#     # KompasObject.ksCMZoomEntireDocument
#
#     return True
#
# def del_orientation(iKompasDocument_a3d, markings, file_a3d):
#     for marking in markings:
#         # iKompasDocument = iDocuments.Open(file_a3d, False, False) #a3d
#         # iKompasDocument_a3d.Active = True
#         # iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)
#         iKompasDocument3D1 = API7.IKompasDocument3D1(iKompasDocument_a3d)
#         iViewProjectionManager = iKompasDocument3D1.ViewProjectionManager
#
#         # Удаляем старую ориентацию с конца
#         for i in reversed(range(iViewProjectionManager.Count)):
#             iViewProjection7 = iViewProjectionManager.ViewProjection(i)
#             if iViewProjection7:
#                 name_ViewProjection = iViewProjection7.Name
#                 # print(name_ViewProjection)
#                 if name_ViewProjection == marking:
#                     # check = iViewProjection7.Delete()
#                     if iViewProjection7.Delete():
#                         log_message(f'Удалили ориентацию {marking} в {file_a3d}')
#                     # print(f'{cyan}Удалили старую ориентацию - {name_ViewProjection}{default}')
#                     iViewProjection7.Update()
#                     # iKompasDocument3D.RebuildDocument()
#                     iKompasDocument_a3d.Save()
#                     iKompasDocument_a3d.Close(1)
#                     iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)
#
#     return iKompasDocument_a3d
#
# def create_cdw(path, file_template = None):
#     #
#     # if os.path.isfile(path_cdw):
#     #     return path
#     #Создаёт чертеж
#     file_name = os.path.basename(path)
#
#     iKompasDocument = iDocuments.Open(file_template, False, True)
#     iLayoutSheets = iKompasDocument.LayoutSheets
#     iLayoutSheet = iLayoutSheets.Item(0)
#     iSheetFormat = iLayoutSheet.Format
#     layout_style_number = iLayoutSheet.LayoutStyleNumber
#
#     if one_sheet:
#
#         # layout_style_number = 1001.0
#         iSheetFormat.Format = con0.ksFormatA2
#         vertical_orientation = False
#
#     if not one_sheet:
#         # layout_style_number = 1003.0
#         iSheetFormat.Format = con0.ksFormatA4
#         vertical_orientation = True
#
#     # # Изменим параметры листа оформления
#     iSheetFormat.FormatMultiplicity = 1
#     iSheetFormat.VerticalOrientation = vertical_orientation
#     # iLayoutSheet.LayoutLibraryFileName = f'{path_to_scripts}\\Template\\Drawing_specification_styles.lyt'
#     # iLayoutSheet.LayoutStyleNumber = layout_style_number
#     iLayoutSheet.SheetType = con0.ksDocumentSheet
#     iLayoutSheet.Update()
#
#     # folder_path = os.path.dirname(file_a3d)# Получаем путь до папки куда сохраняем
#     # path_cdw = os.path.join(folder_path, f"{file_name}.cdw")
#     # path_cdw = r'C:\Users\ik\Desktop\КМД\20250220-КМ _ Здание\03 _ Design\01 _CAD\part'
#     iKompasDocument.SaveAs(path_cdw)
#     iKompasDocument.Close(0)
#     log_message(f'Создали файл {file_name}')
#
#     return path, True
#
# def insert_view(marking, text, safe_array=None, one_sheet=None, insert_dimensions=True, edit_scale=True, iView = None, embodiement = 0):
#
#     iView_top = None
#     iView_left = None
#
#     if iView:
#         iView_base = iView
#         iView_base.Current = True
#         iView_base.Update()
#         iAssociationView_base = API7.IAssociationView(iView_base)
#
#     if not iView:
#         if one_sheet:
#             view_X = 0.0
#             view_Y = 0.0
#
#         else:
#             view_X = 112.5
#             view_Y = 150.0
#
#         scale = 1 / 10
#         shift = 3 / scale
#         iAssociationViews = []
#         iView_base = iViews.Add(con0.vt_Standart) # Создаём графический объект "Вид"
#         iView_base.X, iView_base.Y, iView_base.Scale = view_X, view_Y, scale
#         iViewDesignation = API7.IViewDesignation(iView_base)
#         iViewDesignation.ShowScale = False # Масштаб
#         iViewDesignation.ShowName = False # Масштаб
#
#         iAssociationView_base = API7.IAssociationView(iView_base)
#         iAssociationView_base.SourceFileName = file_a3d
#
#         iAssociationViews.append(iAssociationView_base)
#
#         # iKompasDocument = iDocuments.Open(file_a3d, True, False)
#         iEmbodimentsManager_cdw = API7.IEmbodimentsManager(iAssociationView_base)
#         # print(f'iEmbodimentsManager_cdw:{iEmbodimentsManager_cdw}')
#         # iEmbodiment = iEmbodimentsManager_cdw.Embodiment(1)
#         iEmbodimentsManager_cdw.SetCurrentEmbodiment(embodiement)
#         # print(iEmbodimentsManager_cdw.SetCurrentEmbodiment(1))
#         # print(iEmbodiment)
#         # print(f'iEmbodiment.Name:{iEmbodiment.GetMarking(-1, 0)}')
#         # sys.exit(0)
#
#         if KompasVersion > 21:
#             iAssociationView_base.SetProjectionObjects(safe_array)
#
#         iAssociationView_base.ProjectionName = marking
#         iAssociationView_base.VisibleLinesStyle = con0.ksCSNormal
#         iAssociationView_base.BreakLinesVisible = False  # линии переходов
#         iAssociationView_base.HiddenLines = True # передать невидимые линии
#         iAssociationView_base.HiddenLinesVisible = True # невидимые линии
#         iAssociationView_base.Update()
#
#         additional_view = not ('@016' in text or '@137' in text)
#
#         if additional_view:
#             log_message(f'Для {marking} вставили вид сверху {marking}')
#             iView_top = iViews.Add(con0.vt_Projected)
#             iView_top.Name = f"{marking} Сверху"
#             iView_top.X, iView_top.Y, iView_top.Scale = view_X, view_Y - (2/scale), scale
#
#             iViewDesignation = API7.IViewDesignation(iView_top)
#             iViewDesignation.ShowScale = False#Масштаб
#             iViewDesignation.ShowName = False#Масштаб
#
#             iAssociationView_top = API7.IAssociationView(iView_top)
#             iAssociationView_top.ProjectionLink = True
#             iAssociationView_top.VisibleLinesStyle = con0.ksCSNormal
#             iAssociationView_top.BaseView = iView_base
#             iAssociationView_top.BreakLinesVisible = False  # линии переходов
#             iAssociationView_top.HiddenLines = True  # передать невидимые линии
#             iAssociationView_top.HiddenLinesVisible = True  # невидимые линии
#             iView_top.Update()
#
#             iAssociationViews.append(iAssociationView_top)
#
#         script = os.path.basename('_autorupture.pyw')
#         if not check_access(script):
#             log_message(f"❌Похоже кто-то не задонатил за {'Авторазрывы'}, пропускаем...", "error")
#         else:
#             autorupture(iAssociationViews, iKompasDocument2D1, iView_base, 15, 20)
#
#         gabarit_base_view = get_gabarit_object(iView_base, iKompasDocument2D1)
#
#         if iView_top:
#             gabarit_view_top = get_gabarit_object(iView_top, iKompasDocument2D1)
#             iView_top.X = view_X
#             iView_top.Y = view_Y - (shift + (gabarit_base_view[1] + gabarit_view_top[1])/2)
#             iView_top.Update()
#
#         if left_view:
#             log_message(f'Для элемента {marking} вставили вид слева')
#             iView_left = iViews.Add(con0.vt_Projected)
#             iView_left.Name = f"{marking} Слева"
#
#             iView_left.X = view_X + shift
#             iView_left.Y = view_Y
#             iView_left.Scale = scale
#
#             iViewDesignation = API7.IViewDesignation(iView_left)
#             iViewDesignation.ShowScale = False#Масштаб
#             iViewDesignation.ShowName = False#Масштаб
#
#             iAssociationView_left = API7.IAssociationView(iView_left)
#             iAssociationView_left.ProjectionLink = True
#             iAssociationView_left.VisibleLinesStyle = con0.ksCSNormal
#             iAssociationView_left.BaseView = iView_base
#
#             # iAssociationViews.append(iAssociationView_left)
#             iView_left.Update()
#
#             gabarit_view_left = get_gabarit_object(iView_left, iKompasDocument2D1)
#             iView_left.X = view_X + (shift + (gabarit_base_view[0] + gabarit_view_left[0])/2)
#             iView_left.Y = view_Y
#             iView_left.Update()
#
#         script = os.path.basename('__K_autoscale.py')
#         if not check_access(script):
#             log_message(f"Похоже кто-то не задонатил за {'Автомасштабы'}, пропускаем...", "error")
#             edit_scale = False
#
#         if edit_scale:
#             gabarit_geom = get_gabarit_geom(iView_base, iKompasDocument2D1)
#             scale = auto_scale(gabarit_geom)
#             if iView_top:
#                 iView_top.Name = f"{marking} Сверху"
#                 iView_top.Scale = scale
#                 iView_top.Update()
#             if iView_left:
#                 iView_left.Name = f"{marking} Слева"
#                 iView_left.Scale = scale
#                 iView_left.Update()
#             iView_base.Name = f"{marking}"
#             iView_base.Scale = scale
#             iView_base.Update()
#             for iAssociationView in iAssociationViews:
#                 del_BreakLines(iAssociationView)
#             autorupture(iAssociationViews, iKompasDocument2D1, iView_base, 15, 20) # Повторно устанавливаем разрыв
#
#         script = os.path.basename('_K_autodimensions.pyw')
#         if not check_access(script):
#             log_message(f"Похоже кто-то не задонатил за {'Авторазмеры'}, пропускаем...", "error")
#             insert_dimensions = False
#
#         if insert_dimensions:
#             try:
#                 add_linear_dimensions(iView_base, iKompasDocument_cdw, True)
#                 log_message('Образмерили базовый вид')
#             except:
#                 log_message(f'Не удалось образмерить', 'warn')
#             if iView_top:
#                 try:
#                     add_linear_dimensions(iView_top, iKompasDocument_cdw, True)
#                     print("Образмерили вид сверху")
#                 except:
#                     log_message(f'Не удалось образмерить', 'warn')
#             if left_view:
#                 try:
#                     add_linear_dimensions(iView_left, iKompasDocument_cdw, False)
#                     print("Образмерили вид слева")
#                 except:
#                     log_message(f'Не удалось образмерить', 'warn')
#         # Вставляем маркировку
#
#     if one_sheet:
#         # iAssociationView_base.Update()
#         iDrawingContainer = API7.IDrawingContainer(iView_base)
#         iDrawingTexts = iDrawingContainer.DrawingTexts
#
#         iDrawingText = next(
#             (iDrawingTexts.DrawingText(i) for i in range(iDrawingTexts.Count)
#              if "Дет." in API7.IText(iDrawingTexts.DrawingText(i)).Str),
#             None
#         )
#
#         if not iDrawingText:
#             iDrawingText = iDrawingTexts.Add()
#             iDrawingText.Allocation = con0.ksAlLeft
#
#         iText = API7.IText(iDrawingText)
#         iText.Style = con0.ksTSDrawingAnnotation
#         iText.Str = text
#         for i in range(iText.Count):
#             iTextLine = iText.TextLine(i)
#             iTextLine.LeftEdge = 0.0
#             iTextItem = iTextLine.TextItem(0)
#
#             iTextFont = API7.ITextFont(iTextItem)
#             # iTextFont.FontName = "GOST Type AU"
#             iTextFont.Height = 3.5
#             if i == 0:
#                 iTextFont.Underline = True
#             iTextItem.Update()
#
#         _, iText_Y, *_ = get_gabarit_object(iText, iKompasDocument2D1)
#
#         scale = iView_base.Scale
#         iSymbols2DContainer = API7.ISymbols2DContainer(iView_base)
#
#         # Максимальное значение Y из размеров
#         y = max(
#             ( iSymbols2DContainer.LineDimensions.LineDimension(i).Y3
#              for i in range( iSymbols2DContainer.LineDimensions.Count)),
#             default=0
#         )
#
#         # Минимальный X из отрезков и окружностей
#         min_x_segments = [
#             min(seg.X1, seg.X2)
#             for seg in (iDrawingContainer.LineSegments.LineSegment(i)
#                         for i in range(iDrawingContainer.LineSegments.Count))
#         ]
#
#         min_x_circles = [
#             circ.Xc - circ.Radius
#             for circ in (iDrawingContainer.Circles.Circle(i)
#                          for i in range(iDrawingContainer.Circles.Count))
#         ]
#
#         x = min([*min_x_segments, *min_x_circles], default=0)
#
#         iDrawingText.X = x
#         iDrawingText.Y = y + (4 + iText_Y) / scale
#         iDrawingText.Update()
#
#     return path_cdw
#
# def edit_view(view_association_dict):
#
#     if KompasVersion >= 23:
#         updated_views = {}  # сюда будем записывать успешно обработанные
#
#         for iView_number in list(view_association_dict.keys()):
#             iView_name, iView, iAssociationView = view_association_dict[iView_number]
#             # print(iAssociationView.SourceFileName)
#             iKompasDocument_cdw_a3d = iDocuments.Open(iAssociationView.SourceFileName, False, False)
#             iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_cdw_a3d)
#             iKompasDocument_cdw.Active = True
#
#             iBody7 = None
#             if not iAssociationView.SourceFileName.lower().endswith('.m3d'): #Пропускаем m3d
#                 bodies = iAssociationView.GetProjectionObjects(iKompasDocument3D)
#
#                 if bodies:
#                     iBody7 = bodies[0]
#
#                 if not iBody7:
#                     # print(f'Не удалось получить bodies')
#                     continue
#
#                 if iBody7.Marking != iView.Name:
#                     log_message(f'Меняем имя сущ вида {iView.Name} на {iBody7.Marking}')
#                     iView.Name = iBody7.Marking
#                     iView.Update()
#                     # print(f'iView.Update():{iView.Update()}')
#                     iKompasDocument2D1.RebuildDocument()
#
#                     updated_views[iView_number] = (iView.Name, iView, iAssociationView)
#                     del view_association_dict[iView_number]
#
#                 if iBody7.Marking != Path(iKompasDocument_cdw.PathName).stem and not one_sheet:
#                     log_message(f'Чертеж {iKompasDocument_cdw.PathName} для элемента {iBody7.Marking} имеет не верное имя')
#
#             if iAssociationView.SourceFileName.lower().endswith('.m3d'):
#                 iPart7 = iKompasDocument3D.TopPart
#                 marking = iPart7.Marking
#                 if marking != iView.Name:
#                     log_message(f'Меняем имя сущ вида {iView.Name} на {marking}')
#                     iView.Name = marking
#                     iView.Update()
#                     # print(f'iView.Update():{iView.Update()}')
#                     iKompasDocument2D1.RebuildDocument()
#
#                     updated_views[iView_number] = (iView.Name, iView, iAssociationView)
#                     del view_association_dict[iView_number]
#
#                 if Path(iAssociationView.SourceFileName).stem != iView.Name:
#                     log_message(f'Чертеж {iKompasDocument_cdw.PathName} для элемента {marking} имеет не верное имя', 'error')
#
#             # iKompasDocument_a3d.Active = True
#             iKompasDocument_cdw_a3d.Close(0)
#
#     print(f'Виды обработаны')
#     return updated_views
#
# def spec_iAttachedDocuments(marking, cdw_path):
#     """
#     Для каждого базового объекта спецификации:
#       - если у какого-либо тела (Geometry) Marking == marking,
#         добавляет ссылку на чертёж cdw_path (если её ещё нет),
#         удаляет битые ссылки и обновляет объект.
#     Возвращает True, если что-то изменилось.
#     """
#     print('Обновляем ссылки на чертежи в объектах спецификации...')
#     try:
#         if not (KompasVersion >= 23 and int(iKompasDocument_a3d.DocumentType) == 5):
#             return False
#     except Exception:
#         return False
#
#     target_marking = str(marking).strip()
#     target_path_norm = _norm_path(cdw_path)
#
#     try:
#         spec_desc = iKompasDocument_a3d.SpecificationDescriptions.Active
#         base_objects = spec_desc.BaseObjects
#     except Exception:
#         return False
#
#     any_updated = False
#     for i in range(_coll_count(base_objects)):
#         base_obj = _coll_item(base_objects, i)
#         if not base_obj:
#             continue
#
#         geom = getattr(base_obj, "Geometry", None)
#         if not geom or _coll_count(geom) == 0:
#             continue
#
#         matched = False
#         for gi in range(_coll_count(geom)):
#             body = _coll_item(geom, gi)
#             if not body:
#                 continue
#             try:
#                 if str(getattr(body, "Marking", "")).strip() == target_marking:
#                     matched = True
#                     break
#             except Exception:
#                 pass
#         if not matched:
#             continue
#
#         attached = getattr(base_obj, "AttachedDocuments", None)
#         if attached is None:
#             continue
#
#         already_has = False
#         for di in range(_coll_count(attached) - 1, -1, -1):
#             doc = _coll_item(attached, di)
#             if not doc:
#                 continue
#             try:
#                 name = str(getattr(doc, "Name", "")).strip()
#             except Exception:
#                 name = ""
#             if not name or not os.path.isfile(name):
#                 try:
#                     doc.Delete()
#                     any_updated = True
#                 except Exception:
#                     pass
#                 continue
#             if _norm_path(name) == target_path_norm:
#                 already_has = True
#
#         if not already_has:
#             try:
#                 attached.Add(cdw_path, True)
#                 any_updated = True
#             except Exception:
#                 pass
#
#         try:
#             base_obj.Update()
#         except Exception:
#             pass
#
#     if any_updated:
#         try:
#             iKompasDocument_a3d.Save()
#         except Exception:
#             pass
#
#     return any_updated
#
# def _spec_attach_in_doc(doc, marking, cdw_path):
#     """Привязка cdw к ОДНОМУ документу спецификации (doc). Возвращает True, если были изменения."""
#     dt = getattr(doc, "DocumentType", None)
#     if KompasVersion < 23 or dt not in (5, 5.0):
#         return False
#
#     target_marking = str(marking).strip()
#     target_path_norm = _norm_path(cdw_path)
#
#     try:
#         spec_desc = doc.SpecificationDescriptions.Active
#         base_objects = spec_desc.BaseObjects
#     except Exception:
#         return False
#
#     any_updated = False
#
#     for i in range(_coll_count(base_objects)):
#         base_obj = _coll_item(base_objects, i)
#         if not base_obj:
#             continue
#
#         geom = getattr(base_obj, "Geometry", None)
#         if not geom or _coll_count(geom) == 0:
#             continue
#
#         matched = False
#         for gi in range(_coll_count(geom)):
#             body = _coll_item(geom, gi)
#             if not body:
#                 continue
#             try:
#                 if str(getattr(body, "Marking", "")).strip() == target_marking:
#                     matched = True
#                     break
#             except Exception:
#                 pass
#         if not matched:
#             continue
#
#         attached = getattr(base_obj, "AttachedDocuments", None)
#         if attached is None:
#             continue
#
#         already_has = False
#         for di in range(_coll_count(attached) - 1, -1, -1):
#             adoc = _coll_item(attached, di)
#             if not adoc:
#                 continue
#             try:
#                 name = str(getattr(adoc, "Name", "")).strip()
#             except Exception:
#                 name = ""
#             if not name or not os.path.isfile(name):
#                 try:
#                     adoc.Delete()
#                     any_updated = True
#                 except Exception:
#                     pass
#                 continue
#             if _norm_path(name) == target_path_norm:
#                 already_has = True
#
#         if not already_has:
#             try:
#                 attached.Add(cdw_path, True)
#                 any_updated = True
#             except Exception:
#                 pass
#
#         try:
#             base_obj.Update()
#         except Exception:
#             pass
#
#     if any_updated:
#         try:
#             doc.Save()
#         except Exception:
#             pass
#
#     return any_updated
#
#
# def spec_attach_to_all_a3d(marking, cdw_path, paths_tuple, skip_path=None):
#     """
#     Привязать cdw ко ВСЕМ *.a3d из набора paths_tuple.
#     - Не использует уже открытый документ.
#     - Каждый файл открывается/сохраняется/закрывается внутри функции.
#     - Если передан skip_path, этот путь будет пропущен.
#     Возвращает True, если хотя бы в одном документе были изменения.
#     """
#     # нормализуем список путей: убираем '*', берём только .a3d, убираем дубли, исключаем skip_path
#     skip_norm = _norm_path(skip_path) if skip_path else None
#     seen = set()
#     a3d_list = []
#     for p in paths_tuple:
#         p_clean = p.rstrip('*')
#         if not p_clean.lower().endswith('.a3d'):
#             continue
#         n = _norm_path(p_clean)
#         if skip_norm and n == skip_norm:
#             continue
#         if n in seen:
#             continue
#         seen.add(n)
#         a3d_list.append(p_clean)
#
#     any_updated = False
#     for a3d_path in a3d_list:
#         try:
#             doc = iDocuments.Open(a3d_path, False, False)
#             changed = _spec_attach_in_doc(doc, marking, cdw_path)
#             any_updated = changed or any_updated
#             # сохранение уже делается внутри _spec_attach_in_doc при изменениях
#         except Exception as e:
#             log_message(f"Не удалось привязать {Path(cdw_path).name} к {a3d_path}: {e}", "warn")
#         finally:
#             try:
#                 doc.Close(1)
#             except Exception:
#                 pass
#
#     return any_updated
#
#
# # def spec_iAttachedDocuments(marking, cdw_path):
# #     if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
# #         print(f'Обновляем ссылку на чертеж в объекте спецификации')
# #         iSpecificationDescriptions = iKompasDocument_a3d.SpecificationDescriptions
# #         iSpecificationDescription = iSpecificationDescriptions.Active
# #         iSpecificationBaseObjects = iSpecificationDescription.BaseObjects
# #
# #         iSpecificationBaseObject = None
# #         for i in range(iSpecificationBaseObjects.Count):
# #             iSpecificationBaseObject = iSpecificationBaseObjects.Item(i)
# #             iBody7 = iSpecificationBaseObject.Geometry[0]
# #             if iBody7.Marking == marking:
# #                 # break
# #                 if iSpecificationBaseObject:
# #                     iAttachedDocuments = iSpecificationBaseObject.AttachedDocuments
# #                     for i in range(iAttachedDocuments.Count):
# #                         iAttachedDocument = iAttachedDocuments.Item(i)
# #                         if iAttachedDocument:
# #
# #                             if not os.path.isfile(iAttachedDocument.Name):
# #                                 iAttachedDocument.Delete()
# #
# #                             if cdw_path == iAttachedDocument.Name:
# #                                 continue
# #
# #                     iAttachedDocuments.Add(cdw_path, True)
# #                     iSpecificationBaseObject.Update()
# #                     iKompasDocument_a3d.Save()
# #                 return True
# #             else:
# #                 print(f'Что-то со спецификацией c элементом {marking}')
# #                 return False
# #
# # # def spec_iAttachedDocuments(marking, cdw_path):
# # #     if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
# # #         print(f'Обновляем ссылку на чертеж в объекте спецификации')
# # #         iSpecificationDescriptions = iKompasDocument_a3d.SpecificationDescriptions
# # #         iSpecificationDescription = iSpecificationDescriptions.Active
# # #         iSpecificationBaseObjects = iSpecificationDescription.BaseObjects
# # #
# # #         iSpecificationBaseObject = None
# # #         for i in range(iSpecificationBaseObjects.Count):
# # #             iSpecificationBaseObject = iSpecificationBaseObjects.Item(i)
# # #             iBody7 = iSpecificationBaseObject.Geometry[0]
# # #             if iBody7.Marking == marking:
# # #                 break
# # #
# # #         if iSpecificationBaseObject:
# # #             iAttachedDocuments = iSpecificationBaseObject.AttachedDocuments
# # #             for i in range(iAttachedDocuments.Count):
# # #                 iAttachedDocument = iAttachedDocuments.Item(i)
# # #                 if iAttachedDocument:
# # #
# # #                     if not os.path.isfile(iAttachedDocument.Name):
# # #                         iAttachedDocument.Delete()
# # #
# # #                     if cdw_path == iAttachedDocument.Name:
# # #                         continue
# # #
# # #             iAttachedDocuments.Add(cdw_path, True)
# # #             iSpecificationBaseObject.Update()
# # #             iKompasDocument_a3d.Save()
# # #         return True
# # #     else:
# # #         print(f'Что-то со спецификацией c элементом {marking}')
# # #         return False
#
#
#
# def spec_del_iAttachedDocuments(markings):
#     if KompasVersion >= 23 and iKompasDocument_a3d.DocumentType == 5.0:
#         for marking in markings:
#             print(f'Ищем файл чертежа {marking} в объектах спецификации: {file_a3d}')
#             iSpecificationDescriptions = iKompasDocument_a3d.SpecificationDescriptions
#             iSpecificationDescription = iSpecificationDescriptions.Active
#             iSpecificationBaseObjects = iSpecificationDescription.BaseObjects
#
#             for i in range(iSpecificationBaseObjects.Count):
#                 iSpecificationBaseObject = iSpecificationBaseObjects.Item(i)
#                 iBody7 = iSpecificationBaseObject.Geometry[0]
#                 if iBody7.Marking == marking:
#                     print(f'В объекте спецификации элемент {marking} - найден')
#                     iAttachedDocuments = iSpecificationBaseObject.AttachedDocuments
#
#                     for i in range(iAttachedDocuments.Count):
#                         iAttachedDocument = iAttachedDocuments.Item(i)
#                         if iAttachedDocument:
#                             cdw_path = Path(iAttachedDocument.Name)
#                             if Path(cdw_path).stem not in {'Детали', 'Пластины', marking} and Path(cdw_path).is_file():
#                                 print(f'Чертеж с именем файла {cdw_path} следует переименовать в {marking}')
#                                 iAttachedDocument.Delete()
#                                 iSpecificationBaseObject.Update()
#                                 # Формируем новый путь с тем же расширением и директорией, но с именем из marking
#                                 # cdw_path_new = Path(cdw_path).with_name(marking + Path(cdw_path).suffix)
#                                 # cdw_path.rename(cdw_path_new)
#                                 # cdw_path = cdw_path_new
#                                 # iAttachedDocuments.Add(cdw_path, True)
#                                 # check_spec = False
#
#                         if iAttachedDocument and not os.path.isfile(iAttachedDocument.Name):
#                             print(f'Удалили ссылку на чертеж {iAttachedDocument.Name}, так как он не существует')
#                             iAttachedDocument.Delete()
#                             iSpecificationBaseObject.Update()
#                     break
#
#                     iSpecificationBaseObject.Update()
#                     iKompasDocument_a3d.Save()
#     return
#
# def extract_file_paths(raw: str) -> list[str]:
#     """Извлекает .a3d и .m3d пути из строки, даже если в путях есть запятые и точки"""
#     if isinstance(raw, str):
#         return re.findall(r"[A-Z]:\\.*?\.(?:a3d|m3d)", raw, flags=re.IGNORECASE)
#     return []
#
# def df_read(xls, one_sheet, filter_column=None, filter_value=None, exclude=False):
#
#     excel_handler = ExcelHandler(xls)
#     df = excel_handler.read_excel(header_row=1)
#
#     if filter_column and filter_value is not None:
#         if isinstance(filter_value, list):
#             filter_value = [str(val) for val in filter_value]
#             if exclude:
#                 df = df[~df[filter_column].isin(filter_value)]
#             else:
#                 df = df[df[filter_column].isin(filter_value)]
#         else:
#             filter_value = str(filter_value)
#             if exclude:
#                 df = df[~df[filter_column].str.contains(filter_value, na=False)]
#             else:
#                 df = df[df[filter_column] == filter_value]
#
#     df = df[df['№ элемента'].notna()]
#     # df['№ элемента'] = df['№ элемента'].apply(clean_element_num)
#
#     excel_handler.data = df
#     df = df.astype(str)
#     df = excel_handler.restore_symbols('Наименование')
#
#     dict_a3d = {}
#     dict_element_info = {}
#
#     for _, row in df.iterrows():
#         # Извлекаем пути в зависимости от условий
#         if KompasVersion >= 23 and row['Тип объекта'] == 'Тело':
#             paths = extract_file_paths(row.get('Путь до марки', ''))
#         else:
#             paths = extract_file_paths(row.get('Полное имя файла', ''))
#
#             m3d_paths = [p for p in paths if p.lower().endswith('.m3d')] # Фильтрация путей только с .m3d
#             if not m3d_paths:
#                 print(f'Пропускаем файл: {paths} (так как нет пути в столбце "Полное имя файла")')
#                 continue
#             paths = m3d_paths
#
#         # element_num = str(int(float(row['№ элемента'])))
#         x = row['№ элемента']
#         try:
#             # Попытка привести к числу — если получилось, обрезаем дробную часть
#             element_num = str(int(float(x)))
#         except (ValueError, TypeError):
#             # Если не число — просто берём как строку без лишних пробелов
#             element_num = str(x).strip()
#
#         # element_num = str(row['№ элемента']).strip() #1011.0 → '1011.0' '1011-01' → '1011-01' для строки
#         # element_num = str(row['№ элемента']) if pd.notna(row['№ элемента']) else ""
#
#         temp_items = []
#
#         if math.isnan(row['Длина, мм']):
#             log_message(f"[!] Пропущена строка с № элемента: {row['№ элемента']} — отсутствует значение 'Длина, мм'", 'error')
#             continue
#
#         has_tak = pd.notna(row['Так']) and pd.to_numeric(row['Так'], errors='coerce') > 0
#         has_naoborot = pd.notna(row['Наоборот']) and pd.to_numeric(row['Наоборот'], errors='coerce') > 0
#
#         if has_tak:
#             temp_items.append({4.0: element_num, 238175427236.0: "1"})
#         if has_naoborot:
#             temp_items.append({4.0: element_num, 255901398516.0: "1"})
#
#         if has_tak and not has_naoborot:
#             # info_str = f"Дет.{element_num} - {int(float(row['Так']))} шт.&/{row['Наименование']}&/L={int(float(round(row['Длина, мм']),0))} мм"
#             info_str = (
#                 f"Дет.{element_num} - "
#                 f"{int(round(float(row['Так'])))} шт."
#                 f"&/{row['Наименование']} L={int(round(float(row['Длина, мм'])))} мм"
#                 # f"&/L={int(round(float(row['Длина, мм'])))} мм"
#             )
#         elif has_naoborot and not has_tak:
#             # info_str = f"Дет.{element_num}(н)-{int(float(row['Наоборот']))} шт.&/{row['Наименование']}&/L={int(float(row['Длина, мм']))} мм"
#             info_str = (
#                 f"Дет.{element_num} - "
#                 f"{int(round(float(row['Наоборот'])))} шт."
#                 f"&/{row['Наименование']} L={int(round(float(row['Длина, мм'])))} мм"
#                 # f"&/L={int(round(float(row['Длина, мм'])))} мм"
#             )
#         elif has_tak and has_naoborot:
#             info_str = (
#                 f"Дет.{element_num}(т) - {int(float(row['Так']))} шт.&/"
#                 f"Дет.{element_num}(н) - {int(float(row['Наоборот']))} шт.&/"
#                 f"{row['Наименование']}&/L={int(round(float(row['Длина, мм'])))} мм"
#             )
#         else:
#             info_str = None
#
#         if info_str:
#             dict_element_info[element_num] = info_str
#
#         if temp_items:
#             key = tuple(paths)
#             if not one_sheet:
#                 while key in dict_a3d:
#                     if len(key) > 1:
#                         key = key[:-1] + (key[-1] + '*',)
#                     else:
#                         key = (key[0] + '*',)
#
#             if key not in dict_a3d:
#                 dict_a3d[key] = []
#             dict_a3d[key].extend(temp_items)
#
#     # if not dict_a3d:
#     #     print(f'{red}В словаре элементов для создания чертежа - пусто{default}')
#     #     input('\n\rРабота завершена.\t\n')
#     #     sys.exit()
#
#     return dict_a3d, dict_element_info
#
#
# if __name__ == "__main__":
#     global iKompasDocument2D, iKompasDocument2D1
#
#     KompasObject, iApplication, KompasVersion = get_kompas()
#     iDocuments = iApplication.Documents
#
#     #Подготавливаем путь до обрабатываемой папки
#     path = get_active_doc_path(iApplication)
#
#     script = os.path.basename(__file__)
#     if not check_access(script):
#         input(f"❌ Похоже кто-то не задонатил за {script.split('.')[0]}, пропускаем...")
#         sys.exit()
#
# ###
#     xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/Материалы/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
#     path_folder_cdw = easygui.diropenbox("Укажите папку для сохранения чертежей", default=path)
#     file_template = easygui.fileopenbox(msg="Укажите файл шаблона *.cdt", title="",default=f"{path}/*.cdt")
#     if not file_template:
#         print(f'Файл шаблона не указан, выбран шаблон по умолчанию')
#         file_template = f'{path_to_scripts}\\Template\\03 _ СПДС Для деталей.cdt'
#
#     mode_plate = None
#     mode = input(f'Создать проекции элемента в отдельных файлах чертежей, или на одном?'
#                  f'\n(На отдельных - любой текст, На одном - без текста)? > ')
#     if not mode:
#         mode_plate = input(f'Для пластин создать отдельный файл чертежа (Да - любой текст, Нет - без текста)? >')
#     if mode:
#         one_sheet = False
#     else:
#         one_sheet = True
#
#     left_view = None
#     left_view = input(f'Добавить третий проекционный вид слева?'
#                  f'\n(Добавить - любой текст, Нет - без текста)? > ')
#
#     edit_scale = ""
#     edit_scale = input(f'Подобрать масштаб?'
#                  f'\n(Да - любой текст, Нет - без текста)? > ')
#
#     insert_dimensions = ""
#     if KompasVersion > 21:
#         insert_dimensions = input(f'Добавить размеры?'
#                                 f'\n(Да - любой текст, Нет - без текста)? > ')
# ###
#
#     # xls = r'C:\Users\ik\Desktop\Пример\01 _ CAD\Материалы\1.2 _ Ведомость элементов.xlsx'
#     # path_folder_cdw = r'C:\Users\ik\Desktop\Пример\01 _ CAD\Материалы'
#     # mode = False
#     # mode_plate = False
#     # left_view = True
#     # edit_scale = True
#     # insert_dimensions = True
#     # one_sheet = True
#
#     results = []
#
#     if not mode_plate:
#         dict_a3d_exclude, dict_element_info_exclude = df_read(xls, one_sheet)
#         results.append((dict_a3d_exclude, dict_element_info_exclude, 'Детали.cdw'))
#
#     if mode_plate:
#         dict_a3d_exclude, dict_element_info_exclude = df_read(xls, one_sheet, 'Эскиз сечения', ['@016', '@137'], exclude=True)
#         results.append((dict_a3d_exclude, dict_element_info_exclude, 'Детали.cdw'))
#
#         dict_a3d_include, dict_element_info_include = df_read(xls, one_sheet, 'Эскиз сечения', ['@016', '@137'], exclude=False)
#         results.append((dict_a3d_include, dict_element_info_include, 'Пластины.cdw'))
#
#     if not results:
#         print(f'В словаре элементов для создания чертежа - пусто')
#         input('\n\rРабота завершена.\t\n')
#         sys.exit()
#
#     timer = Timer()
#     timer.start()  # Запускаем таймер
#
#     iApplication.HideMessage = con0.ksHideMessageYes
#
#     print(f'Проверяем ссылки на чертежи в объектах спецификации и удаляем предыдущие ориентации...')
#     spec_dict = defaultdict(set)
#     for dict_a3d_exclude, _, _ in results:
#         for paths_tuple, data_list in dict_a3d_exclude.items():
#             numbers = [d[4.0] for d in data_list if 4.0 in d]  # только значения по ключу 4.0
#
#             for raw_path in paths_tuple:
#                 clean_path = raw_path.rstrip('*')  # удаляем *, если есть
#                 spec_dict[clean_path].update(numbers)  # добавляем уникальные значения
#
#     # spec_dict = {k: sorted(v, key=int) for k, v in spec_dict.items()} # Преобразуем множества в списки
#     spec_dict = {k: sorted(v, key=extract_number) for k, v in spec_dict.items()} # Преобразуем множества в списки
#
#     for file_a3d, markings in spec_dict.items():
#         if file_a3d.lower().endswith('.m3d'):
#             continue  # Пропускаем файлы с расширением m3d
#         # print(f"{file_a3d}: {markings}")
#         iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)  # a3d
#
#         spec_del_iAttachedDocuments(markings)
#         iKompasDocument_a3d = del_orientation(iKompasDocument_a3d, markings, file_a3d)
#         iKompasDocument_a3d.Save()
#         iKompasDocument_a3d.Close(1)
#
#     for dict_a3d, dict_element_info, name_cdw in results:
#     ### Работаем с чертежом
#         if one_sheet:
#             print(f'\nВставляем все виды в один файл чертежа')
#
#             path_cdw = os.path.join(path_folder_cdw, name_cdw)
#             check = None # Новый файл чертежа не создавали
#             if not os.path.isfile(path_cdw):
#                 _, check = create_cdw(path_cdw, file_template)
#
#     ### Анализируем чертёж
#             print(f'Собираем информацию о существующих видах')
#             iKompasDocument_cdw = iDocuments.Open(path_cdw, False, False)
#             iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument_cdw)
#             iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
#             iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
#             iViews = iViewsAndLayersManager.Views
#
#             view_association_dict = {}
#             final_view_association_dict = {}
#
#             if KompasVersion > 21:
#                 if not check:
#                     for i in range(iViews.Count):
#                         iView = iViews.View(i)
#                         if iView.Type == 10032:
#                             iAssociationView = API7.IAssociationView(iView)
#                             if not iAssociationView.BaseView:
#                                 iView_name = iView.Name
#                                 iView_number = iView.Number
#                                 print(f'Ассоциативный главный вид {iView_name} найден')
#                                 view_association_dict[iView_number] = (iView_name, iView, iAssociationView)
#
#                     ### Редактируем существующие виды
#                     print(f'Проверяем имена видов и при необходимости редактируем')
#                     updated = edit_view(view_association_dict)
#                     final_view_association_dict.update(updated)
#                     final_view_association_dict.update(view_association_dict)
#
#             print(f'\nНаходим элемент и вставляем ЛСК для вставки элемента в чертеж')
#             for file_list_a3d, item_list in dict_a3d.items():
#                 file_list_a3d = (file_list_a3d[0],)  # Берем только первый путь в кортеже
#                 file_list_ather_a3d = file_list_a3d[1:]  # Сохраняем оставшиеся пути
#                 for file_a3d in file_list_a3d:
#
#                     iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)
#                     iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)
#
#                     dict_a3d_elem = {file_a3d: item_list}
#                     # view_association_dict = edit_view(item_list, view_association_dict)  ### Редактируем имена существующих видов список видов сущ чертежа
#
#         ### Находим элемент и вставляем ЛСК и получаем информацию для вставки в чертеж
#                     iKompasDocument_a3d.Active = True
#                     dict_2d = search_body(dict_a3d_elem, dict_element_info) #Вставляем ориентации и получаем тела для проецирования в модель
#                     # print(f'final_view_association_dict:{final_view_association_dict}')
#                     existing_markings = {data[0]: key for key, data in final_view_association_dict.items()} # Получаем все iView из view_association_dict
#
#                     for marking, (safe_array, text, embodiement) in dict_2d.items():
#                         iKompasDocument_cdw.Active = True
#                         print(f'Обрабатываем элемент {marking}')
#                         if marking in existing_markings:
#                             print(f'{marking} - вид вставлен ранее')
#                             key_in_dict = existing_markings[marking]
#                             iView = final_view_association_dict[key_in_dict][1]
#                             path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale, iView, embodiement)
#                             continue
#
#                         else:
#                             path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale,None, embodiement)
#                             print(f'{marking} - Готово')
#
#                         iKompasDocument_cdw.Save()
#                         iKompasDocument_a3d.Active = True
#
#                         if not file_a3d.lower().endswith('.m3d'):
#                             spec_iAttachedDocuments(marking, path_cdw) # Пропускаем файлы с расширением m3d
#
#                     iKompasDocument_a3d.Close(1)
#
#                     # for marking, (safe_array, text, embodiement) in dict_2d.items():
#                     #     for file_a3d in file_list_ather_a3d:
#                     #         iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)
#                     #         spec_iAttachedDocuments(marking, path_cdw)
#                     #         iKompasDocument_a3d.Close(1)
#
#             iKompasDocument_cdw.Close(1)
#
#         if not one_sheet:
#
#             print(f'\nВставляем виды в отдельные файлы чертежей')
#             for file_a3d, item_list in dict_a3d.items():
#
#                 file_a3d = file_a3d[0]  # Берем первый путь до сборки
#                 file_a3d = file_a3d.split('*', 1)[0]
#
#                 item = item_list[0]  # Берём единственный словарь из списка
#                 marking = item.get(4.0)
#                 path_cdw = os.path.join(path_folder_cdw, marking + '.cdw')
#                 check = False  # Новый файл чертежа не создавали
#
#                 if not os.path.isfile(path_cdw):
#                     path_cdw, check = create_cdw(path_cdw, file_template)
#
#     ### Анализируем существующий чертёж
#                 print(f'Анализируем существующий чертеж для {marking}')
#                 iKompasDocument_cdw = iDocuments.Open(path_cdw, False, False)
#                 iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument_cdw)
#                 iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
#                 iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
#                 iViews = iViewsAndLayersManager.Views
#
#                 view_association_dict = {}
#                 final_view_association_dict = {}
#
#                 if KompasVersion >= 23:
#                     for i in range(iViews.Count):
#                         iView = iViews.View(i)
#                         if iView.Type == 10032:
#                             iView_name = iView.Name
#                             iView_number = iView.Number
#                             iAssociationView = API7.IAssociationView(iView)
#                             if not iAssociationView.BaseView:
#                                 print(f'Ассоциативный главный вид {iView_name} найден')
#                                 view_association_dict[iView_number] = (iView_name, iView, iAssociationView)
#
#                     updated = edit_view(view_association_dict)
#                     final_view_association_dict.update(updated)
#                     final_view_association_dict.update(view_association_dict)
#
#                 iKompasDocument_a3d = iDocuments.Open(file_a3d, False, False)
#                 iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument_a3d)
#
#                 dict_a3d_elem = {file_a3d: item_list}
#                 # view_association_dict = edit_view(item_list, view_association_dict)  ### Редактируем имена существующих видов список видов сущ чертежа
#
#                 ### Находим элемент и вставляем ЛСК и получаем информацию для вставки в чертеж
#                 iKompasDocument_a3d.Active = True
#                 dict_2d = search_body(dict_a3d_elem, dict_element_info)  # Вставляем ориентации и получаем тела для проецирования в модель
#                 # dict_2d:{'401': [win32com.client.VARIANT(8201, (<win32com....44>,)), 'Дет.401 - 1 шт.&/@131120x120x5 С345&/L=5850 мм']}
#                 existing_markings = {data[0]: data[1] for data in final_view_association_dict.values()}  # Получаем все iView из view_association_dict
#
#                 for marking, (safe_array, text, embodiement) in dict_2d.items():
#                     iKompasDocument_cdw.Active = True
#                     print(f'Обрабатываем элемент {marking}')
#                     if marking in existing_markings:
#                         iView = existing_markings[marking]
#                         path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale, iView, embodiement)
#                         iKompasDocument_cdw.Close(1)
#                         iKompasDocument_a3d.Active = True
#                         if not file_a3d.lower().endswith('.m3d'):
#                             spec_iAttachedDocuments(marking, path_cdw)  # Пропускаем файлы с расширением m3d
#                         iKompasDocument_a3d.Save()
#                         iKompasDocument_a3d.Close(1)
#                         print(f'{marking} - вставлен ранее\n')
#                         continue
#
#                     else:
#                         path_cdw = insert_view(marking, text, safe_array, one_sheet, insert_dimensions, edit_scale, None, embodiement)
#                         iKompasDocument_cdw.Close(1)
#                         iKompasDocument_a3d.Active = True
#                         if not file_a3d.lower().endswith('.m3d'):
#                             spec_iAttachedDocuments(marking, path_cdw) # Пропускаем файлы с расширением m3d
#                         iKompasDocument_a3d.Save()
#                         iKompasDocument_a3d.Close(1)
#                         print(f'{marking} - Готово\n')
#
#     iApplication.HideMessage = con0.ksShowMessage
#     print(f'\n{timer.stop()}')
#     input('\rРабота завершена.	\n')