# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Dict, Tuple, Optional
from pathlib import Path
import os, sys
import re

import easygui

from __Kompas import get_kompas, get_active_doc_path, log_message
from __TextTransform import text_transform_with_font
from _Config import xlsx_base, path_to_scripts

# ==== Константы ключей ====
KEY_ADDR = 'Адрес объекта'
KEY_NAME = 'Наименование проекта'
KEY_CODE = 'Шифр проекта'
KEY_STAGE = 'Стадия проекта'
KEY_ORG = 'Организация'
KEY_MONTH = 'Месяц сдачи проекта'
HARD_BREAK = '&/'

# ==== Геометрия полей штампа (мм) ====
ADDR_W, ADDR_H_DEFAULT, ADDR_H_WITH_PREFIX = 120.0, 10.0, 15.0
NAME_W, NAME_H = 70.0, 15.0
DEFAULT_FONT = 3.0

# -----------------------------------------------------------------------------
# Поиск файла настроек
# -----------------------------------------------------------------------------
def find_settings_file(start_dir: Path, filename: str) -> Optional[Path]:
    """
    Ищет `filename`, поднимаясь от `start_dir` вверх по дереву.
    Возвращает путь, либо None (если пользователь отменил выбор).
    Вшиты удобные фолбэки для OiSMK.txt и Информация по проекту.txt.
    """
    start_dir = Path(start_dir).expanduser().resolve()
    for cur in [start_dir, *start_dir.parents]:
        cand = cur / filename
        if cand.exists():
            return cand

    # Фолбэки
    if filename == "OiSMK.txt":
        log_message('Файл "OiSMK.txt" в проекте не найден — используем дефолт.', "warn")
        p = (Path(path_to_scripts) / "OiSMK" / "OiSMK.txt")
        if not p.exists():
            p = Path(r'I:\Documents\LIBRARY\00 _ Python\OISMK\OiSMK.txt')
        return p if p.exists() else None

    if filename == "Информация по проекту.txt":
        log_message('Файл "Информация по проекту.txt" в проекте не найден — используем дефолт.', "warn")
        p = Path(path_to_scripts) / "Scripts" / "Информация по проекту.txt"
        return p if p.exists() else None

    # Диалог выбора
    chosen = easygui.fileopenbox(
        msg=f'Файл "{filename}" не найден. Укажите вручную.',
        title="Поиск файла настроек",
        default=str(start_dir / "*.txt")
    )
    return Path(chosen) if chosen else None

# -----------------------------------------------------------------------------
# Чтение/парсинг файла
# -----------------------------------------------------------------------------
def _read_text_file(path: Path) -> str:
    for enc in ("utf-8-sig", "cp1251"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    # последняя попытка без указания кодировки
    return path.read_text()

def parse_settings_file(file_settings: Path) -> Dict[str, str]:
    """
    Парсит ключ:_:значение по строкам. Пустые строки и строки без разделителя игнорируются.
    Строки, начинающиеся с #, ;, // — считаются комментариями.
    """
    if not file_settings or not file_settings.exists():
        raise FileNotFoundError(f"Файл настроек не найден: {file_settings}")

    raw = _read_text_file(file_settings)
    dic: Dict[str, str] = {}

    for raw_line in raw.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(("#", ";", "//")):
            continue
        if ":_" not in line:
            # мягко игнорируем «левую» строку, но можно и логнуть
            # log_message(f"Строка без разделителя ':_': {line}", "warn")
            continue
        key, value = line.split(":_", 1)
        dic[key.strip()] = value.strip()

    return dic

# -----------------------------------------------------------------------------
# Пост-обработка полей, подготовка для штампа
# -----------------------------------------------------------------------------
def _split_keep_prefix_addr(text: str) -> Tuple[str, str]:
    """
    Делим по «по адресу» (с/без двоеточия), оставляя левую часть как префикс,
    правую — как адрес для оборачивания.
    """
    if not text:
        return "", ""
    m = re.search(r"(.*?\bпо адресу\b:?\s*)", text, flags=re.IGNORECASE | re.DOTALL)
    if not m:
        return "", text.strip()
    prefix = m.group(1)
    rest = text[len(prefix):].strip()
    return prefix.strip(), rest

def transform_field_with_breaks(full_text: str, width: float, height: float, base_font: float) -> Tuple[str, float]:
    """
    Универсальная обвязка: учитывает готовые переносы &/ (абзацы),
    подбирает **минимальную** высоту шрифта, достаточную для всех абзацев.
    """
    parts = [p.strip() for p in (full_text or "").split(HARD_BREAK) if p.strip()]
    if not parts:
        return "", base_font

    results, heights = [], []
    for part in parts:
        res, fh = text_transform_with_font(part, width, height, base_font)
        results.append(res)
        heights.append(fh)

    return HARD_BREAK.join(results), min(heights)

def cook_settings_for_stamp(dic: Dict[str, str]) -> Dict[str, Tuple[str, float] | str]:
    """
    Готовит словарь для штампа:
      - KEY_ADDR -> (текст с &/, высота_шрифта)
      - KEY_NAME -> (текст с &/, высота_шрифта)
      - остальные поля — как есть.
    """
    out: Dict[str, Tuple[str, float] | str] = dict(dic)  # копия

    # Адрес (учитываем «по адресу …»)
    addr_raw = dic.get(KEY_ADDR, "")
    if HARD_BREAK in addr_raw:
        text, h = transform_field_with_breaks(addr_raw, ADDR_W, ADDR_H_DEFAULT, DEFAULT_FONT)
        out[KEY_ADDR] = (text, h)
    else:
        prefix, addr_part = _split_keep_prefix_addr(addr_raw)
        if addr_part:
            # если есть префикс — поле выше (15 мм), иначе стандартные 10 мм
            h_target = ADDR_H_WITH_PREFIX if prefix else ADDR_H_DEFAULT
            text, h = transform_field_with_breaks(addr_part, ADDR_W, h_target, DEFAULT_FONT)
            out[KEY_ADDR] = ((prefix + HARD_BREAK if prefix else "") + text, h)
        else:
            text, h = transform_field_with_breaks(addr_raw, ADDR_W, ADDR_H_DEFAULT, DEFAULT_FONT)
            out[KEY_ADDR] = (text, h)

    # Наименование проекта
    name_raw = dic.get(KEY_NAME, "")
    if HARD_BREAK in name_raw:
        text, h = transform_field_with_breaks(name_raw, NAME_W, NAME_H, DEFAULT_FONT)
    else:
        text, h = text_transform_with_font(name_raw, NAME_W, NAME_H, DEFAULT_FONT)
    out[KEY_NAME] = (text, h)

    # Остальные поля — без преобразований
    for k in (KEY_CODE, KEY_STAGE, KEY_ORG, KEY_MONTH):
        if k in dic:
            out[k] = dic[k]

    return out

# -----------------------------------------------------------------------------
# Пример использования
# -----------------------------------------------------------------------------
if __name__ == "__main__":

    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    iApplication.MessageBoxEx(f'Заполняем основную надпись активного чертежа', '', 0x0 | 0x40)

    # исходная стартовая папка
    # start_folder = Path(r'C:\Users\ik\Desktop\Primer')
    start_folder = iKompasDocument.Path
    fname = 'Информация по проекту.txt'

    path = find_settings_file(start_folder, fname)
    if not path:
        log_message(f'Файл "{fname}" не найден и не выбран вручную.', "error")
        sys.exit(1)

    try:
        dic_raw = parse_settings_file(path)
        dic_for_stamp = cook_settings_for_stamp(dic_raw)
    except Exception as e:
        log_message(f'Ошибка при чтении/обработке файла настроек: {e}', "error")
        sys.exit(1)

    print(dic_for_stamp)


# # -*- coding: utf-8 -*-
# import sys
# import re
# from _TextTransform import text_transform_with_font
# import easygui, os.path
# from _Config import xlsx_base, path_to_scripts
# from pathlib import Path
# from _Colors import log_message
#
# # Поиск файла настроек начиная от вложенной папки и выше
# def search_file_settings(cur_dir, file_name):
#     while True:
#         file_list = os.listdir(cur_dir)
#         parent_dir = os.path.dirname(cur_dir)
#         if file_name in file_list:
#             # print("Файл найден в: ", cur_dir)
#             path_settings = cur_dir + "\\" + file_name
#             break
#         else:
#             if cur_dir == parent_dir:
#                 print(f'Файл "{file_name}"в папке с проектом не найден')
#                 if file_name == "OiSMK.txt":
#                     print('Используем файл настроек из папки с программой OiSMK')
#                     path_settings = Path(path_to_scripts) / "OiSMK" / "OiSMK.txt"
#                     # log_message(path_settings, "error")
#                     if not path_settings.exists():
#                         path_settings = r'I:\Documents\LIBRARY\00 _ Python\OISMK\OiSMK.txt'
#                     return path_settings
#                 if file_name == "Информация по проекту.txt":
#                     print('Используем файл настроек из папки со скриптами')
#                     path_settings = Path(path_to_scripts) / "Вспомогательные скрипты" / "Информация по проекту.txt"
#                     return path_settings
#                 else:
#                     path_settings = easygui.fileopenbox(msg=f'Файл "{file_name}"в папке не найден, укажите файл вручную', title="",
#                                                     default=cur_dir + "/*.txt")
#
#                     if path_settings is None:
#                         print('Путь до файла не выбран')
#                         return False
#                 break
#
#             else:
#                 cur_dir = parent_dir
#     return path_settings
#
# # Чтение файла настроек в словарь
# def reed_file_settings(file_settings):
#     try:
#         dic = {}  # Создаем пустой словарь
#         try:
#             # Попытка чтения файла с кодировкой UTF-8
#             with open(file_settings, encoding='utf-8-sig') as f_in:
#                 lines = filter(None, (line.rstrip() for line in f_in))  # Читаем файл без пустых строк
#                 for line in lines:
#                     key, value = line.split(':_', 1)
#                     dic[key] = value.strip()  # Добавляем в словарь
#         except UnicodeDecodeError:
#             # Если не удалось прочитать файл с кодировкой UTF-8, пробуем ANSI (Windows-1251)
#             try:
#                 with open(file_settings, encoding='cp1251') as f_in:
#                     lines = filter(None, (line.rstrip() for line in f_in))  # Читаем файл без пустых строк
#                     for line in lines:
#                         key, value = line.split(':_', 1)
#                         dic[key] = value.strip()  # Добавляем в словарь
#             except Exception as e:
#                 print(f'Файл настроек {file_settings} - не подходящий, либо заполнен неверно')
#                 input(f'\rНажмите клавишу ввода{" " * 5}\n')
#                 sys.exit(1)  # Завершение программы в случае ошибки
#
#         # Обработка "Адрес объекта"
#         address = dic.get('Адрес объекта', '')
#         if '&/' in address:
#             # Если строка уже содержит '&/', разбиваем её и обрабатываем каждую часть
#             parts = address.split('&/')
#             transformed_parts = []
#             heights = []
#
#             for part in parts:
#                 result, font_height = text_transform_with_font(part, 120, 10, 3)
#                 transformed_parts.append(result)
#                 heights.append(font_height)
#
#             # Итоговая строка остается исходной, минимальная высота выбирается из всех частей
#             min_height = min(heights)
#             dic['Адрес объекта'] = (address, min_height)
#         else:
#             if re.search(r'\bпо адресу\b', address):
#                 # Разделяем адрес на части
#                 base_text = address.partition('по адресу:')[0] + address.partition('по адресу:')[1]
#                 address_part = address.partition('по адресу:')[2]
#
#                 # Обрабатываем текст через функцию
#                 result, font_height = text_transform_with_font(address_part, 120, 15, 3)
#                 dic['Адрес объекта'] = (
#                     base_text + '&/' + result,
#                     font_height
#                 )
#             else:
#                 # Обрабатываем полный текст через функцию
#                 result, font_height = text_transform_with_font(address, 120, 10, 3)
#                 dic['Адрес объекта'] = (result, font_height)
#
#         # Обработка "Наименование проекта"
#         name_project = dic.get('Наименование проекта', '')
#         if '&/' in name_project:
#             parts = name_project.split('&/')
#             transformed_parts = []
#             heights = []
#
#             for part in parts:
#                 result, font_height = text_transform_with_font(part, 70, 15, 3)
#                 transformed_parts.append(result)
#                 heights.append(font_height)
#
#             min_height = min(heights)
#             dic['Наименование проекта'] = (name_project, min_height)
#         else:
#             result, font_height = text_transform_with_font(name_project, 70, 15, 3)
#             dic['Наименование проекта'] = (result, font_height)
#
#         return dic
#     except Exception as e:
#         print(f'Файл настроек {file_settings} - не подходящий, либо заполнен неверно')
#         input(f'\rНажмите клавишу ввода{" " * 5}\n')
#         sys.exit(1)  # Завершение программы в случае ошибки
#
# if __name__ == "__main__":
#     path = r'C:\Users\ik\Desktop\Primer'
#     # file_settings = r'C:/Users/ik/Desktop/Холодильник1/04 _ Design/01 _ CAD/Информация по проекту.txt'
#     file_settings = search_file_settings(path, 'Информация по проекту.txt')
#     dic_settings = reed_file_settings(file_settings)
#     print(dic_settings)
