import sys
from __Kompas import *
from __dxf_get_geometry_from_layer import dxf_check
from __Utils import zip_folder
import os, easygui, openpyxl
from shutil import rmtree
import pandas as pd
import _Config
# from _Debug import *

'''Создание dxf пластин по отчету 2.1 _ Пластины.xlsx'''

def dxf_for_all(xlsx, format_cnc, code_project=''):
    log_message(f'Выгружаем dxf/{_Config.format_cnc} пластин по отчету', 'title')
    # KompasObject, iApplication, KompasVersion = get_kompas()
    try:
        if isinstance(xlsx, pd.DataFrame):  # Если передан уже готовый DataFrame
            df = xlsx
            path_file = df['Полное имя файла'].iloc[0]
            path = os.path.dirname(path_file) + '\\'  # Получаем путь к родительской папке
            _Config.zip = False

        else:  # Если передан путь к файлу
            wb = openpyxl.load_workbook(filename=xlsx, data_only=True)
            df = pd.read_excel(xlsx, sheet_name='Пластины', engine='openpyxl', header=1)
            path = xlsx.rsplit('.', 1)[0] + '\\'  # Папка, куда сохранять dxf, stp

    except Exception:
        input('Похоже, файл отчета не подходящий')
        sys.exit()

    # Если папки для сохранения dxf не существует, то создать
    if not os.path.exists(path):
        os.makedirs(path)

    def get_countur(iView_base, iView_system):
        iDrawingContainer = API7.IDrawingContainer(iView_base)

        total_elements = sum(
            getattr(iDrawingContainer, name).Count
            for name in (
                "Arcs", "Circles", "Beziers", "ConicCurves", "Ellipses", "EllipseArcs",
                "Lines", "LineSegments", "Nurbses", "PolyLines2D", "Rectangles",
                "RegularPolygons", "StraightSlots"
            )
            if hasattr(iDrawingContainer, name)
        )
        # print("Суммарное кол-во примитивов :", total_elements)

        iLineSegments = iDrawingContainer.LineSegments
        iCircles = iDrawingContainer.Circles

        x = y = None
        if iLineSegments and iLineSegments.Count > 0:
            length_max = -1
            for i in range(iLineSegments.Count):
                iLineSegment = iLineSegments.LineSegment(i)
                length = iLineSegment.Length
                if length > length_max:
                    length_max = length
                    x, y = iLineSegment.X1, iLineSegment.Y1
        else:
            if iCircles and iCircles.Count > 0:
                radius_max = -1
                for i in range(iCircles.Count):
                    iCircle = iCircles.Circle(i)
                    radius = iCircle.Radius
                    if radius > radius_max:
                        radius_max = radius
                        x, y = iCircle.X, iCircle.Y

        if x is None or y is None:
            print("⚠️ Не найдено ни одной линии или окружности для центра.")
            return False

        # Создаём контура
        iDrawingContainer_system = API7.IDrawingContainer(iView_system)
        iDrawingContours_system = iDrawingContainer_system.DrawingContours
        iDrawingContours = iDrawingContainer.DrawingContours

        iDrawingGroup = iDrawingContours.MakeEncloseContours(False, x, y, False)
        iDrawingContours_obj = iDrawingGroup.Objects(0)

        iDrawingContours_list = (
            list(iDrawingContours_obj)
            if isinstance(iDrawingContours_obj, (list, tuple))
            else [iDrawingContours_obj]
        )

        new_contours = []
        contour_elements = 0

        try:
            for iDrawingContour in iDrawingContours_list:
                iContour = API7.IContour(iDrawingContour)
                contour_elements += iContour.Count
                tmp_objects = iContour.TmpObjects

                iDrawingContour_new = iDrawingContours_system.Add()
                iDrawingContour_new.Style = 1
                iDrawingContour_new.LayerNumber = 0
                iDrawingContour_new.Update()  # Инициализация

                iContour_new = API7.IContour(iDrawingContour_new)
                iContour_new.Closed = True
                iContour_new.CopySegments(tmp_objects, True)

                new_contours.append(iDrawingContour_new)

            # print(f"Суммарное кол-во примитивов в контурах: {contour_elements}")

            if contour_elements == total_elements:
                # print("Сумма элементов совпадает. Проверяем Update() новых контуров...")
                for iDrawingContour_new in new_contours:
                    if not iDrawingContour_new.Update():
                        raise RuntimeError("Ошибка обновления контура")

                print("Все контуры успешно добавлены")
                return True

            else:
                print("⚠️ Сумма элементов не совпадает, новые контуры не активированы.")
                raise RuntimeError("Сумма элементов не совпадает")

        except Exception as e:
            print(f"❌ Ошибка: {e}. Откат изменений...")
            for iDrawingContour_new in new_contours:
                try:
                    iDrawingContours_system.Remove(iDrawingContour_new)
                except:
                    pass
            return False

    iDocuments = iApplication.Documents
    # print(f'iDocuments.Count:{iDocuments.Count}')

    for i in range(df.shape[0]):  # количество строк в экселе
        file_name = df['Полное имя файла'].iloc[i]
        gn = df['Гнутость'].iloc[i]
        file_name_save = df['Наименование для dxf'].iloc[i]
        num = df['№'].iloc[i]
        marking = df['№ элемента'].iloc[i]

        # Новые поля
        width = df['Ширина, мм'].iloc[i]
        length = df['Длина, мм'].iloc[i]
        thickness = df['Толщина, мм'].iloc[i]

        # Проверки
        if pd.isna(file_name) or str(file_name).strip() == '':
            log_message(f'В строке {i + 1} пустое значение в столбце "Полное имя файла", строка пропущена', 'warn')
            continue

        if pd.isna(num) or str(num).strip() == '':
            log_message(f'В строке {i + 1} пустое значение в столбце "№", строка пропущена', 'warn')
            continue

        if not os.path.exists(file_name):
            log_message(f'Файл пластины не найден!!!, file_name', 'error')
            continue


        iKompasDocument, opened = iDocuments.Item(file_name), True

        if not iKompasDocument:
            iKompasDocument, opened = iDocuments.Open(file_name, False, False), False  # Невидимый, Для записи

        if not iKompasDocument:
            log_message(f'Не удалось открыть документ, {file_name}', 'error')
            continue

        # print(f'iKompasDocument.Visible: {iKompasDocument.Visible}')
        iApplication.HideMessage = con0.ksHideMessageYes  # если потребуется гасить диалоги, то раскомменитровать

        #Определяем угол поворота текста и высоту шрифта
        iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
        iPart7 = iKompasDocument3D.TopPart  # Верхний компонент (сам документ)

        iFeature7 = API7.IFeature7(iPart7)
        result_bodies = iFeature7.ResultBodies  # Считаем что тело одно

        if isinstance(result_bodies, tuple):
            log_message(f'В файле модели {df['Полное имя файла'].iloc[i]} больше одного тела, пропускаем', 'warn')
            if not opened:  # Если документ не был открыт
                iKompasDocument.Close(0)  # Закрыть документ
            continue
        else:
            iBody7 = result_bodies

        if iBody7:
            _, x_1, y_1, z_1, x_2, y_2, z_2 = (round(val) for val in iBody7.GetGabarit())
            gabarit_x, gabarit_y, gabarit_z = x_2 - x_1, y_2 - y_1, z_2 - z_1
            # if not opened:  # Если документ не был открыт
            #     iKompasDocument.Close(0)  # Закрыть документ
        else:
            log_message(f'Похоже в {file_name} нет геометрии, пропускаем...', 'error')
            continue
        # print(gabarit_x, gabarit_y, gabarit_z)
        # if KompasVersion >=24:
        #     gabarit_z, gabarit_y, gabarit_x = gabarit_y, gabarit_z, gabarit_x

        # print(f'gabarit_z:{gabarit_z}, gabarit_y:{gabarit_y}, gabarit_x:{gabarit_x}')

        if gabarit_z < gabarit_y:
            text_angle = 0.0
            h_font = min(gabarit_z // 3, _Config.max_h_font)
            text_X = 0.0
            text_Y = -h_font/2
        else:
            text_angle = 90.0
            h_font = min(gabarit_y // 3, _Config.max_h_font)
            text_X = h_font/2
            text_Y = 0.0

        def add_drawing(name_view="Развертка", projectionName="#Развертка", unfold = True):
            #  Создай документ "Чертеж"
            # iDocuments_FRW = iApplication.Documents
            iKompasDocumentFRW = iDocuments.Add(con0.ksDocumentDrawing, False)

            #  Создай графический объект "Вид"
            iKompasDocument2D = API7.IKompasDocument2D(iKompasDocumentFRW)
            iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
            iViews = iViewsAndLayersManager.Views
            iView_system = iViews.View(0)

            iView = iViews.Add(con0.vt_Arbitrary)
            iView.Number = 1
            iView.Name = name_view
            iView.Background = False
            iView.Visible = True
            iView.Current = True
            iView.Color = 0
            iView.Comment = ""
            iView.X = 0.0
            iView.Y = 0.0
            iView.Scale = 1.0
            iView.Angle = 0.0
            iViewDesignation = API7.IViewDesignation(iView)
            iViewDesignation.ShowName = False
            iViewDesignation.ShowUnfold = False
            iViewDesignation.ShowScale = False
            iViewDesignation.ShowTurn = False
            iViewDesignation.ShowAngle = False
            iViewDesignation.ShowPage = False
            iViewDesignation.ShowZone = False
            iAssociationView = API7.IAssociationView(iView)
            iAssociationView.SourceFileName = file_name
            iAssociationView.ProjectionName = projectionName
            iAssociationView.ExplodedView = False
            iAssociationView.Unfold = unfold
            iAssociationView.VisibleLinesStyle = con0.ksCSNormal
            iAssociationView.HiddenLines = False
            iAssociationView.BreakLinesVisible = False
            iAssociationView.BreakLinesStyle = con0.ksCSThin
            iAssociationView.BendLinesVisible = False
            iAssociationView.BendLinesStyle = con0.ksCSDash2Dots
            iAssociationViewElements = API7.IAssociationViewElements(iView)
            iAssociationViewElements.ProjectLayers = True
            iAssociationViewElements.ProjectAllObjects = False
            iAssociationViewElements.ProjectBodies = True
            iAssociationViewElements.ProjectSurfaces = False
            iAssociationViewElements.ProjectCurves = False
            iAssociationViewElements.ProjectPoints = False
            iAssociationViewElements.HiddenObjectsVisible = False
            iAssociationViewElements.ProjectHiddenComponents = False
            iAssociationViewElements.ProjectAxis = False
            iAssociationViewElements.ProjectAllDesignations = False
            iAssociationViewElements.ProjectThreads = True
            iAssociationViewElements.ProjectDimensions = False
            iAssociationViewElements.ProjectRoughs = False
            iAssociationViewElements.ProjectBases = False
            iAssociationViewElements.ProjectTolerances = False
            iAssociationViewElements.ProjectPositions = False
            iAssociationViewElements.ProjectLeaders = False
            iAssociationViewElements.ProjectMarkLeaders = False
            iAssociationViewElements.ProjectBrandLeaders = False
            iAssociationViewElements.ProjectStandartElements = True
            iAssociationViewElements.ProjectSpecRough = False
            iAssociationViewElements.CreateAxis = False
            iAssociationViewElements.CreateCentresMarkers = False
            iAssociationViewElements.CreateCircularCentres = False
            iAssociationViewElements.CreateCircularCentres = False
            iAssociationViewElements.CreateLinearCentres = False
            iAssociationViewElements.CreateCentresMarkers = False
            iView_base = iView
            iView.Update()

            #  Измени параметры листа оформления
            iLayoutSheets = iKompasDocumentFRW.LayoutSheets
            iLayoutSheet = iLayoutSheets.Item(0)
            iSheetFormat  = iLayoutSheet.Format
            iSheetFormat.FormatMultiplicity = 1
            iSheetFormat.VerticalOrientation = True
            iSheetFormat.Format = con0.ksFormatA4
            iLayoutSheet.LayoutLibraryFileName = ""
            iLayoutSheet.LayoutStyleNumber = 0.0
            iLayoutSheet.SheetType = con0.ksDocumentSheet
            iLayoutSheet.Update()

            iKompasDocumentFRW.Active = True
            ### Собираем контур
            if KompasVersion > 22:
                check = get_countur(iView_base, iView_system)

                # # print("✅ Все контуры успешно обновлены. Удаляем исходный вид.")
                if check:
                    iView_base.Delete()

            # iKompasDocumentFRW.Active = True
            iDrawingDocument = API7.IDrawingDocument(iKompasDocument2D)
            iTechnicalDemand = iDrawingDocument.TechnicalDemand
            if iTechnicalDemand:
                iTechnicalDemand.Delete()
                iSpecRough = iDrawingDocument.SpecRough
                iSpecRough.Delete()

            if _Config.marking_2d:
                # Создаем номер элемента в новом виде
                # print(iKompasDocumentFRW.Active)
                iLayers = iView_system.Layers
                iLayer = iLayers.Add()
                iLayer.Name = "Обозначение"
                iLayer.Background = False
                iLayer.Visible = True
                iLayer.Current = False
                iLayer.Color = rgb_to_bgr_int(color_name="red")
                iLayer.Comment = ""
                iLayer.Printable = True
                iLayer.Update()

                iDrawingContainer = API7.IDrawingContainer(iView_system)
                iDrawingTexts = iDrawingContainer.DrawingTexts
                iDrawingText = iDrawingTexts.Add()
                iDrawingText.X = text_X
                iDrawingText.Y = text_Y
                iDrawingText.Angle = text_angle
                iDrawingText.HFormat = con0.ksHFormatNot
                iDrawingText.VFormat = False
                iDrawingText.Allocation = con0.ksAlCentre
                iDrawingText.MirrorSymmetry = False
                iDrawingText.LayerNumber = 1
                iDrawingText.Update()

                iText = API7.IText(iDrawingText)
                iText.Style = con0.ksTSDrawingAnnotation

                iTextLine = iText.Add()
                iTextLine.Style = con0.ksTSDrawingAnnotation
                iTextLine.Step = 1.0
                iTextLine.Align = con0.ksAlignLeft
                iTextLine.IndentedLine = 0.0
                iTextLine.StepBeforeParagraph = 0.0
                iTextLine.StepAfterParagraph = 0.0
                iTextLine.LeftEdge = 0.0
                iTextLine.RightEdge = 0.0
                iTextLine.Level = 0
                iTextLine.Numbering = con0.ksTNumbNoNumber
                iTextLine.NewPage = False

                iTextItem = iTextLine.Add()
                iTextItem.ItemType = con0.ksTItString
                iTextItem.NewLine = True
                iTextItem.Str = marking

                iTextFont = API7.ITextFont(iTextItem)
                iTextFont.FontName = "GOST type A (plotter)"
                iTextFont.Height = h_font
                iTextFont.WidthFactor = 1.0
                iTextFont.Color = 0
                iTextFont.Bold = False
                iTextFont.Italic = False
                iTextFont.Underline = False
                iTextFont.TextLineStep = 0.0
                iTextItem.Update()
                iDrawingText.Update()

                if _Config.destroy:
                    #Создаем макроэлемент
                    ksDocument2D = KompasObject.TransferInterface(iKompasDocumentFRW, 1, 0)
                    text_mark = ksDocument2D.ksConvertTextToCurve(iText.Reference)
                    ksDocument2D.ksStoreTmpGroup(text_mark)
                    iDrawingText.Delete()

                    iDrawingContainer = API7.IDrawingContainer(iView_system)
                    iLineSegments = iDrawingContainer.LineSegments  # сущ отрезки на листе

                    iMacroObjects = iDrawingContainer.MacroObjects
                    iMacroObjects = iMacroObjects.Add()
                    iMacroObjects.Command = -1
                    iMacroObjects.DoubleClickEditable = False
                    iMacroObjects.HotPointsEditable = False
                    iMacroObjects.ExternalEditable = False
                    iMacroObjects.Name = "Номер элемента"
                    iMacroObjects.PropertyObjectEditable = False

                    iDrawingContainer = API7.IDrawingContainer(iMacroObjects)
                    line_segments = iDrawingContainer.LineSegments
                    line_segment_trash = line_segments.Add()
                    line_segment_trash.Style = con0.ksCSThin
                    line_segment_trash.X1 = 100.0
                    line_segment_trash.Y1 = 0.0
                    line_segment_trash.X2 = 5.0
                    line_segment_trash.Y2 = 0.0
                    line_segment_trash.Update()
                    iMacroObjects.Update()

                    for iLineSegment in iLineSegments:
                        res = iMacroObjects.AddObjects(iLineSegment)

                    line_segment_trash.Delete()
                    iMacroObjects.Update()

                iLayer_system = iLayers.Layer(0)
                iLayer_system.Current = True
                iLayer_system.Update()

                convert_to_DXF = iApplication.Converter(KompasObject.ksSystemPath(1) + r'\ImpExp\dwgdxfExp.rtw') # Конвертер файлов КОМПАС
                convert_to_DXF.Convert("", path + file_name_save + ".dxf", 1, False)
                print(f'{file_name_save} - Готово')

                if _Config.destroy:
                    gabarit = (gabarit_y, gabarit_z)
                    dxf_file = path + file_name_save + ".dxf"
                    dxf_test = dxf_check(dxf_file, gabarit, ["Системный слой", "Обозначение"])

                    if dxf_test:
                        # print(f'{C.yellow}В файле {C.default}{file_name_save}.dxf - {C.yellow}есть пересечение геометрии{C.default}')
                        convert_to_FRW = iApplication.Converter(KompasObject.ksSystemPath(1) + r'\ImpExp\dwgdxfImp.rtw')
                        iConverterParameters = convert_to_FRW.ConverterParameters(1)
                        file = path + file_name_save + ".dxf"
                        convert_to_FRW.Convert(file, file[:-4] + ".frw", 1, False)
                        os.remove(file)
                        if not dxf_test == True and not dxf_test == False:
                            #Смещаем мароэлемент
                            iKompasDocument_FRW = iApplication.ActiveDocument
                            iKompasDocument2D_FRW = API7.IKompasDocument2D(iKompasDocument_FRW)
                            iViewsAndLayersManager_FRW = iKompasDocument2D_FRW.ViewsAndLayersManager
                            iViews_FRW = iViewsAndLayersManager_FRW.Views
                            iView_FRW = iViews_FRW(0)

                            iDrawingContainer_FRW = API7.IDrawingContainer(iView_FRW)
                            iMacroObjects_FRW = iDrawingContainer_FRW.MacroObjects
                            iMacroObject_FRW = iMacroObjects_FRW.MacroObject(0) #Выбираем первый макроэлемент

                            x, y = dxf_test
                            _, _, angle_old, _, _ = iMacroObject_FRW.GetPlacement()
                            iMacroObject_FRW.SetPlacement(x, y, angle_old, False, False)
                            iKompasDocument2D_FRW.Save()
                            convert_to_DXF = iApplication.Converter(KompasObject.ksSystemPath(1) + r'\ImpExp\dwgdxfExp.rtw')  # Конвертер файлов КОМПАС
                            convert_to_DXF.Convert("", file, 1, False)
                            iKompasDocumentFRW.Close(0)

                        _Config.zip = False

            if not _Config.marking_2d:
                convert_to_DXF = iApplication.Converter(KompasObject.ksSystemPath(1) + r'\ImpExp\dwgdxfExp.rtw') # Конвертер файлов КОМПАС
                test = convert_to_DXF.Convert('', path + file_name_save + ".dxf", 1, False)
                if test != 1 :
                    print("Косяк при сохранении в dxf")
                # iKompasDocumentFRW.SaveAs(path + file_name_save + ".frw")
                iKompasDocumentFRW.Close(1)
                print(f'{file_name_save} - Готово')
            if not opened:  # Если документ не был открыт
                iKompasDocument.Close(0)  # Закрыть документ

        if gn == 1:  # Если деталь гнутая
            iDocument3D = KompasObject.ActiveDocument3D()
            iAdditionFormatParam = iDocument3D.AdditionFormatParam()
            iAdditionFormatParam.Init()

            format_mapping = {"stp": 214, "igs": 4}

            for cnc_format, code in format_mapping.items():
                if getattr(_Config, f"format_cnc") == cnc_format:
                    iAdditionFormatParam.format = code
                    iDocument3D.SaveAsToAdditionFormat(path + file_name_save + f".{format_cnc}", iAdditionFormatParam)
                    print(f'{file_name_save}.{format_cnc} - Готово')


            if _Config.dxf_unfold: #("Деталь гнутая, сохраняем развертку в dxf")
                print(f'Для {marking} Выгружаем развёртку в {file_name_save}.dxf - Готово')
                add_drawing(name_view="Развертка", projectionName="#Развертка", unfold = True)

        else:
            add_drawing(name_view="Спереди", projectionName="#Спереди", unfold = False)

        if not opened:  # Если документ не был открыт
            iKompasDocument.Close(0)  # Закрыть документ

    kompas_file_unlock(iApplication)

    iApplication.HideMessage = con0.ksShowMessage
    # Упаковываем в архив
    if _Config.zip_archive:
        zip_folder(os.path.dirname(path), os.path.dirname(os.path.dirname(path)) + '\\' + os.path.basename(os.path.dirname(path)).replace("2.1", "2.2") + ' dxf.zip')
        rmtree(os.path.dirname(path), ignore_errors=True)

if __name__ == "__main__":
    # print('DXF_for_all от 16.02.2025')
    xlsx = r'I:\Documents\MY PROJECT\Active Project\Олег\20250713-КМ _ Схемы\03 _ Design\01 _ CAD\Материалы\2.1 _ Пластины.xlsx'
    zip = False
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    # xlsx = easygui.fileopenbox(msg="Укажите файл 2.1 _ Пластины.xlsx", title="", default=f"{path}/*2.1 _ Пластины.xlsx")  # Путь до файла отчёта
    dxf_for_all(xlsx, _Config.format_cnc)
    # input('\nРабота завершена.')
