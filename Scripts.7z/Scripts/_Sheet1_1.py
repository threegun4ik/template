"""
Скрипт формирования ведомости марок из файла 'Общий отчёт.xlsx'.
На выходе: 1.1 _ Ведомость марок.xlsx

Функции:
- Чтение и предобработка данных из Excel
- Формирование итоговой спецификации и сохранение в новый Excel
- Автоматическое форматирование Excel файла
"""

# ===== Стандартная библиотека =====
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Font
from openpyxl.styles import NamedStyle
from pathlib import Path
import pandas as pd
import numpy as np
import easygui

from __Kompas import get_kompas, get_active_doc_path, log_message
from __ExcelHandler import ExcelHandler


def sheet1_1(xls, code_project=""):
    log_message(f'Подготавливаю ведомость отправочных марок и элементов металлоконструкции', 'title')

    xlsx = Path(xls).parent / '1.1 _ Ведомость марок.xlsx'
    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler для марок

    df = excel_handler.read_excel()  # Читаем таблицу в dataframe
    df = df.rename(columns={'№ элемента': 'Обозначение'})  # Переименуем столбец

    # Список отправочных марок
    df = df[df['Марка'].notna() & ~df['Марка'].str.contains(r'\*', na=False)]
    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом

    df = excel_handler.line_joining_df(
        ['Марка', 'Наименование', 'Масса марки', 'Примечание', 'Тип объекта', 'Полное имя файла'],
        ['Кол-во, шт.'], ignore_value=None) # Объединим строки

    df['Примечание'] = np.nan

    # Добавим столбцы
    df['П/п'] = range(1, len(df) + 1)  # Нумерация строк
    df['Масса общ., кг'] = ""
    df['Номер чертежа'] = ""

    df = df[
        ['П/п', 'Марка', 'Кол-во, шт.', 'Наименование', 'Масса марки', 'Масса общ., кг', 'Номер чертежа', 'Примечание',
         'Тип объекта', 'Полное имя файла']]# Отсортируем таблицу

    df.to_excel(xlsx, sheet_name="Ведомость марок", index=False) #Запишем данные в xlsx

    ###
    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Ведомость марок']  # Выбираем лист по имени

    ###Название таблицы
    ws.insert_rows(1)  # Вставим строку
    ws["A1"] = f'{code_project}. Ведомость марок'

    ws["A2"] = "П/п"
    ws["B2"] = "Обозначение марки"
    ws["C2"] = "Кол-во, шт."
    ws["D2"] = "Наименование"
    ws["E2"] = "Масса 1 шт., кг"
    ws["F2"] = "Масса всего, кг"
    ws["G2"] = "Номер чертежа"
    ws["H2"] = "Примечание"

    for row in range(3, ws.max_row + 1):
        ws["F" + str(row)] = f'=E{row}*C{row}'  # Масса всего

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов

    excel_handler.fix_dimensions(ws, ['A'], width=10)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['C', 'E', 'F'], width=15)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['B'], width=35)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['D', 'H'], width=45)  # Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 30  # Измените высоту первой строки

    # Включите перенос текста по словам и выравнивание по центру для ячеек во второй строке
    for cell in ws[2]:  # Итерируем по ячейкам во второй строке
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

    # Создание маппинга выравниваний для столбцов
    alignment_map = {
        **{letter: Alignment(horizontal='center', vertical='center') for letter in 'ACEFG'},
        # **{letter: Alignment(horizontal='right', vertical='center') for letter in 'F'},
        **{letter: Alignment(horizontal='left', vertical='center') for letter in 'BG'}
    }
    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем со второй строки, чтобы пропустить заголовки
        for cell in row:
            column_letter = openpyxl.utils.get_column_letter(cell.column)
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    # Скроем ненужные столбцы
    for col in ['I', 'J']:
        ws.column_dimensions[col].hidden = True

    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)  # Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = Alignment(horizontal='left', vertical='center')

    ws.auto_filter.ref = 'A2:{}'.format(
        openpyxl.utils.get_column_letter(ws.max_column) + '2')  # Автофильтр на вторую строку

    excel_handler.format_columns(ws, ['E', 'F'], n=1, start_row=3)  # Округление до n знаков после запятой
    last_row = ws.max_row

    ws.cell(row=last_row + 2, column=5, value='Итого').font = Font(bold=True)  # Столбец J (10) # Добавляем строку 'Итого'
    # Установка выравнивания
    ws.cell(row=last_row + 2, column=6).alignment = Alignment(horizontal='right', vertical='center')
    # Устанавливаем формулу в столбец 'J' для последней строки
    ws.cell(row=last_row + 2, column=6, value=f'=ROUND(SUM(F3:F{last_row}), 1)').font = Font(bold=True)
    ws.cell(row=last_row + 2, column=6, value=f'=ROUND(SUM(F3:F{last_row}), 1)').number_format = '0 "кг"'

    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()
    log_message(f'Ведомость марок - создана', 'ok')

if __name__ == "__main__":
    # xls = r"C:\Users\ik\Desktop\Тесты\сборка\Материалы\Общий отчёт.xlsx"
    KompasObject, iApplication, KompasVersion = get_kompas()
    # path = get_active_doc_path(iApplication)
    # xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
    xls = r"C:\Users\ik\Desktop\!2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\!01 _ CAD\Материалы\Общий отчёт.xlsx"
    sheet1_1(xls)
    input('\n\rРабота завершена.	\n')
