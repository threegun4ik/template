"""
Скрипт формирования ведомости элементов из файла 'Общий отчёт.xlsx'.
На выходе: 1.2.1 _ Ведомость элементов по маркам.xlsx

Функции:
- Чтение и предобработка данных из Excel
- Формирование итоговой спецификации и сохранение в новый Excel
- Автоматическое форматирование Excel файла
"""

import os, pyperclip, easygui, re
import sys

import pandas as pd
from pathlib import Path
import shutil
import math
import numpy as np

from __ExcelHandler import ExcelHandler
from __Kompas import *
import _Config

import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Font
from openpyxl.styles import NamedStyle
import xlwings as xw

def sheet1_2_1(xls, code_project=""):
    log_message(f'Подготавливаю ведомость элементов металлоконструкции по маркам', 'title')

    xlsx = Path(xls).parent / '1.2.1 _ Ведомость элементов по маркам.xlsx'
    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler для элементов
    df = excel_handler.read_excel()  # Читаем таблицу в dataframe

    df.dropna(subset=['Эскиз сечения'], inplace=True)  # удалим пустые строки по столбцу с эскизом сечений

    #Проверим есть ли хотя бы один элемент конструкции и если нет, то далее код не выполняем
    if df.shape[0] < 1:
        print("Элементов металлоконструкций в отчёте не найдено")
        os.remove(xlsx)
        return False

    # Сортировка с учётом чисел и строк отдельно
    df = (df.assign(_num=pd.to_numeric(df['№ элемента'], errors='coerce'))
          .sort_values(by=['_num', '№ элемента'], key=lambda col: col.map(str))
          .drop(columns='_num')
          .reset_index(drop=True))

    def update_gn_rif(df):
        def modify_section(row):
            riflenie = row['Рифление']
            gnutost = row['Гнутость']
            addition = ""

            if riflenie == 1 and gnutost == 1:
                addition = "(рифленая_гнутая)"
            elif riflenie == 1 and gnutost == 0:
                addition = "(рифленая)"
            elif riflenie == 0 and gnutost == 1:
                addition = "(гнутая)"
            else:
                addition = ""

            # Если нужно дописывать через пробел
            if addition:
                return f"{row['Сечение из Компас']} {addition}"
            else:
                return row['Сечение из Компас']

        df['Сечение из Компас'] = df.apply(modify_section, axis=1)
        return df

    df = update_gn_rif(df) #Дописываем в 'Сечение из Компас' пластинам если гнутая и рифленая

    df['Наименование'] = ''# Заменяем все значения в столбце 'Наименование' на пустые строки
    df['Путь до марки'] = df['Полное имя файла']

    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом

    df = excel_handler.line_joining_df(
        ['№ элемента', 'Наименование', 'Сечение', 'Тип объекта', 'Марка стали', 'Длина, мм', 'Ширина, мм',
         'Толщина, мм', 'Рифление', 'Гнутость','Элемент марки', 'Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ',
         'Площадь 1 м, м²'],
        ['Кол-во, шт.', 'Так', 'Наоборот', 'Масса элементов, кг'],
        ['Путь до марки'],
        ['Полное имя файла', 'Примечание'], ignore_value=None)# Объединим строки

    df['Элемент марки'] = df['Элемент марки'].apply(excel_handler.sort_cell_values)# Отсортируем строки в ячейках по возрастанию
    # df["Сечение из Компас"] = df["Сечение из Компас"].str.replace(r'\s+', ' ', regex=True).str.strip() # Удаляем двойные пробелы

    # Заполняем примечание
    df['Примечание'] = np.nan
    df['Площадь всех эл., м²'] = np.nan
    df["Площадь 1 эл., м²"] = df["Площадь 1 м, м²"] * df["Длина, мм"] / 1000
    df.drop(columns=["Площадь 1 м, м²"], inplace=True)

    # Отсортируем таблицу
    df = df[['№ элемента', 'Наименование', 'Кол-во, шт.', 'Так', 'Наоборот', 'Длина, мм', 'Ширина, мм', 'Толщина, мм',
             'Рифление', 'Гнутость', 'Марка стали', 'Масса элемента, кг', 'Масса элементов, кг', 'Площадь 1 эл., м²',
             'Площадь всех эл., м²', 'Элемент марки', 'Примечание', 'Сечение', 'Эскиз сечения', 'Наименование профиля ГОСТ, ТУ',
             'Наименование или марка металла ГОСТ, ТУ', 'Тип объекта', 'Полное имя файла', 'Путь до марки']]

    df.to_excel(xlsx, sheet_name="Ведомость элементов по маркам", index=False)  # Записали в xlsx

    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Ведомость элементов по маркам']  # Выбираем лист по имени

    ###Название таблицы
    ws.insert_rows(1)  # Вставим строку
    ws["A1"] = f'{code_project}. Ведомость элементов'

    for row in range(3, ws.max_row + 1):
        ws[f"B{row}"] = f'=CONCATENATE(R{row}, " ", K{row})' # Формула для наименования
        ws[f"M{row}"] = f'=(D{row}+E{row})*L{row}'  # Масса элементов, кг

        # Формула площади
        sketch_code = ws[f"S{row}"].value  # Эскиз сечения
        if sketch_code in ["@016", "@137"]:
            formula = f"=C{row} * 2 * ((F{row}*G{row})*10^-6 + (F{row}+G{row})*H{row}*10^-6)" # Если это пластина — своя формула
        else:
            formula = f"=N{row}*(D{row}+E{row})" # Остальные — обычная длина × площадь профиля × кол-во
        ws[f"O{row}"].value = formula

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов

    excel_handler.fix_dimensions(ws, ['A', 'C', 'D', 'E', 'I', 'J'], width=10)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['F', 'G', 'H', 'K', 'L', 'M','N', 'O', 'P'], width=15)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['B'], width=25)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['Q'], width=45)  # Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 30  # Измените высоту первой строки

    # Включите перенос текста по словам и выравнивание по центру для ячеек во второй строке
    for cell in ws[2]:  # Итерируем по ячейкам во второй строке
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

    # Создание маппинга выравниваний для столбцов
    alignment_map = {
        **{letter: Alignment(horizontal='center', vertical='center') for letter in 'ACDEFGHIJKLMNO'},
        # **{letter: Alignment(horizontal='right', vertical='center') for letter in 'F'},
        **{letter: Alignment(horizontal='left', vertical='center') for letter in 'BPQTU'}
    }
    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем со второй строки, чтобы пропустить заголовки
        for cell in row:
            column_letter = openpyxl.utils.get_column_letter(cell.column)
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    # Скроем ненужные столбцы
    for col in ['C', 'G', 'H', 'I', 'J', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y']:
        ws.column_dimensions[col].hidden = True

    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)  # Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = Alignment(horizontal='left', vertical='center')

    ws.auto_filter.ref = 'A2:{}'.format(openpyxl.utils.get_column_letter(ws.max_column) + '2')  # Автофильтр на вторую строку

    excel_handler.format_columns(ws, ['F', 'L', 'M', 'N', 'O'], n=1, start_row=3)  # Округление до n знаков после запятой
    last_row = ws.max_row

    # Проверки
    excel_handler.check_empty_rows_in_cell_column(ws, 2, 'D, E, G, H, I, J, U, O, W, Y, Q')  # Проверка таблицы на пустые ячейки в ячейках с третей строки и выделяем их цветом
    excel_handler.compare_columns(ws, 'A', 'F', 'K')  # Сравниваем значения в столбце A и проверяем столбцы B, C, D
    number_format_style = NamedStyle(name="number_format_style", number_format="0.0")# Определение стиля для числовых форматов

    # Добавление стиля числового формата в столбцы G и H
    for col in ['G', 'H']:
        for row in range(2, ws.max_row + 1):  # Начинаем с 2-й строки, чтобы пропустить заголовок
            cell = ws[f"{col}{row}"]
            if cell.value is not None and isinstance(cell.value, (int, float)):
                cell.style = number_format_style


    ws.cell(row=last_row + 2, column=12, value='Итого').font = Font(bold=True)  # Столбец J (10)# Добавляем строку 'Итого'
    ws.cell(row=last_row + 2, column=13).alignment = Alignment(horizontal='right', vertical='center')# Установка выравнивания
    ws.cell(row=last_row + 2, column=13, value=f'=ROUND(SUM(M3:M{last_row}), 1)').font = Font(bold=True)# Устанавливаем формулу в столбец для последней строки
    ws.cell(row=last_row + 2, column=13, value=f'=ROUND(SUM(M3:M{last_row}), 1)').number_format = '0 "кг"'
    # Строка "Итого" для площади проката
    # ws.cell(row=last_row + 2, column=14, value='Итого').font = Font(bold=True)  # Столбец N (14)
    ws.cell(row=last_row + 2, column=15).alignment = Alignment(horizontal='right', vertical='center')
    ws.cell(row=last_row + 2, column=15, value=f'=ROUNDUP(SUM(O3:O{last_row}), 0)').font = Font(bold=True)
    ws.cell(row=last_row + 2, column=15).number_format = '0 "м²"'  # Установка формата "м²"

    # Удаление из ячеек 0 в столбцах Так и Наоборот
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=4, max_col=5):
        for cell in row:
            if cell.value == 0:  # Проверка на 0
                cell.value = None  # Замена на None

    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()
    pyperclip.copy(os.path.dirname(xls))  # Запишем путь до папки с xlsx в буфер обмена
    log_message(f'Ведомость элементов металлоконструкции - создана', 'ok')

    # Открываем книгу через Excel
    with xw.App(visible=False) as app:  # Создаём приложение и делаем его невидимым
        wb = xw.Book(xlsx)  # Открываем файл
        app.calculate()  # Пересчёт всех формул
        wb.save()  # Сохраняем файл
        wb.close()  # Закрываем книгу
    return xlsx

if __name__ == "__main__":
    xls = r"C:\Users\ik\Desktop\!2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\!01 _ CAD\Материалы\Общий отчёт.xlsx"
    # path = get_active_doc_path(iApplication)
    # xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
    sheet1_2_1(xls, _Config.format_cnc)
    input('\n\rРабота завершена.	\n')

