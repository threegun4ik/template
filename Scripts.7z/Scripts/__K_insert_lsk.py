import sys
import easygui
from pathlib import Path

from __Kompas import *
from __K_m3d_to_i3d import m3d_to_i3d
from traceback import format_exc


def insert_lcs(filename_m3d: str, filename_i3d: str, format_cnc: str, KompasObject, iApplication):
    """Вставляет в m3d ЛСК и сохраняет в stp или igs"""
    elem = []  # Список временных объектов, которые нужно будет удалить позже (оси, плоскости и т.д.)

    iDocuments = iApplication.Documents
    filename_m3d = str(filename_m3d)

    # Пробуем получить уже открытый документ или открыть новый
    iKompasDocument, opened = iDocuments.Item(filename_m3d), True

    try:
        if not iKompasDocument:
            iKompasDocument = iDocuments.Open(filename_m3d, False, True)
            opened = False

        if not iKompasDocument:
            print(f'Ошибка: не удалось открыть файл {filename_m3d}')# {red}
            return

        # Получаем доступ к API7 объектов модели
        iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
        # iDocument3D = KompasObject.ActiveDocument3D() # Перестал работать верно
        iDocument3D = KompasObject.TransferInterface(iKompasDocument3D, 1, 0)
        iPart7 = iKompasDocument3D.TopPart

        if not all([iKompasDocument3D, iDocument3D, iPart7]):
            print(f'Ошибка: Не удалось получить доступ к API Kompas 3D')# {red}
            return

        iModelContainer = API7.IModelContainer(iPart7)
        iFaces = iModelContainer.Objects(con3.o3d_face)  # Все грани модели
        iAxes3D = API7.IAuxiliaryGeomContainer(iPart7).Axes3D  # Для добавления осей

        # Инициализация переменных для поиска наилучших граней/осей
        largest_area_sum, largest_face_sum = -1, None  # для цилиндров/конусов
        largest_plane_area, largest_plane_face = -1, None  # для плоских граней
        longest_length, longest_edge = -1, None  # для самой длинной прямой ребра
        surface3D_type2 = False  # флаг — найдена ли хотя бы одна плоская грань

        # --- Анализ всех граней тела ---
        for iFace in iFaces:
            iMathSurface3D = iFace.MathSurface
            if iMathSurface3D.Surface3DType in {3, 4}:  # Конус или цилиндр
                # Создаём оси-ребра для скруглений для оси Y
                iAxis3D = iAxes3D.Add(con3.o3d_axisConeFace)
                API7.IAxis3DByConeface(iAxis3D).Face = iFace
                iAxis3D.Update()
                elem.append(iAxis3D)

                area_cone = iFace.GetArea(3) # Площадь цилиндрической грани
                connected_faces = iFace.ConnectedFaces # Стыкуемые грани

                flat_faces = [f for f in connected_faces if f.MathSurface.Surface3DType == 2] # Получаем только плоские грани

                if not flat_faces:
                    flat_faces = [iFace]  # Если плоских граней нет используем найденную


                total_area_flats = sum(f.GetArea(3) for f in flat_faces) # Получаем площади стыкуемых плоских граней
                total_area = area_cone + total_area_flats # Суммарная площадь цилиндра и прилегающих плоскостей

                # Запоминаем набор с максимальной суммарной площадью
                if total_area > largest_area_sum:
                    largest_area_sum = total_area

                    max_face = max(flat_faces, key=lambda f: f.GetArea(3)) # среди плоских выбираем с наибольшей площадью
                    if max_face.GetArea(3) > area_cone: # сравниваем: плоская грань или цилиндрическая больше по площади
                        largest_face_sum = max_face
                    else:
                        largest_face_sum = iFace  # цилиндрическая грань крупнее — выбираем её

            elif iMathSurface3D.Surface3DType == 2:  # Если цилиндрических нет работаем с плоской гранью
                surface3D_type2 = True
                area = iFace.GetArea(3)
                if area > largest_plane_area:
                    largest_plane_area = area
                    largest_plane_face = iFace

        # --- Выбор итоговой "лучшей" плоскости для оси X ---
        if largest_plane_area > largest_area_sum:
            largest_area = largest_plane_area
            largest_face = largest_plane_face
        else:
            largest_area = largest_area_sum
            largest_face = largest_face_sum

        # --- Поиск самого длинного прямого ребра (для ориентации вдоль профиля) для оси Y---
        for iEdge in iModelContainer.Objects(con3.o3d_edge):
            if iEdge.IsStraight and iEdge.GetLength(3) > longest_length:
                longest_length, longest_edge = iEdge.GetLength(3), iEdge

        # --- Проверка, что нужные элементы найдены ---
        if not (largest_face):
            print(f'Ошибка: Не найдены подходящие плоскость и ребро для ЛСК') #{red}
            print(f'Проблемный файл: {filename_m3d}') #{yellow}
            m3d_to_i3d(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication)
            return False

        # --- Центр масс — точка установки ЛСК ---
        iMassInertiaParam7 = API7.IMassInertiaParam7(iPart7)
        Xc, Yc, Zc = iMassInertiaParam7.Xc * 10, iMassInertiaParam7.Yc * 10, iMassInertiaParam7.Zc * 10

        # --- Создание ЛСК и установка ориентации ---
        iLocalCoordinateSystems = API7.IAuxiliaryGeomContainer(iPart7).LocalCoordinateSystems
        iLocalCoordinateSystem = iLocalCoordinateSystems.Add()
        iLocalCoordinateSystem.X, iLocalCoordinateSystem.Y, iLocalCoordinateSystem.Z = Xc, Yc, Zc
        iLocalCoordinateSystem.Current, iLocalCoordinateSystem.OrientationType = 1, con3.ksAxisOrientation

        iLocalCSAxesDirectionParam = API7.ILocalCSAxesDirectionParam(iLocalCoordinateSystem.LocalCSParameters)

        # Ось X (перпендикуляр к стенке)
        if surface3D_type2:
            iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, largest_face)

        # Ось Y (вдоль ребра профиля)
        name = filename_m3d.lower()
        if not "пластина" in name or not "полоса" in name:
            if longest_edge:# and not surface3D_type2:
                iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOY, longest_edge)

        iLocalCoordinateSystem.Update()

        # --- Создание вспомогательной плоскости для вида ---
        iPlane3D = iModelContainer.AddObject(con3.o3d_planeOffset)
        # API7.IPlane3DByOffset(iPlane3D).BasePlane = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeXOY)
        API7.IPlane3DByOffset(iPlane3D).BasePlane = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeYOZ)
        iPlane3D.Update()
        elem.append(iPlane3D)

        # --- Установка текущего вида по этой плоскости ---
        plane = KompasObject.TransferInterface(iPlane3D, 1, 0)
        iPlacement = plane.GetSurface().GetSurfaceParam().GetPlacement()
        iViewProjection = iDocument3D.GetViewProjectionCollection().NewViewProjection()
        iViewProjection.name = '1'
        iViewProjection.SetPlacement(iPlacement)
        iViewProjection.SetCurrent()

        # --- Экспорт модели в указанный формат ---
        format_dict = {'stp': 214, 'igs': 4}
        if format_cnc in format_dict:
            iAdditionFormatParam = iDocument3D.AdditionFormatParam()
            iAdditionFormatParam.Init()
            iAdditionFormatParam.format = format_dict[format_cnc]
            iAdditionFormatParam.SetPlacement(iPlacement)
            iDocument3D.SaveAsToAdditionFormat(filename_i3d, iAdditionFormatParam)

        print(f'{Path(filename_m3d).stem} - Готово')

    except:
        print((f'Ошибка {format_exc()}')) #{magenta}

    finally:
        # Закрытие и очистка
        if not opened:
            for el in elem:
                API7.IFeature7(el).Delete()
        if not opened and iKompasDocument:
            iKompasDocument.Close(1)

        # print(f'Всего: {iDocuments.Count}')
        # iKompasDocument = iDocuments(filename_m3d)
        # if iKompasDocument:
        #     iKompasDocument.Close(1)
        return True



if __name__ == "__main__":
    KompasObject, iApplication, KompasVesrsion = get_kompas()
    filename_m3d = None

    filename_m3d = r'I:\Documents\MY PROJECT\Active Project\Олег\Стойки\Материалы\3d parts\m3d\1701_Пластина 10x235_L360мм_С245_1(т)шт.m3d'
    # path = k_path_active_doc()
    # filename_m3d = easygui.fileopenbox(msg="Укажите файл модели m3d", default=f"{path}/*.m3d")
    # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
    if filename_m3d:
        folder_i3d = Path(filename_m3d).parent
        format_cnc = 'igs'
        filename_i3d = folder_i3d / format_cnc / (Path(filename_m3d).stem + '.' + format_cnc)
        filename_i3d.parent.mkdir(parents=True, exist_ok=True)
        # print('тут')
        insert_lcs(filename_m3d, filename_i3d, format_cnc,KompasObject, iApplication)
    else:
        print('debug')
        iKompasDocument =iApplication.ActiveDocument
        filename_m3d = iKompasDocument.PathName #Полный путь до файла
        # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
        folder_i3d = Path(filename_m3d).parent
        format_cnc = 'igs'
        file_name_without_extension = Path(filename_m3d).stem
        filename_i3d = Path(folder_i3d) / format_cnc / (file_name_without_extension + '.' + format_cnc)
        filename_i3d.parent.mkdir(parents=True, exist_ok=True)  # Создаем папку, если не существует
        insert_lcs(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication)

#
# def insert_lcs(filename_m3d: str, filename_i3d: str, format_cnc: str, KompasObject, iApplication):
#     """Вставляет в m3d ЛСК и сохраняет в stp или igs"""
#     elem = []  # Список для удаления временных объектов
#
#     iDocuments = iApplication.Documents
#     filename_m3d = str(filename_m3d)  # Убедимся, что передан путь в виде строки
#     iKompasDocument, opened = iDocuments.Item(filename_m3d), True  # Проверяем, открыт ли документ
#
#     try:
#         if not iKompasDocument:
#             iKompasDocument = iDocuments.Open(filename_m3d, False, True)
#             opened = False  # Документ был открыт в этом скрипте
#
#         if not iKompasDocument:
#             print(f'{red}Ошибка: не удалось открыть файл {filename_m3d}{default}')
#             return
#
#         iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
#         iDocument3D = KompasObject.ActiveDocument3D()
#         iPart7 = iKompasDocument3D.TopPart
#
#
#         if not all([iKompasDocument3D, iDocument3D, iPart7]):
#             print(f'{red}Ошибка: Не удалось получить доступ к API Kompas 3D{default}')
#             return
#
#         iModelContainer = API7.IModelContainer(iPart7)
#         iFaces = iModelContainer.Objects(con3.o3d_face)
#         iAxes3D = API7.IAuxiliaryGeomContainer(iPart7).Axes3D
#
# #####
#         largest_area_sum, largest_face_sum = -1, None
#         largest_plane_area, largest_plane_face = -1, None
#         longest_length, longest_edge = -1, None
#
#         surface3D_type2 = False
#
#         for iFace in iFaces:
#             iMathSurface3D = iFace.MathSurface
#             if iMathSurface3D.Surface3DType in {3, 4}:  # Конус или цилиндр
#                 #Добавляем ребра
#                 iAxis3D = iAxes3D.Add(con3.o3d_axisConeFace)
#                 API7.IAxis3DByConeface(iAxis3D).Face = iFace
#                 # largest_face = iFace
#                 iAxis3D.Update()
#                 elem.append(iAxis3D)
#
#                 area_cone = iFace.GetArea(3)
#                 connected_faces = iFace.ConnectedFaces
#
#                 # Собираем все стыкуемые плоскости (Surface3DType == 2)
#                 flat_faces = [f for f in connected_faces if f.MathSurface.Surface3DType == 2]
#
#                 if not flat_faces:
#                     flat_faces = [iFace] # для труб
#                     # continue
#
#                 # Суммируем площади всех плоскостей в группе
#                 total_area_flats = sum(f.GetArea(3) for f in flat_faces)
#                 total_area = area_cone + total_area_flats
#
#                 if total_area > largest_area_sum:
#                     largest_area_sum = total_area
#
#                     # Ищем среди плоскостей максимальную по площади грань
#                     max_area = -1
#                     max_face = None
#                     for f in flat_faces:
#                         a = f.GetArea(3)
#                         if a > max_area:
#                             max_area = a
#                             max_face = f
#
#                     largest_face_sum = max_face
#
#             elif iMathSurface3D.Surface3DType == 2:  # Плоскость
#                 surface3D_type2 = True
#                 area = iFace.GetArea(3)
#                 if area > largest_plane_area:
#                     largest_plane_area = area
#                     largest_plane_face = iFace
#
#         # Выбираем максимальный по площади вариант:
#         if largest_plane_area > largest_area_sum:
#             # print(f'{largest_plane_area} > {largest_area_sum}')
#             largest_area = largest_plane_area
#             largest_face = largest_plane_face
#         else:
#             # print(f'{largest_plane_area} < {largest_area_sum}')
#             largest_area = largest_area_sum
#             largest_face = largest_face_sum
#
#         for iEdge in iModelContainer.Objects(con3.o3d_edge):
#             if iEdge.IsStraight and iEdge.GetLength(3) > longest_length:
#                 longest_length, longest_edge = iEdge.GetLength(3), iEdge
#
#         if not (largest_face):
#             print(f'{red}Ошибка: Не найдены подходящие плоскость и ребро для ЛСК{default}')
#             print(f'{yellow}Проблемный файл:{default} {filename_m3d}')
#             m3d_to_i3d(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication)
#             return False
#
#         # Массово-центровочные характеристики
#         iMassInertiaParam7 = API7.IMassInertiaParam7(iPart7)
#         Xc, Yc, Zc = iMassInertiaParam7.Xc * 10, iMassInertiaParam7.Yc * 10, iMassInertiaParam7.Zc * 10
#
#         # Создание ЛСК
#         iLocalCoordinateSystems = API7.IAuxiliaryGeomContainer(iPart7).LocalCoordinateSystems
#         iLocalCoordinateSystem = iLocalCoordinateSystems.Add()
#         iLocalCoordinateSystem.X, iLocalCoordinateSystem.Y, iLocalCoordinateSystem.Z = Xc, Yc, Zc
#         iLocalCoordinateSystem.Current, iLocalCoordinateSystem.OrientationType = 1, con3.ksAxisOrientation
#         iLocalCSAxesDirectionParam = API7.ILocalCSAxesDirectionParam(iLocalCoordinateSystem.LocalCSParameters)
#
#         if longest_edge:
#             # print(f'longest_edge:{longest_edge}')
#             iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOY, longest_edge)
#
#         if surface3D_type2:
#             # print(f'largest_face:{largest_face}')
#             iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, largest_face)
#         iLocalCoordinateSystem.Update()
#
#         # # # Создание вспомогательной плоскости
#         iPlane3D = iModelContainer.AddObject(con3.o3d_planeOffset)
#         API7.IPlane3DByOffset(iPlane3D).BasePlane = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeXOY)
#         iPlane3D.Update()
#         elem.append(iPlane3D)
#
#         # Установка вида
#         plane = KompasObject.TransferInterface(iPlane3D, 1, 0)
#         iPlacement = plane.GetSurface().GetSurfaceParam().GetPlacement()
#
#         iViewProjection = iDocument3D.GetViewProjectionCollection().NewViewProjection()
#         iViewProjection.name = '1'
#         iViewProjection.SetPlacement(iPlacement)
#         iViewProjection.SetCurrent()
#
#         # Экспорт в нужный формат
#         format_dict = {'stp': 214, 'igs': 4}
#         if format_cnc in format_dict:
#             iAdditionFormatParam = iDocument3D.AdditionFormatParam()
#             iAdditionFormatParam.Init()
#             iAdditionFormatParam.format = format_dict[format_cnc]
#             iAdditionFormatParam.SetPlacement(iPlacement)
#             iDocument3D.SaveAsToAdditionFormat(filename_i3d, iAdditionFormatParam)
#
#         print(f'{Path(filename_m3d).stem} - Готово')
#     except:
#         print((f'{magenta}Ошибка {format_exc()}{default}'))
#
#     finally:
#         if not opened and iKompasDocument:
#             iKompasDocument.Close(1)  # Закрываем только если открывали в этом скрипте
#         if not opened:
#             for el in elem:  # Удаляем временные объекты
#                 API7.IFeature7(el).Delete()
#         return True
#
#
#
# if __name__ == "__main__":
#     # from _Kompas import get_kompas
#     KompasObject, iApplication, KompasVesrsion = get_kompas()
#     filename_m3d = None
#
#     # filename_m3d = r'I:\Documents\20250220-КМ _ Здание\03 _ Design\01 _ CAD\Материалы\3d parts\m3d\1001_Двутавр 35Ш3_L11053мм_С255_4(т)шт.m3d'
#     # path = k_path_active_doc()
#     # filename_m3d = easygui.fileopenbox(msg="Укажите файл модели m3d", default=f"{path}/*.m3d")
#     # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
#     if filename_m3d:
#         folder_i3d = Path(filename_m3d).parent
#         format_cnc = 'igs'
#         filename_i3d = folder_i3d / format_cnc / (Path(filename_m3d).stem + '.' + format_cnc)
#         filename_i3d.parent.mkdir(parents=True, exist_ok=True)
#         # print('тут')
#         insert_lcs(filename_m3d, filename_i3d, format_cnc,KompasObject, iApplication)
#     else:
#         print('debug')
#         iKompasDocument =iApplication.ActiveDocument
#         filename_m3d = iKompasDocument.PathName #Полный путь до файла
#         # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
#         folder_i3d = Path(filename_m3d).parent
#         format_cnc = 'igs'
#         file_name_without_extension = Path(filename_m3d).stem
#         filename_i3d = Path(folder_i3d) / format_cnc / (file_name_without_extension + '.' + format_cnc)
#         filename_i3d.parent.mkdir(parents=True, exist_ok=True)  # Создаем папку, если не существует
#         insert_lcs(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication)
#



# import sys
# import easygui
# from pathlib import Path
# from _Kompas import *
# from _K_m3d_to_i3d import m3d_to_i3d
# from _Colors import *
# from traceback import format_exc
#
#
# def insert_lcs(filename_m3d: str, filename_i3d: str, format_cnc: str, KompasObject, iApplication):
#     """Вставляет в m3d ЛСК и сохраняет в stp или igs"""
#     elem = []  # Список для удаления временных объектов
#
#     iDocuments = iApplication.Documents
#     filename_m3d = str(filename_m3d)  # Убедимся, что передан путь в виде строки
#     iKompasDocument, opened = iDocuments.Item(filename_m3d), True  # Проверяем, открыт ли документ
#
#     try:
#         if not iKompasDocument:
#             iKompasDocument = iDocuments.Open(filename_m3d, False, True)
#             opened = False  # Документ был открыт в этом скрипте
#
#         if not iKompasDocument:
#             print(f'{red}Ошибка: не удалось открыть файл {filename_m3d}{default}')
#             return
#
#         iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
#         iDocument3D = KompasObject.ActiveDocument3D()
#         iPart7 = iKompasDocument3D.TopPart
#
#         if not all([iKompasDocument3D, iDocument3D, iPart7]):
#             print(f'{red}Ошибка: Не удалось получить доступ к API Kompas 3D{default}')
#             return
#
#         iModelContainer = API7.IModelContainer(iPart7)
#         iFaces = iModelContainer.Objects(con3.o3d_face)
#         iAxes3D = API7.IAuxiliaryGeomContainer(iPart7).Axes3D
#
#
#         largest_area, largest_face = -1, None
#         longest_length, longest_edge = -1, None
#
#         for iFace in iFaces:
#             iMathSurface3D = iFace.MathSurface
#             if iMathSurface3D.Surface3DType in {3, 4}:  # Конус или цилиндр
#                 iAxis3D = iAxes3D.Add(con3.o3d_axisConeFace)
#                 API7.IAxis3DByConeface(iAxis3D).Face = iFace
#                 # largest_face = iFace
#                 iAxis3D.Update()
#                 elem.append(iAxis3D)
#
#             if iMathSurface3D.Surface3DType == 2:  # Плоскость
#                 area = iFace.GetArea(3)
#                 if area > largest_area:
#                     surface3D_type2 = True
#                     largest_area, largest_face = area, iFace
#
#         for iEdge in iModelContainer.Objects(con3.o3d_edge):
#             if iEdge.IsStraight and iEdge.GetLength(3) > longest_length:
#                 longest_length, longest_edge = iEdge.GetLength(3), iEdge
#
#         if not (largest_face and longest_edge):
#             print(f'{red}Ошибка: Не найдены подходящие плоскость и ребро для ЛСК{default}')
#             print(f'{yellow}Проблемный файл:{default} {filename_m3d}')
#             m3d_to_i3d(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication)
#             return False
#
#         # Массово-центровочные характеристики
#         iMassInertiaParam7 = API7.IMassInertiaParam7(iPart7)
#         Xc, Yc, Zc = iMassInertiaParam7.Xc * 10, iMassInertiaParam7.Yc * 10, iMassInertiaParam7.Zc * 10
#
#         # Создание ЛСК
#         iLocalCoordinateSystems = API7.IAuxiliaryGeomContainer(iPart7).LocalCoordinateSystems
#         iLocalCoordinateSystem = iLocalCoordinateSystems.Add()
#         iLocalCoordinateSystem.X, iLocalCoordinateSystem.Y, iLocalCoordinateSystem.Z = Xc, Yc, Zc
#         iLocalCoordinateSystem.Current, iLocalCoordinateSystem.OrientationType = 1, con3.ksAxisOrientation
#
#         iLocalCSAxesDirectionParam = API7.ILocalCSAxesDirectionParam(iLocalCoordinateSystem.LocalCSParameters)
#         if surface3D_type2:
#             iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOX, largest_face)
#         iLocalCSAxesDirectionParam.SetDirectingObject(con3.o3d_axisOY, longest_edge)
#         iLocalCoordinateSystem.Update()
#
#         # # # Создание вспомогательной плоскости
#         iPlane3D = iModelContainer.AddObject(con3.o3d_planeOffset)
#         API7.IPlane3DByOffset(iPlane3D).BasePlane = iLocalCoordinateSystem.DefaultObject(con3.o3d_planeXOY)
#         iPlane3D.Update()
#         elem.append(iPlane3D)
#
#         # Установка вида
#         plane = KompasObject.TransferInterface(iPlane3D, 1, 0)
#         iPlacement = plane.GetSurface().GetSurfaceParam().GetPlacement()
#
#         iViewProjection = iDocument3D.GetViewProjectionCollection().NewViewProjection()
#         iViewProjection.name = '1'
#         iViewProjection.SetPlacement(iPlacement)
#         iViewProjection.SetCurrent()
#
#         # Экспорт в нужный формат
#         format_dict = {'stp': 214, 'igs': 4}
#         if format_cnc in format_dict:
#             iAdditionFormatParam = iDocument3D.AdditionFormatParam()
#             iAdditionFormatParam.Init()
#             iAdditionFormatParam.format = format_dict[format_cnc]
#             iAdditionFormatParam.SetPlacement(iPlacement)
#             iDocument3D.SaveAsToAdditionFormat(filename_i3d, iAdditionFormatParam)
#
#         print(f'{Path(filename_m3d).stem} - Готово')
#     except:
#         print((f'{magenta}Ошибка {format_exc()}{default}'))
#
#     finally:
#         if not opened and iKompasDocument:
#             iKompasDocument.Close(1)  # Закрываем только если открывали в этом скрипте
#         if not opened:
#             for el in elem:  # Удаляем временные объекты
#                 API7.IFeature7(el).Delete()
#         return True
#
#
#
# if __name__ == "__main__":
#     # from _Kompas import get_kompas
#     KompasObject, iApplication = get_kompas()
#     filename_m3d = None
#
#     # filename_m3d = r'I:\Documents\20250220-КМ _ Здание\03 _ Design\01 _ CAD\Материалы\3d parts\m3d\1001_Двутавр 35Ш3_L11053мм_С255_4(т)шт.m3d'
#     # path = k_path_active_doc()
#     # filename_m3d = easygui.fileopenbox(msg="Укажите файл модели m3d", default=f"{path}/*.m3d")
#     # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
#     if filename_m3d:
#         folder_i3d = Path(filename_m3d).parent
#         format_cnc = 'igs'
#         filename_i3d = folder_i3d / format_cnc / (Path(filename_m3d).stem + '.' + format_cnc)
#         filename_i3d.parent.mkdir(parents=True, exist_ok=True)
#         # print('тут')
#         insert_lcs(filename_m3d, filename_i3d, format_cnc,KompasObject, iApplication)
#     else:
#         print('debug')
#         iKompasDocument =iApplication.ActiveDocument
#         filename_m3d = iKompasDocument.PathName #Полный путь до файла
#         # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
#         folder_i3d = Path(filename_m3d).parent
#         format_cnc = 'igs'
#         file_name_without_extension = Path(filename_m3d).stem
#         filename_i3d = Path(folder_i3d) / format_cnc / (file_name_without_extension + '.' + format_cnc)
#         filename_i3d.parent.mkdir(parents=True, exist_ok=True)  # Создаем папку, если не существует
#         insert_lcs(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication)
