import easygui, os
from pathlib import Path
import os

from __ExcelHandler import ExcelHandler
from __Kompas import *
from _cutting_plan import cutting_plan

import openpyxl
from openpyxl.styles import PatternFill, Border, Alignment, Side
from openpyxl.drawing.image import Image
import pandas as pd

def xls_to_cdw(df, cell_widths, merge_cells, text_styles):
    n_x = df.shape[0]  # Количество строк
    n_y = df.shape[1]  # Количество столбцов

    iKompasDocument = iApplication.ActiveDocument #  Получи интерфейс активного документа
    documentType = iKompasDocument.DocumentType
    KompasObject.ksError(f'Импортируем таблицу из Excel в активный чертёж')
    if documentType != 1:
        iApplication.MessageBoxEx('Активный документ не чертеж', 'Ошибка', 0)
        sys.exit()

    #  Создай графический объект "Таблица"
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
    iViews = iViewsAndLayersManager.Views
    iView = iViews.ActiveView
    iSymbols2DContainer = API7.ISymbols2DContainer(iView)
    iDrawingTables = iSymbols2DContainer.DrawingTables
    iDrawingTable = iDrawingTables.Add(n_x, n_y, 30.0, 30.0, 1) #Тут размер таблицы
    iDrawingTable.X = 0
    iDrawingTable.Y = 0
    iDrawingTable.Angle = 0.0
    iDrawingTable.FixedCellsSize = False
    iDrawingTable.FixedRowCount = False
    iDrawingTable.FixedColumnCount = False
    iTable = API7.ITable(iDrawingTable)
    cell_number = 0
    # Перебор каждой ячейки таблицы

    # Проход по строкам и столбцам DataFrame
    for row_index in range(df.shape[0]):  # Количество строк
        for col_index in range(df.shape[1]):  # Количество столбцов
            # Получение значения ячейки
            # cell_value = cell_number  # Нумерация по порядку

            # Индекс для доступа к нужному элементу в списке text_param
            index = row_index * df.shape[1] + col_index

            horizontal_align, vertical_align, italic, bold = text_styles[index]
            # print(horizontal_align, vertical_align, italic, bold)
            alignments = {
                'Left': con0.ksAlignLeft,
                'Center': con0.ksAlignCenter,
                'Right': con0.ksAlignRight,
                'General': con0.ksAlignCenter
            }

            # print(f"Строка {row_index}, Столбец {col_index}: {horizontal_align}, {vertical_align}, Italic={italic}, Bold={bold}")
            cell_number += 1
            iTableCell = iTable.CellById(cell_number)  # Номер ячейки
            iCellFormat = API7.ICellFormat(iTableCell)
            iCellFormat.TextStyle = 10
            iCellFormat.ReadOnly = False
            iCellFormat.OneLine = False
            # iCellFormat.LeftEdge = 0.5
            # iCellFormat.RightEdge = -0.5
            # iCellFormat.SpaceBefore = 0.0
            # iCellFormat.SpaceAfter = 0.0
            iCellFormat.Width = cell_widths[cell_number - 1]
            iCellFormat.Height = 8.0 #Высота строки
            iCellFormat.HFormat = con0.ksHFormatDivision
            iCellFormat.VFormat = True

            iText = API7.IText(iTableCell.Text)
            iText.Style = con0.ksTSTableCell  # Текст для таблицы (ячейка)

            iTextLine = iText.Add()
            iTextLine.Style = con0.ksHFormatDivision
            iTextLine.Step = 1.0

            iTextLine.Align = alignments.get(horizontal_align, iTextLine.Align)
            iTextLine.IndentedLine = 0.0
            iTextLine.StepBeforeParagraph = 0.0
            iTextLine.StepAfterParagraph = 0.0
            iTextLine.LeftEdge = 1.0
            iTextLine.RightEdge = 1.0
            iTextLine.Level = 0
            # iTextLine.Numbering = con0.ksTNumbNoNumber
            # iTextLine.NewPage = False

            iTextItem = iTextLine.Add()
            iTextItem.ItemType = con0.ksTItString
            iTextItem.NewLine = True

            if pd.isna(df.iat[row_index, col_index]):
                iTextItem.Str = ""  # Если значение NaN, присваиваем пустую строку
            else:
                # Преобразуем значение в строку с заменой точки на запятую
                iTextItem.Str = str(df.iat[row_index, col_index]).replace('.', ',')
            iTextFont = API7.ITextFont(iTextItem)
            iTextFont.FontName = "GOST Type AU"
            iTextFont.Height = 3.0
            iTextFont.WidthFactor = 1.0
            iTextFont.Color = 0
            iTextFont.Bold = bool(bold)
            iTextFont.Italic = bool(italic)
            iTextFont.TextLineStep = 0.0
            iTextItem.Update()

    iDrawingTable.Update()
    #Объединяем ячейки
    for merged_cell in merge_cells:
        row_start, col_start, row_end, col_end = merged_cell
        iTableRange = iTable.Range(row_start, col_start, row_end, col_end)
        iTableRange.CombineCells()
    iDrawingTable.Update()

def has_images_in_column(ws, target_col=7):
    for img in ws._images:
        try:
            col = img.anchor._from.col
            if isinstance(col, int) and col == target_col:
                return True
            if hasattr(col, 'col') and col.col == target_col:
                return True
        except AttributeError:
            continue
    return False

def reorder_columns_with_images_fixed_size(ws, new_ws, new_order):
    image_map = {}
    for image in ws._images:
        if image.anchor and hasattr(image.anchor, '_from'):
            row, col = image.anchor._from.row + 1, image.anchor._from.col + 1
            image_map[(row, col)] = image
    return image_map

def reorder_columns_with_text_details(ws, new_ws, new_order):
    import re
    import random

    color_by_element = {}
    fallback_colors = {}
    thin_border = Border(left=Side(style='thin'),
                         right=Side(style='thin'),
                         top=Side(style='thin'),
                         bottom=Side(style='thin'))

    def parse_geometry(cell_value):
        return re.findall(r"\((\d+)\s+(\d+)\)", str(cell_value))

    def get_random_color(element_id):
        if element_id not in fallback_colors:
            fallback_colors[element_id] = "{:06x}".format(random.randint(0x444444, 0xDDDDDD))
        return fallback_colors[element_id]

    geometry_map = {}

    for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
        row_index = row[0].row
        num_row = ws.cell(row=row_index, column=1).value  # A Номер
        profile_cell = ws.cell(row=row_index, column=4).value  # D - Наименование профиля
        length_cell = ws.cell(row=row_index, column=3).value  # C - длина заготовки
        col_cell = ws.cell(row=row_index, column=5).value  # E Количество заготовок
        residue_cell = ws.cell(row=row_index, column=6).value  # F - остаток
        geo_cell = ws.cell(row=row_index, column=8).value  # H Карта раскроя

        geometries = parse_geometry(geo_cell)
        if not geometries:
            continue

        segment_list = []
        used_length = 0

        for length_str, elem_id in geometries:
            length = int(length_str)
            color = get_random_color(elem_id)
            segment_list.append({
                "section": profile_cell,
                "length": length,
                "element": elem_id,
                "color": color
            })
            used_length += length

        if residue_cell and isinstance(residue_cell, (int, float)) and residue_cell > 0:
            segment_list.append({
                "length": int(residue_cell),
                "section": profile_cell,
                "element": None,
                "color": "FFFFFF"
            })

        geometry_map[row_index] = segment_list

    # print("\nПлан раскладки деталей:")
    # for row_idx, segments in geometry_map.items():
    #     print(f"Строка {row_idx}:")
    #     for s in segments:
    #         label = f"Дет. {s['element']} - L{s['length']} мм" if s['element'] else f"Остаток - {s['length']} мм"
    #         print(f"Сечение: {s['section']} - '{label}', цвет: #{s['color']}")

    return {"geometry_map": geometry_map}

def sheet1_6(xls, code_project=""):
    log_message(f'Форматирую карту раскроя', 'title')
    xlsx = Path(xls).parent / '1.6 _ Карта раскроя.xlsx'
    new_order = [1, 4, 2, 5, 6, 8, 3, 7]

    wb = openpyxl.load_workbook(xls)
    ws = wb.active

    new_wb = openpyxl.Workbook()
    new_ws = new_wb.active

    images_exist = has_images_in_column(ws, target_col=7)
    text_in_H = any(ws.cell(row=row, column=8).value not in (None, "") for row in range(2, ws.max_row + 1))

    if images_exist:
        image_map = reorder_columns_with_images_fixed_size(ws, new_ws, new_order)
        use_text = False
    elif text_in_H:
        image_map = reorder_columns_with_text_details(ws, new_ws, new_order)
        use_text = True
    else:
        raise ValueError("Нет изображений и текст в столбце H отсутствует.")

    for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
        for new_col_idx, old_col_idx in enumerate(new_order, start=1):
            cell = row[old_col_idx - 1]
            new_cell = new_ws.cell(row=cell.row + 1, column=new_col_idx)
            value = cell.value

            if new_col_idx in [3, 5]:
                try:
                    new_cell.value = float(value)
                except (ValueError, TypeError):
                    new_cell.value = value
            elif use_text and new_col_idx == 6:
                fallback_text = ws.cell(row=cell.row, column=8).value
                new_cell.value = fallback_text if fallback_text else ""
                new_cell.alignment = Alignment(wrapText=True, vertical='top')
            else:
                new_cell.value = value

            new_cell.border = Border(left=Side(style='thin'),
                                     right=Side(style='thin'),
                                     top=Side(style='thin'),
                                     bottom=Side(style='thin'))

            if new_col_idx in [1, 3, 4, 5]:
                new_cell.alignment = Alignment(horizontal='center', vertical='center')
            elif new_col_idx != 6:
                new_cell.alignment = Alignment(vertical='center')

            if not use_text and new_col_idx == 6:
                img = image_map.get((cell.row, old_col_idx))
                if img:
                    new_ws.add_image(Image(img.ref), new_cell.coordinate)

    ws = new_ws

    for row in range(2, ws.max_row + 2):
        ws.row_dimensions[row].height = 57

    ExcelHandler.auto_dimensions(ws)
    ExcelHandler.fix_dimensions(ws, 'F', 245)
    ExcelHandler.fix_dimensions(ws, 'C', 12)
    if images_exist:
        ws.delete_cols(7)  # Удаляем только столбец G (7-й по счёту)

    ws["A1"] = f'{code_project}. Карта раскроя'
    headers = {
        "A2": "№",
        "B2": "Наименование профиля",
        "C2": "Длина заготовки, мм",
        "D2": "Кол-во заготовок, шт.",
        "E2": "Остаток, мм",
        "F2": "Карта (*Внутри геометрии - длина отреза, под геометрией - номер элемента)"
    }
    for cell, value in headers.items():
        ws[cell] = value

    for cell in ws[2]:
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = openpyxl.styles.Alignment(horizontal='left', vertical='center')

    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.print_title_rows = '2:1'

    max_row = ws.max_row
    max_col = ws.max_column
    ws.print_area = f'A1:{openpyxl.utils.get_column_letter(max_col)}{max_row}'

    ws.page_setup.centerHorizontally = True
    ws.page_setup.centerVertically = True

    new_wb.save(xlsx)
    ExcelHandler.adjust_image_position(xlsx, 2.0, 2.0)

    os.remove(xls)

    script = os.path.basename('_cutting_plan.py')
    if not check_access(script):
        log_message('Похоже вы не оплатили скрипт "Карта раскроя в Компас", пропускаем...', 'red')
        return
    cutting_plan(xlsx)

    log_message('Оформление карты раскроя выполнено', 'ok')

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xls = easygui.fileopenbox(msg="Укажите файл Карты раскроя... после RealCut", title="",
                               default=f"{path}/*Карта*.xlsx")
    # xls = r'C:\Users\ik\Desktop\Карта_2025_07_15_16_38_50.xlsx'

    sheet1_6(xls)
    input('\n\rРабота завершена.\t\n')

# import easygui, os
# from pathlib import Path
#
# from _ExcelHandler import ExcelHandler
# from _Kompas import *
# from _Colors import *
#
# import openpyxl
# from openpyxl.styles import PatternFill, Border, Alignment, Side
# from openpyxl.drawing.image import Image
#
# '''1.6 _ Карта раскроя.xlsx после RealCut'''
#
# def sheet1_6(xls, code_project=""):
#     print(f"\n{blue}Форматирую карту раскроя{default}")
#     ###Карта раскроя
#     xlsx = Path(xls).parent / '1.6 _ Карта раскроя.xlsx'
#     new_order = [1, 4, 2, 5, 6, 8, 3, 7]  # Порядок колонок: 4 колонка станет 2
#
#     wb = openpyxl.load_workbook(xls) # Читаем исходный Excel файл
#     ws = wb.active #Активный лист
#
#     new_wb = openpyxl.Workbook() # Создаем новый workbook для сохранения результатов
#     new_ws = new_wb.active #Активный лист
#
#     def reorder_columns_with_images_fixed_size(ws, new_ws, new_order):
#         # Определение стилей границ
#         thin_border = Border(left=Side(style='thin'),
#                              right=Side(style='thin'),
#                              top=Side(style='thin'),
#                              bottom=Side(style='thin'))
#
#         """
#         Переставляет столбцы с учетом изображений, авто настраивает ширину первых 5 столбцов, фиксирует ширину 6-го столбца.
#         """
#         # Копируем данные в новом порядке, смещая все строки на одну вниз
#         for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
#             for new_col_idx, old_col_idx in enumerate(new_order, start=1):
#                 cell = row[old_col_idx - 1]  # Получаем старую ячейку
#                 new_cell = new_ws.cell(row=cell.row + 1, column=new_col_idx)  # Смещаем вставку на одну строку вниз
#                 value = cell.value
#
#                 # Проверка и преобразование значений в числовой формат для столбцов C и E
#                 if new_col_idx in [3, 5]:  # Столбцы C (3) и E (5)
#                     try:
#                         new_cell.value = float(value)  # Преобразование значения в число
#                     except (ValueError, TypeError):
#                         new_cell.value = value  # Оставляем значение как есть, если не удается преобразовать
#                 else:
#                     new_cell.value = value  # Копируем значение
#
#                 # Добавляем границы
#                 new_cell.border = thin_border
#
#                 # Установка выравнивания
#                 if new_col_idx in [1, 3, 4, 5]:  # Столбцы C (3) и E (5)
#                     new_cell.alignment = Alignment(horizontal='center', vertical='center')
#                 else:
#                     new_cell.alignment = Alignment(vertical='center')
#
#                 # Если в старой ячейке было изображение, копируем его
#                 for image in ws._images:
#                     if image.anchor._from.row == cell.row - 1 and image.anchor._from.col == old_col_idx - 1:
#                         new_image = Image(image.ref)  # Создаем изображение для вставки
#                         new_ws.add_image(new_image, new_ws.cell(row=cell.row + 1, column=new_col_idx).coordinate)
#
# ###
#     # Копируем данные из таблицы в новый файл с пересортировкой столбцов
#     reorder_columns_with_images_fixed_size(ws, new_ws, new_order)
#     ws = new_ws
#
#     # Устанавливаем фиксированную высоту строк
#     for row in range(2, ws.max_row + 2):  # Начинаем с 2-й строки (так как 1-я строка пустая)
#         ws.row_dimensions[row].height = 57
#
#     ExcelHandler.auto_dimensions(ws)  # Автоматическая настройка ширины столбцов с 1 по 5
#     ExcelHandler.fix_dimensions(ws, 'F', 245)  # Устанавливаем фиксированную ширину для столбца F
#     ExcelHandler.fix_dimensions(ws, 'C', 12)  # Устанавливаем фиксированную ширину для столбца F
#     ws.delete_cols(6, 2)  # Удаление двух столбцов, начиная с F (6-й столбец)
#
#     ###Название таблицы
#     ws["A1"] = f'{code_project}. Карта раскроя'
#
#     # Оформление заголовков
#     headers = {
#         "A2": "№",
#         "B2": "Наименование профиля",
#         "C2": "Длина заготовки, мм",
#         "D2": "Кол-во заготовок, шт.",
#         "E2": "Остаток, мм",
#         "F2": "Карта (*Внутри геометрии - длина отреза, под геометрией - номер элемента)"
#     }
#     for cell, value in headers.items():
#         ws[cell] = value
#
#     # Включите перенос текста по словам и выравнивание по центру для ячеек во второй строке
#     for cell in ws[2]:  # Итерируем по ячейкам в первой строке
#         cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")
#
#     ###Оформления заголовка
#     ws.merge_cells(start_row=1, start_column=1, end_row=1,
#                    end_column=ws.max_column)  # Объединить ячейки первой строки
#     cell = ws.cell(row=1, column=1)
#     cell.font = openpyxl.styles.Font(bold=True)
#     cell.alignment = openpyxl.styles.Alignment(horizontal='left', vertical='center')
#
#     # Настройка разметки страницы
#     ws.page_setup.paperSize = ws.PAPERSIZE_A3
#     ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
#     ws.page_setup.fitToWidth = 1
#     ws.page_setup.fitToHeight = 0
#     ws.print_title_rows = '2:1'  # Сквозные строки для печати
#
#     # Установка области печати
#     max_row = ws.max_row
#     max_col = ws.max_column
#     ws.print_area = f'A1:{openpyxl.utils.get_column_letter(max_col)}{max_row}'
#
#     # Устанавливаем параметры для центрации содержимого страницы при печати
#     ws.page_setup.centerHorizontally = True
#     ws.page_setup.centerVertically = True
#
#     new_wb.save(xlsx)  # Сохраняем новый файл
#     ExcelHandler.adjust_image_position(xlsx, 2.0, 2.0)  # Сдвигаем изображения в таблице
#
#     os.remove(xls)
#     print(f'{green}Оформление карты раскроя выполнено{default}')
#
#
# if __name__ == "__main__":
#     xls = r'C:\Users\ik\Desktop\Карта_2025_07_14_17_46_59 — копия.xlsx'
#
#     # KompasObject, iApplication, KompasVersion = get_kompas()
#     # path = get_active_doc_path(iApplication)
#     # xls = easygui.fileopenbox(msg="Укажите файл Карты раскроя... после RealCut", title="",
#     #                            default=f"{path}/*Карта*.xlsx")
#     sheet1_6(xls)
#     input('\n\rРабота завершена.	\n')