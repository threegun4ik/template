from typing import List, Tuple
import re
import math

def text_transform_with_font(
    text: str,
    width: float,
    height: float,
    font_height: float,
    *,
    min_font_height: float = 2.0,
    char_width_ratio: float = 0.58,     # немного реалистичнее 0.6 для кириллицы
    line_spacing_ratio: float = 1.20,   # межстрочный
    hard_break_token: str = "&/",       # явные переносы, которые уже есть в тексте
    hyphenate_long_words: bool = True
) -> Tuple[str, float]:
    """
    Подбирает высоту шрифта и разбивает текст по строкам так, чтобы поместиться в прямоугольник (width x height), мм.
    Возвращает: (строка_с_разделителем, финальная_высота_шрифта).
    """

    # --- быстрые гварды ---
    text = (text or "").strip()
    if not text or width <= 0 or height <= 0:
        return "", max(min_font_height, min(font_height, max(0.1, font_height)))

    # --- утилиты ---
    _spaces_re = re.compile(r"\s+")
    def normalize(s: str) -> str:
        return _spaces_re.sub(" ", s.strip())

    def capacity_for(h: float) -> Tuple[int, int]:
        """Сколько символов в строке и сколько строк влезет при высоте h."""
        char_w = max(0.001, h * char_width_ratio)
        line_h = max(0.001, h * line_spacing_ratio)
        max_chars = max(1, int(width // char_w))
        max_lines = max(1, int(height // line_h))
        return max_chars, max_lines

    def split_hard_blocks(s: str) -> List[str]:
        """Разделить по уже заданным жёстким переносам (&/), сохраняя их как границы абзацев."""
        if not hard_break_token:
            return [s]
        parts = [normalize(p) for p in s.split(hard_break_token)]
        return [p for p in parts if p != ""]

    def hyphenate(word: str, max_chars: int) -> List[str]:
        """Разбить слишком длинное слово по max_chars с дефисом (простая и надёжная стратегия)."""
        if not hyphenate_long_words or len(word) <= max_chars:
            return [word]
        # оставляем место под дефис
        chunk_size = max(1, max_chars - 1)
        out = []
        i = 0
        n = len(word)
        while i < n:
            # последний кусок без дефиса
            if i + chunk_size >= n:
                out.append(word[i:n])
                break
            out.append(word[i:i + chunk_size] + "-")
            i += chunk_size
        return out

    def wrap_block_to_lines(block: str, max_chars: int) -> List[str]:
        """Жадная разбивка блока (без hard breaks) на строки по словам + перенос длинных слов."""
        words_raw = block.split(" ")
        # сначала разрежем длинные слова
        words: List[str] = []
        for w in words_raw:
            if len(w) > max_chars:
                words.extend(hyphenate(w, max_chars))
            else:
                words.append(w)

        lines: List[str] = []
        cur: List[str] = []
        cur_len = 0  # длина текущей строки с учётом пробелов

        for w in words:
            add_len = len(w) if not cur else len(w) + 1  # плюс 1 за пробел, если не первая
            if cur_len + add_len <= max_chars or (not cur):  # всегда помещаем хотя бы одно слово
                cur.append(w)
                cur_len += add_len
            else:
                lines.append(" ".join(cur))
                cur = [w]
                cur_len = len(w)
        if cur:
            lines.append(" ".join(cur))
        return lines

    def try_wrap(h: float) -> Tuple[List[str], int, int]:
        """Собрать все строки при высоте h. Вернёт (lines, max_chars, max_lines)."""
        max_chars, max_lines = capacity_for(h)
        lines_all: List[str] = []
        for blk in split_hard_blocks(text):
            lines_all.extend(wrap_block_to_lines(blk, max_chars))
        return lines_all, max_chars, max_lines

    # --- бинарный поиск по высоте шрифта: находим МАКСИМАЛЬНУЮ высоту, которая помещается ---
    lo = max(0.1, min_font_height)
    hi = max(lo, font_height)
    best_h = lo
    best_lines: List[str] = []

    # если исходный шрифт уже помещается — попробуем от него вверх (чтобы вернуть как можно крупнее)
    # но общая идея: двоичный поиск на отрезке [lo, hi]
    for _ in range(24):  # достаточно ~24 итераций для точности < 1e-6, но мы ограничим до ~0.05мм
        mid = (lo + hi) / 2.0
        lines_mid, _, max_lines_mid = try_wrap(mid)
        if len(lines_mid) <= max_lines_mid:
            best_h = mid
            best_lines = lines_mid
            lo = mid  # можно поднять шрифт
        else:
            hi = mid  # надо уменьшить шрифт
        if hi - lo < 0.05:  # точность в 0.05 мм более чем достаточно
            break

    # если даже на минимальном не поместилось — примем минимальный и отдадим как есть (линий будет больше)
    if not best_lines:
        best_h = lo
        best_lines, _, max_lines = try_wrap(best_h)
        # если строк больше, чем помещается, всё равно вернём — задача вызывающей стороны, что делать:
        # можно обрезать и поставить "..." (закомментировано примером ниже)
        # if len(best_lines) > max_lines:
        #     best_lines = best_lines[:max_lines-1] + [best_lines[max_lines-1] + "…"]

    return (hard_break_token.join(best_lines), round(best_h, 2))



if __name__ == "__main__":
    # Пример использования
    text = "Выполнение ИД по факту ДеминВода длинное название проекта которое точно не влезет в отведенное поле потому что оно очень длинное и это ни в какие ворота так как я уже третий раз пытаюсь сформировать данное наименование проекта"
    text = 'г. Санкт-Петербург, г. Пушкин, Ячевский проезд дом 4, строение 1'
    width=120
    height=15
    font_height = 3
    result, font = text_transform_with_font(text, width, height, font_height)
    print(result)
    print(font)
# def text_transform_with_font(text: str, width: float, height: float, font_height: float) -> tuple[str, float]:
#     """
#     Разбивает текст на строки, чтобы он вписывался в заданное текстовое поле с учётом размеров шрифта.
#
#     :param text: Исходный текст.
#     :param width: Ширина текстового поля в мм.
#     :param height: Высота текстового поля в мм.
#     :param font_height: Начальная высота шрифта в мм.
#     :return: Кортеж (разбитая строка, высота шрифта).
#     """
#     MIN_FONT_HEIGHT = 2  # Минимальная высота шрифта в мм
#
#     # Коэффициенты для расчёта ширины и высоты строки
#     CHAR_WIDTH_RATIO = 0.6  # Средняя ширина символа относительно высоты шрифта
#     LINE_SPACING_RATIO = 1.2  # Коэффициент межстрочного интервала относительно высоты шрифта
#
#     while font_height >= MIN_FONT_HEIGHT:
#         char_width = font_height * CHAR_WIDTH_RATIO  # Ширина одного символа в мм
#         line_height = font_height * LINE_SPACING_RATIO  # Высота одной строки в мм
#
#         max_chars_per_line = int(width // char_width)  # Максимальное количество символов в строке
#         max_lines = int(height // line_height)  # Максимальное количество строк
#
#         words = text.split()  # Разбиваем текст на слова
#         lines = []  # Список для хранения строк
#         current_line = []  # Текущая линия для формирования строки
#
#         # Разбиваем текст на строки
#         for word in words:
#             # Проверяем, поместится ли слово в текущей строке
#             if sum(len(w) for w in current_line) + len(current_line) + len(word) <= max_chars_per_line:
#                 current_line.append(word)
#             else:
#                 # Завершаем текущую строку и начинаем новую
#                 lines.append(" ".join(current_line))
#                 current_line = [word]
#
#         # Добавляем последнюю строку, если она не пустая
#         if current_line:
#             lines.append(" ".join(current_line))
#
#         # Проверяем, влезают ли все строки в высоту поля
#         if len(lines) <= max_lines:
#             result = "&/".join(lines)  # Объединяем строки с разделителем "&/"
#             return result, font_height
#
#         # Уменьшаем высоту шрифта и пробуем снова
#         font_height -= 0.1
#
#     # Если текст не влезает при минимальном шрифте, разбиваем с минимальным шрифтом
#     font_height = MIN_FONT_HEIGHT
#     char_width = font_height * CHAR_WIDTH_RATIO
#     max_chars_per_line = int(width // char_width)
#
#     words = text.split()
#     lines = []
#     current_line = []
#
#     for word in words:
#         if sum(len(w) for w in current_line) + len(current_line) + len(word) <= max_chars_per_line:
#             current_line.append(word)
#         else:
#             lines.append(" ".join(current_line))
#             current_line = [word]
#
#     if current_line:
#         lines.append(" ".join(current_line))
#
#     result = "&/".join(lines)
#     return result, font_height
#
#
# if __name__ == "__main__":
#     # Пример использования
#     text = "Выполнение ИД по факту ДеминВода длинное название проекта которое точно не влезет в отведенное поле потому что оно очень длинное и это ни в какие ворота так как я уже третий раз пытаюсь сформировать данное наименование проекта"
#     text = 'г. Санкт-Петербург, г. Пушкин, Ячевский проезд дом 4, строение 1'
#     width=120
#     height=15
#     font_height = 3
#     result, font = text_transform_with_font(text, width, height, font_height)
#     print(result)
#     print(font)