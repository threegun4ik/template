import os, re, easygui
from __ExcelHandler import ExcelHandler
from pandas.io.formats import excel
import openpyxl
from openpyxl.styles import Font, Alignment
from __Kompas import *
from pathlib import Path

'''1.3 _ Стандартные и покупные изделия.xlsx'''
def sheet1_3(xls, code_project=""):

    log_message(f"Подготавливаю отдельную ведомость по стандартным изделиям", 'title')
    excel.ExcelFormatter.header_style = None  # Удалить границы таблицы
    xlsx = Path(xls).parent / '1.3 _ Стандартные и покупные изделия.xlsx'

    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
    df = excel_handler.read_excel()  # Читаем таблицу в dataframe

    df = df[df['Раздел спецификации'].isin(['Стандартные изделия', 'Прочие изделия', 'Покупные изделия'])].reset_index()  # оставим только нужное по значению в столбце 'Раздел спецификации'

    if df.shape[0] < 1:  # Если кол-во строк меньше 1
        print("Стандартных деталей в отчёте не найдено")
        # os.remove(xlsx)
        return

    df = df[['Наименование', 'Длина, мм', 'Кол-во, шт.','kМасса', 'kМасса сумм', 'Ширина, мм', 'Элемент марки', 'Примечание']]  # Отсортируем таблицу и оставим только нужные столбцы
    # Переименуем столбцы
    df = df.rename(columns={
        'kМасса': 'Масса 1 шт., кг',
        'kМасса сумм': 'Масса всего, кг',
        'Ширина, мм': 'Для заказа'
    })

    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом
    df = excel_handler.line_joining_df(['Наименование', 'Длина, мм'],
                           ['Кол-во, шт.', 'Масса всего, кг'],
                           ['Элемент марки'],
                           ignore_column=None, ignore_value=None)#Объеденим строки

    # # Отсортируем строки в ячейках по возрастанию
    # df['Наименование'] = df['Наименование'].apply(excel_handler.sort_cell_values)

    # Функция для сортировки значений по алфавиту и числовым частям
    def sort_alphanum(value):
        # Используем регулярное выражение для разбиения строки на части с буквами и числами
        return [int(part) if part.isdigit() else part for part in re.split(r'(\d+)', value)]

    try:
        df['Элемент марки'] = df['Элемент марки'].apply(
            lambda x: ", ".join(
                sorted(set(x.replace('*', '').split(";")), key=sort_alphanum)
            )  # Удаляем "*" и дубликаты, сортируем
        )
    except Exception as e:
        pass

    df.to_excel(xlsx, sheet_name="Стандартные изделия", index=True)  # Создадим файл отчета и запишем данные в него

    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Стандартные изделия']

   ###Название таблицы
    ws.insert_rows(1)  # Вставим строку
    ws["A1"] = (f'{code_project}. Ведомость стандартных и покупных изделий')
    ws["A2"] = "№"
    ws["G2"] = "Для заказа"

    for row in range(3, ws.max_row + 1):
        ws["A" + str(row)] = f'=ROW()-2'  # Номер строки
        ws['G' + str(row)] = f'=CONCATENATE(A{row},") ",B{row}," - ",D{row}, " шт.")' # =СЦЕПИТЬ(A3;") ";B3;" - ";D3;" шт.")


    excel_handler.format_columns(ws, ['E', 'F'], n=1, start_row=3)  # Округление до n знаков после запятой

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов
    excel_handler.fix_dimensions(ws, ['A'], width=10)  # Фиксированная ширина столбцов
    excel_handler. fix_dimensions(ws, ['B'], width=30)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['D', 'E', 'F'], width=12)  # Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 30  # Измените высоту первой строки

    # Включите перенос текста по словам и выравнивание по центру для ячеек в первой строке
    for cell in ws[2]:  # Итерируем по ячейкам во второй строке
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

    # Создание маппинга выравниваний для столбцов
    alignment_map = {
        **{letter: Alignment(horizontal='center', vertical='center') for letter in 'ADCEFIJL'},
        **{letter: Alignment(horizontal='left', vertical='center') for letter in 'BGH'}
    }

    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем со второй строки, чтобы пропустить заголовки
        for cell in row:
            column_letter = openpyxl.utils.get_column_letter(cell.column)
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1,
                   end_column=ws.max_column)  # Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = openpyxl.styles.Alignment(horizontal='left', vertical='center')

    ws.auto_filter.ref = 'A2:{}'.format(openpyxl.utils.get_column_letter(ws.max_column) + '2')  # Автофильтр на вторую строку

    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()
    log_message(f'Ведомость стандартных и покупных изделий - создана', 'ok')

if __name__ == "__main__":
    xls = r"C:\Users\ik\Desktop\!2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\!01 _ CAD\Материалы\Общий отчёт.xlsx"
    KompasObject, iApplication, KompasVersion = get_kompas()
    # path = get_active_doc_path(iApplication)
    # xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
    sheet1_3(xls, '')
    input('\n\rРабота завершена.	\n')
