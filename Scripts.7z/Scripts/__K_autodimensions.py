import sys
from __Kompas import *
from _Config import *
from __Debug import *
import random
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from shapely.geometry import LineString, Point
from shapely.strtree import STRtree
import numpy as np
import math
from math import isclose
from collections import Counter, defaultdict

TOLERANCE_DIST = 1e-6  # точность расстояния
TOLERANCE_EDGE = 1e-8  # точность для концов линий

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)  # Уровень по умолчанию (INFO, WARNING и т.п.)

# Обработчик для вывода в консоль (один раз)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)  # Внутренний уровень обработчика
    formatter = logging.Formatter('[%(levelname)s] %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)


########################################################################################################################
# !!! Главная функция для запуска авторазмеров
def add_linear_dimensions(iView, iKompasDocument, all_dimensions=True):
    '''Главная функция для запуска авторазмеров'''
    global iKompasDocument2D, iKompasDocument2D1, iDrawingContainer, iLineSegments
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    iDrawingGroups = iKompasDocument2D1.DrawingGroups
    iDrawingContainer = API7.IDrawingContainer(iView)
    iLineSegments = iDrawingContainer.LineSegments

    # 1. Сбор действительных объектов чертежа для построения контура
    obj_all, obj_by_type_real = collection_drawing_objects(iDrawingContainer)
    # 2. Получение внешнего контура (временная геометрия)
    obj_external_contour = get_external_contour(obj_all, obj_by_type_real)
    # 3. Построение касательных к дугам не 90 градусов
    _, obj_external_dict = collection_drawing_objects(obj_external_contour) # словарь с координатами для поиска действительного obj в obj_by_type
    tangents_list = build_tangents(obj_by_type_real, obj_external_dict)
    # 4. Обновление списка объектов с касательными
    obj_all, obj_by_type = collection_drawing_objects(iDrawingContainer) #Повторно получаем объекты и словари с касательными
    obj_external_contour = get_external_contour(obj_all, obj_by_type)
    # 5. Создаем словарь с внешним контуром и внутренними элементами сравнивая временные объекты контура и действительные объекты
    obj_by_type_external, obj_by_type_internal = split_by_external_contour(
        obj_by_type,
        obj_external_contour,
        extract_coords_fn=extract_coords
    ) # obj_by_type_external - временные объекты контура, obj_by_type_internal - действительные внутри контура

    # 6. Получение информации для размеров
    dims = calculate_all_dimensions(
        obj_by_type_external,
        obj_by_type_internal, iView,
        all_dimensions
    )
    # print(f'obj_by_type_real:{obj_by_type_real}')
    # print(f'dims:{dims}')

    # 7. Удаление временных касательных, не попавших в размеры
    cleanup_unused_tangents(iView, tangents_list)

    return obj_external_contour

### Подготовка существующей геомтерии и добавление новой
def collection_drawing_objects(source):
    """
    Получает элементы чертежа.

    Аргументы:
    - source — либо iDrawingContainer, либо список интерфейсов

    Возвращает:
    - obj_all_list — список всех интерфейсов
    - obj_by_type_dict — словарь: тип → список словарей с ключами:
        - 'obj' — интерфейс
        - 'coords' — кортеж координат
    """

    obj_all_list = []
    obj_by_type_dict = {
        "ILineSegment": [],
        "ICircle": [],
        "IArc": [],
        "IEllipseArc": []
    }

    if isinstance(source, tuple):
        for obj in source:
            type_name = type(obj).__name__
            obj_all_list.append(obj)
            if type_name in obj_by_type_dict:
                obj_by_type_dict[type_name].append({
                    "obj": obj,
                    "coords": extract_coords(obj)
                })
    else:
        # Обрабатываем iDrawingContainer
        for collection, getter in [
            (source.LineSegments, lambda i: source.LineSegments.LineSegment(i)),
            (source.Circles, lambda i: source.Circles.Circle(i)),
            (source.Arcs, lambda i: source.Arcs.Arc(i)),
            (source.EllipseArcs, lambda i: source.EllipseArcs.EllipseArc(i))
        ]:
            for i in range(collection.Count):
                obj = getter(i)
                obj_all_list.append(obj)
                type_name = type(obj).__name__
                obj_by_type_dict[type_name].append({
                    "obj": obj,
                    "coords": extract_coords(obj)
                })

    return obj_all_list, obj_by_type_dict

def get_alternating_contour_points(line_segments, tolerance=1e-6):
    from shapely.geometry import LineString
    from shapely.strtree import STRtree

    def is_connected(seg1, seg2):
        """Проверяет, имеют ли отрезки общие точки с учётом tolerance."""
        for p1 in seg1.coords:
            for p2 in seg2.coords:
                if abs(p1[0] - p2[0]) < tolerance and abs(p1[1] - p2[1]) < tolerance:
                    return True
        return False

    # Преобразуем вход в LineString-объекты
    lines = [LineString([(x1, y1), (x2, y2)]) for x1, y1, x2, y2 in (item["coords"] for item in line_segments)]

    used = set()
    contour_points = set()

    for i, line in enumerate(lines):
        if i in used:
            continue

        contour_points.update(line.coords)
        used.add(i)

        # Ищем смежный отрезок и пропускаем его (только один ближайший)
        for j in range(i + 1, len(lines)):
            if j in used:
                continue
            if is_connected(line, lines[j]):
                used.add(j)
                break  # Пропускаем только один смежный
    return contour_points


def get_external_contour(obj_all, obj_by_type):
    global iDrawingContainer
    all_contours = []
    iDrawingContours = iDrawingContainer.DrawingContours

    contour_points = set()
    contour_points = get_alternating_contour_points(obj_by_type.get("ILineSegment", []))

    for item in obj_by_type.get("ICircle", []):
        xc, yc, r = item["coords"]
        contour_points.add((xc, yc))

    def sort_key(p):
        x, y = p
        if y == 0 and x < 0:
            return (0, -x)
        elif y == 0 and x >= 0:
            return (1, x)
        elif y > 0:
            return (2, y, x)
        else:
            return (3, -y, x)

    sorted_points = sorted(contour_points, key=sort_key)

    for x, y in sorted_points:
        iDrawingGroup = iDrawingContours.MakeEncloseContours(obj_all, x, y, False)
        iDrawingContour_tmp = iDrawingGroup.Objects(0)

        if isinstance(iDrawingContour_tmp, (list, tuple)): # Проверяем тип объекта
            contour_list = [iDrawingContour_tmp[0]] # Если это список или кортеж — используем как список
            # debug_iContour = API7.IContour(contour_list[0])
            # debug_obj = debug_iContour.TmpObjects
            # visual(debug_obj)
        else:
            contour_list = [iDrawingContour_tmp] # Если это один объект (не список и не кортеж) — оборачиваем в список
            # debug_iContour = API7.IContour(contour_list[0])
            # debug_obj = debug_iContour.TmpObjects
            # visual(debug_obj)

        for iDrawingContour_tmp in contour_list:
            iContour_tmp = API7.IContour(iDrawingContour_tmp)
            # debug_obj = iContour_tmp.TmpObjects
            # visual(debug_obj)
            all_contours.append(iContour_tmp)

    intermediate_contours = []
    iDrawingContour = all_contours[0]
    for next_contour in all_contours[1:]:
        new_contour = iDrawingContours.AddBooleanResultContours(iDrawingContour, next_contour, con0.ksUnion)
        logger.debug(f'Выполнено объединение контуров')
        if isinstance(new_contour, tuple):
            for extra in new_contour[1:]:
                extra.Delete()
            new_contour = new_contour[0]
        intermediate_contours.append(iDrawingContour)
        intermediate_contours.append(next_contour)
        iDrawingContour = new_contour

    iContour = API7.IContour(iDrawingContour)
    obj_external_contour = iContour.TmpObjects
    # visual(obj_external_contour)

    logger.debug('Удаляем итоговый контур')
    iDrawingContour.Delete()

    for iContour_tmp in intermediate_contours:
        iDrawingContour_tmp = API7.IDrawingContour(iContour_tmp)
        iDrawingContour_tmp.Delete()

    return obj_external_contour


def extract_coords(obj):
    type_name = type(obj).__name__
    if type_name == "ILineSegment":
        return (obj.X1, obj.Y1, obj.X2, obj.Y2)
    elif type_name == "ICircle":
        return (obj.Xc, obj.Yc, obj.Radius)
    elif type_name == "IArc":
        return normalize_arc_coords(obj.X1, obj.Y1, obj.X2, obj.Y2, obj.Xc, obj.Yc, obj.Angle1, obj.Angle2, obj.Direction)
    elif type_name == "IEllipseArc":
        return normalize_ellipse_arc_coords(obj.SemiAxisA, obj.SemiAxisB, obj.Xc, obj.Yc,
                                            obj.Angle, obj.Angle1, obj.Angle2, obj.T1, obj.T2, obj.Direction)
    else:
        return ()

def normalize_arc_coords(x1, y1, x2, y2, xc, yc, angle1, angle2, direction):
    """
    Возвращает кортеж:
      (x1, y1, x2, y2, xc, yc, tang1, tang2, direction)
    причем если мы меняем порядок точек, то и направление дуги нужно инвертировать.
    """
    # Считаем углы касательных в радианах
    tang1 = np.radians(angle1 + ( 90 if not direction else -90))
    tang2 = np.radians(angle2 + (-90 if not direction else  90))

    # Решаем, потребуется ли swap
    swap = (x1, y1) > (x2, y2)
    if swap:
        # Если меняем порядок точек, то:
        # 1) меняем местами начальные/конечные координаты
        # 2) меняем углы местами
        # 3) инвертируем направление
        return (
            round(x2, 9), round(y2, 9),
            round(x1, 9), round(y1, 9),
            round(xc, 9), round(yc, 9),
            tang2, tang1,
            not bool(direction)
        )
    else:
        # Без swap оставляем всё как есть
        return (
            round(x1, 9), round(y1, 9),
            round(x2, 9), round(y2, 9),
            round(xc, 9), round(yc, 9),
            tang1, tang2,
            bool(direction)
        )

def normalize_ellipse_arc_coords(a, b, xc, yc, angle_deg, angle1, angle2, t1, t2, direction):
    phi = np.radians(angle_deg)

    def ellipse_point(t):
        x = a * np.cos(t)
        y = b * np.sin(t)
        xr = x * np.cos(phi) - y * np.sin(phi) + xc
        yr = x * np.sin(phi) + y * np.cos(phi) + yc
        return round(xr, 9), round(yr, 9)

    def ellipse_tangent_angle(t):
        dx = -a * np.sin(t)
        dy = b * np.cos(t)
        dxr = dx * np.cos(phi) - dy * np.sin(phi)
        dyr = dx * np.sin(phi) + dy * np.cos(phi)
        return np.arctan2(dyr, dxr)

    angle1 = ellipse_tangent_angle(t1)
    angle2 = ellipse_tangent_angle(t2)

    p_start = ellipse_point(t1)
    p_end = ellipse_point(t2)

    if direction:
        p_start, p_end = p_end, p_start
        angle1, angle2 = angle2, angle1

    return (*p_start, *p_end, round(xc, 9), round(yc, 9), round(angle1, 9),round(angle2, 9), t1, t2, direction)

# Строит касательные к дугам и накладывает ограничения на них
def build_tangents(obj_by_type, obj_external_by_type):
    """
    Строит касательные к дугам и эллиптическим дугам на основе временного внешнего контура.

    Параметры:
        obj_by_type (dict): Словарь действительных объектов по типам.
        obj_external_by_type (dict): Словарь временных объектов по типам (из внешнего контура).

    Возвращает:
        list: Список новых касательных отрезков (объектов).
    """
    global iLineSegments
    arc_and_ellipse_map = {}

    real_segments = obj_by_type.get("ILineSegment", [])
    real_arcs = obj_by_type.get("IArc", [])
    real_ellipses = obj_by_type.get("IEllipseArc", [])

    for type_name in ("IArc", "IEllipseArc"):
        candidates = real_arcs if type_name == "IArc" else real_ellipses

        for temp_arc in obj_external_by_type.get(type_name, []):
            temp_coords = temp_arc["coords"]
            real_obj = find_matching_real_object(temp_coords, candidates)

            if not real_obj:
                print(f"[!] Не найден реальный объект для {type_name} с координатами {temp_coords}")
                continue

            # Извлекаем угол между касательными
            tang1 = temp_coords[6]
            tang2 = temp_coords[7]
            angle_diff = abs(tang2 - tang1) % (2 * np.pi)
            if angle_diff > np.pi:
                angle_diff = 2 * np.pi - angle_diff

            # Пропускаем, если угол ≈ 90 градусов
            if abs(angle_diff - np.pi / 2) < 1e-2:
                # print(f"[!] Пропущен {type_name} с углом ≈ 90° (угол = {math.degrees(angle_diff):.2f}°)")
                continue

            segments = match_segments(temp_coords, real_segments)

            arc_and_ellipse_map[id(real_obj)] = {
                "obj": real_obj,
                "coords": temp_coords,
                "segments": segments
            }

    tangents = []

    for data in arc_and_ellipse_map.values():
        obj = data["obj"]
        coords = data["coords"]
        segments = data["segments"]
        type_name = type(obj).__name__

        if type_name == "IEllipseArc":
            new_lines = construct_ellipse_tangents(obj, coords, segments)

        elif type_name == "IArc":
            new_lines = construct_arc_tangents(obj, coords, segments)

        else:
            print("Неизвестный тип объекта:", obj)
            new_lines = []

        tangents.extend(new_lines or [])

    return tangents

def find_matching_real_object(temp_coords, candidates):
    """Находит реальный объект по совпадающим координатам."""
    temp_coords_rounded = tuple(round(c, 6) for c in temp_coords)
    for real in candidates:
        real_coords_rounded = tuple(round(c, 6) for c in real["coords"])
        if real_coords_rounded == temp_coords_rounded:
            return real["obj"]
    return None

def match_segments(arc_coords, real_segments):
    """Находит реальные отрезки, которые касаются дуги по её точкам."""
    arc_points = {
        (round(arc_coords[i], 6), round(arc_coords[i + 1], 6))
        for i in range(0, len(arc_coords) - 1, 2)
    }

    matching = []
    for seg in real_segments:
        x1y1 = (round(seg["coords"][0], 6), round(seg["coords"][1], 6))
        x2y2 = (round(seg["coords"][2], 6), round(seg["coords"][3], 6))
        if x1y1 in arc_points or x2y2 in arc_points:
            matching.append(seg)
    return matching

def construct_arc_tangents(obj, coords, segments):
    """Строит касательные к дугам и накладывает ограничения"""
    global iLineSegments
    x1, y1, x2, y2, xc, yc, angle1, angle2, direction = coords
    L = 1e6  # Длина касательной

    def point_along_angle(x, y, angle, length):
        return x + length * np.cos(angle), y + length * np.sin(angle)

    def intersect(p1, p2, p3, p4):
        """Пересечение прямых через две пары точек"""
        x1, y1 = p1
        x2, y2 = p2
        x3, y3 = p3
        x4, y4 = p4
        denom = (x1 - x2)*(y3 - y4) - (y1 - y2)*(x3 - x4)
        if abs(denom) < 1e-8:
            return None
        px = ((x1*y2 - y1*x2)*(x3 - x4) - (x1 - x2)*(x3*y4 - y3*x4)) / denom
        py = ((x1*y2 - y1*x2)*(y3 - y4) - (y1 - y2)*(x3*y4 - y3*x4)) / denom
        return (px, py)

    p1_dir = point_along_angle(x1, y1, angle1, L)
    p2_dir = point_along_angle(x2, y2, angle2, L)
    intersection = intersect((x1, y1), p1_dir, (x2, y2), p2_dir)

    if not intersection:
        return  # Касательные не пересекаются

    ix, iy = intersection

    # Вспомогательная функция создания отрезка и возврата его IDrawingObject1
    def create_line(x_start, y_start, x_end, y_end):
        iLineSegment = iLineSegments.Add()
        iLineSegment.X1, iLineSegment.Y1 = x_start, y_start
        iLineSegment.X2, iLineSegment.Y2 = x_end, y_end
        iLineSegment.Style = con0.ksCSThin
        iLineSegment.Update()
        return API7.IDrawingObject1(API7.IDrawingObject(iLineSegment)), iLineSegment

    obj_lineSegments = []
    # Построение линий
    line1_obj, obj_iLineSegment = create_line(x1, y1, ix, iy)
    obj_lineSegments.append(obj_iLineSegment)
    line2_obj, obj_iLineSegment = create_line(x2, y2, ix, iy)
    obj_lineSegments.append(obj_iLineSegment)

    arc_obj = API7.IDrawingObject1(API7.IDrawingObject(obj))

    def add_constraint(source, index, target, target_index, constraint_type):
        constr = source.NewConstraint()

        if constr is None:
            print("Не удалось создать объект ограничения")
            return

        constr.ConstraintType = constraint_type
        constr.Index = index
        constr.Partner = target
        constr.PartnerIndex = target_index
        constr.Create()


    # Наложение ограничений: совпадение концов и касание
    add_constraint(arc_obj, 1, line1_obj, 0, con0.ksCMergePoints)        # дуга-X1
    add_constraint(arc_obj, 0, line1_obj, 0, con0.ksCTangentTwoCurves)   # касание
    add_constraint(arc_obj, 2, line2_obj, 0, con0.ksCMergePoints)        # дуга-X2
    add_constraint(arc_obj, 0, line2_obj, 0, con0.ksCTangentTwoCurves)   # касание

    # Обе касательные сходятся в одной точке
    add_constraint(line1_obj, 1, line2_obj, 1, con0.ksCMergePoints)

    return tuple(obj_lineSegments)

def construct_ellipse_tangents(obj, coords, segments):
    """Строит касательные к дуге эллипса и накладывает ограничения"""
    global iLineSegments
    x1, y1, x2, y2, xc, yc, angle1, angle2, t1, t2, direction = coords

    L = 1e6  # длина касательной

    def point_along_angle(x, y, angle, length):
        return x + length * np.cos(angle), y + length * np.sin(angle)

    def intersect(p1, p2, p3, p4):
        x1, y1 = p1
        x2, y2 = p2
        x3, y3 = p3
        x4, y4 = p4
        denom = (x1 - x2)*(y3 - y4) - (y1 - y2)*(x3 - x4)
        if abs(denom) < 1e-8:
            return None
        px = ((x1*y2 - y1*x2)*(x3 - x4) - (x1 - x2)*(x3*y4 - y3*x4)) / denom
        py = ((x1*y2 - y1*x2)*(y3 - y4) - (y1 - y2)*(x3*y4 - y3*x4)) / denom
        return (px, py)

    p1_dir = point_along_angle(x1, y1, angle1, L)
    p2_dir = point_along_angle(x2, y2, angle2, L)
    intersection = intersect((x1, y1), p1_dir, (x2, y2), p2_dir)
    if not intersection:
        return

    ix, iy = intersection

    def create_line(x_start, y_start, x_end, y_end):
        iLineSegment = iLineSegments.Add()
        iLineSegment.X1, iLineSegment.Y1 = x_start, y_start
        iLineSegment.X2, iLineSegment.Y2 = x_end, y_end
        iLineSegment.Style = con0.ksCSThin
        iLineSegment.Update()
        return API7.IDrawingObject1(API7.IDrawingObject(iLineSegment)), iLineSegment

    obj_lineSegments = []
    line1_obj, obj_iLineSegment = create_line(x1, y1, ix, iy)
    obj_lineSegments.append(obj_iLineSegment)
    line2_obj, obj_iLineSegment = create_line(x2, y2, ix, iy)
    obj_lineSegments.append(obj_iLineSegment)

    arc_obj = API7.IDrawingObject1(API7.IDrawingObject(obj))

    def add_constraint(source, index, target, target_index, constraint_type):
        iParametriticConstraint = source.NewConstraint()
        if iParametriticConstraint is None:
            print("Не удалось создать объект ограничения")
            return
        iParametriticConstraint.ConstraintType = constraint_type
        iParametriticConstraint.Index = index
        iParametriticConstraint.Partner = target
        iParametriticConstraint.PartnerIndex = target_index
        iParametriticConstraint.Create()

    # Наложение ограничений: совпадение концов и касание
    add_constraint(arc_obj, 1, line1_obj, 0, con0.ksCTangentTwoCurves) # Касание дуги с новым отрезком
    add_constraint(arc_obj, 0, line2_obj, 0, con0.ksCTangentTwoCurves) # Касание дуги с новым отрезком
    add_constraint(line1_obj, 1, line2_obj, 1, con0.ksCMergePoints) # Совпадающие точки новых отрезков

    # Функция для поиска объекта с совпадающей с дугой точкой
    def find_matching_point_obj(x_target, y_target, segments, tol=1e-6):
        for seg in segments:
            obj = seg['obj']
            x1, y1, x2, y2 = seg['coords']
            if abs(x1 - x_target) < tol and abs(y1 - y_target) < tol:
                return API7.IDrawingObject1(API7.IDrawingObject(obj)), 0
            if abs(x2 - x_target) < tol and abs(y2 - y_target) < tol:
                return API7.IDrawingObject1(API7.IDrawingObject(obj)), 1
        return None, None

    # Поиск объектов с совпадающими концами
    seg1_obj, seg1_index = find_matching_point_obj(x1, y1, segments)
    seg2_obj, seg2_index = find_matching_point_obj(x2, y2, segments)

    # Совпадение концов новых касательных с концами существующих сегментов
    if seg1_obj is not None:
        add_constraint(line1_obj, 0, seg1_obj, seg1_index, con0.ksCMergePoints)

    if seg2_obj is not None:
        add_constraint(line2_obj, 0, seg2_obj, seg2_index, con0.ksCMergePoints)

    return tuple(obj_lineSegments)

def split_by_external_contour(obj_by_type, obj_external_contour, extract_coords_fn):
    """
    Разделяет obj_by_type на внешний и внутренний контур:
    - obj_by_type_external — формируется строго из obj_external_contour с координатами
    - obj_by_type_internal — всё остальное из obj_by_type, не входящее во внешний по координатам

    Аргументы:
    - obj_by_type: словарь {тип → [{'obj': ..., 'coords': ...}]}
    - obj_external_contour: список интерфейсов (без координат)
    - extract_coords_fn: функция извлечения координат

    Возвращает:
    - (obj_by_type_external, obj_by_type_internal)
    """
    # Формируем obj_by_type_external на основе obj_external_contour
    obj_by_type_external = defaultdict(list)
    coords_external_set = set()

    for obj in obj_external_contour:
        obj_type = type(obj).__name__
        coords = tuple(round(c, 9) for c in extract_coords_fn(obj))
        coords_external_set.add(coords)
        obj_by_type_external[obj_type].append({
            "obj": obj,
            "coords": coords
        })

    # Формируем obj_by_type_internal — всё, что не входит в coords_external_set
    obj_by_type_internal = defaultdict(list)
    for obj_type, items in obj_by_type.items():
        for item in items:
            coords = tuple(round(c, 9) for c in item["coords"])
            if coords not in coords_external_set:
                obj_by_type_internal[obj_type].append(item)

    return dict(obj_by_type_external), dict(obj_by_type_internal)

########################################################################################################################
### Расчёт размеров и их объединение
def calculate_all_dimensions(obj_external_contour, obj_internal_contour, iView, all_dims):

    scale = iView.Scale
    offset = (10.0 / scale)
    ### Отладка
    # print(f'obj_external_contour:{obj_external_contour}')
    # print(f'obj_internal_contour:{obj_internal_contour}')

    # 1. Обработка внешнего контура находим габаритные точки
    min_x, max_x, min_y, max_y = get_bounds_from_obj_by_type(obj_external_contour)
    # Получаем из внешнего контура список сегментов с координатами
    contour_coords = [
        {"x1": x1, "y1": y1, "x2": x2, "y2": y2}
        for item in obj_external_contour.get("ILineSegment", [])
        for x1, y1, x2, y2 in [item["coords"]]
    ]

    # Сбор всех уникальных точек контура
    contour_points = set()
    for s in contour_coords:
        contour_points.add((s["x1"], s["y1"]))
        contour_points.add((s["x2"], s["y2"]))

    contour_dims = get_contour_dimension_points(contour_coords, contour_points, offset)  # Получение габаритных размеров для внешнего контура
    contour_dims = sort_dims_by_direction_desc(contour_dims) # Сортируем размеры от большего к меньшему

    if not all_dims:
        apply_dimensions_to_view(iView, contour_dims, {})
        return merge_dimensions(contour_dims, {})

    # 2. Обработка внутренних объектов (отверстия)
    internal_centers, circle_info = extract_internal_centers(obj_internal_contour)

    between_centers = get_nearest_cross_links(internal_centers, tol=1e-3) # список отрезков между центрами окружностей
    horiz_links = find_extreme_segments_from_circle_rows(internal_centers, contour_points, mode="horizontal")# отрезок от центра окружности до ближайшей точки контура
    vert_links = find_extreme_segments_from_circle_rows(internal_centers, contour_points, mode="vertical")# отрезок от центра окружности до ближайшей точки контура

    # размеры внутреннего контура
    dims_horizontal = get_segments_dimension_points(horiz_links, min_x, max_x, min_y, max_y, offset, mode="horizontal")
    dims_vertical = get_segments_dimension_points(vert_links, min_x, max_x, min_y, max_y, offset, mode="vertical")

    # print(f'{blue}between_centers{default}')
    dims_between_centers = get_segments_dimension_points(between_centers, min_x, max_x, min_y, max_y, offset) #Размеры между центрами отверстий
    # print(f'{blue}between_centers{default}')

    dims_internal = merge_dimensions(dims_horizontal, dims_vertical) # итоговое объединение размеров между центрами и конутром
    dims_internal = merge_dimensions(dims_internal, dims_between_centers) # итоговое объединение размеров между центрами и конутром

    isolated_line_points = get_disconnected_line_segment_points(obj_external_contour, min_x, max_x, min_y, max_y) #Точки отрезков не соединенных с дугами
    # print(isolated_line_points)
    dims_external_not_arc = get_segments_dimension_points(isolated_line_points, min_x, max_x, min_y, max_y, offset)

    # print(f'isolated_line_points:{isolated_line_points}')

    shifted_segments_h, shifted_segments_v  = get_shifted_connected_segments(obj_external_contour) # Список отрезков соединяемых с дугами продлеваем на величину дуги
    # print(f'shifted_segments:{shifted_segments_h}')
    # visual(shifted_segments_h)
#####!!!!!
    dims_external_arc_h = get_segments_dimension_points(shifted_segments_h, min_x, max_x, min_y, max_y, offset, "horizontal")
    dims_external_arc_v = get_segments_dimension_points(shifted_segments_v, min_x, max_x, min_y, max_y, offset, "vertical")
    # print(f"dims_external_arc_h:{dims_external_arc_h}")
    dims_external_arc = merge_dimensions(dims_external_arc_h, dims_external_arc_v)
    # print(f'dims_external_arc:{dims_external_arc}')
    dims_internal = sort_dims_by_direction_desc(dims_internal)
    dims_external_not_arc = sort_dims_by_direction_desc(dims_external_not_arc)
    dims_external_arc = sort_dims_by_direction_desc(dims_external_arc)
    #
    dims_external = merge_dimensions(dims_external_not_arc, dims_external_arc)
    merged = merge_dimensions(contour_dims, dims_external) #Габаритные размеры и размеры внешнего контура
    # dims_external = dims_external_not_arc
    # merged = dims_external
    merged = merge_dimensions(merged, dims_internal) # + размеры внутренние

    # merged = merge_dimensions(dims_internal, {})
    dims = adjust_all_dimensions(merged, min_x, max_x, min_y, max_y, scale, offset) #Выравниваем размеры относительно друг друга
    # 4. Вставка размеров на чертёж
    apply_dimensions_to_view(iView, dims, circle_info)
    # return merged
    return dims

# Внутренние отверстия
def extract_internal_centers(obj_by_type_internal):
    """
    Извлекает центры окружностей и информацию по радиусам из obj_by_type_internal,
    используя coords = (x, y, r).

    Возвращает:
    - centers — список [(x, y), ...]
    - circle_info — словарь {радиус: [(x, y, obj), ...]}
    """
    centers = []
    circle_info = defaultdict(list)

    if "ICircle" not in obj_by_type_internal:
        return centers, circle_info

    for item in obj_by_type_internal["ICircle"]:
        x, y, r = item["coords"]
        obj = item["obj"]
        centers.append((x, y))
        circle_info[r].append((x, y, obj))

    return centers, circle_info

def get_bounds_from_obj_by_type(obj_by_type):
    """
    Находит габариты (min_x, max_x, min_y, max_y) по координатам всех объектов.

    Аргумент:
    - obj_by_type — словарь {тип → [{'obj': ..., 'coords': ...}]}

    Возвращает:
    - (min_x, max_x, min_y, max_y)
    """
    x_vals = []
    y_vals = []

    for items in obj_by_type.values():
        for item in items:
            coords = item["coords"]
            # Берём чётные индексы как X, нечётные — Y (работает и для отрезков, и для окружностей)
            for i, val in enumerate(coords):
                if i % 2 == 0:
                    x_vals.append(val)
                else:
                    y_vals.append(val)

    if not x_vals or not y_vals:
        return None  # или (0, 0, 0, 0) если нужен безопасный возврат

    return min(x_vals), max(x_vals), min(y_vals), max(y_vals)

def get_disconnected_line_segment_points(obj_by_type_real, min_x, max_x, min_y, max_y, tolerance=1e-6):
    """
    Возвращает список уточнённых координат для изолированных (не связанных с дугами) горизонтальных и вертикальных отрезков.

    Функция:
    - собирает все уникальные точки из геометрических объектов (отрезков, дуг и эллиптических дуг),
    - исключает из обработки те отрезки, которые касаются дуг,
    - определяет направление отрезка (горизонтальный или вертикальный),
    - уточняет координаты концов отрезков, привязывая их к ближайшим точкам на той же линии,
      но ближе к экстремумам по перпендикулярной оси (по bounding box),
    - пропускает диагональные отрезки.

    Аргументы:
        obj_by_type_real (dict): Словарь объектов по типу ('ILineSegment', 'IArc', 'IEllipseArc'),
                                 содержащих ключ 'coords' с координатами.
        min_x, max_x, min_y, max_y (float): Границы геометрии по осям X и Y.
        tolerance (float): Допустимая погрешность при сравнении координат.

    Возвращает:
        list of dict: Список отрезков с уточнёнными координатами.
    """

    def is_close(p1, p2):
        """Сравнивает две точки с учётом заданной погрешности."""
        return abs(p1[0] - p2[0]) < tolerance and abs(p1[1] - p2[1]) < tolerance

    # def find_closest_to_extreme_axis(p, all_points, axis='x', min_x=None, max_x=None, min_y=None, max_y=None, tolerance=1e-6):
    #     """
    #     Находит точку на той же координате по заданной оси, которая ближе к границе по перпендикулярной оси.
    #     Например, если axis='x', то точки сравниваются по Y, а выбирается та, что ближе к min_x/max_x.
    #     """
    #     if axis == 'x':
    #         # Совпадение по Y, ищем по X
    #         candidates = [pt for pt in all_points if abs(pt[1] - p[1]) < tolerance]
    #         def distance_to_extreme(pt): return min(abs(pt[0] - min_x), abs(pt[0] - max_x))
    #     else:
    #         # Совпадение по X, ищем по Y
    #         candidates = [pt for pt in all_points if abs(pt[0] - p[0]) < tolerance]
    #         def distance_to_extreme(pt): return min(abs(pt[1] - min_y), abs(pt[1] - max_y))
    #
    #     if not candidates:
    #         # print(f"  Нет кандидатов по оси {axis} для точки {p}")
    #         return p
    #
    #     selected = min(candidates, key=distance_to_extreme)
    #     # print(f"  Поиск по точке {p}, ось={axis}, найдено кандидатов: {candidates}")
    #     # print(f"    Выбрана точка: {selected} (по расстоянию до экстремума)")
    #     return selected

    def find_closest_to_extreme_axis(p, all_points, axis='x', min_x=None, max_x=None, min_y=None, max_y=None,
                                     tolerance=1e-6):
        """
        Приоритет точкам, строго лежащим на той же линии (x или y),
        только если таких нет — берём ближайшую к границе по другой оси.
        """
        if axis == 'x':
            # по вертикали — одинаковый x (одна вертикальная линия)
            line_points = [pt for pt in all_points if abs(pt[0] - p[0]) < tolerance]

            def distance(pt):
                return abs(pt[1] - p[1])

            def distance_to_extreme(pt):
                return min(abs(pt[1] - min_y), abs(pt[1] - max_y))
        else:
            # по горизонтали — одинаковый y (одна горизонтальная линия)
            line_points = [pt for pt in all_points if abs(pt[1] - p[1]) < tolerance]

            def distance(pt):
                return abs(pt[0] - p[0])

            def distance_to_extreme(pt):
                return min(abs(pt[0] - min_x), abs(pt[0] - max_x))

        # 1. Пробуем выбрать ближайшую на той же линии
        if line_points:
            return min(line_points, key=distance)

        # 2. Если не нашли, берём ближайшую к границе
        candidates = line_points if line_points else all_points
        return min(candidates, key=distance_to_extreme) if candidates else p


    def collect_all_geometry_points(obj_by_type_real, tolerance=1e-6):
        """Собирает все уникальные точки из отрезков, дуг и эллиптических дуг."""
        points = set()
        for seg in obj_by_type_real.get("ILineSegment", []):
            x1, y1, x2, y2 = seg["coords"]
            points.add((x1, y1))
            points.add((x2, y2))
        for arc in obj_by_type_real.get("IArc", []):
            x1, y1, x2, y2 = arc["coords"][:4]
            points.add((x1, y1))
            points.add((x2, y2))
        for e_arc in obj_by_type_real.get("IEllipseArc", []):
            x1, y1, x2, y2 = e_arc["coords"][:4]
            points.add((x1, y1))
            points.add((x2, y2))
        return points

    # Собираем точки, которые принадлежат дугам и эллиптическим дугам
    arc_points = set()
    for arc in obj_by_type_real.get("IArc", []):
        arc_points.add((arc["coords"][0], arc["coords"][1]))
        arc_points.add((arc["coords"][2], arc["coords"][3]))
    for ell_arc in obj_by_type_real.get("IEllipseArc", []):
        arc_points.add((ell_arc["coords"][0], ell_arc["coords"][1]))
        arc_points.add((ell_arc["coords"][2], ell_arc["coords"][3]))

    # Собираем все уникальные точки геометрии
    all_line_points = collect_all_geometry_points(obj_by_type_real)
    # print(f'all_line_points:{all_line_points}')

    result_segments = []
    # print(f'all_line_points:{all_line_points}')

    for seg in obj_by_type_real.get("ILineSegment", []):
        x1, y1, x2, y2 = seg["coords"]
        p1 = (x1, y1)
        p2 = (x2, y2)

        # Пропускаем отрезки, концы которых совпадают с точками дуг
        if any(is_close(p1, arc_p) or is_close(p2, arc_p) for arc_p in arc_points):
            continue

        is_horizontal = abs(y1 - y2) < tolerance
        is_vertical = abs(x1 - x2) < tolerance

        # print(f"\nОбработка отрезка: ({x1}, {y1}) -> ({x2}, {y2})")
        new_p1, new_p2 = p1, p2

        if is_horizontal:
            # print("  Отрезок горизонтальный")
            new_p1 = find_closest_to_extreme_axis(p1, all_line_points, axis='y',
                                                  min_x=min_x, max_x=max_x, min_y=min_y, max_y=max_y)
            new_p2 = find_closest_to_extreme_axis(p2, all_line_points, axis='y',
                                                  min_x=min_x, max_x=max_x, min_y=min_y, max_y=max_y)

        elif is_vertical:
            # print("  Отрезок вертикальный")
            new_p1 = find_closest_to_extreme_axis(p1, all_line_points, axis='x',
                                                  min_x=min_x, max_x=max_x, min_y=min_y, max_y=max_y)
            new_p2 = find_closest_to_extreme_axis(p2, all_line_points, axis='x',
                                                  min_x=min_x, max_x=max_x, min_y=min_y, max_y=max_y)

        # else:
        #     print("  Диагональный отрезок — пропуск")

        # print(f"  После уточнения: {new_p1} -> {new_p2}")
        result_segments.append({
            'x1': new_p1[0], 'y1': new_p1[1],
            'x2': new_p2[0], 'y2': new_p2[1]
        })

    return result_segments

def get_shifted_connected_segments(obj_by_type_real, tolerance=1e-6):
    """
    Возвращает списки горизонтальных и вертикальных отрезков, которые смещаются вдоль направления отрезков,
    с учётом векторов дуг (для компенсации примыкающих дуг) и последующей корректировкой координат по существующей геометрии.

    Функция:
    - собирает все отрезки, дуги и эллиптические дуги,
    - вычисляет вектор направления для каждого отрезка,
    - смещает начальные и конечные точки отрезков в зависимости от направления дуг, примыкающих к этим точкам,
    - после смещения определяет горизонтальные и вертикальные отрезки,
    - корректирует координаты концов отрезков по существующим точкам геометрии (по оси X или Y),
    - возвращает два списка: горизонтальные и вертикальные отрезки.

    Аргументы:
        obj_by_type_real (dict): Словарь с ключами 'ILineSegment', 'IArc', 'IEllipseArc', каждый из которых содержит список объектов с ключом 'coords'.
        tolerance (float): Погрешность сравнения координат (по умолчанию 1e-6).

    Возвращает:
        tuple: (horizontal_segments, vertical_segments) — два списка отрезков с координатами {'x1', 'y1', 'x2', 'y2'}.
    """

    def is_close(p1, p2):
        """Проверяет, что точки находятся на расстоянии меньше tolerance."""
        return abs(p1[0] - p2[0]) < tolerance and abs(p1[1] - p2[1]) < tolerance

    def normalize(vx, vy):
        """Нормализует вектор (vx, vy)."""
        length = math.hypot(vx, vy)
        if length < 1e-12:
            return 0.0, 0.0
        return vx / length, vy / length

    def project(dx, dy, dir_x, dir_y):
        """Проецирует вектор (dx, dy) на направление (dir_x, dir_y)."""
        return dx * dir_x + dy * dir_y

    def collect_all_points(obj_by_type_real):
        """Собирает все уникальные точки из всех отрезков и дуг."""
        points = set()
        for seg in obj_by_type_real.get("ILineSegment", []):
            x1, y1, x2, y2 = seg["coords"]
            points.add((x1, y1))
            points.add((x2, y2))
        for arc in obj_by_type_real.get("IArc", []):
            x1, y1, x2, y2 = arc["coords"][:4]
            points.add((x1, y1))
            points.add((x2, y2))
        for ell_arc in obj_by_type_real.get("IEllipseArc", []):
            x1, y1, x2, y2 = ell_arc["coords"][:4]
            points.add((x1, y1))
            points.add((x2, y2))
        return points

    def find_nearest_by_axis(p, all_pts, axis='x'):
        """
        Находит ближайшую точку к p среди всех точек на той же координате по оси axis.
        Используется для корректировки смещённых координат, чтобы они соответствовали существующим точкам.
        """
        if axis == 'x':
            same_y = [pt for pt in all_pts if abs(pt[1] - p[1]) < tolerance]
            return min(same_y, key=lambda pt: abs(pt[0] - p[0]), default=p)
        else:
            same_x = [pt for pt in all_pts if abs(pt[0] - p[0]) < tolerance]
            return min(same_x, key=lambda pt: abs(pt[1] - p[1]), default=p)

    # Собираем векторы всех дуг и эллиптических дуг
    arc_vectors = []
    for arc in obj_by_type_real.get("IArc", []):
        x1, y1, x2, y2 = arc["coords"][:4]
        arc_vectors.append({"p1": (x1, y1), "p2": (x2, y2), "dx": x2 - x1, "dy": y2 - y1})
    for ell_arc in obj_by_type_real.get("IEllipseArc", []):
        x1, y1, x2, y2 = ell_arc["coords"][:4]
        arc_vectors.append({"p1": (x1, y1), "p2": (x2, y2), "dx": x2 - x1, "dy": y2 - y1})

    # Все геометрические точки (для корректировки)
    all_geometry_points = collect_all_points(obj_by_type_real)

    horizontal_segments = []
    vertical_segments = []

    for seg in obj_by_type_real.get("ILineSegment", []):
        x1, y1, x2, y2 = seg["coords"]
        p1 = (x1, y1)
        p2 = (x2, y2)

        # Направление отрезка
        dir_x, dir_y = normalize(x2 - x1, y2 - y1)

        shift1 = 0.0
        shift2 = 0.0

        # Рассчитываем смещения для начальной и конечной точек отрезка на основе проекции дуг
        for arc in arc_vectors:
            dx, dy = arc["dx"], arc["dy"]
            projection = project(dx, dy, dir_x, dir_y)

            if is_close(p1, arc["p1"]):
                shift1 += projection
            elif is_close(p1, arc["p2"]):
                shift1 -= projection

            if is_close(p2, arc["p1"]):
                shift2 += projection
            elif is_close(p2, arc["p2"]):
                shift2 -= projection

        # Смещённые точки вдоль направления отрезка
        shifted_p1 = (p1[0] + dir_x * shift1, p1[1] + dir_y * shift1)
        shifted_p2 = (p2[0] + dir_x * shift2, p2[1] + dir_y * shift2)

        # Определение горизонтальности / вертикальности
        is_horizontal = abs(shifted_p1[1] - shifted_p2[1]) < tolerance
        is_vertical = abs(shifted_p1[0] - shifted_p2[0]) < tolerance

        if is_horizontal:
            # Уточняем координаты по Y
            shifted_p1 = find_nearest_by_axis(shifted_p1, all_geometry_points, axis='y')
            shifted_p2 = find_nearest_by_axis(shifted_p2, all_geometry_points, axis='y')
            horizontal_segments.append({
                'x1': shifted_p1[0], 'y1': shifted_p1[1],
                'x2': shifted_p2[0], 'y2': shifted_p2[1],
            })
        elif is_vertical:
            # Уточняем координаты по X
            shifted_p1 = find_nearest_by_axis(shifted_p1, all_geometry_points, axis='x')
            shifted_p2 = find_nearest_by_axis(shifted_p2, all_geometry_points, axis='x')
            vertical_segments.append({
                'x1': shifted_p1[0], 'y1': shifted_p1[1],
                'x2': shifted_p2[0], 'y2': shifted_p2[1],
            })

    return horizontal_segments, vertical_segments

def resolve_offset_coord(x1, y1, x2, y2, offset_positive, offset_negative, axis='y', strtree=None, tolerance=1e-6):
    """
    Выбирает координату смещения (по оси 'x' или 'y') на основе координат двух точек.
    Строит размерные линии от (x1, y1) и (x2, y2) и проверяет пересечения с контуром.
    """

    from shapely.geometry import Point, LineString

    pt1 = Point(x1, y1)
    pt2 = Point(x2, y2)

    # Координаты по выбранной оси
    if axis == 'y':
        coord1 = y1
        coord2 = y2
        base1 = x1
        base2 = x2
    else:
        coord1 = x1
        coord2 = x2
        base1 = y1
        base2 = y2

    # Центр и приоритетное направление
    center = (coord1 + coord2) / 2
    preferred = offset_positive if abs(offset_positive - center) < abs(offset_negative - center) else offset_negative
    fallback = offset_negative if preferred == offset_positive else offset_positive

    # print(f"\n=== [OFFSET RESOLVE] axis={axis}, coord1={coord1}, coord2={coord2}, center={center}")
    # print(f"[DEBUG] Предпочтительное смещение: {preferred}, запасное: {fallback}")

    # Генерация тестовых линий
    def make_test_lines(offset):
        return [
            LineString([pt1, Point(x1, offset)]) if axis == 'y' else LineString([pt1, Point(offset, y1)]),
            LineString([pt2, Point(x2, offset)]) if axis == 'y' else LineString([pt2, Point(offset, y2)])
        ]

    # Проверка соосности и наложения
    def is_colinear_and_overlapping(line1, line2, axis='x', tol=1e-6):
        if axis == 'x':
            same_y = abs(line1.coords[0][1] - line2.coords[0][1]) < tol
            if not same_y:
                return False
            a_min, a_max = sorted([p[0] for p in line1.coords])
            b_min, b_max = sorted([p[0] for p in line2.coords])
        else:
            same_x = abs(line1.coords[0][0] - line2.coords[0][0]) < tol
            if not same_x:
                return False
            a_min, a_max = sorted([p[1] for p in line1.coords])
            b_min, b_max = sorted([p[1] for p in line2.coords])
        return not (a_max < b_min or b_max < a_min)  # Есть наложение

    # Проверка пересечений
    def has_intersections_full_check(test_lines, strtree, tolerance=1e-6):
        def is_close(p1, p2, tol=tolerance):
            return abs(p1.x - p2.x) < tol and abs(p1.y - p2.y) < tol

        if strtree is None:
            return False
        try:
            candidates = strtree.geometries
        except AttributeError:
            candidates = list(strtree.query(LineString([(-1e9, -1e9), (1e9, 1e9)])))

        for i, test_line in enumerate(test_lines):
            # print(f"\n[DEBUG] Тестовая линия {i}: {list(test_line.coords)}")
            # print(f"         Длина: {test_line.length:.2f}")
            for candidate in candidates:
                if not isinstance(candidate, LineString) or candidate.is_empty or not candidate.is_valid:
                    continue

                inter = test_line.intersection(candidate)
                if not inter.is_empty:
                    if inter.geom_type == 'LineString':
                        axis_dir = 'x' if abs(test_line.coords[0][0] - test_line.coords[1][0]) < tolerance else 'y'
                        if is_colinear_and_overlapping(test_line, candidate, axis=axis_dir, tol=tolerance):
                            # print("  [DEBUG] → Пересечение соосно и наложено — пропускаем")
                            continue
                        return True
                    elif inter.geom_type == 'Point':
                        p0, p1 = test_line.boundary.geoms
                        if not (is_close(inter, p0) or is_close(inter, p1)):
                            # print("  [DEBUG] → Точка касания НЕ в концах — считаем пересечением")
                            return True
                        # else:
                            # print("  [DEBUG] → Касание в конце — пропускаем")
        return False

    # Проверка обоих направлений
    test_lines_pref = make_test_lines(preferred)
    intersects_preferred = has_intersections_full_check(test_lines_pref, strtree)

    test_lines_fallback = make_test_lines(fallback)
    intersects_fallback = has_intersections_full_check(test_lines_fallback, strtree)

    # Логика выбора
    if not intersects_preferred:
        result = preferred
        test_lines = test_lines_pref
        used_fallback = False
    elif not intersects_fallback:
        result = fallback
        test_lines = test_lines_fallback
        used_fallback = True
    else:
        result = preferred
        test_lines = test_lines_pref
        used_fallback = True  # fallback бесполезен

    # Отладка
    # size_value = abs(x2 - x1) if axis == 'y' else abs(y2 - y1)
    # proj_label = "Горизонтальная" if axis == 'y' else "Вертикальная"
    # print(f'\n[DEBUG] Новый размер — {proj_label} проекция: |{x2} - {x1}| = {size_value:.2f}')
    # print(f"[RESULT] Выбранная координата смещения (размерная линия): {result}")
    # print(f"[DEBUG] Использован fallback: {used_fallback}")
    # print(f"[DEBUG] Линии для визуализации:")
    # for line in test_lines:
    #     print(f"         {list(line.coords)}")

    return result

def get_contour_dimension_points(contour_segments, contour_points, offset_value=10.0):
    results = {}
    line_objects = []
    for seg in contour_segments:
        try:
            line = LineString([(seg['x1'], seg['y1']), (seg['x2'], seg['y2'])])
            if line.is_valid and not line.is_empty:
                line_objects.append(line)
        except Exception:
            continue
#???
    strtree = STRtree(line_objects)
    # for i, geom in enumerate(line_objects):
    #     print(f"{i}: {geom.wkt}")
#????
    all_y = [p[1] for p in contour_points]
    all_x = [p[0] for p in contour_points]
    min_y, max_y = min(all_y), max(all_y)
    min_x, max_x = min(all_x), max(all_x)

    # --- Горизонтальный размер ---
    left_points = [pt for pt in contour_points if abs(pt[0] - min_x) < TOLERANCE_DIST]
    right_points = [pt for pt in contour_points if abs(pt[0] - max_x) < TOLERANCE_DIST]

    if left_points and right_points:
        left_pt = max(left_points, key=lambda p: p[1])
        right_pt = max(right_points, key=lambda p: p[1])

        x1, y1 = left_pt
        x2, y2 = right_pt
        x3 = (x1 + x2) / 2
        # y3 = resolve_offset_coord(y1, y2, max_y + offset_value, min_y - offset_value, axis='y', strtree=strtree)
        y3 = resolve_offset_coord(x1, y1, x2, y2, max_y + offset_value, min_y - offset_value, axis='y', strtree=strtree)

        if abs(x1 - x2) > TOLERANCE_DIST:
            add_dimension_result(results, 'horizontal', x1, y1, x2, y2, x3, y3, True)

    # --- Вертикальный размер ---
    bottom_points = [pt for pt in contour_points if abs(pt[1] - min_y) < TOLERANCE_DIST]
    top_points = [pt for pt in contour_points if abs(pt[1] - max_y) < TOLERANCE_DIST]

    if bottom_points and top_points:
        bottom_pt = sorted(bottom_points, key=lambda p: (p[0], p[1]))[0]
        top_pt = sorted(top_points, key=lambda p: (p[0], -p[1]))[0]

        x1, y1 = bottom_pt
        x2, y2 = top_pt
        y3 = (y1 + y2) / 2
        x3 = resolve_offset_coord(x1, y1, x2, y2, max_x + offset_value, min_x - offset_value, axis='x', strtree=strtree)

        if abs(y1 - y2) > TOLERANCE_DIST:
            add_dimension_result(results, 'vertical', x1, y1, x2, y2, x3, y3, False)

    return results

def get_segments_dimension_points(segment_coordinates, min_x, max_x, min_y, max_y, offset_value=10.0, mode=None):
    '''Возвращает координаты размеров с учётом пересечений мнимых линий и экстремумов внешнего контура'''
    results = {}

    contour_segments = [
        seg for seg in segment_coordinates if all(k in seg for k in ('x1', 'y1', 'x2', 'y2'))
    ]

    line_objects = []
    for seg in contour_segments:
        try:
            line = LineString([(seg['x1'], seg['y1']), (seg['x2'], seg['y2'])])
            if line.is_valid and not line.is_empty:
                line_objects.append(line)
        except Exception:
            continue

    strtree = STRtree(line_objects) if line_objects else None

    for seg in contour_segments:
        x1, y1 = seg['x1'], seg['y1']
        x2, y2 = seg['x2'], seg['y2']

        is_horizontal = abs(x1 - x2) > 1e-6
        is_vertical = abs(y1 - y2) > 1e-6

        # Горизонтальный размер
        if is_horizontal and (mode is None or mode == "horizontal"):
            x3 = (x1 + x2) / 2
            # y3 = resolve_offset_coord(y1, y2, max_y + offset_value, min_y - offset_value, axis='y', strtree=strtree)
            y3 = resolve_offset_coord(x1, y1, x2, y2, max_y + offset_value, min_y - offset_value, axis='y',strtree=strtree)
            add_dimension_result(results, 'horizontal', x1, y1, x2, y2, x3, y3, True)

        # Вертикальный размер
        if is_vertical and (mode is None or mode == "vertical"):
            y3 = (y1 + y2) / 2
            # x3 = resolve_offset_coord(x1, x2, max_x + offset_value, min_x - offset_value, axis='x', strtree=strtree)
            x3 = resolve_offset_coord(x1, y1, x2, y2, max_x + offset_value, min_x - offset_value, axis='x', strtree=strtree)

            add_dimension_result(results, 'vertical', x1, y1, x2, y2, x3, y3, False)

    return results

### Находит отрезки между ближайшими соседями по четырем направлениям
def get_nearest_cross_links(centers, tol=1e-2):
    """Находит отрезки между ближайшими соседями по четырем направлениям"""
    segments = []
    for i, (x0, y0) in enumerate(centers):
        nearest = {'left': None, 'right': None, 'up': None, 'down': None}
        dist = {'left': float('inf'), 'right': float('inf'), 'up': float('inf'), 'down': float('inf')}

        for j, (x1, y1) in enumerate(centers):
            if i == j:
                continue
            dx, dy = x1 - x0, y1 - y0

            # Горизонтальные соседи (по Y)
            if abs(y1 - y0) < tol:
                if dx < 0 and abs(dx) < dist['left']:
                    dist['left'] = abs(dx)
                    nearest['left'] = (x1, y1)
                elif dx > 0 and abs(dx) < dist['right']:
                    dist['right'] = abs(dx)
                    nearest['right'] = (x1, y1)

            # Вертикальные соседи (по X)
            if abs(x1 - x0) < tol:
                if dy < 0 and abs(dy) < dist['down']:
                    dist['down'] = abs(dy)
                    nearest['down'] = (x1, y1)
                elif dy > 0 and abs(dy) < dist['up']:
                    dist['up'] = abs(dy)
                    nearest['up'] = (x1, y1)

        for direction in nearest:
            point = nearest[direction]
            if point:
                x1, y1 = point
                # Чтобы не дублировать (A→B и B→A), только если A < B
                if (x0, y0) < (x1, y1):
                    segments.append({'x1': x0, 'y1': y0, 'x2': x1, 'y2': y1})

    return segments

### Находит экстремальные (крайние) сегменты, соединяющие внутренние окружности
def find_extreme_segments_from_circle_rows(internal_centers, contour_points, tolerance=1e-3, mode="horizontal"):
    """Находит экстремальные сегменты, соединяющие внутренние окружности с внешним контуром, по строкам или столбцам."""
    if not internal_centers or not contour_points:
        return []

    axis = 'y' if mode == "horizontal" else 'x'
    groups = group_circles_by_axis(internal_centers, axis=axis, tolerance=1.0)
    segments = []

    for i, group in enumerate(groups):
        # print(f"\nГруппа {i+1} ({mode}):")
        # for g in group:
        #     # print(f"  Окружность: {g}")

        if mode == "horizontal":
            def cmp_key(p):
                key_val = (-round(p[1] / tolerance) * tolerance, -p[0])  # приоритет: строка (Y), затем X (по убыванию)
                # print(f"  Ключ сортировки для {p}: {key_val}")
                return key_val

            extreme_circle = max(group, key=cmp_key)  # крайний правый
            # print(f"  >> Выбрана крайняя окрыжность: {extreme_circle}")
            fixed_y = extreme_circle[1]
            candidates = [p for p in contour_points if abs(p[1] - fixed_y) < tolerance]

            if candidates:
                closest_point = min(candidates, key=lambda p: abs(p[0] - extreme_circle[0]))
                # print(f"  Найдено {len(candidates)} кандидатов по Y={fixed_y}, ближайшая точка: {closest_point}")
            else:
                closest_y_candidates = sorted(contour_points, key=lambda p: (abs(p[1] - fixed_y), -p[1], p[0]))  # сначала ближе по Y, потом выше, потом левее

                if closest_y_candidates:
                    closest_point = closest_y_candidates[0]
                    # print(f"  Нет кандидатов по точному Y, выбрана ближайшая по Y и X: {closest_point}")
                else:
                    closest_point = (extreme_circle[0], extreme_circle[1])

            segments.append({
                'x1': extreme_circle[0], 'y1': extreme_circle[1],
                'x2': closest_point[0], 'y2': closest_point[1]
            })

        elif mode == "vertical":
            def cmp_key(p):
                key_val = (-round(p[1] / tolerance) * tolerance, p[0])  # приоритет: столбец (Y), затем X (по возрастанию)
                # print(f"  Ключ сортировки для {p}: {key_val}")
                return key_val

            extreme_circle = min(group, key=cmp_key)  # крайний верхний
            fixed_x = extreme_circle[0]
            candidates = [p for p in contour_points if abs(p[0] - fixed_x) < tolerance]

            if candidates:
                closest_point = min(candidates, key=lambda p: abs(p[1] - extreme_circle[1]))
                # print(f"  Найдено {len(candidates)} кандидатов по X={fixed_x}, ближайшая точка: {closest_point}")
            else:
                # сначала ближе по X, потом выше по Y, потом левее по X
                closest_x_candidates = sorted(contour_points, key=lambda p: (abs(p[0] - fixed_x), -p[1], p[0]))

                if closest_x_candidates:
                    closest_point = closest_x_candidates[0]
                    # print(f"  Нет кандидатов по точному X, выбрана ближайшая по X и Y: {closest_point}")
                else:
                    closest_point = (extreme_circle[0], extreme_circle[1])

            segments.append({
                'x1': extreme_circle[0], 'y1': extreme_circle[1],
                'x2': closest_point[0], 'y2': closest_point[1]
            })

    segments = filter_vertical_aligned_segments(segments, tolerance=1e-2)
    return segments

def filter_vertical_aligned_segments(segments, tolerance=1e-3):
    from collections import defaultdict

    # Группируем по X (с учётом погрешности)
    def round_key(x): return round(x / tolerance) * tolerance

    grouped = defaultdict(list)
    for seg in segments:
        key = round_key(seg['x1'])
        grouped[key].append(seg)

    filtered_segments = []
    for segs in grouped.values():
        # Оставляем только один — самый верхний и левый
        best = min(segs, key=lambda s: (-s['y1'], s['x1']))
        filtered_segments.append(best)

    return filtered_segments

def group_circles_by_axis(centers, axis='y', tolerance=1.0):
    """Группирует центры окружностей по близким координатам вдоль заданной оси."""
    groups = []
    sorted_centers = sorted(centers, key=lambda p: p[1] if axis == 'y' else p[0])

    for center in sorted_centers:
        added = False
        for group in groups:
            ref_val = group[0][1] if axis == 'y' else group[0][0]
            cur_val = center[1] if axis == 'y' else center[0]
            if isclose(cur_val, ref_val, abs_tol=tolerance):
                group.append(center)
                added = True
                break
        if not added:
            groups.append([center])

    return groups

def _is_at_boundary(point, line1, line2):
    """ Проверяет, лежит ли точка пересечения на границе line1 или line2. """
    def boundary_points(line):
        b = line.boundary
        if isinstance(b, Point):
            return [b]
        elif hasattr(b, 'geoms'):
            return list(b.geoms)
        return []

    for p in boundary_points(line1) + boundary_points(line2):
        if point.distance(p) < TOLERANCE_EDGE:
            return True
    return False

def add_dimension_result(results, direction, x1, y1, x2, y2, x3, y3, is_horizontal):
    '''Добавляет запись с координатами для установки размеров'''
    results.setdefault(direction, []).append({
        'X1': x1,
        'Y1': y1,
        'X2': x2,
        'Y2': y2,
        'X3': x3,
        'Y3': y3,
        'is_horizontal': is_horizontal
    })

def sort_dims_by_direction_desc(dims):
    """
    Сортирует размеры (dimensions) отдельно для горизонтальных и вертикальных направлений
    в порядке убывания длины.

    Аргументы:
        dims (dict): Словарь с двумя ключами:
            - 'horizontal': список горизонтальных размеров, где каждый размер — словарь с ключами 'X1', 'X2'
            - 'vertical': список вертикальных размеров, где каждый размер — словарь с ключами 'Y1', 'Y2'

    Возвращает:
        dict: Новый словарь с теми же ключами ('horizontal' и 'vertical'), где списки отсортированы:
            - Горизонтальные размеры — по длине по оси X (от большего к меньшему)
            - Вертикальные размеры — по длине по оси Y (от большего к меньшему)
    """

    def horizontal_length(dim):
        # Длина горизонтального размера по оси X
        return abs(dim['X2'] - dim['X1'])

    def vertical_length(dim):
        # Длина вертикального размера по оси Y
        return abs(dim['Y2'] - dim['Y1'])

    sorted_dims = {
        # Сортируем горизонтальные размеры по убыванию длины
        'horizontal': sorted(dims.get('horizontal', []), key=horizontal_length, reverse=True),
        # Сортируем вертикальные размеры по убыванию длины
        'vertical': sorted(dims.get('vertical', []), key=vertical_length, reverse=True)
    }

    return sorted_dims

def merge_dimensions(dims1, dims2):
    '''Объединяет списки с размерами и удаляет только дубли, отдавая приоритет связанным размерам (по общим точкам)'''
    merged = {}

    for direction in ['horizontal', 'vertical']:
        merged[direction] = {}
        seen_keys = set()

        # Подсчёт всех концов размеров
        point_counter = Counter()
        for dim in dims1.get(direction, []) + dims2.get(direction, []):
            pt1 = (round(dim['X1'], 3), round(dim['Y1'], 3))
            pt2 = (round(dim['X2'], 3), round(dim['Y2'], 3))
            point_counter[pt1] += 1
            point_counter[pt2] += 1

        for dim in dims1.get(direction, []) + dims2.get(direction, []):
            if direction == 'horizontal':
                pt1 = round(dim['X1'], 3)
                pt2 = round(dim['X2'], 3)
                y3 = dim['Y3']
            else:
                pt1 = round(dim['Y1'], 3)
                pt2 = round(dim['Y2'], 3)
                x3 = dim['X3']

            key = tuple(sorted([pt1, pt2]))
            p1 = (round(dim['X1'], 3), round(dim['Y1'], 3))
            p2 = (round(dim['X2'], 3), round(dim['Y2'], 3))

            if key not in seen_keys:
                merged[direction][key] = dim
                seen_keys.add(key)
            else:
                existing = merged[direction][key]

                # Сравниваем по количеству совпадающих концов
                dim_score = point_counter[p1] + point_counter[p2]
                existing_p1 = (round(existing['X1'], 3), round(existing['Y1'], 3))
                existing_p2 = (round(existing['X2'], 3), round(existing['Y2'], 3))
                existing_score = point_counter[existing_p1] + point_counter[existing_p2]

                if dim_score > existing_score:
                    merged[direction][key] = dim
                elif dim_score == existing_score:
                    # fallback: выбираем ближний к объекту
                    tolerance = 1e-3
                    if direction == 'horizontal':
                        dist_current = min(abs(dim['Y1'] - y3), abs(dim['Y2'] - y3))
                        dist_existing = min(abs(existing['Y1'] - existing['Y3']), abs(existing['Y2'] - existing['Y3']))
                        if (
                            dist_current < dist_existing - tolerance or
                            (abs(dist_current - dist_existing) <= tolerance and y3 > existing['Y3'] + tolerance)
                        ):
                            merged[direction][key] = dim
                    else:
                        dist_current = min(abs(dim['X1'] - x3), abs(dim['X2'] - x3))
                        dist_existing = min(abs(existing['X1'] - existing['X3']), abs(existing['X2'] - existing['X3']))
                        if (
                            dist_current < dist_existing - tolerance or
                            (abs(dist_current - dist_existing) <= tolerance and x3 < existing['X3'] - tolerance)
                        ):
                            merged[direction][key] = dim

    for direction in merged:
        merged[direction] = list(merged[direction].values())

    return merged

def adjust_all_dimensions(merged, min_x, max_x, min_y, max_y, scale, offset=7.0):

    def split_dimensions_by_extremes(merged, min_x, max_x, min_y, max_y, offset):
        result = {
            'horizontal_top': [],
            'horizontal_down': [],
            'vertical_left': [],
            'vertical_right': []
        }
        for dim in merged.get('horizontal', []):
            y_avg = dim['Y3'] #(dim['Y1'] + dim['Y2']) / 2
            # y_avg = (dim['Y1'] + dim['Y2']) / 2
            if abs(y_avg - max_y) < abs(y_avg - min_y):
                # Сверху — размещаем выше max_y
                dim['Y3'] = max_y + offset
                result['horizontal_top'].append(dim)
            else:
                # Снизу — размещаем ниже min_y
                dim['Y3'] = min_y - offset
                result['horizontal_down'].append(dim)

        for dim in merged.get('vertical', []):
            x_avg = dim['X3'] #(dim['X1'] + dim['X2']) / 2
            # x_avg = (dim['X1'] + dim['X2']) / 2
            if abs(x_avg - min_x) < abs(x_avg - max_x):
                # Слева — размещаем левее min_x
                dim['X3'] = min_x - offset
                result['vertical_left'].append(dim)
            else:
                # Справа — размещаем правее max_x
                dim['X3'] = max_x + offset
                result['vertical_right'].append(dim)

        return result

    def adjust_rows(data: dict, offset: float = 20.0) -> dict:
        def length(dim):
            return abs(dim['X2'] - dim['X1']) if dim['is_horizontal'] else abs(dim['Y2'] - dim['Y1'])

        def ranges_overlap(r1, r2):
            return not (r1[1] <= r2[0] or r2[1] <= r1[0])

        def swap_rows_by_length(rows):
            changed = True
            while changed:
                changed = False
                for i in range(len(rows) - 1):
                    upper_row = rows[i]
                    lower_row = rows[i + 1]
                    to_move_up = []
                    to_move_down = []
                    for lower_dim in lower_row:
                        lower_range = (min(lower_dim['X1'], lower_dim['X2']) if lower_dim['is_horizontal']
                                       else min(lower_dim['Y1'], lower_dim['Y2']),
                                       max(lower_dim['X1'], lower_dim['X2']) if lower_dim['is_horizontal']
                                       else max(lower_dim['Y1'], lower_dim['Y2']))
                        lower_len = length(lower_dim)
                        for upper_dim in upper_row:
                            upper_range = (min(upper_dim['X1'], upper_dim['X2']) if upper_dim['is_horizontal']
                                           else min(upper_dim['Y1'], upper_dim['Y2']),
                                           max(upper_dim['X1'], upper_dim['X2']) if upper_dim['is_horizontal']
                                           else max(upper_dim['Y1'], upper_dim['Y2']))
                            upper_len = length(upper_dim)
                            if ranges_overlap(lower_range, upper_range):
                                if lower_len > upper_len:
                                    if lower_dim not in to_move_up:
                                        to_move_up.append(lower_dim)
                                    if upper_dim not in to_move_down:
                                        to_move_down.append(upper_dim)
                    if to_move_up or to_move_down:
                        changed = True
                        for dim in to_move_up:
                            if dim in lower_row:
                                lower_row.remove(dim)
                                upper_row.append(dim)
                        for dim in to_move_down:
                            if dim in upper_row:
                                upper_row.remove(dim)
                                lower_row.append(dim)
            return rows

        def build_rows(sizes, tolerance=0.5):
            def ranges_overlap_with_tolerance(r1, r2, tol):
                # Если диапазоны касаются концами — не считаем перекрытием
                if abs(r1[1] - r2[0]) <= tol or abs(r2[1] - r1[0]) <= tol:
                    return False
                # Основная проверка с учётом погрешности
                return not (r1[1] < r2[0] - tol or r2[1] < r1[0] - tol)

            sizes = sorted(sizes, key=lambda d: min(d['X1'], d['X2']) if d['is_horizontal'] else min(d['Y1'], d['Y2']))
            rows = []

            for size in sizes:
                size_range = (
                    min(size['X1'], size['X2']) if size['is_horizontal'] else min(size['Y1'], size['Y2']),
                    max(size['X1'], size['X2']) if size['is_horizontal'] else max(size['Y1'], size['Y2'])
                )
                placed = False

                for row in rows:
                    if all(
                            not ranges_overlap_with_tolerance(
                                size_range,
                                (
                                        min(r['X1'], r['X2']) if r['is_horizontal'] else min(r['Y1'], r['Y2']),
                                        max(r['X1'], r['X2']) if r['is_horizontal'] else max(r['Y1'], r['Y2'])
                                ),
                                tolerance
                            )
                            for r in row
                    ):
                        row.append(size)
                        placed = True
                        break

                if not placed:
                    rows.append([size])

            return rows

        dims = data.get('horizontal', []) if data and data.get('horizontal') else data.get('vertical', [])
        rows = build_rows(dims)
        rows = swap_rows_by_length(rows)


        for i, row in enumerate(reversed(rows[:-1]), 1):
            for dim in row:
                if dim['is_horizontal']:
                    dim['Y3'] += offset * i
                    # dim['Y3'] += 50
                    # print(offset * i)

                else:
                    dim['X3'] += offset * i
                    # dim['X3'] += 50
                    # print(offset * i)

        return {
            'horizontal': [d for row in rows for d in row] if dims and dims[0].get('is_horizontal') else [],
            'vertical': [d for row in rows for d in row] if dims and not dims[0].get('is_horizontal') else []
        }

    # Шаг 1: разделить размеры по сторонам
    split = split_dimensions_by_extremes(merged, min_x, max_x, min_y, max_y, offset)

    # Шаг 2: обрабатывать каждую группу с нужным offset
    updated = {
        'horizontal': [],
        'vertical': []
    }

    offset = 7/scale
    for group, dims in split.items():
        if not dims:
            continue

        direction = group
        if direction == 'horizontal_top':
            result = adjust_rows({'horizontal': dims}, offset)
            updated['horizontal'].extend(result['horizontal'])
        elif direction == 'horizontal_down':
            result = adjust_rows({'horizontal': dims}, -offset)
            updated['horizontal'].extend(result['horizontal'])
        elif direction == 'vertical_left':
            result = adjust_rows({'vertical': dims}, -offset)
            updated['vertical'].extend(result['vertical'])
        elif direction == 'vertical_right':
            result = adjust_rows({'vertical': dims}, offset)
            updated['vertical'].extend(result['vertical'])

    return updated

def visual(segments, visual_name='Визуализация'):
    '''Визуализация для отладки'''

    def get_random_color():
        '''Задаёт рандомные цвета для отрезков в визуализации'''
        return "#{:06x}".format(random.randint(0, 0xFFFFFF))

    segments = list(segments) if isinstance(segments, (list, tuple)) else [segments]

    fig, ax = plt.subplots()

    if not hasattr(segments, '__iter__'):
        raise TypeError("Аргумент должен быть итерируемым (список, кортеж и т.д.)")

    for obj in segments:
        type_name = type(obj).__name__
        color = get_random_color()

        if isinstance(obj, dict):
            # Если это дуга (наличие характерных ключей)
            if all(k in obj for k in ['cx', 'cy', 'r', 'angle1', 'angle2', 'direction']):
                cx, cy = obj['cx'], obj['cy']
                r = obj['r']
                start_angle = obj['angle1']
                end_angle = obj['angle2']
                direction = obj['direction']

                start_angle %= 360
                end_angle %= 360

                if direction == False:  # Counter-clockwise
                    if end_angle <= start_angle:
                        end_angle += 360
                else:
                    if start_angle <= end_angle:
                        start_angle += 360
                    start_angle, end_angle = end_angle, start_angle

                arc = mpatches.Arc((cx, cy), width=2 * r, height=2 * r,
                                   angle=0, theta1=start_angle, theta2=end_angle,
                                   edgecolor=color)
                ax.add_patch(arc)

                x_start = cx + r * np.cos(np.radians(start_angle))
                y_start = cy + r * np.sin(np.radians(start_angle))
                x_end = cx + r * np.cos(np.radians(end_angle))
                y_end = cy + r * np.sin(np.radians(end_angle))
                ax.plot([x_start, x_end], [y_start, y_end], 'o', color=color)

            else:
                # Обычный отрезок
                x1, y1, x2, y2 = obj['x1'], obj['y1'], obj['x2'], obj['y2']
                ax.plot([x1, x2], [y1, y2], color=color, marker='o')

        elif type_name == "ICircle":

            cx, cy = obj.Xc, obj.Yc
            r = obj.Radius
            circle = mpatches.Circle((cx, cy), radius=r, edgecolor=color, fill=False)
            ax.add_patch(circle)
            # Отметить центр окружности и точку на окружности
            ax.plot(cx, cy, 'x', color=color)  # Центр
            # ax.plot(obj.X, obj.Y, 'o', color=color)  # Точка на окружности

        # Дуга (IArc)
        elif type_name == "IArc":
            cx, cy = obj.Xc, obj.Yc
            r = obj.Radius
            start_angle = obj.Angle1
            end_angle = obj.Angle2
            direction = obj.Direction

            # Приведение углов в диапазон [0, 360)
            start_angle %= 360
            end_angle %= 360

            if direction == False:  # Counter-clockwise
                if end_angle <= start_angle:
                    end_angle += 360
            else:  # Clockwise
                if start_angle <= end_angle:
                    start_angle += 360
                # Поменять местами, потому что matplotlib рисует CCW
                start_angle, end_angle = end_angle, start_angle

            arc = mpatches.Arc((cx, cy), width=2 * r, height=2 * r,
                               angle=0, theta1=start_angle, theta2=end_angle,
                               edgecolor=color)
            ax.add_patch(arc)

            # Отметить начало и конец дуги
            x_start = cx + r * np.cos(np.radians(start_angle))
            y_start = cy + r * np.sin(np.radians(start_angle))
            x_end = cx + r * np.cos(np.radians(end_angle))
            y_end = cy + r * np.sin(np.radians(end_angle))
            ax.plot([x_start, x_end], [y_start, y_end], 'o', color=color)

        elif type_name == "IEllipseArc":
            cx, cy = obj.Xc, obj.Yc
            a = obj.SemiAxisA
            b = obj.SemiAxisB
            tilt = np.radians(obj.Angle)  # угол наклона осей
            t1 = np.radians(obj.Angle1)  # начальный параметр
            t2 = np.radians(obj.Angle2)  # конечный параметр
            direction = obj.Direction

            # Инвертируем логику выбора сектора:
            if direction:  # По часовой (True)
                if t2 <= t1:
                    t2 += 2 * np.pi
                t_values = np.linspace(t1, t2, 200)
            else:  # Против часовой (False)
                if t1 <= t2:
                    t1 += 2 * np.pi
                t_values = np.linspace(t1, t2, 200)[::-1]

            # Параметрическое уравнение эллипса
            cos_t = np.cos(t_values)
            sin_t = np.sin(t_values)

            x = cx + a * cos_t * np.cos(tilt) - b * sin_t * np.sin(tilt)
            y = cy + a * cos_t * np.sin(tilt) + b * sin_t * np.cos(tilt)

            ax.plot(x, y, color=color)
            ax.plot([x[0], x[-1]], [y[0], y[-1]], 'o', color=color)

        elif type_name == "ILineSegment":
            x1, y1 = obj.X1, obj.Y1
            x2, y2 = obj.X2, obj.Y2
            ax.plot([x1, x2], [y1, y2], color=color, marker='o')

        else:
            print(f"Неизвестный тип: {type(obj)} — объект пропущен")

    ax.set_aspect('equal')
    plt.grid(True)
    plt.title(visual_name)
    plt.show()

# Вставка размеров
def apply_dimensions_to_view(iView, dims, circle_info):
    iSymbols2DContainer = API7.ISymbols2DContainer(iView)
    iLineDimensions = iSymbols2DContainer.LineDimensions
    iDiametralDimensions = iSymbols2DContainer.DiametralDimensions
    scale = iView.Scale

    for dim in dims.get('horizontal', []) + dims.get('vertical', []):
        iLineDimension = iLineDimensions.Add()
        iLineDimension.X1, iLineDimension.Y1 = dim['X1'], dim['Y1']
        iLineDimension.X2, iLineDimension.Y2 = dim['X2'], dim['Y2']
        iLineDimension.X3, iLineDimension.Y3 = dim['X3'], dim['Y3']
        iLineDimension.Orientation = con0.ksLinDHorizontal if dim['is_horizontal'] else con0.ksLinDVertical
        iLineDimension.Angle = 0.0
        iDimensionParams = API7.IDimensionParams(iLineDimension)
        iDimensionParams.InitDefaultValues()
        iLineDimension.Update()

        API7.IDrawingObject1(API7.IDrawingObject(iLineDimension)).Associate()

    for radius, circles in circle_info.items():
        # Сортировка по Y (от большего к меньшему), затем по X (от меньшего к большему)
        circles.sort(key=lambda c: (-c[1], c[0]))  # (x, y, iCircle)
        main_circle = circles[0][2]
        count = len(circles)

        # Добавление диаметрального размера
        iDiametralDimension = iDiametralDimensions.Add()
        iDiametralDimension.BaseObject = main_circle
        iDiametralDimension.Angle = 315.0

        # Параметры размера
        iDimensionParams = API7.IDimensionParams(iDiametralDimension)
        iDimensionParams.InitDefaultValues()
        iDimensionParams.TextType = con0.ksDTPOnShelf
        iDimensionParams.RemoteLine1 = False #
        iDimensionParams.RemoteLine2 = False #
        iDimensionParams.ArrowType1 = con0.ksLeaderArrow #
        iDimensionParams.ArrowType2 = con0.ksLeaderArrow #
        iDimensionParams.ArrowPos = con0.ksDimArrowAuto #
        iDimensionParams.TextPos = -1
        iDimensionParams.TextOnLine = con0.ksDimTextParallelOnLine
        iDimensionParams.TextBase = con0.ksDimBaseP1
        iDimensionParams.ShelfDirection = con0.ksLSRight
        # iDimensionParams.TextBase = con0.ksDimBaseP2
        iDimensionParams.ShelfAngle = 315.0
        iDimensionParams.ShelfLength = 10#3/scale
        iDimensionParams.Gap = True
        iDimensionParams.GapValue = 0

        # Текст размера
        if count>1:
            iDimensionText = API7.IDimensionText(iDiametralDimension)
            iText = iDimensionText.TextUnder
            iTextLine = iText.TextLine(0)
            iTextItem = iTextLine.TextItem(0)
            iTextItem.Str = f"{count} отв."
            iTextItem.Update()

        iDiametralDimension.Update()

        API7.IDrawingObject1(API7.IDrawingObject(iDiametralDimension)).Associate()

### Удаляем неиспользуемые касательные у скруглений
def cleanup_unused_tangents(iView, tangents):
    iSymbols2DContainer = API7.ISymbols2DContainer(iView)
    dim_points = set()

    for i in range(iSymbols2DContainer.LineDimensions.Count):
        dim = iSymbols2DContainer.LineDimensions.LineDimension(i)
        dim_points.update([(round(dim.X1, 4), round(dim.Y1, 4)), (round(dim.X2, 4), round(dim.Y2, 4))])

    for seg in tangents:
        pt1 = (round(seg.X1, 4), round(seg.Y1, 4))
        pt2 = (round(seg.X2, 4), round(seg.Y2, 4))
        if pt1 not in dim_points and pt2 not in dim_points:
            seg.Delete()

if __name__ == "__main__":
    # logger.setLevel(logging.DEBUG)
    logger.setLevel(logging.WARNING)

    KompasObject, iApplication, KompasVersion = get_kompas()
    iDocuments = iApplication.Documents
    iKompasDocument = iApplication.ActiveDocument
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
    iViews = iViewsAndLayersManager.Views

    iSelectionManager = iKompasDocument2D1.SelectionManager
    iAssociationViews = iSelectionManager.SelectedObjects #Выделенные виды

    if not iAssociationViews:
        iView = iViews.ActiveView
        iSegments = add_linear_dimensions(iView, iKompasDocument,True)
    else:
        if not isinstance(iAssociationViews, (list, tuple)):
            iAssociationViews = (iAssociationViews,)

        try:
            for i, iAssociationView in enumerate(iAssociationViews):
                iView = API7.IView(iAssociationViews[i])
                iSegments = add_linear_dimensions(iView, iKompasDocument, True)
        except:
            iApplication.MessageBoxEx(f'Для образмеривания нужно выделить вид/виды целиком или не выделять ничего', 'Ошибка', 0)
            sys.exit(0)

