
from __Kompas import *


def auto_scale(gabarit_geom, scale=1/10):
    scale_list = [1 / 100, 1 / 75, 1 / 50, 1 / 40, 1 / 25, 1 / 20, 1 / 15, 1 / 10, 1 / 5, 1 / 4, 1 / 2.5, 1 / 2, 1, 2, 2.5, 4, 5, 10, 15, 20, 25, 40, 50, 75, 100]

    w = float(gabarit_geom["width"])
    h = float(gabarit_geom["height"])
    # print(f'Исходный габаритный прямоугольник вида: h={round(h)}, w={round(w)}')
    # Добавим текущий масштаб в список, если он отсутствует
    if scale not in scale_list:
        scale_list.append(scale)
    # Найдём индекс текущего масштаба
    scale_list = sorted(set(scale_list + [scale]))  # Уникальный и отсортированный

    for test_scale in scale_list:
        # if test_scale < scale:
        #     continue  # Пропускаем текущий и меньшие масштабы
        scale_ratio = test_scale / scale
        test_w = w * scale_ratio
        test_h = h * scale_ratio

        # print(f'test_scale:{format_scale(test_scale)}')

        test = min(test_h, test_w)
        # print(f'test={round(test)}')
        if test >= 9:
            print(f'Найден подходящий масштаб:  {format_scale(test_scale)}')
            scale = test_scale
            break
    return scale


if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    iViews = iKompasDocument2D.ViewsAndLayersManager.Views
    iView = iViews.ActiveView
    iView.Scale = 1/25
    iView.Update()

    # Текущий масштаб
    scale = iView.Scale

    print(f'Текущий масштаб: {format_scale(scale)}')
    # Получаем размеры в текущем масштабе
    gabarit_geom = get_gabarit_geom(iView, iKompasDocument2D1)
    print(f'gabarit_geom={gabarit_geom}')
    scale = auto_scale(gabarit_geom)
    iView.Scale = scale
    iView.Update()

    # g = get_gabarit_geom(iView, iKompasDocument2D1)
    # w = float(g["width"])
    # h = float(g["height"])
    # print(f'После изменения масштаба: w={round(w)}, h={round(h)}')