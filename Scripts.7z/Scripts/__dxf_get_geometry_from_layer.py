import ezdxf
from shapely.geometry import Point, LineString, Polygon
from shapely.affinity import translate
import numpy as np
from __Debug import *


def dxf_check_intersections(dxf_doc, gabarit, layers, step=1.0):
    """Проверяет пересечения между всей геометрией слоев."""

    if "Системный слой" not in layers or "Обозначение" not in layers:
        print("Ошибка: Слои 'Системный слой' и 'Обозначение' должны присутствовать в списке.")
        return False

    # Извлекаем всю геометрию из слоев
    system_layer_geometries = extract_layer_geometry(dxf_doc, "Системный слой")
    fraser_layer_geometries = extract_layer_geometry(dxf_doc, "Обозначение")

    # Проверяем пересечения всех объектов между двумя слоями
    for system_geom in system_layer_geometries:
        for fraser_geom in fraser_layer_geometries:
            if system_geom.intersects(fraser_geom):
                log_message('Есть пересечения между слоями "Системный слой" и "Обозначение"!')

                # Применяем смещение к слоям "Обозначение" и проверяем пересечения
                # print("🔄 Пробуем сместить вправо.")
                displacement = try_displace_entities(dxf_doc, layers, max_steps=gabarit[0]//2)
                if displacement:
                    log_message(f"Номер элемента можно сместить на {displacement} для устранения пересечений и обеспечения минимального расстояния.")

                    # Применяем смещение к геометриям слоя 'Обозначение'
                    displaced_fraser_layer_geometries = [
                        translate(geom, xoff=displacement[0], yoff=displacement[1])
                        for geom in fraser_layer_geometries
                    ]
                    return displacement

                else:
                    # Пробуем сместить в другом направлении (влево)
                    # print("🔄 Пробуем сместить влево.")
                    new_displacement = try_displace_entities(dxf_doc, layers, direction=(-step, 0.0), max_steps=gabarit[0]//2)

                    if new_displacement:
                        log_message(f"Номер элемента можно сместить на {new_displacement} для устранения пересечений и обеспечения минимального расстояния")
                        # Применяем новое смещение к геометриям слоя 'Обозначение'
                        displaced_fraser_layer_geometries = [
                            translate(geom, xoff=new_displacement[0], yoff=new_displacement[1])
                            for geom in fraser_layer_geometries
                        ]

                        return new_displacement  # Завершаем перебор, возвращаем смещение

                    else:
                        # Пробуем сместить вверх
                        # print("🔄 Пробуем сместить вверх.")
                        new_displacement = try_displace_entities(dxf_doc, layers, direction=(0.0, step), max_steps=gabarit[1]//2)
                        if new_displacement:
                            log_message(f"Номер элемента можно сместить на {new_displacement} для устранения пересечений и обеспечения минимального расстояния")
                            return new_displacement  # Завершаем перебор, возвращаем смещение

                        else:
                #         # Пробуем сместить вниз
                #             print("🔄 Пробуем сместить вниз.")
                            new_displacement = try_displace_entities(dxf_doc, layers, direction=(0.0, -step), max_steps=gabarit[1]//2)

                            if new_displacement:
                                log_message(
                                    f"Номер элемента можно сместить на {displacement} для устранения пересечений и обеспечения минимального расстояния.")

                                return new_displacement  # Завершаем перебор, возвращаем смещение
                            else:
                                log_message(f"Невозможно устранить пересечения смещением с минимальным расстоянием", "warn")

                                return True

    # print("✅ Нет пересечений между слоями 'Системный слой' и 'Обозначение'.")
    return False  # Пересечений нет

def try_displace_entities(dxf_doc, layers, direction=(1.0, 0.0), step=1.0, max_steps=500, min_distance=5.0):
    """
    Пытается сместить макроэлемент в слое "Обозначение" относительно геометрии слоя "Системный слой".
    direction - кортеж с направлением смещения (dx, dy).
    Возвращает координаты смещения или False, если смещение невозможно.
    """
    max_steps = int(max_steps)
    entities = {layer: [] for layer in layers}

    def extract_entities_from_block(block_name):
        """Функция для извлечения геометрии из блока"""
        block = dxf_doc.blocks.get(block_name)
        extracted = []
        if block:
            for entity in block:
                if entity.dxftype() == "LINE":
                    extracted.append(LineString([entity.dxf.start, entity.dxf.end]))
                elif entity.dxftype() in ["LWPOLYLINE", "POLYLINE"]:
                    points = [(point[0], point[1]) for point in entity.get_points()]
                    extracted.append(Polygon(points))
                elif entity.dxftype() == "CIRCLE":
                    center = entity.dxf.center
                    radius = entity.dxf.radius
                    extracted.append(Point(center).buffer(radius))
        return extracted

    msp = dxf_doc.modelspace()
    for layer in layers:
        for entity in msp.query(f'*[layer=="{layer}"]'):
            if entity.dxftype() == 'LINE':
                entities[layer].append(LineString([entity.dxf.start, entity.dxf.end]))
            elif entity.dxftype() in ['LWPOLYLINE', 'POLYLINE']:
                points = [(point[0], point[1]) for point in entity.get_points()]
                entities[layer].append(Polygon(points))
            elif entity.dxftype() == 'CIRCLE':
                center = entity.dxf.center
                radius = entity.dxf.radius
                entities[layer].append(Point(center).buffer(radius))
            elif entity.dxftype() == "INSERT":
                block_name = entity.dxf.name
                block_entities = extract_entities_from_block(block_name)
                entities[layer].extend(block_entities)

    # Получаем геометрию слоев
    system_layer_entities = entities["Системный слой"]
    milling_layer_entities = entities["Обозначение"]

    # Функция для проверки пересечений после смещения
    def check_displacement(displacement):
        for milling_entity in milling_layer_entities:
            displaced_entity = translate(milling_entity, xoff=displacement[0], yoff=displacement[1])
            for system_entity in system_layer_entities:
                if displaced_entity.intersects(system_entity):
                    return True  # Пересечение есть
        return False  # Пересечений нет

    # Функция для проверки минимального расстояния
    def check_min_distance(displacement):
        for milling_entity in milling_layer_entities:
            displaced_entity = translate(milling_entity, xoff=displacement[0], yoff=displacement[1])
            for system_entity in system_layer_entities:
                # Проверяем минимальное расстояние между объектами
                distance = displaced_entity.distance(system_entity)
                if distance < min_distance:
                    return False  # Если расстояние меньше 10 мм, возвращаем False
        return True  # Если все объекты имеют расстояние >= 10 мм

    # Пробуем сместить в указанном направлении
    current_displacement = (0.0, 0.0)
    for i in range(max_steps):
        # Пробуем сместить на один шаг в заданном направлении
        current_displacement = (
            current_displacement[0] + direction[0] * step,
            current_displacement[1] + direction[1] * step
        )

        if not check_displacement(current_displacement) and check_min_distance(current_displacement):
            return current_displacement  # Возвращаем координаты смещения

    # Если ни одно смещение не подходит
    return False


def circle_to_polygon(center, radius, num_points=36):
    """Создаёт многоугольник, аппроксимирующий окружность."""
    angles = np.linspace(0, 2 * np.pi, num_points, endpoint=False)
    points = [(center[0] + np.cos(angle) * radius, center[1] + np.sin(angle) * radius) for angle in angles]
    return Polygon(points)

def extract_layer_geometry(dxf_doc, layer_name):
    layer_entities = [entity for entity in dxf_doc.modelspace() if entity.dxf.layer == layer_name]

    geometries = []

    for entity in layer_entities:
        try:
            if entity.dxftype() == 'LINE':  # Для линии
                geometries.append(LineString([(entity.dxf.start.x, entity.dxf.start.y),
                                              (entity.dxf.end.x, entity.dxf.end.y)]))
            elif entity.dxftype() == 'CIRCLE':
                # Преобразуем окружность в Polygon (приблизительно)
                center = (entity.dxf.center.x, entity.dxf.center.y)
                radius = entity.dxf.radius
                circle_poly = circle_to_polygon(center, radius)
                geometries.append(circle_poly)
            elif entity.dxftype() == 'INSERT':  # Если объект является блоком
                block_name = entity.dxf.name
                block = dxf_doc.blocks.get(block_name)
                if block:
                    for nested_entity in block:
                        if nested_entity.dxftype() == 'LINE':
                            geometries.append(LineString([(nested_entity.dxf.start.x, nested_entity.dxf.start.y),
                                                          (nested_entity.dxf.end.x, nested_entity.dxf.end.y)]))
                        elif nested_entity.dxftype() == 'CIRCLE':
                            center = (nested_entity.dxf.center.x, nested_entity.dxf.center.y)
                            radius = nested_entity.dxf.radius
                            circle_poly = circle_to_polygon(center, radius)
                            geometries.append(circle_poly)
                        # Добавьте обработку других типов объектов, если необходимо
        except Exception as e:
            print(f"Не удалось извлечь геометрию для объекта: {entity} ({e})")

    return geometries

def get_line_endpoints(line):
    # Получаем начальную и конечную точку отрезка линии (двумерные координаты)
    return np.array([line.dxf.start.x, line.dxf.start.y]), np.array([line.dxf.end.x, line.dxf.end.y])

def get_arc_endpoints(arc):
    # Получаем начальную и конечную точку дуги (двумерные координаты)
    start_angle = arc.dxf.start_angle
    end_angle = arc.dxf.end_angle
    center = np.array([arc.dxf.center.x, arc.dxf.center.y])
    radius = arc.dxf.radius
    start_point = center + radius * np.array([np.cos(np.radians(start_angle)), np.sin(np.radians(start_angle))])
    end_point = center + radius * np.array([np.cos(np.radians(end_angle)), np.sin(np.radians(end_angle))])
    return start_point, end_point

def create_contour_from_line_and_arc(dxf_doc, layer_name="Системный слой"):
    msp = dxf_doc.modelspace()
    # Список для хранения точек контура
    contour_points = []
    # Фильтруем элементы только по нужному слою
    lines = [line for line in msp.query('LINE') if line.dxf.layer == layer_name]
    arcs = [arc for arc in msp.query('ARC') if arc.dxf.layer == layer_name]
    if not lines and not arcs:
        raise ValueError(f"В слое '{layer_name}' нет ни линий, ни дуг.")

    # Начинаем с первого объекта
    current_start, current_end = get_line_endpoints(lines[0]) if lines else get_arc_endpoints(arcs[0])  # Начинаем с первой линии или дуги

    # Добавляем начальную точку контура
    contour_points.append(current_start)

    # Добавляем все линии и дуги, соединяя их
    while len(contour_points) < len(lines) + len(arcs):
        for line in lines:
            line_start, line_end = get_line_endpoints(line)
            if np.allclose(current_end, line_start):
                contour_points.append(line_end)
                current_start, current_end = line_start, line_end
                break

        for arc in arcs:
            arc_start, arc_end = get_arc_endpoints(arc)
            if np.allclose(current_end, arc_start):
                contour_points.append(arc_end)
                current_start, current_end = arc_start, arc_end
                break

    # Замыкаем контур
    contour_points.append(contour_points[0])
    return np.array(contour_points)

def is_fraser_inside_system_layer(dxf_doc, system_layer_geometries, fraser_layer_geometries):
    """Проверяет, находится ли геометрия слоя 'Обозначение' внутри внешнего контура 'Системный слой'."""
    # Получаем контур из функции create_contour_from_line_and_arc
    contour_points = create_contour_from_line_and_arc(dxf_doc, layer_name="Системный слой")

    # Преобразуем np.array(contour_points) в Polygon
    if contour_points is None or len(contour_points) == 0:
        print("Ошибка: контур пуст")
        return False

    # Преобразуем контур в Polygon для дальнейших проверок
    outer_contour = Polygon(contour_points)

    # Проверяем, если контур не является валидным
    if not outer_contour.is_valid or outer_contour.is_empty:
        print("Ошибка: внешний контур не валиден или пуст")
        return False

    # Проверяем нахождение фрезера внутри внешнего контура
    for geometry in fraser_layer_geometries:
        if isinstance(geometry, LineString):
            if not outer_contour.contains(geometry):
                print("❌ Геометрия блока на слое 'Обозначение' не находится внутри внешнего контура 'Системный слой'")
                return False  # Завершаем функцию, если геометрия не внутри

    print("✅ Геометрия блока на слое 'Обозначение' находится внутри внешнего контура 'Системный слой'")
    # # Визуализируем геометрии
    # fig, ax = plt.subplots(figsize=(6, 6))
    #
    # # Отображаем внешний контур (слой 'Системный слой')
    # if isinstance(outer_contour, Polygon):
    #     x, y = outer_contour.exterior.xy
    #     ax.fill(x, y, alpha=0.5, color='blue', label="Системный слой (внешний контур)")
    #
    # # Отображаем геометрии слоя 'Обозначение'
    # for geom in fraser_layer_geometries:
    #     if isinstance(geom, LineString):
    #         x, y = geom.xy
    #         ax.plot(x, y, color='red', label="Обозначение")
    #
    # ax.set_title('Визуализация слоев: Системный слой и Обозначение')
    # ax.set_xlabel('X')
    # ax.set_ylabel('Y')
    # ax.set_aspect('equal')
    #
    # # Показываем график
    # plt.legend()
    # plt.show()
    return True  # Возвращаем True, если все геометрии находятся внутри

def dxf_check(dxf_file, gabarit, layers = ["Системный слой", "Обозначение"]):
    # Загружаем DXF файл
    dxf_doc = ezdxf.readfile(dxf_file)
    # Извлекаем геометрии из слоев
    system_layer_geometries = extract_layer_geometry(dxf_doc, "Системный слой")
    fraser_layer_geometries = extract_layer_geometry(dxf_doc, "Обозначение")

    # Визуализируем геометрии
    # plot_geometries(system_layer_geometries, fraser_layer_geometries)

    # Проверка пересечений между слоями "Системный слой" и "Обозначение"
    check_intersections = dxf_check_intersections(dxf_doc, gabarit, layers)

    # Проверка нахождения "Обозначение" внутри "Системного слоя"
    # is_inside = is_fraser_inside_system_layer(dxf_doc, system_layer_geometries, fraser_layer_geometries)

    return check_intersections

if __name__ == "__main__":
    dxf_file = r"C:\Users\ik\Desktop\Primer\Холодильник\Материалы\2.1 _ Пластины\2013_10мм_С245_2шт.dxf"
    # file_path = r"C:\Users\ik\Desktop\Primer\005. Балконы\Материалы\2.1 _ Пластины\485_2мм_С245_11шт.dxf"
    gabarit_z = 100
    gabarit_y = 120
    gabarit = (gabarit_y, gabarit_z)
    check_intersections = dxf_check(dxf_file, gabarit, ["Системный слой", "Обозначение"])
    print(check_intersections)
