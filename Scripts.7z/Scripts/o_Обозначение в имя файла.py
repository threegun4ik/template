import sys

from __Kompas import *
from __Debug import *
from pathlib import Path
import re, time, os, shutil
import unicodedata as _ud

# =============================================================================
#                               ПАРАМЕТРЫ
# =============================================================================
RENAME_TOP_ASM = True    # В конце открыть верхнюю сборку уже под новым именем
MAX_RETRY = 2            # Повторы ReplaceExternalFilesNames при временных ошибках
DRAWING_EXTS = (".cdw", ".spw")  # «одноимённые» документы: чертеж/спецификация

# === Правило имени файла из свойств модели ===
# "{marking}{sep}{name}":
#   m&n -> "m _ n", только m -> "m", только n -> " _ n"
FILENAME_TEMPLATE = "{marking}{sep}{name}"
SEPARATOR = " _ "
MAX_STEM_LEN = 120

# === Шаблоны имён по расширениям ===
# Можно задать свой template и sep для каждого расширения.
# Если расширение не указано — используется FILENAME_TEMPLATE и SEPARATOR.
FILENAME_TEMPLATES = {
    ".a3d": {"template": "{marking}{sep}{name}", "sep": " _ "},   # сборки
    ".m3d": {"template": "{marking}", "sep": " _ "},   # детали
    ".cdw": {"template": "{marking}{sep}{name}", "sep": " _ "},   # чертежи
    ".spw": {"template": "{marking} _ Спецификация", "sep": " _ "},  # спецификации
}

# — спец-шаблоны для "частичных" чертежей (когда в виде вставлено тело из сборки)
PARTIAL_DRAWING_TEMPLATES = {
    ".cdw": "{stamp_marking}{sep}{stamp_name}",                 # Чертёж
    # ".cdw": "{stamp_marking}",                 # Чертёж
    ".spw": "{stamp_marking}{sep}{stamp_name} _ Спецификация",  # Спецификация
}

# =============================================================================
#                           ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# =============================================================================

def _norm_win(p: str) -> str:
    """Нормализация пути (убираем лишние слэши/точки, регистр сохраняем)."""
    return os.path.normpath(str(p))

def _same_path(a: str, b: str) -> bool:
    """Сравнение путей без учёта регистра."""
    return os.path.normpath(str(a)).casefold() == os.path.normpath(str(b)).casefold()

def _exists_case_insensitive(p: Path) -> bool:
    """Существование пути без учёта регистра (на случай сетевых/нестандартных FS)."""
    try:
        return any(child.name.lower() == p.name.lower() for child in p.parent.iterdir())
    except Exception:
        return p.exists()

def _unique_target_path(target: Path) -> Path:
    """Если целевой файл уже есть — добавляем _1, _2, ... пока не станет уникальным."""
    if not _exists_case_insensitive(target):
        return target
    stem, suf = target.stem, target.suffix
    parent = target.parent
    k = 1
    while True:
        cand = parent / f"{stem}_{k}{suf}"
        if not _exists_case_insensitive(cand):
            return cand
        k += 1

def _open_doc(iApplication, path: str, *, visible=False, read_only=False):
    iDocuments = iApplication.Documents
    try:
        return iDocuments.Open(path, visible, read_only)
    except Exception:
        # запасной вариант уже открытый файл
        return iDocuments.Open(path)

def _close_doc_quiet(doc):
    """Мягко закрыть документ, игнорируя второстепенные ошибки."""
    try:
        doc.Close(1)
    except Exception:
        pass

def _get_drawing_stamp(iApplication, drw_path: str) -> tuple[str | None, str | None]:
    """Возвращает (Обозначение=4.0, Наименование=5.0) из штампа чертежа."""
    doc = None
    try:
        doc = _open_doc(iApplication, drw_path, visible=False, read_only=True)
        try:
            doc2d = API7.IKompasDocument2D(doc)
        except Exception:
            return (None, None)

        iPropertyMng = API7.IPropertyMng(iApplication)
        try:
            p_mark = iPropertyMng.GetProperty(doc, 4.0)
            p_name = iPropertyMng.GetProperty(doc, 5.0)
        except Exception:
            try:
                p_mark = iPropertyMng.GetProperty(doc2d, 4.0)
                p_name = iPropertyMng.GetProperty(doc2d, 5.0)
            except Exception:
                return (None, None)

        keeper = API7.IPropertyKeeper(doc2d)

        def _val(p):
            try:
                r = keeper.GetPropertyValue(p, 0, True)
                return (r[1] if isinstance(r, (list, tuple)) and len(r) > 1 else None)
            except Exception:
                return None

        marking = _val(p_mark)
        name    = _val(p_name)
        marking = (str(marking).strip() or None) if marking is not None else None
        name    = (str(name).strip() or None)    if name    is not None else None
        return (marking, name)
    finally:
        _close_doc_quiet(doc)


def _check_drawing_is_partial(iApplication, drw_path: str) -> tuple[bool, list[str], str | None, str | None]:
    """
    Возвращает:
      (is_partial, source_paths, stamp_marking, stamp_name)
    is_partial = True, если (Наименование или, если его нет, Обозначение) из штампа
    НЕ совпадает ни с одним стемом файлов из IAssociationView.SourceFileName.
    """
    source_paths = _get_models_from_drawing(iApplication, drw_path)
    stems = [Path(p).stem for p in source_paths]
    mark, name = _get_drawing_stamp(iApplication, drw_path)
    ref = (name or mark)
    is_partial = bool(ref) and bool(stems) and all(str(ref).casefold() != s.casefold() for s in stems)
    return (is_partial, source_paths, mark, name)


def _compose_partial_drawing_path(drw_path: str, stamp_marking: str | None, stamp_name: str | None) -> str | None:
    """
    Формирует новое имя для «частичного» чертежа по его штампу, с учётом спец-шаблонов.
    Если штамп пуст — вернёт None (ничего не переименовываем).
    """
    m = (str(stamp_marking).strip() if stamp_marking else "")
    n = (str(stamp_name).strip()    if stamp_name    else "")
    if not m and not n:
        return None  # нечего подставлять

    ext = Path(drw_path).suffix.lower()
    # берём разделитель из общих настроек для этого расширения
    cfg = FILENAME_TEMPLATES.get(ext, {"template": FILENAME_TEMPLATE, "sep": SEPARATOR})
    sep = cfg.get("sep", SEPARATOR)

    # применяем отдельный шаблон для частичных
    tmpl = PARTIAL_DRAWING_TEMPLATES.get(ext, "{stamp_marking}{sep}{stamp_name}")
    stem = tmpl.format(stamp_marking=m, stamp_name=n, sep=sep)
    stem = _sanitize_filename(stem)

    p = Path(drw_path)
    return str(p.with_name(f"{stem}{p.suffix}"))



def _fs_rename(old_path: Path, new_path: Path) -> bool:
    old_path = Path(old_path)
    new_path = Path(new_path)

    try:
        new_path.parent.mkdir(parents=True, exist_ok=True)

        # один раз гарантируем уникальность целевого имени
        target = _unique_target_path(new_path)

        print(f"[DBG] fs_rename: {old_path} -> {target}")
        if not old_path.exists():
            print(f"[ERR] Исходный файл не найден перед переименованием: {old_path}")
            return False

        os.replace(str(old_path), str(target))

        # sanity-check: старый путь после os.replace существовать не должен
        if old_path.exists():
            print(f"[WARN] После os.replace файл по старому пути всё ещё существует: {old_path}")
            try:
                old_path.unlink()
                print(f"[WARN] Старый файл принудительно удалён: {old_path}")
            except Exception as e:
                print(f"[ERR] Не удалось удалить старый файл {old_path}: {e}")
                # формально перенос уже сделан, но мусор остался
                return False

        return True

    except Exception as e:
        print(f"[Ошибка файлового переименования] {old_path} -> {new_path}: {e}")
        return False


def _replace_links_in_document(iKompasDocument, pairs: list[tuple[str, str]]) -> list[tuple[str, str, bool]]:
    """Массовая замена внешних ссылок в открытом документе (ReplaceExternalFilesNames)."""
    res = []
    try:
        iDoc1 = API7.IKompasDocument1(iKompasDocument)
    except Exception as e:
        print(f"[Ошибка] Не удалось получить IKompasDocument1: {e}")
        return [(o, n, False) for (o, n) in pairs]

    for old, new in pairs:
        ok = False
        for t in range(MAX_RETRY + 1):
            try:
                iDoc1.ReplaceExternalFilesNames(True, old, new)
                ok = True
                break
            except Exception:
                if t < MAX_RETRY:
                    time.sleep(0.25)
                else:
                    ok = False
        res.append((old, new, ok))
    try:
        iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
        iKompasDocument3D.RebuildDocument()
        iKompasDocument.Save()
    except Exception:
        pass
    return res

def _attach_to_open_document(kompas_doc, paths: list[str]):
    """
    Прикрепляет файлы к «Связным документам» ИМЕННО ЭТОГО открытого документа.
    ВАЖНО: PDM создаётся от того же документа (не от активного/верхнего).
    """
    if not kompas_doc or not paths:
        return

    import os
    pdm = API7.IProductDataManager(kompas_doc)    # ← per-document
    pk  = API7.IPropertyKeeper(kompas_doc)

    current = tuple(pdm.ObjectAttachedDocuments(pk) or ())
    norm = lambda x: os.path.normcase(os.path.normpath(str(x)))
    seen = {norm(p) for p in current}
    add  = [p for p in paths if p and norm(p) not in seen]
    if not add:
        return

    pdm.SetObjectAttachedDocuments(pk, current + tuple(add))
    try:
        kompas_doc.Save()  # чтобы прикреплённое появилось в UI
    except Exception:
        pass

    # контрольное чтение — для лога
    after = tuple(pdm.ObjectAttachedDocuments(pk) or ())
    print(f"[Attached-DocLevel] +{add}")
    print(f"[Attached-DocLevel OK] now: {after}")


# --- санитайзер и формирование нового имени -----------------------------------
_INVALID_CHARS_RE = re.compile(r'[<>:"/\\|?*\x00-\x1F]+')
_SPACES_RE = re.compile(r'\s+')

def _sanitize_filename(stem: str) -> str:
    s = "" if stem is None else str(stem)
    s = _INVALID_CHARS_RE.sub(" ", s)
    s = _SPACES_RE.sub(" ", s).strip()
    s = re.sub(r'\s*_\s*', ' _ ', s)
    s = re.sub(r'\s{2,}', ' ', s).strip(" ._")
    return s[:MAX_STEM_LEN] if len(s) > MAX_STEM_LEN else s

def _compose_new_path(old_file: str, marking: str | None, name: str | None) -> str | None:
    if not old_file:
        return None

    ext = Path(old_file).suffix.lower()
    cfg = FILENAME_TEMPLATES.get(ext, {"template": FILENAME_TEMPLATE, "sep": SEPARATOR})
    template = cfg.get("template", FILENAME_TEMPLATE)
    sep = cfg.get("sep", SEPARATOR)

    m = (str(marking).strip() if marking else "")
    n = (str(name).strip()     if name     else "")
    if not m and not n:
        return None

    # быстрые варианты для двух популярных шаблонов
    if template == "{marking}{sep}{name}":
        stem = f"{m}{sep}{n}" if (m and n) else (m or f"{sep}{n}")
    elif template == "{name}{sep}{marking}":
        stem = f"{n}{sep}{m}" if (m and n) else (n or f"{sep}{m}")
    else:
        # произвольный шаблон
        stem = template.format(marking=m, name=n, sep=sep)

    stem = _sanitize_filename(stem)
    p = Path(old_file)
    return str(p.with_name(f"{stem}{p.suffix or ''}"))


# --- устойчивый (Unicode/регистронезависимый) поиск одноимённых файлов --------
def _nfc(s: str) -> str:
    return _ud.normalize('NFC', s or '')

def _fname_key(name: str) -> str:
    return _nfc(name).casefold()

def _find_neighbor_by_stem_ci(parent: Path, stem: str, ext: str) -> str | None:
    """Ищем в папке parent файл STEM+EXT без учёта регистра и юникод-вариантов."""
    target_key = _fname_key(f"{stem}{ext}")
    try:
        for child in parent.iterdir():
            if _fname_key(child.name) == target_key:
                return str(child)
    except Exception:
        pass
    return None


# =============================================================================
#                         ОБХОД СОСТАВА (детали/сборки)
# =============================================================================

def _get_part_props(iPart7):
    """Безопасное чтение ключевых свойств компонента/сборки."""
    return {
        "file": getattr(iPart7, "FileName", None),
        "name": getattr(iPart7, "Name", None),
        "marking": getattr(iPart7, "Marking", None),
        "standard": bool(getattr(iPart7, "Standard", False)),
        "is_detail": bool(getattr(iPart7, "Detail", False)),  # True=деталь, False=сборка
        "is_local": bool(getattr(iPart7, "IsLocal", False)),
    }

def _get_models_from_drawing(iApplication, drw_path: str) -> list[str]:
    """
    Открывает .cdw/.spw и собирает пути моделей из ассоциативных видов.
    Возвращает список нормализованных абсолютных путей.
    Работает устойчиво на разных версиях API: пытается несколько путей доступа к Views.
    """
    models = set()
    doc = None
    try:
        # лучше без UI для стабильности COM
        doc = _open_doc(iApplication, drw_path, visible=False, read_only=True)

        # 2D-документ
        try:
            doc2d = API7.IKompasDocument2D(doc)
        except Exception as e:
            print(f"[DBG] IKompasDocument2D failed for {drw_path}: {e}")
            return []

        # универсальный перечислитель видов (несколько fallback'ов)
        def iter_views():
            # 1) Через ViewsAndLayersManager.Views
            try:
                mgr = getattr(doc2d, "ViewsAndLayersManager", None)
                if mgr:
                    views = getattr(mgr, "Views", None)
                    if views:
                        cnt = int(getattr(views, "Count", 0) or 0)
                        for i in range(cnt):
                            try:
                                yield views.Item(i)
                            except Exception as e:
                                print(f"[DBG] {Path(drw_path).name}: Views.Item({i}) -> {e}")
            except Exception as e:
                print(f"[DBG] {Path(drw_path).name}: ViewsAndLayersManager -> {e}")

            # 2) Прямо doc2d.Views
            try:
                views2 = getattr(doc2d, "Views", None)
                if views2:
                    cnt2 = int(getattr(views2, "Count", 0) or 0)
                    for i in range(cnt2):
                        try:
                            yield views2.Item(i)
                        except Exception as e:
                            print(f"[DBG] {Path(drw_path).name}: doc2d.Views.Item({i}) -> {e}")
            except Exception as e:
                print(f"[DBG] {Path(drw_path).name}: doc2d.Views -> {e}")

            # 3) Через листы/Layouts (некоторые версии API именно так)
            try:
                layouts = getattr(doc2d, "Layouts", None)
                if layouts:
                    lcnt = int(getattr(layouts, "Count", 0) or 0)
                    for li in range(lcnt):
                        try:
                            layout = layouts.Item(li)
                            lviews = getattr(layout, "Views", None)
                            if lviews:
                                lvcnt = int(getattr(lviews, "Count", 0) or 0)
                                for vi in range(lvcnt):
                                    try:
                                        yield lviews.Item(vi)
                                    except Exception as e:
                                        print(f"[DBG] {Path(drw_path).name}: layout {li} Views.Item({vi}) -> {e}")
                        except Exception as e:
                            print(f"[DBG] {Path(drw_path).name}: layouts.Item({li}) -> {e}")
            except Exception as e:
                print(f"[DBG] {Path(drw_path).name}: Layouts -> {e}")

        # собираем источники
        for v in iter_views():
            src = None

            # A) у некоторых видов свойство есть прямо на объекте
            try:
                src = getattr(v, "SourceFileName", None)
            except Exception:
                src = None

            # B) у ассоциативных — через интерфейс IAssociationView
            if not src:
                try:
                    av = API7.IAssociationView(v)
                    src = getattr(av, "SourceFileName", None)
                except Exception:
                    src = None

            if src:
                # нормализуем и делаем абсолютным (вдруг путь относительный)
                src = _norm_win(src)
                if not os.path.isabs(src):
                    try:
                        base_dir = str(Path(getattr(doc, "PathName", drw_path)).parent)
                    except Exception:
                        base_dir = str(Path(drw_path).parent)
                    src = _norm_win(str(Path(base_dir) / src))
                models.add(src)

    except Exception as e:
        print(f"[DBG] open/scan fail {drw_path}: {e}")
    finally:
        _close_doc_quiet(doc)

    out = list(models)
    print(f"[DBG] _get_models_from_drawing: {drw_path} -> {out}")
    return out

def collect_parts_and_assemblies(iPart7, result=None, *, skip_standard=True, skip_local=True, _parent_file=None):
    """
    Рекурсивно строит список components (ТОЛЬКО детали/сборки):
      node = {file,type,name,marking,parents,children,new_path}
    Никаких прикреплений чертежей здесь нет — они подхватываются во время прохода снизу-вверх.
    """
    if result is None:
        result = []

    props = _get_part_props(iPart7)
    file_name = props["file"]
    if not file_name:
        return result

    if skip_standard and props["standard"]:
        return result
    if skip_local and props["is_local"]:
        return result

    existing = next((r for r in result if _same_path(r["file"], file_name)), None)
    if existing is None:
        node = {
            "file": file_name,
            "type": "part" if props["is_detail"] else "assembly",
            "name": props["name"],
            "marking": props["marking"],
            "standard": props["standard"],
            "is_local": props["is_local"],
            "children": [],
            "parents": [] if _parent_file is None else [_parent_file],
            "new_path": _compose_new_path(file_name, props["marking"], props["name"]),
        }
        result.append(node)
    else:
        node = existing
        if _parent_file and all(not _same_path(_parent_file, p) for p in node["parents"]):
            node["parents"].append(_parent_file)
        if not node.get("new_path"):
            node["new_path"] = _compose_new_path(node["file"], node.get("marking"), node.get("name"))

    # Обход детей, если сборка
    if not props["is_detail"]:
        iModelObjects = getattr(iPart7, "Parts", None)
        if iModelObjects is not None:
            count = getattr(iModelObjects, "Count", 0)
            for i in range(count):
                child = API7.IPart7(iModelObjects.Item(i))
                child_file = getattr(child, "FileName", None)
                if child_file and all(not _same_path(child_file, c) for c in node["children"]):
                    node["children"].append(child_file)

                collect_parts_and_assemblies(
                    child,
                    result,
                    skip_standard=skip_standard,
                    skip_local=skip_local,
                    _parent_file=file_name,
                )
    return result

# =============================================================================
#                     Порядок обхода «снизу-вверх»
# =============================================================================

def _asm_depth(file_path: str, idx: dict, memo: dict) -> int:
    """Глубина узла = макс. расстояние до корня (верхней сборки)."""
    if file_path in memo:
        return memo[file_path]
    node = idx.get(file_path)
    if not node:
        memo[file_path] = 0
        return 0
    parents = node.get("parents") or []
    if not parents:
        memo[file_path] = 0
        return 0
    d = 1 + max(_asm_depth(p, idx, memo) for p in parents if p in idx)
    memo[file_path] = d
    return d

def _documents_bottom_up_order(components: list[dict]) -> list[str]:
    """Все 3D-документы (детали/сборки) в порядке снизу-вверх."""
    idx = {c["file"]: c for c in components}
    memo = {}
    docs = [c for c in components if c.get("type") in ("assembly", "part")]
    docs.sort(key=lambda c: _asm_depth(c["file"], idx, memo), reverse=True)
    return [c["file"] for c in docs]


# =============================================================================
#                       ОСНОВНОЙ ИСПОЛНИТЕЛЬ (ренейм+линки)
# =============================================================================

def plan_and_execute(components: list, _pdm=None):
    """
    Сценарий:
      1) Переименовываем 3D-файлы по шаблону.
      1.5) (НОВОЕ) Сканиуем .cdw/.spw в папке активного документа и строим индекс:
           модель -> [связанные чертежи из iAssociationView.SourceFileName]
      2) Идём снизу-вверх по 3D-документам:
          * Открываем документ;
          * Ищем рядом одноимённые .cdw/.spw (по новому и возможному старому stem)
            + добавляем чертежи из индекса (могут лежать в других папках);
          * Прикрепляем найденные к ЭТОМУ открытому документу (уровень документа);
          * При необходимости переименовываем сами .cdw/.spw по шаблону;
          * Выполняем ReplaceExternalFilesNames;
          * Закрываем документ.
      3) В конце открываем верхнюю сборку.
    """

    # -------- 0) План переименования 3D --------
    todo = [c for c in components if c.get("new_path") and Path(c["new_path"]).name != Path(c["file"]).name]

    # Верхняя сборка (без родителей)
    top_candidates = [c for c in components if c.get("type") == "assembly" and not (c.get("parents") or [])]
    top_asm = top_candidates[0] if top_candidates else None

    # Листья -> корень
    idx = {c["file"]: c for c in components}
    memo = {}
    def depth(node):
        parents = node.get("parents") or []
        if not parents: return 0
        if node["file"] in memo: return memo[node["file"]]
        d = 1 + max(depth(idx[p]) for p in parents if p in idx)
        memo[node["file"]] = d
        return d

    def _as_dir_path(p: Path) -> Path:
        """Гарантируем, что это папка: если передали путь к файлу — берём parent."""
        try:
            # Если есть суффикс вида ".a3d"/".m3d"/".cdw"/".spw" — это файл.
            if p.suffix:
                return p.parent
        except Exception:
            pass
        return p

    todo.sort(key=depth, reverse=True)

    print("План переименования (3D):")
    for n in todo:
        tag = " (TOP)" if (top_asm and _same_path(n["file"], top_asm["file"])) else ""
        print(f"  [{n['type']}] {n['file']}  ->  {n['new_path']}{tag}")

    # --- 1) Закрыть активный документ и определить корень сканирования чертежей ---
    KompasObject, iApplication, KompasVersion = get_kompas()

    drawings_root = None
    try:
        active = iApplication.ActiveDocument
        if active:
            p = getattr(active, "Path", None)
            # Path может быть файлом! Нормализуем:
            if p:
                drawings_root = _as_dir_path(Path(str(p)))
            else:
                pn = getattr(active, "PathName", None)
                if pn:
                    drawings_root = _as_dir_path(Path(str(pn)))
            _close_doc_quiet(active)
    except Exception:
        pass

    if drawings_root is None:
        if top_asm and top_asm.get("file"):
            drawings_root = Path(top_asm["file"]).parent
        else:
            any_file = next((c["file"] for c in components if c.get("file")), None)
            drawings_root = Path(any_file).parent if any_file else Path.cwd()

    # Отладочные логи
    print(f"[ScanRoot] drawings_root = {drawings_root}")
    print(f"[ScanRoot] exists={drawings_root.exists()} is_dir={drawings_root.is_dir()}")

    # -------- 1.5) Скан .cdw/.spw и индекс ассоциаций: модель -> [чертежи] --------
    assoc_index: dict[str, list[str]] = {}
    try:
        exts = tuple(e.lower() for e in DRAWING_EXTS)
        print(f"[ScanRoot] drawings_root = {drawings_root}")
        print(f"[ScanRoot] exists={drawings_root.exists()} is_dir={drawings_root.is_dir()}")
        for root, _, files in os.walk(str(drawings_root)):
            for fn in files:
                if Path(fn).suffix.lower() in exts:
                    drw_path = _norm_win(str(Path(root) / fn))
                    try:
                        model_files = _get_models_from_drawing(iApplication, drw_path)
                    except Exception as e:
                        print(f"[DBG] _get_models_from_drawing failed for {drw_path}: {e}")
                        model_files = []
                    for mf in model_files:
                        key = _norm_win(mf).casefold()
                        assoc_index.setdefault(key, []).append(drw_path)
        print(f"[DBG] assoc_index models count: {len(assoc_index)}")
    except Exception as e:
        print(f"[Предупреждение] Индексация чертежей в '{drawings_root}': {e}")


    # -------- 2) ФИЗИЧЕСКОЕ переименование 3D на диске --------

    # >>> ОТЛАДКА: покажем, какие .a3d лежат в папке верхней сборки до переименования
    try:
        if top_asm and top_asm.get("file"):
            asm_dir = Path(top_asm["file"]).parent
            print("=== Файлы .a3d ДО переименования ===")
            for f in sorted(asm_dir.glob("*.a3d")):
                try:
                    print("  ", f, " size:", f.stat().st_size)
                except Exception:
                    print("  ", f, " (ошибка получения размера)")
    except Exception as e:
        print(f"[DBG] Не удалось вывести список .a3d до переименования: {e}")
    # <<< КОНЕЦ ОТЛАДКИ

    rename_pairs: list[tuple[str, str]] = []
    ok_count = 0
    for n in todo:
        old_path = Path(n["file"])
        target = _unique_target_path(Path(n["new_path"]))
        n["new_path"] = str(target)

        if _same_path(str(old_path), str(target)):
            print(f"[SKIP] Имя не меняется: {old_path}")
            continue
        if not old_path.exists():
            print(f"[Ошибка] Исходный файл не найден: {old_path}")
            continue

        if _fs_rename(old_path, target):
            old_norm = _norm_win(str(old_path))
            new_norm = _norm_win(str(target))
            rename_pairs.append((old_norm, new_norm))
            ok_count += 1
            print(f"[OK] Переименовано на диске: {old_path} -> {target}")

            # Обновим модель components на новые пути
            for node in components:
                if _same_path(node["file"], old_norm):
                    node["file"] = new_norm
                if node.get("parents"):
                    node["parents"] = [new_norm if _same_path(p, old_norm) else p for p in node["parents"]]
                if node.get("children"):
                    node["children"] = [new_norm if _same_path(c, old_norm) else c for c in node["children"]]

    # >>> ОТЛАДКА: покажем .a3d ПОСЛЕ переименования
    try:
        if top_asm and top_asm.get("file"):
            asm_dir = Path(top_asm["file"]).parent
            print("=== Файлы .a3d ПОСЛЕ переименования ===")
            for f in sorted(asm_dir.glob("*.a3d")):
                try:
                    print("  ", f, " size:", f.stat().st_size)
                except Exception:
                    print("  ", f, " (ошибка получения размера)")
    except Exception as e:
        print(f"[DBG] Не удалось вывести список .a3d после переименования: {e}")
    # <<< КОНЕЦ ОТЛАДКИ

    # -------- 3) Путь верхней сборки после ренейма --------
    top_path_new = None
    if RENAME_TOP_ASM and top_asm:
        top_node = next((c for c in components if c.get("type") == "assembly" and not (c.get("parents") or [])), None)
        if top_node:
            top_path_new = top_node["file"]

    # -------- 4) Проход снизу-вверх с подхватом чертежей --------
    order = _documents_bottom_up_order(components)
    print("\nОбработка документов (.m3d, .a3d, + соседние/ассоц. .cdw/.spw) снизу-вверх:")
    try:
        iApplication.HideMessage = con0.ksHideMessageYes

        # Индекс для быстрого доступа к узлу 3D (name/marking для именования .cdw/.spw)
        idx = {c["file"]: c for c in components}

        for doc_path in order:
            doc = None
            try:
                # 4.0) Открыть документ
                doc = _open_doc(iApplication, doc_path)

                # 4.1) Найти одноимённые чертежи по НОВОМУ и, при необходимости, по СТАРОМУ stem (соседи)
                base = Path(doc_path)
                stems = {base.stem}
                # Если этот doc уже попадал в rename_pairs — добавим старый stem
                new_norm = _norm_win(str(base))
                for old, new in rename_pairs:
                    if _same_path(new, new_norm):
                        stems.add(Path(old).stem)
                        break

                neighbor_candidates = []
                for st in stems:
                    for ext in DRAWING_EXTS:
                        real = _find_neighbor_by_stem_ci(base.parent, st, ext)
                        if real:
                            neighbor_candidates.append(real)


                # 4.1.1) Добавим ассоциативные чертежи из индекса
                doc_key = _norm_win(str(base)).casefold()
                assoc_candidates = assoc_index.get(doc_key, [])

                # если модель переименовали — подтянем чертежи, ссылающиеся на старый путь модели
                if assoc_candidates == [] and rename_pairs:
                    for old, new in rename_pairs:
                        if _same_path(new, str(base)):
                            old_key = _norm_win(old).casefold()
                            extra = assoc_index.get(old_key, [])
                            if extra:
                                print(f"[Assoc] Для {base.name}: добавлены {len(extra)} чертеж(а) по старому пути модели")
                                assoc_candidates.extend(extra)
                            break

                # Уникализация объединённого списка
                all_candidates = neighbor_candidates + assoc_candidates
                seen_keys, uniq_neighbors = set(), []
                for p in all_candidates:
                    k = _norm_win(p).casefold()
                    if k not in seen_keys:
                        seen_keys.add(k)
                        uniq_neighbors.append(p)


                # 4.2) Прикрепить найденные чертежи к ЭТОМУ открытому документу
                if uniq_neighbors:
                    _attach_to_open_document(doc, uniq_neighbors)

                # 4.3) При необходимости переименовать сами чертежи по шаблону
                host = idx.get(doc_path, {})
                for drw in uniq_neighbors:
                    # определяем "частичный" ли это чертёж (вставлено тело из сборки)
                    try:
                        is_partial, src_paths, m_stamp, n_stamp = _check_drawing_is_partial(iApplication, drw)
                    except Exception as e:
                        print(f"[DBG] partial-check failed for {drw}: {e}")
                        is_partial, m_stamp, n_stamp = (False, None, None)

                    if is_partial:
                        # для "частичных" — имя от штампа, а не от хоста
                        cand = _compose_partial_drawing_path(drw, m_stamp, n_stamp)
                        if cand and Path(cand).name != Path(drw).name:
                            old_p = Path(drw)
                            new_p = _unique_target_path(Path(cand))  # ← гарантируем уникальность (_1, _2, ...)
                            if old_p.exists() and not _same_path(str(old_p), str(new_p)):
                                if _fs_rename(old_p, new_p):
                                    old_norm = _norm_win(str(old_p))
                                    new_norm = _norm_win(str(new_p))
                                    rename_pairs.append((old_norm, new_norm))
                                    print(f"[OK] Переименовано на диске (частичный чертеж): {old_p} -> {new_p}")
                                    # после ренейма всё равно обновим ссылки внутри самого чертежа
                                    drw_doc = None
                                    try:
                                        drw_doc = _open_doc(iApplication, str(new_p), visible=False, read_only=False)
                                        _replace_links_in_document(drw_doc, rename_pairs)
                                    except Exception:
                                        pass
                                    finally:
                                        _close_doc_quiet(drw_doc)
                        else:
                            # штамп пуст или имя не меняется — хотя бы обновим ссылки
                            drw_doc = None
                            try:
                                drw_doc = _open_doc(iApplication, drw, visible=False, read_only=False)
                                _replace_links_in_document(drw_doc, rename_pairs)
                            except Exception:
                                pass
                            finally:
                                _close_doc_quiet(drw_doc)
                        continue  # следующий чертёж

                    # НЕ частичный — обычное правило по хосту (marking/name верхнего 3D-дока)
                    new_path_for_drw = _compose_new_path(drw, host.get("marking"), host.get("name"))
                    if new_path_for_drw and Path(new_path_for_drw).name != Path(drw).name:
                        old_p = Path(drw)
                        new_p = _unique_target_path(Path(new_path_for_drw))
                        if old_p.exists() and not _same_path(str(old_p), str(new_p)):
                            if _fs_rename(old_p, new_p):
                                old_norm = _norm_win(str(old_p))
                                new_norm = _norm_win(str(new_p))
                                rename_pairs.append((old_norm, new_norm))
                                print(f"[OK] Переименовано на диске (чертеж): {old_p} -> {new_p}")
                                # и сразу обновим ссылки внутри самого чертежа
                                drw_doc = None
                                try:
                                    drw_doc = _open_doc(iApplication, str(new_p), visible=False, read_only=False)
                                    _replace_links_in_document(drw_doc, rename_pairs)
                                except Exception:
                                    pass
                                finally:
                                    _close_doc_quiet(drw_doc)
                    else:
                        # имя не меняем — обновим ссылки
                        drw_doc = None
                        try:
                            drw_doc = _open_doc(iApplication, drw, visible=False, read_only=False)
                            _replace_links_in_document(drw_doc, rename_pairs)
                        except Exception:
                            pass
                        finally:
                            _close_doc_quiet(drw_doc)


                # 4.4) Заменить ссылки в текущем документе
                results = _replace_links_in_document(doc, rename_pairs)
                ok_cnt = sum(1 for _, _, ok in results if ok)
                print(f"[OK] {doc_path}: заменено ссылок {ok_cnt}/{len(results)}")

            except Exception as e:
                print(f"[Ошибка] При обработке {doc_path}: {e}")
            finally:
                _close_doc_quiet(doc)
    finally:
        iApplication.HideMessage = con0.ksShowMessage

    # -------- 5) Открыть верхнюю сборку --------
    try:
        if top_path_new:
            top_doc = _open_doc(iApplication, top_path_new, visible=True)
            iApplication.ActiveDocument = top_doc
            try:
                iKompasDocument3D = API7.IKompasDocument3D(top_doc)
                iKompasDocument3D.RebuildDocument()
                top_doc.Save()
            except Exception:
                pass
            print(f"[OK] Верхняя сборка открыта: {top_path_new}")
    except Exception as e:
        print(f"[Предупреждение] Не удалось открыть верхнюю сборку: {e}")

    # -------- 6) Итоги --------
    print(f"\nГотово. Переименовано файлов: {ok_count}; пар для замены: {len(rename_pairs)}; обработано документов: {len(order)}")



# =============================================================================
#                              ТОЧКА ВХОДА
# =============================================================================

def run_rename_and_relink(skip_standard=True, skip_local=True):

    script = os.path.basename(__file__)
    if not check_access(script):
        input(f"❌ Похоже кто-то не задонатил за {script.split('.')[0]}, пропускаем...")
        sys.exit()

    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
    top = iKompasDocument3D.TopPart

    # Менеджер связных документов (нужен только во время прохода снизу-вверх)
    pdm = API7.IProductDataManager(iKompasDocument)

    # Собираем состав (только детали/сборки)
    components = collect_parts_and_assemblies(
        top,
        skip_standard=skip_standard,
        skip_local=skip_local,
    )

    # Запускаем основной сценарий
    plan_and_execute(components, _pdm=pdm)


# =============================================================================
#                              ЗАПУСК
# =============================================================================
if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
    top_part = iKompasDocument3D.TopPart

    components = collect_parts_and_assemblies(top_part, skip_standard=True, skip_local=True)
    for comp in components:
        print(f"{comp['type']}: {comp['file']} -> {comp['new_path']}")

    run_rename_and_relink(skip_standard=True, skip_local=True)
