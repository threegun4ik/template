import os, easygui, pyperclip
from pathlib import Path
import pandas as pd
import xml.etree.ElementTree as ET
import subprocess

from __ExcelHandler import ExcelHandler

from pandas.io.formats import excel
from __Kompas import *
from _Sheet1_5 import sheet1_5
from _Sheet1_6 import sheet1_6
from CNC_for_a3d import for_cnc_a3d
from _cutting_sheet import cutting_sheet

'''Для программы раскроя проката RelCut'''

def sheet3_1(xls, code_project=''):
    log_message(f"Подготавливаю отчеты для импорта в программу раскроя проката")
    pyperclip.copy(os.path.dirname(xls))  # Запишем путь до папки с xlsx в буфер обмена
    xlsx = Path(xls).parent / '3.1 _ Раскрой.xlsx'
    excel.ExcelFormatter.header_style = None  # Удалить границы таблицы

    ####Раскрой элементы
    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
    df_parts = excel_handler.read_excel(1)  # Читаем таблицу в dataframe

    df_parts = df_parts[df_parts['Эскиз сечения'].notna()]  # удалим пустые строки в столбце с эскизом сечения
    df_parts = df_parts[~df_parts['Эскиз сечения'].str.contains('@016', na=False)] # удалим строки с эскизом @016

    if df_parts.shape[0] < 1:
        print("Элементов проката не найдено")
        return

    excel_handler.data = df_parts  # Обновляем данные в ExcelHandler перед вызовом
    df_parts['Кол-во, шт.'] = df_parts[['Так', 'Наоборот']].fillna(0).sum(axis=1).astype(int)  # Вычисляем сумму "Так" + "Наоборот"
    df_parts = df_parts[['Длина, мм', 'Кол-во, шт.', 'Наименование', '№ элемента',]]  # Отсортируем таблицу
    df_parts.loc[:, 'Длина, мм'] = df_parts['Длина, мм'].round()

    excel_handler.data = df_parts  # Обновляем данные в ExcelHandler перед вызовом
    df_parts = excel_handler.clean_zeros_in_columns(['Наименование'])  # Указываем столбцы, которые нужно очистить

    df_parts.to_excel(xlsx, sheet_name="Раскрой", index = False, float_format="%0.1f")  # Создадим файл отчета и запишем данные в него
    xlsx_cutting=xlsx
####Раскрой склад
    xlsx = Path(xlsx).parent / '3.2 _ Склад.xlsx'

    ##Удаляем файл пробной версии realcut
    filenames = ['rc1d11wd.txt', 'rc1d11p.txt', 'rc2d.txt']
    for filename in filenames:
        try:
            os.remove(os.getenv('APPDATA') + "/" + filename)
        except FileNotFoundError:
            pass

    df_stock = df_parts[['Длина, мм', 'Кол-во, шт.', 'Наименование']]  # Отсортируем таблицу
    df_stock = df_stock.drop_duplicates(subset=['Наименование']) #Оставим уникальные строки по наименованию
    df_stock['Длина, мм'] = '12000'
    df_stock['Кол-во, шт.'] = '1000'

    df_stock.to_excel(xlsx, sheet_name="Склад", index = False)  # Создадим файл отчета и запишем данные в него
    xlsx_warehouse = xlsx
    log_message(f"Отчёты для импорта в программу раскроя - созданы", "ok")

    mode = input(f'Выполнить раскрой в Realcut1d?'
                 f'\n(Да - любой текст, Нет - без текста)? > ')

    # Запускаем программу с файлом
    if mode:

        ###
        # Создание корневого элемента XML
        data = ET.Element("data")

        # Секция <parts> с данными из Excel для раскроя
        parts = ET.SubElement(data, "parts")
        for _, row in df_parts.iterrows():
            part = ET.SubElement(parts, "row")
            ET.SubElement(part, "length").text = str(row['Длина, мм'])
            ET.SubElement(part, "width").text = "0"
            ET.SubElement(part, "quantity").text = str(row['Кол-во, шт.'])
            # ET.SubElement(part, "label").text = str(int(row['№ элемента']))
            # ET.SubElement(part, "label").text = str(row['№ элемента']) if pd.notna(row['№ элемента']) else ""
            value = row['№ элемента']
            # Проверка, является ли значение числом с плавающей точкой с нулевой дробной частью
            if isinstance(value, float) and value.is_integer():
                label_text = str(int(value))
            else:
                label_text = str(value)
            ET.SubElement(part, "label").text = label_text

            ET.SubElement(part, "material").text = str(row['Наименование'])
            ET.SubElement(part, "customer").text = ""
            ET.SubElement(part, "angle_1").text = "90"
            ET.SubElement(part, "angle_2").text = "90"
            ET.SubElement(part, "color").text = "16711680"  # Красный цвет
            ET.SubElement(part, "id").text = "-1"
            ET.SubElement(part, "use_it").text = "1"
            ET.SubElement(part, "utilized_in_optimization").text = "0"

        # Секция <stock> с данными из Excel для склада
        stock = ET.SubElement(data, "stock")
        for _, row in df_stock.iterrows():
            stock_row = ET.SubElement(stock, "row")
            ET.SubElement(stock_row, "length").text = str(row['Длина, мм'])
            ET.SubElement(stock_row, "width").text = "0"
            ET.SubElement(stock_row, "quantity").text = str(row['Кол-во, шт.'])
            ET.SubElement(stock_row, "label").text = "0"  # Для склада, возможно, метка будет другая
            ET.SubElement(stock_row, "material").text = str(row['Наименование'])
            ET.SubElement(stock_row, "customer").text = ""
            ET.SubElement(stock_row, "angle_1").text = "90.0"
            ET.SubElement(stock_row, "angle_2").text = "90.0"
            ET.SubElement(stock_row, "color").text = "16711680"  # Красный цвет (если нужно изменить)
            ET.SubElement(stock_row, "id").text = "-1"
            ET.SubElement(stock_row, "use_it").text = "1"
            ET.SubElement(stock_row, "utilized_in_optimization").text = "0"

        # Преобразование дерева в строку
        tree = ET.ElementTree(data)

        xlm_path = Path(xlsx).parent / 'for_realcut.xml'  # Запись в файл
        tree.write(xlm_path, encoding="utf-8", xml_declaration=True)
        ###

        # username = os.getlogin()
        username = Path.home().parts[2]

        candidate_paths = [
            Path(f'C:/Users/{username}/AppData/Local/Optimal Programs/Real Cut 1D/realcut1d.exe'),
            Path(f'D:/Programs/Real Cut 1D/realcut1d.exe'),
        ]
        realcut_exe = next((p for p in candidate_paths if p.exists()), None)

        if realcut_exe and realcut_exe.exists():
            subprocess.run([str(realcut_exe), str(xlm_path)], check=True)
        else:
            print("❌ Программа Real Cut 1D не установлена или путь указан неверно.")

        os.remove(xlm_path)
        # Папка, в которой будет искать файлы (та же, что у xlm_path)
        parent_dir = Path(xlm_path).parent
        stat_file = None
        map_file = None
        cnc_a3d_file = None

        for file in parent_dir.iterdir():
            if file.is_file() and file.suffix == '.xlsx':
                name_lower = file.name.lower()
                if 'статистика_' in name_lower and stat_file is None:
                    stat_file = file
                elif 'карта_' in name_lower and map_file is None:
                    map_file = file
                elif any(sub in name_lower for sub in ('чпу', 'xge')) and cnc_a3d_file is None:
                    cnc_a3d_file = file

        # Теперь обрабатываем в зависимости от того, кто первый найден
        if map_file:
            sheet1_6(str(map_file), code_project)
        if stat_file:
            sheet1_5(str(stat_file), code_project)
        if cnc_a3d_file:
            for_cnc_a3d(str(cnc_a3d_file))
            os.remove(cnc_a3d_file)

        mode = input(f'Удалить временные отчёты для RealCut?'
                     f'\n(Нет - любой текст, Да - без текста)? > ')

        if not mode:
            os.remove(xlsx_warehouse)
            os.remove(xlsx_cutting)

    cutting_sheet(Path(xlsx).parent) # Добавляем пластины в ведомость проката

if __name__ == "__main__":
    # xls = r'C:\Users\ik\Desktop\Primer\Холодильник\Материалы\1.2 _ Ведомость элементов.xlsx'
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xls = easygui.fileopenbox(msg="Укажите файл 1.2 _ Ведомость элементов.xlsx", title="", default=f"{path}/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
    sheet3_1(xls)
    input('\n\rРабота завершена.	\n')
