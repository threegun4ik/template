from pathlib import Path
from __Kompas import *
from __K_k3d_to_m3d import k3d_to_m3d
from __K_insert_lsk import insert_lcs
from __K_i3d_to_m3d import i3d_to_m3d
from __K_m3d_to_i3d import m3d_to_i3d
import shutil, re

import _Config
import pandas as pd
import os, easygui, openpyxl, sys
from __K_Marking3D import marking_3d

from __Debug import print_full_columns as pfc

# Рекурсивное удаление файлов
def recursive_delete_files(folder):
    # print(folder)
    if not os.path.exists(folder):
        return  # Папки уже нет

    for item in os.listdir(folder):
        item_path = os.path.join(folder, item)
        # print(item_path)
        try:
            if os.path.isdir(item_path):
                shutil.rmtree(item_path)  # Удаляем папку рекурсивно
            else:
                os.remove(item_path)  # Удаляем файл
        except PermissionError:
            print(f"❌ Нет доступа: {item_path} (файл используется системой)")
        except Exception as e:
            print(f"Ошибка при удалении {item_path}: {e}")

    try:
        shutil.rmtree(folder)  # Пытаемся удалить саму папку
    except PermissionError:
        print(f"❌ Нет доступа: {folder} (возможно, файлы заняты системой)")

def cnc_for_all(df, xlsx = None):
    try:
        if isinstance(df, pd.DataFrame):  # Если передан уже готовый DataFrame
            df = df
            if not xlsx:
                xlsx = df['Полное имя файла'].iloc[0]
            folder_path = Path(xlsx).parent

        else:  # Если передан путь к файлу
            xlsx = df
            wb = openpyxl.load_workbook(filename=xlsx, data_only=True)
            df = pd.read_excel(df, sheet_name='Ведомость элементов', engine='openpyxl', header=1)
            folder_path = Path(xlsx).parent
            # print(xlsx)

    except Exception:
        input('Похоже, файл отчета не подходящий')
        sys.exit()

    # folder_path = Path(xlsx)  # Преобразуем строку в объект Path
    folder_3d_parts = folder_path / "3d parts"
    folder_m3d = folder_3d_parts / "m3d"
    folder_e3d = folder_3d_parts / _Config.format_cnc

    KompasObject, iApplication, KompasVersion = get_kompas()
    iApplication.HideMessage = con0.ksHideMessageNo
    kompas_file_unlock(iApplication)  # Разблокировать файл, открытый компасом
    recursive_delete_files(folder_3d_parts)  # Запускаем удаление папки 3d parts

    # Создаём папки
    folder_3d_parts.mkdir(parents=True, exist_ok=True)
    folder_m3d.mkdir(parents=True, exist_ok=True)
    folder_e3d.mkdir(parents=True, exist_ok=True)

    log_message(f'Адресно сохраняем элементы в m3d', 'how')

    df = df.loc[df['№ элемента'].notna()].copy()  # фильтр + копия Фильтруем строки, где 'Обозначение' не пустое
    # <<< ADD: гарантируем строковый dtype для текстовых полей
    for col in ['Полное имя файла', 'Путь до i3d']:
        if col not in df.columns:
            df[col] = pd.Series(pd.NA, index=df.index, dtype='string')
        else:
            df[col] = df[col].astype('string')

    # iDocuments = iApplication.Documents
    # print(f'Активных документов до k3d_to_m3d документа: {iDocuments.Count}')

    for _, row in df.iterrows(): # Обрабатываем каждую строку
        raw_path = row['Путь до марки']

        # Найдём пути, содержащие допустимые расширения
        paths = re.findall(r"[A-Z]:\\.*?\.(?:a3d|m3d)", raw_path, flags=re.IGNORECASE) #Разбиваем пути правильно

        processed = False  # Флаг для отслеживания выполнения условий

        file_paths = [Path(p) for p in paths]  # список всех возможных .a3d/.m3d путей

        new_file_path = None
        saved_paths = []


        # 1. Обработка "Так"
        if pd.notna(row['Так']) and row['Так'] > 0:
            file_name_m3d = f"{int(row['№ элемента'])}_{row['Сечение']}_L{int(row['Длина, мм'])}мм_{row['Марка стали']}_{int(row['Так'])}(т)шт"
            new_file_path = k3d_to_m3d(
                {4.0: str(int(row['№ элемента'])), 238175427236.0: "1"},
                file_paths,
                folder_m3d,
                file_name_m3d,
                iApplication
            )
            if new_file_path:
                saved_paths.append(str(new_file_path))
                print(f'{file_name_m3d} - готово')
                processed = True

        # 2. Обработка "Наоборот"
        if pd.notna(row['Наоборот']) and row['Наоборот'] > 0:
            file_name_m3d = f"{int(row['№ элемента'])}_{row['Сечение']}_L{int(row['Длина, мм'])}мм_{row['Марка стали']}_{int(row['Наоборот'])}(н)шт"
            new_file_path = k3d_to_m3d(
                {4.0: str(int(row['№ элемента'])), 255901398516.0: "1"},
                file_paths,
                folder_m3d,
                file_name_m3d,
                iApplication
            )
            if new_file_path:
                saved_paths.append(str(new_file_path))
                print(f'{file_name_m3d} - готово')
                processed = True

        # Если ни один не прошёл
        if not processed:
            log_message(f'Пропущена строка {row}: условия не выполнены', 'error')
            log_message(f'Запустите ОиСМК и повторите создание отчетов', 'warn')

        # Если что-то удалось сохранить
        if saved_paths:
            # print(f'{file_name_m3d} - готово')
            df.at[row.name, 'Полное имя файла'] = '; '.join(saved_paths)

        else:
            df.at[row.name, 'Полное имя файла'] = pd.NA
            KompasObject, iApplication, KompasVersion = get_kompas()

    iDocuments = iApplication.Documents
    # print(f'Активных документов после k3d_to_m3d: {iDocuments.Count}')
    kompas_file_unlock(iApplication)  # Разблокировать файл, открытый компасом

    log_message(f'Вставляем ЛСК в каждом элементе...', 'how')
    # print(f'Активных документов до insert_lcs: {iDocuments.Count}')
    paths_i3d = df.apply(
        lambda row: '; '.join([  # ← собираем строки путей через "; "
            (Path(p.strip()).parent.parent  # 1. берём родительскую папку от родителя файла (на два уровня выше)
             / _Config.format_cnc  # 2. добавляем подпапку с именем формата (например "stp" или "igs")
             / Path(p.strip()).stem)  # 3. берём имя файла без расширения
            .with_suffix(f".{_Config.format_cnc}")  # 4. добавляем новое расширение (.stp, .igs и т.п.)
            .as_posix()  # 5. преобразуем в строку с прямыми слешами
            for p in str(row['Полное имя файла']).split('; ')  # обходим все пути, если их несколько через "; "
            if p.strip()  # игнорируем пустые
        ])
        if row['Тип объекта'] != 'Деталь'  # условие: только если объект НЕ "Деталь"
           and pd.notna(row['№ элемента'])  # и номер элемента существует
           and pd.notna(row['Полное имя файла'])  # и есть путь к файлу
        else pd.NA,  # иначе → пустое значение
        axis=1
    )

    df['Путь до i3d'] = pd.Series(paths_i3d, index=df.index, dtype='string')

    def check_and_convert_i3d_to_m3d(row):
        '''Создаем m3d для элементов с правильно вставленной ЛСК и перемещаем в папку m3d'''''

        if (pd.notna(row['Путь до i3d'])):
            file_cnc = i3d_to_m3d(row['Путь до i3d'], KompasObject)  # Вызов функции с параметром file_igs для пластин

            m3d_file = file_cnc.with_suffix('.m3d') # Определяем путь к созданному .m3d файлу (та же папка, но расширение .m3d)
            destination_path = folder_m3d / m3d_file.name # Определяем конечный путь в папке назначения с таким же именем файла
            shutil.move(str(m3d_file), str(destination_path))# Перемещаем файл с заменой, если он уже существует

    # Сохраняем m3d из i3d с правильно вставленной ЛСК
    df.apply(
        lambda row: [
            (
                insert_lcs(file_path.strip(), i3d_path.strip(), _Config.format_cnc, KompasObject, iApplication),
                check_and_convert_i3d_to_m3d(pd.Series({'Путь до i3d': i3d_path.strip()}))
            )
            for file_path, i3d_path in zip(  # ← связываем пары "оригинальный m3d" ↔ "путь до i3d"
                str(row['Полное имя файла']).split('; '),
                str(row['Путь до i3d']).split('; ')
            )
            if file_path.strip() and i3d_path.strip()  # ← обрабатываем только непустые пути
        ]
        if pd.notna(row['Полное имя файла'])  # условие: оба столбца заполнены
           and pd.notna(row['Путь до i3d'])
           and str(row['Полное имя файла']).strip() != ''
           and str(row['Путь до i3d']).strip() != ''
        else None,
        axis=1
    )
    # print(f'Активных документов после insert_lcs: {iDocuments.Count}')
    if _Config.marking_3d:
        # Фильтрация строк, которые не содержат @016 и @137 для маркировки
        filtered_df = df[~df['Эскиз сечения'].str.contains('@016|@137', na=False)]
        log_message('Вставляем маркировку в 3D элементы', 'how')

        for _, row in filtered_df.iterrows():
            marking = row['№ элемента']
            files_m3d = str(row['Полное имя файла']).split('; ')
            files_i3d = str(row['Путь до i3d']).split('; ')

            for file_m3d, file_i3d in zip(files_m3d, files_i3d):
                file_m3d = file_m3d.strip()
                file_i3d = file_i3d.strip()

                if not file_m3d or not file_i3d:
                    log_message(f'Пропущена строка с обозначением: {int(marking)} - без имени файла', 'warn')
                    continue

                # Маркируем и конвертируем
                marking_3d(file_m3d, marking, iApplication)
                check = m3d_to_i3d(file_m3d, file_i3d, _Config.format_cnc, KompasObject, iApplication)
                if check:
                    print(f'{Path(file_m3d).stem} - готово')

    iApplication.HideMessage = con0.ksShowMessage
    kompas_file_unlock(iApplication)
    return df

if __name__ == "__main__":
    # KompasObject, iApplication, KompasVersion = get_kompas()
    # path = get_active_doc_path(iApplication)
    xlsx = r'I:\Documents\MY PROJECT\Active Project\Олег\Стойки\Материалы\1.2 _ Ведомость элементов.xlsx'

    cnc_for_all(xlsx)
    # xlsx = Path(xlsx).parent / 'Материалы'
    # folder_path = Path(xlsx)  # Преобразуем строку в объект Path
    # recursive_delete_files(folder_path)
