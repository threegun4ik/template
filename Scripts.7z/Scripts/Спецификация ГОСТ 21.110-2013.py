import easygui

from _ExcelHandler import ExcelHandler
import pandas as pd
import numpy as np
from _Colors import *

import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Font
from openpyxl.styles import NamedStyle
import xlwings as xw
from pathlib import Path
import _Config
# from _Debug import printprop, printattr
from _Kompas import *

def sheet1_2(xls, code_project=""):

    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler для элементов
    df = excel_handler.read_excel()  # Читаем таблицу в dataframe
    df.columns = df.columns.str.replace(r'[@/]', ' ', regex=True)

    # Изменение значений в соответствии с условием
    df['Количество'] = df['Количество'].astype(float) # Столбец 'Количество' имеет тип float
    df['Ед. измерения'] = df['Ед. измерения'].astype(str) # Столбец 'Ед. измерения' имеет тип str

    # Перенесем длину профиля в длину трубы
    condition = df['Длина трубы'].isna() & df['Длина профиля'].notna()
    df.loc[condition, 'Длина трубы'] = df['Длина профиля']
    df.loc[condition, 'Длина профиля'] = np.nan  # Очистка только изменённых значений

    # Условие для изменения данных
    # condition = df['Объект приложения'].isin(['Pipeline', 'EasySteel'])
    condition = ~df['Длина трубы'].isna()
    df.loc[condition, 'Количество'] = (df.loc[condition, 'Длина трубы'] * df.loc[condition, 'Количество'] / 1000).astype(float)# Присвоение значения с плавающей точкой
    df.loc[condition, 'Наименование'] = df.loc[condition, 'Материал']
    df.loc[condition, 'Масса 1 ед.,кг'] = np.nan
    df.loc[condition, 'Материал'] = np.nan
    df.loc[condition, 'Ед. измерения'] = 'м.п.'

    condition = df['Тип объекта'].isin(['Сборочная единица', 'Деталь', 'Стандартное изделие'])
    df.loc[condition, 'Ед. измерения'] = 'шт.'

    condition = df['Тип объекта'] == 'Сборочная единица'
    df = df.loc[~condition]

    # 'Тип, марка', 'обозначение документа, опросного листа', 'Код продукции', 'Поставщик'
    df = df[['Поз.', 'Наименование', 'Тип, марка, обозначение документа, опросного листа', 'Код продукции', 'Поставщик',
             'Ед. измерения', 'Количество', 'Масса 1 ед.,кг', 'Примечание', 'Раздел спецификации', 'Объект приложения',
             'Тип объекта', 'Объект трубопроводов', 'Полное имя файла']]

    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом
    df = excel_handler.line_joining_df(
            ['Наименование', 'Тип, марка, обозначение документа, опросного листа', 'Код продукции',
            'Поставщик', 'Ед. измерения', 'Масса 1 ед.,кг', 'Раздел спецификации'],
            ['Количество'],
            ['Полное имя файла'],
            ['Поз.', 'Масса 1 ед.,кг', 'Примечание', 'Тип объекта', 'Объект трубопроводов'], ignore_value=None)# Объединим строки

    xlsx = f'{xls}x'
    df.to_excel(xlsx, sheet_name="Спецификация", index=False)  # Записали в xlsx

    f'{code_project}. Ведомость элементов'

    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Спецификация']  # Выбираем лист по имени

    ###Название таблицы
    ws.insert_rows(1)  # Вставим строку
    ws["A1"] = f'{code_project}. Спецификация материалов'
    # ws["A2"] = "№ элемента"

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов

    # excel_handler.fix_dimensions(ws, ['A'], width=20)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['B'], width=130)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['C'], width=60)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['D'], width=35)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['E'], width=45)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['F', 'H'], width=20)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['G'], width=25)  # Фиксированная ширина столбцов
    # excel_handler.fix_dimensions(ws, ['I'], width=40)  # Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 30  # Измените высоту первой строки

    # Включите перенос текста по словам и выравнивание по центру для ячеек во второй строке
    for cell in ws[2]:  # Итерируем по ячейкам во второй строке
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")



    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)  # Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = Alignment(horizontal='left', vertical='center')

    ws.auto_filter.ref = 'A2:{}'.format(openpyxl.utils.get_column_letter(ws.max_column) + '2')  # Автофильтр на вторую строку
    #
    # excel_handler.format_columns(ws, ['G'], n=1, start_row=3)  # Округление до n знаков после запятой
    # last_row = ws.max_row

    # # Проверки
    # excel_handler.check_empty_rows_in_cell_column(ws, 2, 'E, G, H, I, J, U, O, W')  # Проверка таблицы на пустые ячейки в ячейках с третей строки и выделяем их цветом
    # excel_handler.compare_columns(ws, 'A', 'F', 'K')  # Сравниваем значения в столбце A и проверяем столбцы B, C, D
    # number_format_style = NamedStyle(name="number_format_style", number_format="0.0")# Определение стиля для числовых форматов
    # #
    # # Добавление стиля числового формата в столбцы G и H
    # for col in ['G']:
    #     for row in range(2, ws.max_row + 1):  # Начинаем с 2-й строки, чтобы пропустить заголовок
    #         cell = ws[f"{col}{row}"]
    #         if cell.value is not None and isinstance(cell.value, (int, float)):
    #             cell.style = number_format_style
    #
    #
    # ws.cell(row=last_row + 2, column=12, value='Итого').font = Font(bold=True)  # Столбец J (10)# Добавляем строку 'Итого'
    # ws.cell(row=last_row + 2, column=13).alignment = Alignment(horizontal='right', vertical='center')# Установка выравнивания
    # ws.cell(row=last_row + 2, column=13, value=f'=ROUND(SUM(M3:M{last_row}), 1)').font = Font(bold=True)# Устанавливаем формулу в столбец для последней строки
    # ws.cell(row=last_row + 2, column=13, value=f'=ROUND(SUM(M3:M{last_row}), 1)').number_format = '0 "кг"'
    #
    # # Удаление из ячеек 0 в столбцах Так и Наоборот
    # for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=4, max_col=5):
    #     for cell in row:
    #         if cell.value == 0:  # Проверка на 0
    #             cell.value = None  # Замена на None

    # Создание маппинга выравниваний для столбцов
    alignment_map = {
        **{letter: Alignment(horizontal='center', vertical='center') for letter in 'ACDEFGHJKLM'},
        # **{letter: Alignment(horizontal='right', vertical='center') for letter in 'F'},
        **{letter: Alignment(horizontal='left', vertical='center') for letter in 'BN'}
    }
    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем со второй строки, чтобы пропустить заголовки
        for cell in row:
            column_letter = openpyxl.utils.get_column_letter(cell.column)
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    # Скроем ненужные столбцы
    for col in ['J', 'K', 'L', 'M', 'N']:
        ws.column_dimensions[col].hidden = True
    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()
    print(f'{C.green}Ведомость элементов металлоконстркции - создана{C.default}')
    ####

    # Открываем книгу через Excel
    with xw.App(visible=False) as app:  # Создаём приложение и делаем его невидимым
        wb = xw.Book(xlsx)  # Открываем файл
        app.calculate()  # Пересчёт всех формул
        wb.save()  # Сохраняем файл
        wb.close()  # Закрываем книгу

    return xlsx

    # # Настройки для отображения всех строк и столбцов
    # pd.set_option('display.max_rows', None)
    # pd.set_option('display.max_columns', None)
    #
    # # Печать всего DataFrame
    # print(df)
    #
    # # Возвращение настроек к исходным значениям (если необходимо)
    # pd.reset_option('display.max_rows')
    # pd.reset_option('display.max_columns')

if __name__ == "__main__":
    # xls = r'C:\Users\ik\Desktop\Primer\Трубопроводы\Общий отчёт.xls'
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xls = easygui.fileopenbox(msg="Укажите файл отчета", title="", default=f"{path}/*Общий отчёт.xls")  # Путь до файла отчёта
    # xls = r'C:\Users\ik\Desktop\Новая папка\Трубопровод\Отчет.xls'
    sheet1_2(xls)
    input('\n\rРабота завершена.	\n')
