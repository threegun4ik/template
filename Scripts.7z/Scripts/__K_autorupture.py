import customtkinter as ctk
from __Kompas import *
import sys, os

# Глобальные настройки по умолчанию
default_shift = 150
default_break_lines_min = 200
default_max_l = 500

# Флаг запуска из GUI
gui_mode = False

# Сбор сегментов
def collect_segments(iAssociationViews, horizontal, obg_X, obg_Y, max_l):
    segments = []
    for iView in iAssociationViews:
        iAssociationView = API7.IAssociationView(iView)
        bool_HiddenLines = iAssociationView.HiddenLines
        bool_HiddenLinesVisible = iAssociationView.HiddenLinesVisible
        iAssociationView.HiddenLines = True
        iAssociationView.HiddenLinesVisible = True
        # iAssociationView.BreakLinesVisible = True
        iAssociationView.Update()

        iDrawingContainer = API7.IDrawingContainer(iAssociationView)
        iCircles = iDrawingContainer.Circles
        iArcs = iDrawingContainer.Arcs
        iLineSegments = iDrawingContainer.LineSegments

        for n in range(iLineSegments.Count):
            iLineSegment = iLineSegments.LineSegment(n)
            x1, y1 = round(iLineSegment.X1, 1), round(iLineSegment.Y1, 1)
            x2, y2 = round(iLineSegment.X2, 1), round(iLineSegment.Y2, 1)
            start = min(x1, x2) if horizontal else min(y1, y2)
            end = max(x1, x2) if horizontal else max(y1, y2)
            skip = y1 == y2 and end - start > max_l if horizontal else x1 == x2 and end - start > max_l
            if not skip and (end - start) < (obg_X if horizontal else obg_Y) * 0.8:
                segments.append((start, end))

        for n in range(iCircles.Count):
            iCircle = iCircles.Circle(n)
            c = round(iCircle.X, 1) if horizontal else round(iCircle.Y, 1)
            r = round(iCircle.Radius, 1)
            start = c - r
            end = c + r
            if r * 2 < (obg_X if horizontal else obg_Y) * 0.9:
                segments.append((start, end))

        for n in range(iArcs.Count):
            iArc = iArcs.Arc(n)
            x1 = round(iArc.X1, 1)
            y1 = round(iArc.Y1, 1)
            x2 = round(iArc.X2, 1)
            y2 = round(iArc.Y2, 1)
            if horizontal and y1 != y2:
                start, end = sorted([x1, x2])
                if end - start < obg_X * 0.9:
                    segments.append((start, end))
            elif not horizontal and x1 != x2:
                start, end = sorted([y1, y2])
                if end - start < obg_Y * 0.9:
                    segments.append((start, end))

        # iAssociationView.HiddenLines = bool_HiddenLines
        iAssociationView.HiddenLinesVisible = bool_HiddenLinesVisible
        # iAssociationView.BreakLinesVisible = True
        iAssociationView.Update()
    segments.sort()
    return segments

def find_free_zones(segments, shift, min_length):
    free = []
    current_end = None

    for start, end in segments:
        if current_end is None:
            current_end = end
            continue
        if start > current_end:
            gap_start = current_end + shift
            gap_end = start - shift
            if gap_end - gap_start >= min_length:
                free.append((gap_start, gap_end))
        current_end = max(current_end, end)
    return free

def autorupture(iAssociationViews, iKompasDocument2D1=None, iView=None,
                 shift=default_shift, break_lines_min=default_break_lines_min,
                 max_l=default_max_l, use_horizontal=None, use_vertical=None):

    scale = iView.Scale

    if not gui_mode:
        shift /= scale
        break_lines_min /= scale

    obg_X, obg_Y, *_ = [(value - 2) / scale for value in get_gabarit_object(iView, iKompasDocument2D1)]

    if use_horizontal is None or use_vertical is None:
        horizontal_by_gabarit = obg_X > obg_Y
        use_horizontal = horizontal_by_gabarit
        use_vertical = not horizontal_by_gabarit

    if use_horizontal:
        segments_horizontal = collect_segments(iAssociationViews, True, obg_X, obg_Y, max_l)
        free_zones_horizontal = find_free_zones(segments_horizontal, shift, break_lines_min)
    else:
        free_zones_horizontal = []

    if use_vertical:
        segments_vertical = collect_segments(iAssociationViews, False, obg_X, obg_Y, max_l)
        free_zones_vertical = find_free_zones(segments_vertical, shift, break_lines_min)
    else:
        free_zones_vertical = []

    for iAssociationView in iAssociationViews:
        iBreakViewParam = API7.IBreakViewParam(iAssociationView)
        iBreakViewParam.DeleteAllBreakLines()
        iBreakViewParam.BreaksVisible = True

        for start, end in free_zones_horizontal:
            print(f"Свободный промежуток: {round(start)} -> {round(end)}")
            iBreakViewParam.AddBreakLine(start / scale, -obg_Y / scale, end / scale, obg_Y / scale, 0)

        for start, end in free_zones_vertical:
            print(f"Свободный промежуток: {start} -> {end}")
            iBreakViewParam.AddBreakLine(-obg_X / scale, start / scale, obg_X / scale, end / scale, 90)

        iAssociationView.Update()


def run_with_gui():
    global gui_mode
    gui_mode = True

    def on_submit():
        shift = float(shift_entry.get())
        min_len = float(min_entry.get())
        max_len = float(max_entry.get())
        h = horizontal_var.get()
        v = vertical_var.get()
        root.destroy()
        launch_autorupture(shift, min_len, max_len, h, v)

    ctk.set_appearance_mode("system")
    ctk.set_default_color_theme("blue")

    window_width = 300
    window_height = 280

    root = ctk.CTk()
    root.title("Авторазрывы")
    root.attributes('-topmost', 1)

    def place_window():
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x_position = int((screen_width - window_width) / 2)
        y_position = int((screen_height - window_height) / 2)
        root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

    root.after(50, place_window)  # отложить позиционирование

    root.bind("<Return>", lambda event: on_submit())

    frame = ctk.CTkFrame(root)
    frame.pack(fill="both", expand=True, padx=15, pady=15)

    def add_labeled_entry(label_text, default_value):
        container = ctk.CTkFrame(frame, fg_color="transparent")
        container.pack(fill="x", pady=6, padx=5)

        entry = ctk.CTkEntry(container, justify="center")
        entry.insert(0, str(default_value))
        entry.pack(side="left", fill="x", expand=True, padx=(0, 10))

        label = ctk.CTkLabel(container, text=label_text, width=130, anchor="w")
        label.pack(side="left")

        return entry

    shift_entry = add_labeled_entry("Отступ, мм:", default_shift)
    min_entry = add_labeled_entry("Мин. разрыв, мм:", default_break_lines_min)
    max_entry = add_labeled_entry("Макс. длина, мм:", default_max_l)

    horizontal_var = ctk.BooleanVar(value=True)
    vertical_var = ctk.BooleanVar(value=False)

    ctk.CTkCheckBox(frame, text="Разрывы по длинной стороне", variable=horizontal_var).pack(anchor="w", pady=(12, 2), padx=5)
    ctk.CTkCheckBox(frame, text="Разрывы по короткой стороне", variable=vertical_var).pack(anchor="w", pady=(2, 12), padx=5)

    ctk.CTkButton(frame, text="Готово", command=on_submit, height=45).pack(fill="x", padx=5, pady=10)

    root.mainloop()

def del_BreakLines(iAssociationView, x1 = -600000, y1 = -60000, x2 = -601000, y2 = 601000, angel = 0):
    iBreakViewParam = API7.IBreakViewParam(iAssociationView)
    breaks_count = iBreakViewParam.BreaksCount
    if breaks_count > 0:
        iBreakViewParam.DeleteAllBreakLines()
        iBreakViewParam.BreaksVisible = True
        iBreakViewParam.AddBreakLine(x1, y1, x2, y2, angel)
        iAssociationView.Update() # Нужно ли


def launch_autorupture(shift, break_lines_min, max_l, horizontal=None, vertical=None):
    KompasObject, iApplication, KompasVersion = get_kompas()

    script = os.path.basename(__file__)
    if not check_access(script):
        input(f"❌ Похоже кто-то не задонатил за {script.split('.')[0]}, пропускаем...")
        sys.exit()

    iKompasDocument = iApplication.ActiveDocument
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    iViews = iKompasDocument2D.ViewsAndLayersManager.Views
    iAssociationViews = iKompasDocument2D1.SelectionManager.SelectedObjects

    if not iAssociationViews:
        iView = iViews.ActiveView
        del_BreakLines(iView)
        iAssociationViews = (iView,)
        autorupture(iAssociationViews, iKompasDocument2D1, iView, shift, break_lines_min, max_l)
    else:
        if not isinstance(iAssociationViews, (list, tuple)):
            iAssociationViews = (iAssociationViews,)

        try:
            iView = API7.IView(iAssociationViews[0])
            for iAssociationView in iAssociationViews:
                del_BreakLines(iAssociationView)
            autorupture(iAssociationViews, iKompasDocument2D1, iView, shift, break_lines_min, max_l)
        except:
            iApplication.MessageBoxEx(
                'Для размещения разрыва нужно выделить вид/виды целиком или не выделять ничего', 'Ошибка', 0)
            sys.exit(0)

if __name__ == "__main__":
    # run_with_gui()
    launch_autorupture(15, 20, 500)
    # run_with_gui()
