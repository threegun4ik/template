from traceback import format_exc
from fileinput import filename
from pathlib import Path
from shutil import copy2
import time
from win32com.client import gencache, Dispatch
from __Debug import *

from __Kompas import *
import os

"""
Проверяет свойства тел в сборке и сохраняет подходящее тело как деталь.
"""
def k3d_to_m3d(check_dict, file_paths, folder_to_save, file_name_m3d, iApplication):
    """
    Перебирает пути и сохраняет подходящее тело в m3d.
    """

    def check_and_save_bodies(result_bodies):
        """Проверяет свойства тел и сохраняет подходящее тело"""
        result = [(float(k), v) for k, v in check_dict.items()]
        iPropertyMng = API7.IPropertyMng(iApplication)

        def matches_body_properties(iBody7):
            """Сравнивает свойства тела с искомыми значениями"""
            iPropertyKeeper = API7.IPropertyKeeper(iBody7)
            for key, value in result:
                val = iPropertyKeeper.GetPropertyValue(iPropertyMng.GetProperty(iKompasDocument, key), 0, 1, 1)[1]
                if str(val) != str(value):
                    return False
            return True

        iBody7 = next((body for body in (result_bodies if isinstance(result_bodies, tuple) else [result_bodies])
                       if matches_body_properties(body)), None)

        if not iBody7:
            return None

        iKompasDocument1 = API7.IKompasDocument1(iKompasDocument)
        iSaveAsDetailParam = API7.ISaveAsDetailParam(iKompasDocument1.GetInterface(con0.ksObjectSaveAsDetailParam))
        iSaveAsDetailParam.Mirror = not leftHandedCS
        iSaveAsDetailParam.FileName = str(folder_to_save / f"{file_name_m3d}.m3d")
        iSaveAsDetailParam.Unhistored = True
        # iSaveAsDetailParam.Name = file_name_m3d
        iSaveAsDetailParam.Name = iBody7.Name
        iSaveAsDetailParam.Marking = iBody7.Marking
        marking = iBody7.Marking

        iParts = iEmbodiment.Part.Parts
        iPart7 = iParts.SaveAsDetail(iBody7, iSaveAsDetailParam)
        # iPart7.Marking = marking
        # iPart7.Update()
        # printprop(iPart7)

        # if KompasVersion == 21:
        iKompasDocument_m3d = iDocuments.Open(str(folder_to_save / f"{file_name_m3d}.m3d"), False, False)
        iKompasDocument3D_m3d = API7.IKompasDocument3D(iKompasDocument_m3d)
        iPart7_m3d = iKompasDocument3D_m3d.TopPart
        #Удаляем компоненты
        iKompasDocument1.Delete(iPart7_m3d.PartsEx(0))

        iPart7_m3d.Marking = marking
        iPart7_m3d.Update()
        iKompasDocument3D_m3d.RebuildDocument()
        iKompasDocument_m3d.Save()
        iKompasDocument_m3d.Close(1)

        return Path(iSaveAsDetailParam.FileName)

    found = False  # ← отслеживаем общий успех
    for file_a3d in file_paths:
        file_a3d = Path(file_a3d)
        folder_to_save = Path(folder_to_save)
        temp_file_a3d = folder_to_save / f"{file_a3d.name}.bak"
        copy2(file_a3d, temp_file_a3d)

        try:
            iDocuments = iApplication.Documents
            iKompasDocument = iDocuments.Open(temp_file_a3d, False, False)
            iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
            iPart7 = iKompasDocument3D.TopPart
            iEmbodimentsManager = API7.IEmbodimentsManager(iPart7)
            iEmbodimentsManager.SetCurrentEmbodiment(0)

            for i in range(iEmbodimentsManager.EmbodimentCount):
                iEmbodiment = iEmbodimentsManager.Embodiment(i)
                iEmbodimentsManager.SetCurrentEmbodiment(i)
                iEmbodiment = iEmbodimentsManager.CurrentEmbodiment
                leftHandedCS = iEmbodiment.LeftHandedCS

                iFeature7 = API7.IFeature7(iEmbodiment.Part)
                result_bodies = iFeature7.ResultBodies
                result_path = check_and_save_bodies(result_bodies)

                if result_path:
                    found = True
                    iKompasDocument.Close(0)
                    temp_file_a3d.unlink(missing_ok=True)
                    bak_file = result_path.with_suffix(result_path.suffix + ".bak")
                    if bak_file.exists():
                        bak_file.unlink()
                    return result_path

        except Exception as e:
            print(f"Компас упал на элементе {file_name_m3d} в сборке {file_a3d}. Ошибка: {e}")#{fallen}
            file_m3d = folder_to_save / f"{file_name_m3d}.m3d"
            file_m3d.unlink(missing_ok=True)

        finally:
            temp_file_a3d.unlink(missing_ok=True)

    # После перебора всех путей
    if not found:
        print(f"Подходящего тела {file_name_m3d} не найдено ни в одной сборке:")#{red}
        for file_path in file_paths:
            print(f"  └─ {file_path}")

    return False


# def k3d_to_m3d(check_dict, file_paths, folder_to_save, file_name_m3d, iApplication):
#     """
#     Обрабатывает сборку, проверяет свойства тел и сохраняет подходящие тела.
#     """
#     found = None
#     result_path = None
#     def check_and_save_bodies(result_bodies):
#         """Проверяет свойства тел и сохраняет подходящее тело"""
#         result = [(float(k), v) for k, v in check_dict.items()]
#         iPropertyMng = API7.IPropertyMng(iApplication)
#
#         def matches_body_properties(iBody7):
#             """Сравнивает свойства тела с искомыми значениями"""
#             iPropertyKeeper = API7.IPropertyKeeper(iBody7)
#             for key, value in result:
#                 val = iPropertyKeeper.GetPropertyValue(iPropertyMng.GetProperty(iKompasDocument, key), 0, 1, 1)[1]
#                 if str(val) != str(value):
#                     return False
#             return True
#
#         iBody7 = next((body for body in (result_bodies if isinstance(result_bodies, tuple) else [result_bodies])
#                        if matches_body_properties(body)), None)
#
#         if not iBody7:
#             return None
#         marking = iBody7.Marking
#
#         iKompasDocument1 = API7.IKompasDocument1(iKompasDocument)
#         iSaveAsDetailParam = API7.ISaveAsDetailParam(iKompasDocument1.GetInterface(con0.ksObjectSaveAsDetailParam))
#         iSaveAsDetailParam.Mirror = not leftHandedCS
#         iSaveAsDetailParam.FileName = str(folder_to_save / f"{file_name_m3d}.m3d")
#         iSaveAsDetailParam.Unhistored = True
#         # iSaveAsDetailParam.Name = file_name_m3d
#         iSaveAsDetailParam.Name = iBody7.Name
#         iSaveAsDetailParam.Marking = iBody7.Marking
#         marking = iBody7.Marking
#
#         iParts = iEmbodiment.Part.Parts
#         iPart7 = iParts.SaveAsDetail(iBody7, iSaveAsDetailParam)
#         # iPart7.Marking = marking
#         # iPart7.Update()
#         # printprop(iPart7)
#
#         # if KompasVersion == 21:
#         iKompasDocument_m3d = iDocuments.Open(str(folder_to_save / f"{file_name_m3d}.m3d"), False, False)
#         iKompasDocument3D_m3d = API7.IKompasDocument3D(iKompasDocument_m3d)
#         iPart7_m3d = iKompasDocument3D_m3d.TopPart
#         iPart7_m3d.Marking = marking
#         iPart7_m3d.Update()
#         iKompasDocument3D_m3d.RebuildDocument()
#         iKompasDocument_m3d.Save()
#         iKompasDocument_m3d.Close(1)
#
#         return Path(iSaveAsDetailParam.FileName)
#
#
#     for file_a3d in file_paths:
#
#         file_a3d = Path(file_a3d)
#         folder_to_save = Path(folder_to_save)
#         temp_file_a3d = folder_to_save / f"{file_a3d.name}.bak"
#         copy2(file_a3d, temp_file_a3d)
#
#         try:
#             iDocuments = iApplication.Documents
#             iKompasDocument = iDocuments.Open(temp_file_a3d, False, False)
#             iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
#             iPart7 = iKompasDocument3D.TopPart
#             iEmbodimentsManager = API7.IEmbodimentsManager(iPart7)
#             iEmbodimentsManager.SetCurrentEmbodiment(0)
#
#             for i in range(iEmbodimentsManager.EmbodimentCount):
#                 iEmbodiment = iEmbodimentsManager.Embodiment(i)
#                 iEmbodimentsManager.SetCurrentEmbodiment(i)
#                 iEmbodiment = iEmbodimentsManager.CurrentEmbodiment
#                 leftHandedCS = iEmbodiment.LeftHandedCS
#                 # iParts = iEmbodiment.Part.Parts
#                 iFeature7 = API7.IFeature7(iEmbodiment.Part)
#                 result_bodies = iFeature7.ResultBodies
#                 result_path = check_and_save_bodies(result_bodies)
#                 if result_path:
#                     found = True
#                     iKompasDocument.Close(0)
#                     break
#                 # else:
#                 #     print(f"{red}Подходящего тела {file_name_m3d} в сборке {file_a3d} в исполнении {i} найти не удалось{default}")
#                 #     result_path = None
#             if not found:
#                 print(f"{red}Подходящего тела {file_name_m3d} в сборке {file_a3d} в исполнении {i} найти не удалось{default}")
#
#                 result_path = None
#
#         except Exception as e:
#             print(f"{fallen} Компас упал на элементе {file_name_m3d} в сборке {file_a3d}{default}. Ошибка: {e}")
#             # print((f'{magenta}Ошибка {format_exc()}{default}'))
#             file_m3d = folder_to_save / f"{file_name_m3d}.m3d"
#             file_m3d.unlink(missing_ok=True)
#             result_path = None
#
#         finally:
#             try:
#                 temp_file_a3d.unlink(missing_ok=True)
#                 if result_path and (bak_file := result_path.with_suffix(result_path.suffix + ".bak")).exists():
#                     bak_file.unlink()
#                     return result_path
#                 else:
#                     return False
#             except Exception as e:
#                 print(f'Ошибка при удалении временных файлов: {e}')
#
#     # return result_path

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    temp_file_a3d = r'C:\Users\ik\Desktop\2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\01 _ CAD\part\Ст105.a3d'
    check_dict = {4.0: '1601'}
    folder_to_save = Path(temp_file_a3d).parent
    file_name_m3d = 'Test'

    try:
        result = k3d_to_m3d(check_dict, [Path(temp_file_a3d)], folder_to_save, file_name_m3d, iApplication)
        print(f"Файл сохранён: {result}" if result else "Не удалось найти тело")
    except ValueError as e:
        print(f"Ошибка: {e}")



#     C:\Users\ik\Desktop\Primer\Эстакады\Эстакада\Ст1.a3d
