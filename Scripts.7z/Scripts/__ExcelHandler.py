import os, xlrd, re
import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image
from openpyxl.styles import PatternFill, NamedStyle, Border, Alignment, Side
import xlwings as xw
import pandas as pd
import contextlib
from __Debug import log_message

class ExcelHandler:

    def __init__(self, file_path):
        self.file_path = file_path
        self.data = None  # Здесь будет храниться считанная информация из Excel

    def read_excel(self, header_row=0):
        """Чтение Excel файла (.xlsx или .xls)."""
        if str(self.file_path).endswith('.xls'):
            wb = xlrd.open_workbook(self.file_path, logfile=open(os.devnull, 'w'))  # Для .xls используем xlrd
            sheet = wb.sheet_by_index(0)  # Получаем активный лист (первый лист)
            self.data = pd.read_excel(wb, header=header_row)
        else:
            wb = openpyxl.load_workbook(self.file_path)  # Загружаем книгу с помощью openpyxl
            sheet = wb.active  # Получаем активный лист
            self.data = pd.read_excel(self.file_path, engine='openpyxl', header=header_row,
                                      sheet_name=sheet.title)  # Чтение активного листа с указанием строки заголовков
        return self.data

    @staticmethod
    def convert_xls_to_xlsx_pandas(input_file, output_file):
        """Конвертация .xls в .xlsx."""
        df = pd.read_excel(input_file, sheet_name=None)  # Загружаем все листы
        with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
            for sheet, data in df.items():
                data.to_excel(writer, sheet_name=sheet, index=False)

    def convert_xls_to_xlsx(self, output_file):
        """Пересохранение .xls в .xlsx с сохранением картинок и форматирования."""
        app = xw.App(visible=False)  # Открываем Excel в фоновом режиме
        wb = app.books.open(self.file_path)  # Загружаем .xls
        wb.save(output_file)  # Сохраняем как .xlsx
        wb.close()
        app.quit()  # Закрываем Excel

    def remove_empty_rows(df, columns):
        """
        Удаляет строки, в которых есть пустые значения в указанных столбцах.
        :param columns: Список столбцов, которые нужно проверить на пустые значения.
        """
        # Проверка на наличие пустых значений в указанных столбцах и удаление таких строк
        initial_row_count = len(df.data)
        df.data = df.data.dropna(subset=columns)
        final_row_count = len(df.data)

        # Сообщение о том, сколько строк было удалено, только если были удалены строки
        if initial_row_count > final_row_count:
            print(f"Удалено строк: {initial_row_count - final_row_count}, так как в столбцах {columns} пусто")
        return df

    def fill_empty_cells(self, columns, fill_values):
        """
        Проверяет указанные столбцы на наличие пустых значений и, если они есть,
        заполняет их указанными значениями и сообщает об этом.
        :param columns: Список столбцов для проверки на пустые значения.
        :param fill_values: Словарь значений для заполнения пустых ячеек, где ключ — это имя столбца, а значение — что будет вставлено.
        """
        for column in columns:
            if column in fill_values:
                fill_value = fill_values[column]
            else:
                fill_value = "Неизвестный профиль"

            # Проверяем, есть ли в столбце пустые значения
            empty_cells = self.data[column].isna().sum()

            if empty_cells > 0:
                # Сообщаем, сколько пустых ячеек найдено в столбце
                print(f"В столбце '{column}' найдено пустых ячеек: {empty_cells}")

                # Создаем копию столбца, чтобы избежать SettingWithCopyWarning
                self.data.loc[:, column] = self.data[column].fillna(fill_value)

                # Сообщение о заполнении
                print(f"Пустые ячейки в столбце '{column}' были заполнены значением '{fill_value}'")

    def replace_symbols(self, column_name):
        """Замена символов в столбце на основе заданного словаря с дополнительной логикой для '@130'."""
        replacements = {
            '@016': 'Пластина ',
            '@137': 'Полоса ',
            '@140': 'Уголок ',
            '@214': 'Уголок ',
            '@142': 'Двутавр ',
            '@143': 'Швеллер ',
            '@144': 'Швеллер гн ',
            '@146': 'Швеллер гн ',
            '@141': 'Тавр ',
            '@131': 'Труба профильная ',
            '@090': 'Труба ',
            '@218': 'Спаренный швеллер '
        }

        def custom_replace(value):
            if isinstance(value, str):  # Проверка, что значение — строка
                if '@130' in value:
                    return value.replace('@130', 'Труба ' if 'х' in value or 'x' in value else 'Круг ')
                for key, replacement in replacements.items():
                    if key in value:
                        return value.replace(key, replacement)
            return value

        if self.data is not None:
            self.data[column_name] = self.data[column_name].apply(custom_replace)
        else:
            raise ValueError("Данные не загружены. Сначала вызовите read_excel().")

        return self.data

    def restore_symbols(self, column_name):
        """Обратная замена названий профилей на коды вида @xxx."""

        # Обратный словарь: значение → ключ
        replacements = {
            'Пластина ': '@016',
            'Полоса ': '@137',
            'Уголок ': '@140',
            'Двутавр ': '@142',
            'Швеллер гн ': '@144',
            'Швеллер ': '@143',
            'Тавр ': '@141',
            'Труба профильная ': '@131',
            'Круг ': '@130',
            'Труба ': '@090',  # по умолчанию — обычная труба
            'Спаренный швеллер ': '@218',
        }

        def reverse_replace(value):
            if isinstance(value, str):
                for name, code in replacements.items():
                    if value.startswith(name):
                        # Специальная логика для "Труба " и "Круг "
                        if name == 'Труба ' and ('x' not in value and 'х' not in value):
                            return value.replace(name, '@130', 1)
                        elif name == 'Труба ':
                            return value.replace(name, '@090', 1)  # обычная труба
                        elif name == 'Круг ':
                            return value.replace(name, '@130', 1)
                        else:
                            return value.replace(name, code, 1)
            return value

        if self.data is not None:
            self.data[column_name] = self.data[column_name].apply(reverse_replace)
        else:
            raise ValueError("Данные не загружены. Сначала вызовите read_excel().")

        return self.data

    @staticmethod
    def _replace_symbol(value, replacements):
        """Функция для замены символов в значении."""
        if isinstance(value, str):
            for key, replacement in replacements.items():
                if value.startswith(key):
                    return replacement + value[4:]
        return value

    def clean_zeros_in_string(self, value):
        """Метод для очистки нулей в строках чисел"""
        if isinstance(value, str):
            def repl(match):
                whole_part = match.group(1)
                fractional_part = match.group(2).rstrip('0')  # Удаляем нули в конце дробной части
                if not fractional_part:  # Если вся дробная часть состоит из нулей
                    return whole_part
                else:
                    return f'{whole_part},{fractional_part}'

            # Используем регулярное выражение для поиска чисел с дробной частью
            value = re.sub(r'(\d+)[,.](\d+)', repl, value)
            # Убираем запятые/точки перед 'x', например, для '50,00x' и '2,00x'
            value = re.sub(r'(\d+)[,.]00(?=x)', r'\1', value)
        return value

    def clean_zeros_in_columns(self, columns):
        """Метод для применения очистки нулей ко всем указанным столбцам в DataFrame"""
        if self.data is not None:
            for col in columns:
                self.data[col] = self.data[col].apply(self.clean_zeros_in_string)
        else:
            raise ValueError("Данные не загружены. Пожалуйста, загрузите данные с помощью метода load_excel().")
        return self.data

    def clean_data(self):
        """Очистка данных от пустых строк."""
        if self.data is not None:
            self.data = self.data.dropna()
        else:
            raise ValueError("Данные не загружены. Сначала вызовите read_excel().")
        return self.data

    # def line_joining_df(self, compare_columns, sum_columns, concatenate_columns=None, ignore_column=None, ignore_value=None):
    #     """Метод для объединения строк DataFrame по определенным столбцам с суммированием и конкатенацией"""
    #     if self.data is None:
    #         raise ValueError("Нет данных для обработки. Пожалуйста, загрузите данные с помощью метода load_excel().")
    #
    #     df = self.data.copy()  # Копируем DataFrame
    #     original_columns = df.columns.tolist() # Сохраняем исходный порядок столбцов
    #     df = df.where(pd.notnull(df), None) # Приводим пустые значения в сравниваемых столбцах к None
    #
    #     # Отделяем строки с игнорируемыми значениями
    #     if ignore_column and ignore_value:
    #         mask = df[ignore_column].str.contains(ignore_value, na=False)  # Создаем маску для фильтрации
    #         ignore_df = df[mask]  # Строки с игнорируемым значением
    #         # ignore_df = df[df[ignore_column].str.contains(ignore_value, na=False)]
    #         # df = df[~df[ignore_column].str.contains(ignore_value, na=False)]
    #         df = df[~mask]  # Остальные строки
    #     else:
    #         ignore_df = pd.DataFrame()
    #
    #     # Округляем числовые столбцы в compare_columns до 8 знаков после запятой
    #     for col in compare_columns:
    #         # if pd.api.types.is_float_dtype(df[col]):
    #         #     df[col] = df[col].round(8)
    #         if pd.api.types.is_numeric_dtype(df[col]):  # Проверяем, что столбец числовой
    #             df[col] = df[col].round(8)
    #
    #     # Создаем словарь функций агрегации: суммирование для столбцов sum_columns
    #     agg_funcs = {col: 'sum' for col in sum_columns}  # Суммирование по указанным столбцам
    #     # Добавляем логику объединения для столбцов concatenate_columns, если они указаны
    #     if concatenate_columns:
    #         # Для столбцов, которые нужно объединить через запятую, используется join
    #         for col in concatenate_columns:
    #             agg_funcs[col] = lambda x: ', '.join(sorted(set(str(v) for v in x if pd.notna(v))))  # Конкатенация уникальных значений
    #             # agg_funcs[col] = lambda x: '; '.join(sorted(set(str(v) for v in x if pd.notna(v))))  # Конкатенация уникальных значений
    #     # Определяем логику для остальных столбцов: берем первое значение
    #     other_columns = [col for col in df.columns if col not in (compare_columns + sum_columns + (concatenate_columns or []))]
    #     for col in other_columns:
    #         agg_funcs[col] = 'first'
    #
    #     # Группируем DataFrame по столбцам compare_columns с агрегацией
    #     # grouped_df = df.groupby(compare_columns, dropna=False, as_index=False).agg(agg_funcs)
    #     grouped_df = df.groupby(compare_columns, dropna=False, as_index=False).agg(agg_funcs)
    #
    #     # Объединяем строки с игнорируемыми значениями обратно
    #     final_df = pd.concat([grouped_df, ignore_df], ignore_index=True)
    #
    #     # Восстанавливаем исходный порядок столбцов
    #     final_df = final_df[original_columns]
    #
    #     # Обновляем данные в ExcelHandler
    #     self.data = final_df
    #     return self.data

    def line_joining_df(
            self,
            compare_columns,
            sum_columns,
            concatenate_columns=None,
            ignore_column=None,
            ignore_value=None,
            *,
            decimals: int = 8,
            concat_sep: str = ", ",
            concat_unique: bool = True,
            concat_sort_unique: bool = False,
            ignore_regex: bool = False,
            ignore_case: bool = True,
            coerce_numeric_compare: bool = False,
    ):
        """
        Объединяет строки по ключам `compare_columns`, суммируя `sum_columns` и
        конкатенируя `concatenate_columns`. Можно исключить строки по условию:
        `ignore_column`(ы) содержат `ignore_value`(ы) — эти строки не агрегируются,
        а добавляются обратно как есть.

        Параметры:
          compare_columns: последовательность столбцов-ключей для группировки.
          sum_columns: последовательность столбцов для суммирования.
          concatenate_columns: последовательность столбцов для строковой конкатенации.
          ignore_column: строка или последовательность столбцов для фильтра «игнор».
          ignore_value: строка или последовательность значений/шаблонов для поиска.
          decimals: точность округления числовых compare-столбцов.
          concat_sep: разделитель при конкатенации.
          concat_unique: убирать дубликаты при конкатенации.
          concat_sort_unique: сортировать уникальные значения (строковая сортировка).
          ignore_regex: трактовать ignore_value как regex (по умолчанию False).
          ignore_case: регистронезависимый поиск в ignore_column.
          coerce_numeric_compare: пытаться привести compare_columns к числам.

        Возвращает:
          Обновлённый DataFrame и сохраняет его в self.data.
        """
        import pandas as pd

        if self.data is None:
            raise ValueError("Нет данных для обработки. Сначала вызовите load_excel().")

        df = self.data.copy()
        original_columns = df.columns.tolist()

        # ---------- Хелперы ----------
        def _as_list(x):
            """None -> [], str -> [str], итерируемое -> list(...)"""
            if x is None:
                return []
            if isinstance(x, str):
                return [x]
            return list(x)

        def _ensure_cols(cols, where: str):
            missing = [c for c in cols if c not in df.columns]
            if missing:
                raise KeyError(f"Отсутствуют столбцы для {where}: {missing}")

        def _sum_with_nan(s: pd.Series):
            # Возвращает NaN, если все значения NaN (min_count=1 доступно в pandas)
            return s.sum(min_count=1)

        def _concat_unique_preserve_order(values: pd.Series,
                                          sep: str = ", ",
                                          unique: bool = True,
                                          sort_unique: bool = False) -> str:
            vals = values.dropna().astype(str)
            if unique:
                seen = pd.unique(vals)
                if sort_unique:
                    seen = sorted(seen)
                vals = pd.Series(seen)
            return sep.join(vals.tolist())

        def _looks_like_path(text: str) -> bool:
            """Грубая, но практичная эвристика определения путей (Windows/Unix/UNC/относительные)."""
            if not text or not isinstance(text, str):
                return False
            s = text.strip()

            # Признаки путей:
            # 1) Windows-диск: C:\... или C:/...
            if re.match(r"^[A-Za-z]:[\\/]", s):
                return True
            # 2) UNC-путь: \\server\share\...
            if s.startswith("\\\\"):
                return True
            # 3) Абсолютные/домашние/относительные unix: /..., ./..., ../..., ~/...
            if s.startswith(("/", "./", "../", "~/")):
                return True
            # 4) Наличие разделителя каталога и «похоже на имя файла» с расширением
            if ("/" in s or "\\" in s) and re.search(r"\.[A-Za-z0-9]{1,6}$", s):
                return True
            return False

        def _pick_sep_for_series(values: pd.Series, default_sep: str = ", ") -> str:
            """Если среди значений есть пути – используем '; ', иначе default_sep."""
            # .dropna() чтобы не анализировать NaN
            vals = values.dropna().astype(str)
            for v in vals:
                if _looks_like_path(v):
                    return "; "
            return default_sep

        # ---------- Нормализация аргументов ----------
        compare_columns = _as_list(compare_columns)
        sum_columns = _as_list(sum_columns)
        concatenate_columns = _as_list(concatenate_columns)
        ignore_columns = _as_list(ignore_column)
        ignore_values = _as_list(ignore_value)

        # ---------- Валидация ----------
        _ensure_cols(compare_columns, "compare_columns")
        _ensure_cols(sum_columns, "sum_columns")
        if concatenate_columns:
            _ensure_cols(concatenate_columns, "concatenate_columns")
        if ignore_columns:
            _ensure_cols(ignore_columns, "ignore_column")

        # ---------- Фильтр игнорируемых строк ----------
        if ignore_columns and ignore_values:
            # Если ignore_value одно — применяем ко всем столбцам
            if len(ignore_values) == 1:
                ignore_values = ignore_values * len(ignore_columns)
            elif len(ignore_values) != len(ignore_columns):
                raise ValueError(
                    "Количество ignore_value должно быть 1 или совпадать с количеством ignore_column."
                )

            mask = pd.Series(False, index=df.index)
            for col, val in zip(ignore_columns, ignore_values):
                ser = df[col].astype(str)
                needle = str(val)
                if ignore_case:
                    ser = ser.str.lower()
                    needle = needle.lower()
                mask = mask | ser.str.contains(needle, na=False, regex=ignore_regex)

            ignore_df = df[mask]
            df = df[~mask]
        else:
            ignore_df = pd.DataFrame(columns=df.columns)

        # ---------- Округление/приведение compare_columns ----------
        for col in compare_columns:
            if coerce_numeric_compare:
                df[col] = pd.to_numeric(df[col], errors="ignore")
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].round(decimals)

        # ---------- Подготовка агрегаций ----------
        agg_funcs = {}

        # Суммирование с сохранением NaN если все пропуски
        for col in sum_columns:
            if not pd.api.types.is_numeric_dtype(df[col]):
                df[col] = pd.to_numeric(df[col], errors="coerce")
            agg_funcs[col] = _sum_with_nan

        # Конкатенация c динамическим выбором разделителя для каждого столбца
        for col in concatenate_columns:
            agg_funcs[col] = (
                lambda s, uniq=concat_unique, srt=concat_sort_unique, default_sep=concat_sep:
                _concat_unique_preserve_order(
                    s,
                    sep=_pick_sep_for_series(s, default_sep=default_sep),
                    unique=uniq,
                    sort_unique=srt
                )
            )

        # Остальные столбцы: берём первое значение
        key_cols = set(compare_columns) | set(sum_columns) | set(concatenate_columns)
        other_columns = [c for c in df.columns if c not in key_cols]
        for col in other_columns:
            agg_funcs[col] = "first"

        # ---------- Группировка и агрегация ----------
        grouped_df = (
            df.groupby(compare_columns, dropna=False, as_index=False)
            .agg(agg_funcs)
        )

        # ---------- Склейка игнорированных строк и восстановление порядка ----------
        final_df = (
            pd.concat([grouped_df, ignore_df], ignore_index=True)
            if not ignore_df.empty else grouped_df
        )

        # Восстановить исходный порядок столбцов, сохранив новые (если вдруг появились)
        existing_original = [c for c in original_columns if c in final_df.columns]
        final_df = final_df[existing_original + [c for c in final_df.columns if c not in existing_original]]

        self.data = final_df
        return self.data

    def sort_cell_values(self, cell):
        """Сортировка уникальных значений в ячейке."""
        try:
            # Удаляем пробелы и разбиваем строки по разделителю ',' или ';'
            unique_values = set(value.strip() for value in cell.replace(';', ',').split(','))
            # Сортируем значения по возрастанию
            sorted_values = sorted(unique_values, key=lambda x: (x.split('-')[0], x))
            return ', '.join(sorted_values)  # Возвращаем отсортированные значения через ', '
        except Exception as e:
            print(f"Ошибка при обработке значения: {cell}. Ошибка: {e}")
            return cell  # Возвращаем исходное значение в случае ошибки

    def save_to_excel(self, save_path):
        """Сохранение данных в Excel файл."""
        if self.data is not None:
            self.data.to_excel(save_path, index=False, logfile=open(os.devnull, 'w'))
        else:
            raise ValueError("Нет данных для сохранения.")

    @staticmethod
    def auto_dimensions(ws):
        """Автоматическая настройка ширины столбцов на основе их содержимого"""
        dims = {}
        for row in ws.rows:
            for cell in row:
                if cell.value:
                    dims[cell.column_letter] = max((dims.get(cell.column_letter, 0), len(str(cell.value))))
        for col, value in dims.items():
            ws.column_dimensions[col].width = value + 2
        return ws

    @staticmethod
    def fix_dimensions(ws, column, width):
        """Фиксированная ширина столбцов на основе их содержимого"""
        for i in column:
            column_letter = i
            desired_width = width  # Задаем желаемую ширину столбца в пикселях
            column = ws.column_dimensions[column_letter]  # Получаем объект столбца
            column.width = desired_width  # Устанавливаем ширину столбца
        return ws

    @staticmethod
    def check_empty_rows_in_cell_column(ws, start_row, ignore_column):
        """Проверка пустых ячеек в строке"""
        # Итерируемся по строкам, начиная со start_row

        for row in ws.iter_rows(min_row=start_row):
            for i, cell in enumerate(row):
                column_letter = get_column_letter(i + 1)  # Проверяем, не является ли столбец A, B или У
                if column_letter in (ignore_column):
                    continue

                if cell.value is None:
                    log_message(f"!!!Элемент {row[1].value} с пустыми данными в строке {cell.row} в столбце '{column_letter}'!!!", 'warn')
                    cell.fill = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')
        return ws

    @staticmethod
    def compare_columns(ws, col1, *compare_cols):
        """
        Сравнивает значения в первом столбце и проверяет соответствие значений в других столбцах.
        Если значения в col1 совпадают, но значения в других столбцах отличаются, выделяет ячейки красным.

        :param ws: Лист Excel для проверки
        :param col1: Первый столбец для сравнения (буква столбца)
        :param compare_cols: Другие столбцы для сравнения (буквы столбцов)
        """
        # Задаем красный цвет для выделения ячеек с различиями
        red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
        # Словарь для хранения строк по значениям столбца 1
        col1_values = {}

        # Идем по каждой строке начиная со второй (предполагаем, что в первой заголовки)
        for row in range(2, ws.max_row + 1):
            cell1_value = ws[f"{col1}{row}"].value

            if cell1_value is None:  # Пропускаем строки с пустыми значениями
                continue

            # Если значение уже встречалось, проверяем другие столбцы
            if cell1_value in col1_values:
                row_to_compare = col1_values[cell1_value]  # Получаем строку для сравнения
                mismatch_found = False  # Флаг несоответствия

                for col in compare_cols:
                    current_cell = ws[f"{col}{row}"]
                    compare_cell = ws[f"{col}{row_to_compare}"]

                    # Если значения отличаются, выделяем ячейки
                    if current_cell.value != compare_cell.value:
                        current_cell.fill = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')
                        compare_cell.fill = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')

                        mismatch_found = True

                if mismatch_found:
                    log_message(
                        f"\n!!!Найдены одинаковые значения в строке {row_to_compare + 0} и строке {row + 0}, но значения в столбцах отличаются!!!\nСледует запустить OiSMK и выгрузить отчёт повтроно", "error")

            else:
                # Сохраняем строку, если значение встречается впервые
                col1_values[cell1_value] = row
        return ws

    @staticmethod
    def format_columns(ws, columns, n, start_row=1):
        """Формат ячейки с округлением до n знаков после запятой"""
        # Определение формата чисел
        if n > 0:
            format_string = f'0.{"0" * n}'  # Форматирование до n знаков после запятой
        else:
            format_string = '0'  # Форматирование без десятичных знаков

        style = NamedStyle(name='number_format', number_format=format_string)

        # Применение стиля ко всем ячейкам в указанных столбцах, начиная с start_row
        for column_letter in columns:
            for row in range(start_row, ws.max_row + 1):
                cell = ws[f'{column_letter}{row}']
                cell.style = style
        return ws

    def reorder_columns_with_images_fixed_size(ws, new_ws, new_order):
        """
        Переставляет столбцы с учетом изображений, авто настраивает ширину первых 5 столбцов, фиксирует ширину 6-го столбца.
        """
        # Определение стилей границ
        thin_border = Border(left=Side(style='thin'),
                             right=Side(style='thin'),
                             top=Side(style='thin'),
                             bottom=Side(style='thin'))
        # Копируем данные в новом порядке, смещая все строки на одну вниз
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
            for new_col_idx, old_col_idx in enumerate(new_order, start=1):
                cell = row[old_col_idx - 1]  # Получаем старую ячейку
                new_cell = new_ws.cell(row=cell.row + 1, column=new_col_idx)  # Смещаем вставку на одну строку вниз
                value = cell.value

                # Проверка и преобразование значений в числовой формат для столбцов C и E
                if new_col_idx in [3, 5]:  # Столбцы C (3) и E (5)
                    try:
                        new_cell.value = float(value)  # Преобразование значения в число
                    except (ValueError, TypeError):
                        new_cell.value = value  # Оставляем значение как есть, если не удается преобразовать
                else:
                    new_cell.value = value  # Копируем значение

                # Добавляем границы
                new_cell.border = thin_border

                # Установка выравнивания
                if new_col_idx in [1, 3, 4, 5]:  # Столбцы C (3) и E (5)
                    new_cell.alignment = Alignment(horizontal='center', vertical='center')
                else:
                    new_cell.alignment = Alignment(vertical='center')

                # Если в старой ячейке было изображение, копируем его
                for image in ws._images:
                    if image.anchor._from.row == cell.row - 1 and image.anchor._from.col == old_col_idx - 1:
                        new_image = Image(image.ref)  # Создаем изображение для вставки
                        new_ws.add_image(new_image, new_ws.cell(row=cell.row + 1, column=new_col_idx).coordinate)
                        print(new_ws)
            return new_ws

    # Функция смещает все картинки в xlsx на n пунктов
    def adjust_image_position(file_path, shift_X, shift_Y):
        # Открываем книгу
        app = xw.App(visible=False)  # Не показывать Excel
        wb = app.books.open(file_path)
        sheet = wb.sheets.active

        # Выбираем картинку на листе
        for picture in sheet.pictures:
            # Сдвигаем картинку на 1.5 пункта вниз и вправо
            picture.top += shift_Y
            picture.left += shift_X
        # Сохраняем изменения
        wb.save()
        wb.close()
        app.quit()

if __name__ == "__main__":
    file_path = 'C:\\Users\\ik\\Desktop\\02 _ CAD\\Материалы\\Спецификация металлопроката.xls'
    excel_handler = ExcelHandler(file_path)
    data = excel_handler.read_excel()
    print(data)