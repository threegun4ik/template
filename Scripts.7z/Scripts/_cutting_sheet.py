import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path
from __ExcelHandler import ExcelHandler
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from _Config import *
from __Debug import *

if 'SHEET_WIDTH' not in globals():
    SHEET_WIDTH = 1500
    SHEET_HEIGHT = 3000
    TOOL_GAP = 1  # # Зазор (толщина режущего инструмента) в мм


def visualize_sheets(plates, width=SHEET_WIDTH, height=SHEET_HEIGHT):
    used_sheets = []
    visuals = []

    current_sheet = []
    current_y = 0
    row = []
    row_height = 0
    row_x = 0

    for plate in plates:
        placed = False
        w, h = plate['Ширина, мм'], plate['Длина, мм']
        for (pw, ph) in [(w, h), (h, w)]:
            gap_x = TOOL_GAP if row else 0
            if pw + gap_x <= width - row_x:
                row.append((pw, ph))
                visuals.append((len(used_sheets), row_x + gap_x, current_y, pw, ph))  # сохраняем координаты
                row_x += pw + (TOOL_GAP if row_x > 0 else 0)
                row_height = max(row_height, ph)
                placed = True
                break

        if not placed:
            gap_y = TOOL_GAP if current_y > 0 else 0
            if current_y + row_height + gap_y <= height:
                current_sheet.extend(row)
                current_y += row_height + gap_y
                row = []
                row_x = 0
                row_height = 0
                for (pw, ph) in [(w, h), (h, w)]:
                    if pw <= width and ph <= height - current_y:
                        row.append((pw, ph))
                        visuals.append((len(used_sheets), 0, current_y, pw, ph))
                        row_x = pw
                        row_height = ph
                        placed = True
                        break

        if not placed:
            if row:
                current_sheet.extend(row)
            used_sheets.append(current_sheet)
            current_sheet = []
            current_y = 0
            row = []
            row_x = 0
            row_height = 0
            for (pw, ph) in [(w, h), (h, w)]:
                if pw <= width and ph <= height:
                    row.append((pw, ph))
                    visuals.append((len(used_sheets), 0, 0, pw, ph))
                    row_x = pw
                    row_height = ph
                    placed = True
                    break

    if row:
        current_sheet.extend(row)
    if current_sheet:
        used_sheets.append(current_sheet)

    # Визуализация
    num_sheets = len(used_sheets)
    fig, axes = plt.subplots(1, num_sheets, figsize=(6 * num_sheets, 8))
    if num_sheets == 1:
        axes = [axes]

    for i, ax in enumerate(axes):
        ax.set_title(f"Лист {i+1}")
        ax.set_xlim(0, width)
        ax.set_ylim(0, height)
        ax.set_aspect('equal')
        ax.invert_yaxis()  # чтобы ноль был в верхнем левом углу
        ax.set_xticks(range(0, width + 1, 500))
        ax.set_yticks(range(0, height + 1, 500))
        ax.grid(True, linestyle="--", alpha=0.5)

        for sid, x, y, w, h in visuals:
            if sid == i:
                rect = patches.Rectangle((x, y), w, h, linewidth=1, edgecolor='black', facecolor='lightblue')
                ax.add_patch(rect)
                ax.text(x + w/2, y + h/2, f"{int(w)}x{int(h)}", fontsize=8, ha='center', va='center')

    plt.tight_layout()
    plt.show()

def try_place_plates(plates, width=SHEET_WIDTH, height=SHEET_HEIGHT):
    used_sheets = []

    current_sheet = []
    current_y = 0  # текущая высота листа
    row = []
    row_height = 0
    row_x = 0

    for plate in plates:
        placed = False
        w, h = plate['Ширина, мм'], plate['Длина, мм']
        # Пробуем разместить в текущем ряду с учётом поворота
        for (pw, ph) in [(w, h), (h, w)]:
            gap_x = TOOL_GAP if row else 0
            if pw + gap_x <= width - row_x:
                row.append((pw, ph))
                row_x += pw + (TOOL_GAP if row_x > 0 else 0)
                row_height = max(row_height, ph)
                placed = True
                break

        if not placed:
            # Завершаем текущий ряд, проверим по высоте
            gap_y = TOOL_GAP if current_y > 0 else 0
            if current_y + row_height + gap_y <= height:
                current_sheet.extend(row)
                current_y += row_height + gap_y
                row = []
                row_x = 0
                row_height = 0

                # Попробуем снова разместить текущую пластину
                for (pw, ph) in [(w, h), (h, w)]:
                    if pw <= width and ph <= height - current_y:
                        row.append((pw, ph))
                        row_x = pw
                        row_height = ph
                        placed = True
                        break

        if not placed:
            # Текущая пластина не влезает — новый лист
            if row:
                current_sheet.extend(row)
            used_sheets.append(current_sheet)
            current_sheet = []
            current_y = 0
            row = []
            row_x = 0
            row_height = 0
            for (pw, ph) in [(w, h), (h, w)]:
                if pw <= width and ph <= height:
                    row.append((pw, ph))
                    row_x = pw
                    row_height = ph
                    placed = True
                    break

    # Завершаем последний лист
    if row:
        current_sheet.extend(row)
    if current_sheet:
        used_sheets.append(current_sheet)

    # Подсчёт высоты каждого листа
    sheet_sizes = []
    for sheet in used_sheets:
        rows = []
        row = []
        row_w = 0
        row_h = 0
        for pw, ph in sheet:
            gap_x = TOOL_GAP if row_w > 0 else 0
            if row_w + pw + gap_x <= width:
                row.append((pw, ph))
                row_w += pw + gap_x
                row_h = max(row_h, ph)
            else:
                rows.append(row_h)
                row = [(pw, ph)]
                row_w = pw
                row_h = ph
        if row:
            rows.append(row_h)
        total_height = sum(rows) + TOOL_GAP * (len(rows) - 1 if len(rows) > 1 else 0)
        sheet_sizes.append((width, total_height))

    return sheet_sizes

def cutting_sheet(path, df=None):

    results = []
    if not df:
        xlsx = Path(path) / '1.2 _ Ведомость элементов.xlsx'
        df = pd.read_excel(xlsx, sheet_name='Ведомость элементов', engine='openpyxl', header=1)

    target_path = Path(xlsx).parent / '1.5 _ Требуемый прокат.xlsx'

    if df is None or df.empty or not target_path.exists():
        return

    for (thickness, steel, riffle), group in df.groupby(["Толщина, мм", "Марка стали", "Рифление"]):
        expanded = []
        for _, row in group.iterrows():
            for _ in range(int(row["Кол-во, шт."])):
                expanded.append({'Ширина, мм': row['Ширина, мм'], 'Длина, мм': row['Длина, мм']})

        sheets = try_place_plates(expanded)
        sheet_counts = {}
        for w, h in sheets:
            size = f"{w}x{h}"
            sheet_counts[size] = sheet_counts.get(size, 0) + 1
        for size, count in sheet_counts.items():
            results.append({
                "Толщина, мм": thickness,
                "Марка стали": steel,
                "Рифление": riffle,
                "Размер листа, мм": size,
                "Кол-во листов": count
            })


    wb = load_workbook(target_path)
    ws = wb.active
    next_row = ws.max_row + 1  # Найдём первую пустую строку (после последней заполненной)

    # Заполняем строки из result_df
    result_df = pd.DataFrame(results)
    for i, row in result_df.iterrows():
        num_cell = next_row + i

        # Форматирование толщины
        thickness = row['Толщина, мм']
        if thickness == int(thickness):
            thickness_str = str(int(thickness))
        else:
            thickness_str = str(thickness).replace('.', ',')

        # Обработка размеров листа
        w_str, h_str = row['Размер листа, мм'].split('x')
        w_int = int(float(w_str))
        h_int = int(float(h_str))
        h_int_rounded = int(h_int) if h_int == int(h_int) else int(h_int) + 1
        size_str = f"{w_int}x{h_int_rounded}"

        # Собираем имя профиля
        profile_name = f"Лист {thickness_str}x{size_str}" + \
                       (" рифленая" if row["Рифление"] == 1 else "") + \
                       f" {row['Марка стали']}"

        count = row["Кол-во листов"]
        ws.cell(row=num_cell, column=1).value = num_cell - 2  # "№"
        ws.cell(row=num_cell, column=2).value = profile_name  # "Наименование профиля"
        ws.cell(row=num_cell, column=4).value = count  # "Кол-во, шт."
        ws.cell(row=num_cell, column=6).value = f'=CONCATENATE(A{num_cell}, ") ", B{num_cell}, " - ", D{num_cell}, " шт.")'

    # Различные варианты выравнивания для разных столбцов
    alignment_map = {letter: Alignment(horizontal='center', vertical='center') for letter in 'ACDE'}

    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем с 3 строки, чтобы пропустить заголовки
        for cell in row:
            # Получаем букву столбца по номеру
            column_letter = get_column_letter(cell.column)

            # Применяем выравнивание, если столбец есть в маппинге
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    wb.save(target_path)

    # visualize_sheets(expanded) #Визуализация для проверки
    log_message(f"Добавили в ведомость требуемого проката пластины")

    return results

if __name__ == "__main__":
    xlsx = r"C:\Users\ik\Desktop\КМД\20250220-КМ _ Здание\01 _ CAD\Материалы"
    # df = pd.read_excel(xlsx, sheet_name='Пластины', engine='openpyxl', header=1)


    # # Сохраняем в Excel
    #
    # result_df.to_excel(r"C:\Users\ik\Desktop\КМД\20250220-КМ _ Здание\01 _ CAD\Материалы\размещение_листов.xlsx", index=False)
    # print(result_df)

    # Путь к файлу, куда нужно добавить данные
    # xlsx = r"C:\Users\ik\Desktop\КМД\20250220-КМ _ Здание\01 _ CAD\Материалы\1.5 _ Требуемый прокат.xlsx"
    cutting_sheet(xlsx)