import sys, easygui
from pathlib import Path
from traceback import format_exc
from __Kompas import *

def m3d_to_i3d(filename_m3d, filename_i3d, format_cnc, KompasObject, iApplication):
    """Экспорт m3d в stp или igs"""
    filename_m3d = str(filename_m3d)  # Убедимся, что передан путь в виде строки
    iDocuments = iApplication.Documents
    iKompasDocument, opened = iDocuments.Item(filename_m3d), True  # Проверяем, открыт ли документ

    try:
        if not iKompasDocument:
            iKompasDocument = iDocuments.Open(filename_m3d, True, True)
            opened = False  # Документ был открыт в этом скрипте

        # Экспорт в нужный формат
        iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
        iDocument3D = KompasObject.TransferInterface(iKompasDocument3D, 1, 0)
        format_dict = {'stp': 214, 'igs': 4}
        if format_cnc in format_dict:
            iAdditionFormatParam = iDocument3D.AdditionFormatParam()
            iAdditionFormatParam.Init()
            iAdditionFormatParam.format = format_dict[format_cnc]
            iDocument3D.SaveAsToAdditionFormat(filename_i3d, iAdditionFormatParam)

    except:
        log_message(f'Ошибка в m3d_to_i3d: не удалось открыть файл \nfilename_m3d: {filename_m3d} \nfilename_m3d: {filename_i3d}', 'error')
        log_message(f'Код ошибки {format_exc()}', '"warn" ')
    finally:
        if not opened and iKompasDocument:
            iKompasDocument.Close(1)  # Закрываем только если открывали в этом скрипте
        return True

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)

    filename_m3d = None
    # filename_m3d = easygui.fileopenbox(msg="Укажите файл модели m3d", title="", default=f"{path}/*.m3d")
    filename_m3d = r'C:\Users\ik\Desktop\!2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\!01 _ CAD\part\Пластины\2027.m3d'
    if filename_m3d:
        folder_i3d = Path(filename_m3d).parent
        format_cnc = 'igs'

        file_name_without_extension = Path(filename_m3d).stem
        filename_i3d = Path(folder_i3d) / format_cnc / (file_name_without_extension + '.' + format_cnc)

        filename_i3d.parent.mkdir(parents=True, exist_ok=True)  # Создаем папку, если не существует
        m3d_to_i3d(filename_m3d, filename_i3d, format_cnc)
    else:
        print('debug')
        iKompasDocument = iApplication.ActiveDocument
        filename_m3d = iKompasDocument.PathName #Полный путь до файла
        # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
        folder_i3d = Path(filename_m3d).parent
        format_cnc = 'igs'
        file_name_without_extension = Path(filename_m3d).stem
        filename_i3d = Path(folder_i3d) / format_cnc / (file_name_without_extension + '.' + format_cnc)
        filename_i3d.parent.mkdir(parents=True, exist_ok=True)  # Создаем папку, если не существует
        m3d_to_i3d(filename_m3d, filename_i3d, format_cnc)
