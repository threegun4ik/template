import os, easygui
from pathlib import Path

from __ExcelHandler import ExcelHandler
from __Kompas import *

import openpyxl
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

'''1.5 _ Требуемый прокат.xlsx после RealCut'''

###Требуемый прокат (Статистика)
def sheet1_5(xls, code_project=""):
    log_message(f"Подготавливаю ведомость требуемого проката без учета пластин", 'title')

    xlsx = Path(xls).parent / '1.5 _ Требуемый прокат.xlsx'
    # df = read_excel_file(xls, 1)
    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
    df = excel_handler.read_excel(1)  # Читаем таблицу в dataframe

    df = df.drop(['Высота', 'Цена'], axis=1)  # Удалим ненужные столбцы
    df = df[['#', 'Материалы', 'длина', 'Количество', 'Метка', 'Приоритет']]  # Отсортируем таблицу

    df.to_excel(xlsx, sheet_name="Прокат", index=False)  # Создадим файл отчета и запишем данные в него

    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Прокат']  # Выбираем лист по имени

    ###Название таблицы
    ws.insert_rows(1)  # Вставим строку
    ws["A1"] = f'{code_project} .Ведомость требуемого проката'

    ws["A2"] = "№"
    ws["B2"] = "Наименование профиля"
    ws["C2"] = "Длина хлыста, мм"
    ws["D2"] = "Кол-во, шт."
    ws["E2"] = "Итого, м.п."
    ws["F2"] = "Примечание"

    for row in range(3, ws.max_row + 1):
        ws["F" + str(row)] = f'=CONCATENATE(A{row}, ") ", B{row}, " - ", E{row}, " м.п.(по ", C{row}/1000, "м)")'  # Наименование элемента с маркой стали формулой
        ws["E" + str(row)] = f'=C{row}*D{row}/1000'

    # Различные варианты выравнивания для разных столбцов
    alignment_map = {letter: Alignment(horizontal='center', vertical='center') for letter in 'ACDE'}

    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем с 3 строки, чтобы пропустить заголовки
        for cell in row:
            # Получаем букву столбца по номеру
            column_letter = get_column_letter(cell.column)

            # Применяем выравнивание, если столбец есть в маппинге
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

    # Включим перенос текста по словам и выравнивание по центру для ячеек во второй строке
    for cell in ws[2]:  # Итерируем по ячейкам во второй строке
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов
    excel_handler.fix_dimensions(ws, ['A'], width=6)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['B'], width=30)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['C', 'D', 'E'], width=10)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['F'], width=50)  # Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 20  # Измените высоту первой строки
    ws.row_dimensions[2].height = 45  # Измените высоту второй строки

    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)  # Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = openpyxl.styles.Alignment(horizontal='left', vertical='center')

    ws.auto_filter.ref = 'A2:{}'.format(openpyxl.utils.get_column_letter(ws.max_column) + '2')  # Автофильтр на вторую строку

    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()

    log_message(f'Ведомость требуемого проката без учета пластин - создана', 'ok')
    os.remove(xls)


if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xlsx = easygui.fileopenbox(msg="Укажите файл Статистика... после RealCut", title="",
                               default=f"{path}/*Статистика*.xlsx")
    sheet1_5(xlsx)
    input('\n\rРабота завершена.	\n')
