from pathlib import Path
from __Kompas import *
import pyperclip, re
import _Config
import pandas as pd
from CNC_2d_for_all import dxf_for_all

'''Создает dxf или step для активной модели и сохраняет ее в ту же папку где сохранен и файл-родитель'''

title = 'Создание dxf для активной пластины'
print(title + '\n')
KompasObject, iApplication, KompasVersion = get_kompas()
#  Получи интерфейс активного документа
iKompasDocument = iApplication.ActiveDocument
kompas_document_3d = API7.IKompasDocument3D(iKompasDocument)
iPart7 = kompas_document_3d.TopPart

# #Получаем свойства детали
filename = iPart7.FileName
marking = iPart7.Marking
# material = iPart7.Material
name = iPart7.Name
#Подготовим имя файла для сохранения без расширения
path = iKompasDocument.Path #Путь до файла без имени и расширения
pathname = iKompasDocument.PathName #Полное имя файла документа, состоящее из пути, имени и расширения файла

iPropertyKeeper = API7.IPropertyKeeper(iPart7)

FilePart = iPart7.FileName
iDocuments = iApplication.Documents
iDocSb = iDocuments.Item(FilePart)
iPropertyMng = API7.IPropertyMng(iApplication)


iProperty_Gn = iPropertyMng.GetProperty(iDocSb, 187523792346.0)
iProperty_Rif = iPropertyMng.GetProperty(iDocSb, 253729100882.0)
iProperty_t = iPropertyMng.GetProperty(iDocSb, 226778862707.0)
iProperty_b = iPropertyMng.GetProperty(iDocSb, 334229340093.0)
iProperty_h = iPropertyMng.GetProperty(iDocSb, 235833998283.0)
iProperty_material = iPropertyMng.GetProperty(iDocSb, 290108629069.0) # Марка материала (стали)

gn = int(iPropertyKeeper.GetPropertyValue(iProperty_Gn, 0, True, 0)[1])
rif = int(iPropertyKeeper.GetPropertyValue(iProperty_Rif, 0, True, 0)[1])
t = (iPropertyKeeper.GetPropertyValue(iProperty_t, 0, True, 0)[1])*1000
b = int((iPropertyKeeper.GetPropertyValue(iProperty_b, 0, True, 0)[1])*1000)
h = int((iPropertyKeeper.GetPropertyValue(iProperty_h, 0, True, 0)[1])*1000)

material = (iPropertyKeeper.GetPropertyValue(iProperty_material, 0, True, 0)[1])

h_font = (b*1000)//5
#Проверка актуальности обозначения по имени файла
# if marking != Path(filename).stem:
if marking != re.match(r"^[\w-]+", Path(filename).stem).group(0):
	input("Запусти ОиСМК")
else:
	print("ok - сохраняем!")
	num = input("Введите необходимое количство пластин:")
	# num = "1"
	# 1991_С235(рифлёная_гнутая)_4мм_1шт
	if gn == 1 & rif == 1:
		forma = "(рифленая_гнутая)_"
	elif gn == 1:
		forma = "(гнутая)_"
	elif rif == 1:
		forma = "(рифленая)_"
	else:
		forma = ""

	file_name_save = f'{marking}_{str(t).replace('.', ',')}мм_{material}_{forma}{num}шт'
	# name_tab = marking + "_" + name + " " + material + " - " + num + " шт."
	# name_tab = marking + " _ " + str(t).replace('.', ',') + "x" + str(b) + "x" + str(h) + forma + "_" + material + " - " + num + " шт."
	name_tab = f'{marking} _ {str(t).replace('.', ',')}x{str(b)}x{str(h)}{forma}_{material} - {num} шт.'
	# df_name = "Пластина " + str(t).replace('.', ',') + "x" + str(b) + " " + material
	df_name = f'Пластина {str(t).replace('.', ',')}x{str(b)} {material}'


	# Проверяем, существует ли df и не является ли он пустым

	df = pd.DataFrame(columns=[
		"№", "№ элемента", "Наименование", "Кол-во, шт.", "Наоборот", "Марка стали", "Толщина, мм",
		"Ширина, мм", "Длина, мм", "Рифление", "Гнутость", "Гнутые и рифленые", "Масса элемента, кг",
		"Масса элементов, кг", "Элемент марки", "Тип объекта", "Эскиз сечения", "Примечание",
		"Полное имя файла", "Наименование для почты", "Наименование для dxf"
	])

	# Данные новой строки
	new_row = {
		"№": 1, "№ элемента": marking, "Наименование": df_name, "Кол-во, шт.": num, "Марка стали": material,
		"Толщина, мм": t, "Ширина, мм": b, "Длина, мм": h, "Рифление": rif, "Гнутость": gn, "Гнутые и рифленые": forma,
		"Тип объекта": "Деталь", "Эскиз сечения": "@016", "Полное имя файла": filename,
		"Наименование для почты": name_tab, "Наименование для dxf": file_name_save
	}


	# Удаляем None-значения (если есть)
	new_row = {k: v for k, v in new_row.items() if v is not None}

	# Если df пустой или состоит только из NaN, заменяем его на новую строку, иначе добавляем строку через concat
	if df.isna().all().all():
		df = pd.DataFrame([new_row])  # Создаем новый DataFrame
	else:
		df = pd.concat([df.loc[:, df.columns.notna()], pd.DataFrame([new_row])], ignore_index=True)
	print(df['Полное имя файла'].iloc[0])
	# print(df.iloc[0])

	# iApplication.HideMessage = con0.ksHideMessageYes  # если потребуется гасить диалоги, то раскомментарить

	# iApplication.HideMessage = con0.ksShowMessage
	# Записываем наименование для отправки в буфер обмена
	pyperclip.copy("1) " + name_tab)
	dxf_for_all(df, _Config.format_cnc)
	print("Информация по данной пластине записана в буфер обмена")
	print(name_tab)
	input(f'\rРабота завершена.{" " * 4}\n')