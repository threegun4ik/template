# attach_drawings_by_association.py
# -*- coding: utf-8 -*-
import sys, os, easygui
from pathlib import Path
import unicodedata as _ud
from _Config import path_to_scripts

from __Kompas import *
from __Debug import *

# Какие документы считаем "чертежами"
DRAWING_EXTS = (".cdw",)#, ".spw")

# Путь по умолчанию к стилям спецификации/отчёта (.lyt),
DEFAULT_LAYOUT_STYLE_PATH = str(Path(path_to_scripts) / "Template" / "Drawing_specification_styles.lyt")

_restored_styles_log: list[tuple[str, int, str, str]] = []

# -------------- утилиты --------------
def _norm_win(p: str) -> str:
    return os.path.normpath(str(p))

def _restore_layout_styles(kompas_document, fallback_lyt: str) -> list[tuple[int, str, str]]:
    """
    Проверяет все листы документа и, если у листа отсутствует валидный LayoutLibraryFileName,
    прописывает fallback_lyt и делает Update().

    Возвращает список кортежей (sheet_index, old_style, new_style) для всех исправленных листов.
    """
    fixed_details: list[tuple[int, str, str]] = []
    try:
        layout_sheets = getattr(kompas_document, "LayoutSheets", None)
        if not layout_sheets:
            return []

        cnt = int(getattr(layout_sheets, "Count", 0) or 0)
        for i in range(cnt):
            try:
                layout_sheet = layout_sheets.Item(i)
            except Exception:
                continue

            try:
                current = getattr(layout_sheet, "LayoutLibraryFileName", None)
            except Exception:
                current = None

            need_fix = (not current) or (not os.path.isfile(current))
            if need_fix and os.path.isfile(fallback_lyt):
                try:
                    layout_sheet.LayoutLibraryFileName = fallback_lyt
                    try:
                        layout_sheet.Update()
                    except Exception:
                        pass
                    fixed_details.append((i, current or "", fallback_lyt))
                except Exception:
                    pass
    except Exception:
        pass
    return fixed_details

def _same_path(a: str, b: str) -> bool:
    return os.path.normpath(str(a)).casefold() == os.path.normpath(str(b)).casefold()

def _nfc(s: str) -> str:
    return _ud.normalize('NFC', s or '')

def _key(p: str) -> str:
    return _nfc(_norm_win(p)).casefold()

def _open_doc(iApplication, path: str, *, visible=False, read_only=False):
    iDocuments = iApplication.Documents
    try:
        return iDocuments.Open(path, visible, read_only)
    except Exception:
        # fallback — если флаги не поддерживаются в текущей версии
        return iDocuments.Open(path)

def _close_doc_quiet(doc):
    try:
        if doc:
            doc.Close(1)  # 1=без вопросов, сохранить если нужно
    except Exception:
        pass

def _resolve_model_path_from_drawing(doc_obj, drawing_path: str, src: str) -> str:
    """
    Делает абсолютный путь к модели из SourceFileName.
    Если src относительный — резолвит относительно папки чертежа / PathName документа.
    """
    src = _norm_win(src)
    if os.path.isabs(src):
        return src
    # попробуем отталкиваться от PathName документа (иногда точнее)
    base_dir = None
    try:
        base_dir = str(Path(getattr(doc_obj, "PathName", drawing_path)).parent)
    except Exception:
        pass
    if not base_dir:
        base_dir = str(Path(drawing_path).parent)
    return _norm_win(str(Path(base_dir) / src))

def _attach_to_document(iKompasDocument, attach_paths: list[str]) -> int:
    """Прикрепляет attach_paths к 'Связным документам' ИМЕННО ЭТОГО открытого документа."""
    if not iKompasDocument or not attach_paths:
        return 0

    pdm = API7.IProductDataManager(iKompasDocument)  # per-document
    pk  = API7.IPropertyKeeper(iKompasDocument)

    current = tuple(pdm.ObjectAttachedDocuments(pk) or ())
    norm = lambda x: os.path.normcase(os.path.normpath(str(x)))

    seen = {norm(p) for p in current}
    add  = [p for p in attach_paths if p and norm(p) not in seen]

    if not add:
        return 0

    pdm.SetObjectAttachedDocuments(pk, current + tuple(add))
    try:
        iKompasDocument.Save()
    except Exception:
        pass
    return len(add)

# -------------- извлечение источников из чертежа --------------
def get_associated_model_paths(iApplication, drawing_path: str) -> list[str]:
    """
    Открывает .cdw/.spw и собирает абсолютные пути моделей из ассоциативных видов.
    Возвращает список нормализованных абсолютных путей (без дублей).
    """
    models = {}
    iKompasDocument = None
    try:
        # открываем без UI для стабильности
        iKompasDocument = _open_doc(iApplication, drawing_path, visible=False, read_only=False)

        try:
            iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
        except Exception:
            return []
        # === восстановление стилей + лог ===
        try:
            fixed_details = _restore_layout_styles(iKompasDocument, DEFAULT_LAYOUT_STYLE_PATH)
            if fixed_details:
                # записываем в общий лог
                for (idx, oldp, newp) in fixed_details:
                    _restored_styles_log.append((drawing_path, idx, oldp, newp))
                try:
                    iKompasDocument.Save()
                except Exception:
                    pass
        except Exception:
            pass

        # универсальный перечислитель видов (несколько fallback'ов)
        def iter_views():
            # 1) Через ViewsAndLayersManager.Views
            try:
                mgr = getattr(iKompasDocument2D, "ViewsAndLayersManager", None)
                if mgr:
                    views = getattr(mgr, "Views", None)
                    if views:
                        cnt = int(getattr(views, "Count", 0) or 0)
                        for i in range(cnt):
                            try:
                                yield views.Item(i)
                            except Exception:
                                pass
            except Exception:
                pass
            # 2) Прямо doc2d.Views
            try:
                views2 = getattr(iKompasDocument2D, "Views", None)
                if views2:
                    cnt2 = int(getattr(views2, "Count", 0) or 0)
                    for i in range(cnt2):
                        try:
                            yield views2.Item(i)
                        except Exception:
                            pass
            except Exception:
                pass
            # 3) Через Layouts (некоторые версии API именно так)
            try:
                layouts = getattr(iKompasDocument2D, "Layouts", None)
                if layouts:
                    lcnt = int(getattr(layouts, "Count", 0) or 0)
                    for li in range(lcnt):
                        try:
                            layout = layouts.Item(li)
                            lviews = getattr(layout, "Views", None)
                            if lviews:
                                lvcnt = int(getattr(lviews, "Count", 0) or 0)
                                for vi in range(lvcnt):
                                    try:
                                        yield lviews.Item(vi)
                                    except Exception:
                                        pass
                        except Exception:
                            pass
            except Exception:
                pass

        for v in iter_views():
            src = None
            # A) иногда свойство есть прямо на виде
            try:
                src = getattr(v, "SourceFileName", None)
            except Exception:
                src = None
            # B) классический путь — интерфейс IAssociationView
            if not src:
                try:
                    av = API7.IAssociationView(v)
                    src = getattr(av, "SourceFileName", None)
                except Exception:
                    src = None

            if src:
                abs_model = _resolve_model_path_from_drawing(iKompasDocument, drawing_path, src)
                models[_key(abs_model)] = _norm_win(abs_model)

    finally:
        _close_doc_quiet(iKompasDocument)

    return list(models.values())

# -------------- основная процедура --------------
def attach_every_drawing_to_its_models(root_folder: str):
    """
    1) Рекурсивно находит все .cdw/.spw в root_folder.
    2) Для каждого чертежа берёт список моделей из видов (IAssociationView.SourceFileName).
    3) Открывает каждую модель и прикрепляет к ней этот чертёж.
    """
    KompasObject, iApplication, KompasVersion = get_kompas()

    root = Path(root_folder)
    if not root.exists():
        print(f"[ERR] Папка не найдена: {root}")
        return

    # Соберём все чертежи
    drawings = []
    for path in root.rglob("*"):
        try:
            if path.is_file() and path.suffix.lower() in DRAWING_EXTS:
                drawings.append(_norm_win(str(path)))
        except Exception:
            pass

    if not drawings:
        print(f"[INFO] В '{root}' чертежей не найдено.")
        return

    print(f"[INFO] Найдено чертежей: {len(drawings)}")
    total_links = 0
    processed_models = 0

    # Чтобы не открывать одну и ту же модель десятки раз:
    # держим мини-кэш открытых документов по ключу пути.
    open_docs = {}

    try:
        iApplication.HideMessage = con0.ksHideMessageYes

        for drw in drawings:
            # 1) найти все модели, на которые ссылается чертёж
            model_paths = get_associated_model_paths(iApplication, drw)
            if not model_paths:
                print(f"[SKIP] {Path(drw).name}: ассоциативных моделей нет")
                continue

            # 2) для каждой модели — открыть и прикрепить этот чертёж
            for mp in model_paths:
                if not os.path.exists(mp):
                    print(f"[WARN] Модель не найдена на диске: {mp} (из {Path(drw).name})")
                    continue

                k = _key(mp)
                model_doc = open_docs.get(k)
                fresh_opened = False
                try:
                    if model_doc is None:
                        model_doc = _open_doc(iApplication, mp, visible=False, read_only=False)
                        open_docs[k] = model_doc
                        processed_models += 1
                        fresh_opened = True

                    added = _attach_to_document(model_doc, [drw])
                    total_links += added
                    if added:
                        print(f"[OK] {Path(mp).name}: + '{Path(drw).name}' (прикреплён)")
                    else:
                        print(f"[OK] {Path(mp).name}: '{Path(drw).name}' уже прикреплён")

                except Exception as e:
                    print(f"[ERR] Не удалось прикрепить '{Path(drw).name}' к '{mp}': {e}")
                    # если что-то пошло не так сразу после открытия — закроем документ из кэша
                    if fresh_opened and k in open_docs:
                        try:
                            _close_doc_quiet(open_docs.pop(k, None))
                        except Exception:
                            pass

        # Сохраним всё, что открывали
        for k, doc in list(open_docs.items()):
            try:
                doc.Save()
            except Exception:
                pass

    finally:
        # закрываем открытые документы
        for k, doc in list(open_docs.items()):
            _close_doc_quiet(doc)
        try:
            iApplication.HideMessage = con0.ksShowMessage
        except Exception:
            pass

    print("\nГотово.")
    print(f"  • Чертежей обработано: {len(drawings)}")
    print(f"  • Моделей открыто/затронуто: {processed_models}")
    print(f"  • Новых прикреплений: {total_links}")
    print(f"  • Восстановленных стилей: {len(_restored_styles_log)}")
    input("_")


# -------------- CLI --------------
if __name__ == "__main__":
    script = os.path.basename(__file__)
    if not check_access(script):
        input(f"❌ Похоже кто-то не заплатил за {script.split('.')[0]}, пропускаем...")
        sys.exit()

    if len(sys.argv) >= 2:
        folder = sys.argv[1]
    else:
        # Если папка не указана: берём папку активного документа, иначе — текущую
        KompasObject, iApplication, KompasVersion = get_kompas()
        path = get_active_doc_path(iApplication)
        folder = easygui.diropenbox(msg="Выберите папку с чертежами",title="Выбор папки",default=str(path))

    attach_every_drawing_to_its_models(folder)
