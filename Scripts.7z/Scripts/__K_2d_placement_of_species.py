import sys
from shapely.geometry import box
import pythoncom
from win32com.client import VARIANT
from __Kompas import *
from __Debug import *

def normalize_rect(r):
    x1, y1, x2, y2 = r
    return (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))

def rects_from_work_area(work_area, occupied):
    x1, y1, x2, y2 = normalize_rect(work_area)
    all_rects = []
    occupied = [normalize_rect(r) for r in occupied]
    occupied.sort(key=lambda r: r[1])  # по Y

    if occupied[0][1] > y1:
        all_rects.append((x1, y1, x2, occupied[0][1]))
    if occupied[-1][3] < y2:
        all_rects.append((x1, occupied[-1][3], x2, y2))

    for i in range(len(occupied) - 1):
        top = occupied[i][3]
        bottom = occupied[i + 1][1]
        if bottom > top:
            all_rects.append((x1, top, x2, bottom))

    for r in occupied:
        ox1, oy1, ox2, oy2 = r
        if ox1 > x1:
            all_rects.append((x1, oy1, ox1, oy2))
        if ox2 < x2:
            all_rects.append((ox2, oy1, x2, oy2))

    return all_rects

def get_largest_rect_center(rects):
    max_area = -1
    best_center = None
    for x1, y1, x2, y2 in rects:
        area = abs((x2 - x1) * (y2 - y1))
        if area > max_area:
            max_area = area
            best_center = ((x1 + x2) / 2, (y1 + y2) / 2)
    return best_center

def draw_rectangles(iRectangles, rectangles):
    '''Функция построения габаритных прямоугольников для отладки'''
    for rect in rectangles:
        print(rectangles)
        x1, y1, x2, y2 = normalize_rect(rect)
        width = abs(x2 - x1)
        height = abs(y2 - y1)
        r = iRectangles.Add()
        r.X = x1
        r.Y = y1
        r.Width = width
        r.Height = height
        r.Update()

# def arrange_views_by_free_space(iKompasDocument, views_list):
#     iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
#     iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
#     iViews = iKompasDocument2D.ViewsAndLayersManager.Views
#
#     # iView = iViews.ActiveView  # Визуализация свободных зон
#     # iDrawingContainer = API7.IDrawingContainer(iView)  # Визуализация свободных зон
#     # iRectangles = iDrawingContainer.Rectangles  # Визуализация свободных зон
#
#     iLayoutSheets = iKompasDocument.LayoutSheets
#     iLayoutSheet = iLayoutSheets.Item(0)
#
#     width = iLayoutSheet.Format.FormatWidth
#     height = iLayoutSheet.Format.FormatHeight
#
#     # Рабочая зона
#     work_area_x1 = 20
#     work_area_y1 = 5
#     work_area_x2 = width - 5
#     work_area_y2 = height - 5
#     work_area = (work_area_x1, work_area_y1, work_area_x2, work_area_y2)
#     # print(f"Рабочая зона: {work_area}")
#
#     # Основная надпись — 185x55, правый нижний угол совпадает с правым нижним углом рабочей зоны
#     on_width = 185
#     on_height = 55
#
#     on_x2 = work_area_x2
#     on_y2 = work_area_y1  # нижний Y
#     on_x1 = on_x2 - on_width
#     on_y1 = on_y2 + on_height
#
#     block_on_manual = (on_x1, on_y1, on_x2, on_y2)
#     # print(f"Основная надпись: {block_on_manual}")
#
#     occupied = [block_on_manual]
#
#     # Координаты видов до перемещения
#     views_coords = {}
#
#     iDrawingGroups = iKompasDocument2D1.DrawingGroups
#     iDrawingGroup = iDrawingGroups.Add(True, 'TMP')
#
#     views_data = {}
#     for i, iView in enumerate(views_list, start=1):
#
#         iDrawingContainer = API7.IDrawingContainer(iView)
#         iLines = iDrawingContainer.Lines
#         iLineSegments = iDrawingContainer.LineSegments
#         iCircles = iDrawingContainer.Circles
#         iArcs = iDrawingContainer.Arcs
#         # Временная группа для габарита геометрии
#         iDrawingGroup_tmp = iDrawingGroups.Add(True, f"TMP_GEO_{i}")
#
#         print(f"View name: {iView.Name}, LineSegments.Count = {iLineSegments.Count}")
#
#         # Добавляем геометрию в группу
#         for n in range(iLineSegments.Count):
#             iDrawingGroup_tmp.AddObjects(iLineSegments.LineSegment(n))
#         for n in range(iCircles.Count):
#             iDrawingGroup_tmp.AddObjects(iCircles.Circle(n))
#         for n in range(iArcs.Count):
#             iDrawingGroup_tmp.AddObjects(iArcs.Arc(n))
#
#         # Получаем габарит по геометрии
#         gabarit = get_gabarit_object(iKompasDocument2D1, iDrawingGroup_tmp)
#
#         # Сохраняем данные
#         views_data[i] = {
#             "View": iView,
#             "X": iView.X,
#             "Y": iView.Y,
#             "Gabarit": gabarit,
#             "RightBottomCorner": (gabarit[4], gabarit[3]),  # XMax, YMin
#             "Geometry": {
#                 "LineSegments": iLineSegments,
#                 "Circles": iCircles,
#                 "Arcs": iArcs
#             }
#         }
#         # iDrawingGroup_tmp.Delete()
#
#     # Вычисление расстояний
#     g1 = views_data[1]["Gabarit"]
#     g2 = views_data[2]["Gabarit"]
#     g3 = views_data[3]["Gabarit"]
#     g1_corner = views_data[1]["RightBottomCorner"]
#
#     dist2 = g1_corner[1] - g2[5]  # вниз
#     dist3 = g3[2] - g1_corner[0]  # вправо
#
#     if dist2 > dist3:
#         delta = dist2 - dist3
#         view = views_data[3]["View"] # смещаем вид 3 (вправо)
#         view.X = views_data[3]["X"] + delta
#         view.Y = views_data[3]["Y"]
#         view.Update()
#
#
#     elif dist3 > dist2:
#         delta = dist3 - dist2
#         view = views_data[2]["View"] # смещаем вид 2 (вниз)
#         view.X = views_data[2]["X"]
#         view.Y = views_data[2]["Y"] - delta
#         view.Update()
#
#     for i, iView in enumerate(views_list, start=1):
#         views_coords[i] = {"X": iView.X, "Y": iView.Y}
#         # Группировка объектов, как было:
#         iDrawingContainer = API7.IDrawingContainer(iView)
#         iLineSegments = iDrawingContainer.LineSegments
#         iCircles = iDrawingContainer.Circles
#         iArcs = iDrawingContainer.Arcs
#
#         for n in range(iLineSegments.Count):
#             iDrawingGroup.AddObjects(iLineSegments.LineSegment(n))
#         for n in range(iCircles.Count):
#             iDrawingGroup.AddObjects(iCircles.Circle(n))
#         for n in range(iArcs.Count):
#             iDrawingGroup.AddObjects(iArcs.Arc(n))
#
#     # Габариты
#     # safe_array = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_DISPATCH, views_list)
#     # gabarit_views = get_gabarit_object(iKompasDocument2D1, safe_array)
#     gabarit_views = get_gabarit_object(iKompasDocument2D1, iDrawingGroup)
#     gabarit_system_view = get_gabarit_object(iKompasDocument2D1, iViews.View(0))
#
#     #Список видов
#     gabarit_width, gabarit_height = gabarit_views[0], gabarit_views[1]
#
#     # Системный вид
#     rect_system = (gabarit_system_view[2], gabarit_system_view[3], gabarit_system_view[4], gabarit_system_view[5])
#     occupied.append(rect_system)
#
#     # Технические требования
#     iDrawingDocument = API7.IDrawingDocument(iKompasDocument2D)
#     block_gabarit = iDrawingDocument.TechnicalDemand.BlocksGabarits
#
#     if isinstance(block_gabarit, tuple) and len(block_gabarit) == 4:
#         occupied.append(block_gabarit)
#
#     # draw_rectangles(iRectangles, occupied)  # Визуализация свободных зон
#
#     # Генерация прямоугольников свободных зон
#     candidate_rects = rects_from_work_area(work_area, occupied)
#
#     # Фильтрация по размеру
#     filtered_free_rects = []
#     for rect in candidate_rects:
#         x1, y1, x2, y2 = rect
#         width_r = abs(x2 - x1)
#         height_r = abs(y2 - y1)
#         if width_r >= gabarit_width and height_r >= gabarit_height:
#             filtered_free_rects.append(rect)
#
#     # draw_rectangles(iRectangles, filtered_free_rects)  # Визуализация свободных зон
#     # Центр подходящего прямоугольника
#     sheet_center = get_largest_rect_center(filtered_free_rects)
#     if not sheet_center:
#         sheet_center = ((work_area[0] + work_area[2]) / 2, (work_area[1] + work_area[3]) / 2)
#
#     g_w, g_h, g_min_x, g_min_y, _, _ = gabarit_views
#     views_center = (g_min_x + g_w / 2, g_min_y + g_h / 2)
#
#     dx = sheet_center[0] - views_center[0]
#     dy = sheet_center[1] - views_center[1]
#
#     for i, coords in views_coords.items():
#         view = iViews.View(i)
#         view.X = views_coords[i]["X"] + dx
#         view.Y = views_coords[i]["Y"] + dy
#         view.Update()
#
#     print("✅ Виды размещены по максимальной свободной зоне.")

def arrange_views_by_free_space(iKompasDocument, views_list):

    KompasObject, iApplication, KompasVersion = get_kompas()

    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    iViews = iKompasDocument2D.ViewsAndLayersManager.Views

    iLayoutSheets = iKompasDocument.LayoutSheets
    iLayoutSheet = iLayoutSheets.Item(0)

    width = iLayoutSheet.Format.FormatWidth
    height = iLayoutSheet.Format.FormatHeight

    work_area_x1 = 20
    work_area_y1 = 5
    work_area_x2 = width - 5
    work_area_y2 = height - 5
    work_area = (work_area_x1, work_area_y1, work_area_x2, work_area_y2)

    on_width, on_height = 185, 55
    block_on_manual = (
        work_area_x2 - on_width,
        work_area_y1,
        work_area_x2,
        work_area_y1 + on_height
    )

    occupied = [block_on_manual]
    views_data = {}

    iDrawingGroups = iKompasDocument2D1.DrawingGroups
    iDrawingGroup = iDrawingGroups.Add(True, 'TMP')

    for i, iView in enumerate(views_list, start=1):
        iDrawingContainer = API7.IDrawingContainer(iView)
        iLineSegments = iDrawingContainer.LineSegments
        iCircles = iDrawingContainer.Circles
        iArcs = iDrawingContainer.Arcs

        iDrawingGroup_tmp = iDrawingGroups.Add(True, f"TMP_GEO_{i}")
        for n in range(iLineSegments.Count):
            iDrawingGroup_tmp.AddObjects(iLineSegments.LineSegment(n))
        for n in range(iCircles.Count):
            iDrawingGroup_tmp.AddObjects(iCircles.Circle(n))
        for n in range(iArcs.Count):
            iDrawingGroup_tmp.AddObjects(iArcs.Arc(n))

        gabarit = get_gabarit_object(iDrawingGroup_tmp, iKompasDocument2D1)

        views_data[i] = {
            "View": iView,
            "X": iView.X,
            "Y": iView.Y,
            "Gabarit": gabarit,
            "RightBottomCorner": (gabarit[4], gabarit[3]),
        }

    # === Балансировка расстояний относительно вида 1 ===
    g1 = views_data[1]["Gabarit"]
    g1_corner = views_data[1]["RightBottomCorner"]
    x1_right = g1_corner[0]
    y1_down = g1_corner[1]

    max_right = 0
    max_down = 0
    id_right = []
    id_down = []

    for i, data in views_data.items():
        if i == 1:
            continue
        gabarit = data["Gabarit"]
        # Вправо от вида 1
        if gabarit[2] >= x1_right:
            d = gabarit[2] - x1_right
            if d > max_right:
                max_right = d
            id_right.append(i)
        # Вниз от вида 1
        if gabarit[5] <= y1_down:
            d = y1_down - gabarit[5]
            if d > max_down:
                max_down = d
            id_down.append(i)

    # Выравнивание
    if max_right > max_down:
        delta = max_right - max_down
        for i in id_down:
            views_data[i]["Y"] -= delta
            views_data[i]["View"].Y = views_data[i]["Y"]
            views_data[i]["View"].Update()
    elif max_down > max_right:
        delta = max_down - max_right
        for i in id_right:
            views_data[i]["X"] += delta
            views_data[i]["View"].X = views_data[i]["X"]
            views_data[i]["View"].Update()

    # === Центрируем группу видов на листе ===
    x_min = min(data["Gabarit"][2] for data in views_data.values())
    y_min = min(data["Gabarit"][3] for data in views_data.values())
    x_max = max(data["Gabarit"][4] for data in views_data.values())
    y_max = max(data["Gabarit"][5] for data in views_data.values())

    views_width = x_max - x_min
    views_height = y_max - y_min
    current_views_center = ((x_min + x_max) / 2, (y_min + y_max) / 2)

    gabarit_views = get_gabarit_object(iDrawingGroup, iKompasDocument2D1)
    gabarit_system_view = get_gabarit_object(iViews.View(0), iKompasDocument2D1)

    rect_system = (
        gabarit_system_view[2],
        gabarit_system_view[3],
        gabarit_system_view[4],
        gabarit_system_view[5]
    )
    occupied.append(rect_system)

    iDrawingDocument = API7.IDrawingDocument(iKompasDocument2D)
    block_gabarit = iDrawingDocument.TechnicalDemand.BlocksGabarits
    if isinstance(block_gabarit, tuple) and len(block_gabarit) == 4:
        occupied.append(block_gabarit)

    candidate_rects = rects_from_work_area(work_area, occupied)

    filtered_free_rects = [
        rect for rect in candidate_rects
        if abs(rect[2] - rect[0]) >= views_width and abs(rect[3] - rect[1]) >= views_height
    ]

    sheet_center = get_largest_rect_center(filtered_free_rects)
    if not sheet_center:
        sheet_center = ((work_area_x1 + work_area_x2) / 2, (work_area_y1 + work_area_y2) / 2)

    dx = sheet_center[0] - current_views_center[0]
    dy = sheet_center[1] - current_views_center[1]

    for data in views_data.values():
        view = data["View"]
        view.X = data["X"] + dx
        view.Y = data["Y"] + dy
        view.Update()

    print("✅ Виды размещены по максимальной свободной зоне и сбалансированы.")



# def arrange_views_by_free_space(iKompasDocument, views_list):
#     iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
#     iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
#     iViews = iKompasDocument2D.ViewsAndLayersManager.Views
#
#     iLayoutSheets = iKompasDocument.LayoutSheets
#     iLayoutSheet = iLayoutSheets.Item(0)
#
#     width = iLayoutSheet.Format.FormatWidth
#     height = iLayoutSheet.Format.FormatHeight
#
#     work_area_x1 = 20
#     work_area_y1 = 5
#     work_area_x2 = width - 5
#     work_area_y2 = height - 5
#     work_area = (work_area_x1, work_area_y1, work_area_x2, work_area_y2)
#
#     on_width, on_height = 185, 55
#     block_on_manual = (
#         work_area_x2 - on_width,
#         work_area_y1,
#         work_area_x2,
#         work_area_y1 + on_height
#     )
#
#     occupied = [block_on_manual]
#     views_data = {}
#
#     iDrawingGroups = iKompasDocument2D1.DrawingGroups
#     iDrawingGroup = iDrawingGroups.Add(True, 'TMP')
#
#     for i, iView in enumerate(views_list, start=1):
#         iDrawingContainer = API7.IDrawingContainer(iView)
#         iLineSegments = iDrawingContainer.LineSegments
#         iCircles = iDrawingContainer.Circles
#         iArcs = iDrawingContainer.Arcs
#
#         iDrawingGroup_tmp = iDrawingGroups.Add(True, f"TMP_GEO_{i}")
#
#         for n in range(iLineSegments.Count):
#             iDrawingGroup_tmp.AddObjects(iLineSegments.LineSegment(n))
#         for n in range(iCircles.Count):
#             iDrawingGroup_tmp.AddObjects(iCircles.Circle(n))
#         for n in range(iArcs.Count):
#             iDrawingGroup_tmp.AddObjects(iArcs.Arc(n))
#
#         gabarit = get_gabarit_object(iKompasDocument2D1, iDrawingGroup_tmp)
#
#         views_data[i] = {
#             "View": iView,
#             "X": iView.X,
#             "Y": iView.Y,
#             "Gabarit": gabarit,
#             "RightBottomCorner": (gabarit[4], gabarit[3]),
#         }
#
#     x_min = min(data["Gabarit"][2] for data in views_data.values())
#     y_min = min(data["Gabarit"][3] for data in views_data.values())
#     x_max = max(data["Gabarit"][4] for data in views_data.values())
#     y_max = max(data["Gabarit"][5] for data in views_data.values())
#
#     views_width = x_max - x_min
#     views_height = y_max - y_min
#
#     current_views_center = ((x_min + x_max) / 2, (y_min + y_max) / 2)
#
#     gabarit_views = get_gabarit_object(iKompasDocument2D1, iDrawingGroup)
#     gabarit_system_view = get_gabarit_object(iKompasDocument2D1, iViews.View(0))
#
#     rect_system = (
#         gabarit_system_view[2],
#         gabarit_system_view[3],
#         gabarit_system_view[4],
#         gabarit_system_view[5]
#     )
#     occupied.append(rect_system)
#
#     iDrawingDocument = API7.IDrawingDocument(iKompasDocument2D)
#     block_gabarit = iDrawingDocument.TechnicalDemand.BlocksGabarits
#
#     if isinstance(block_gabarit, tuple) and len(block_gabarit) == 4:
#         occupied.append(block_gabarit)
#
#     candidate_rects = rects_from_work_area(work_area, occupied)
#
#     filtered_free_rects = [
#         rect for rect in candidate_rects
#         if abs(rect[2] - rect[0]) >= views_width and abs(rect[3] - rect[1]) >= views_height
#     ]
#
#     sheet_center = get_largest_rect_center(filtered_free_rects)
#
#     if not sheet_center:
#         sheet_center = ((work_area_x1 + work_area_x2) / 2, (work_area_y1 + work_area_y2) / 2)
#
#     dx = sheet_center[0] - current_views_center[0]
#     dy = sheet_center[1] - current_views_center[1]
#
#     for data in views_data.values():
#         view = data["View"]
#         view.X = data["X"] + dx
#         view.Y = data["Y"] + dy
#         view.Update()
#
#     print("✅ Виды размещены по максимальной свободной зоне.")


# === Запуск ===
if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iViews = iKompasDocument2D.ViewsAndLayersManager.Views

    # Собираем виды, исключая системный (нулевой)
    views_to_arrange = [iViews.View(i) for i in range(1, iViews.Count)]
    arrange_views_by_free_space(iKompasDocument, views_to_arrange)
