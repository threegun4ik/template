import os
import re
from pathlib import Path

import pandas as pd
import numpy as np
import easygui
import openpyxl
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from __ExcelHandler import ExcelHandler
from __Kompas import *
import _Config

'''Площади проката и пластин'''
def sheet1_4(xls, code_project=""):
    log_message(f"Подготавливаю ведомость площадей проката", 'title')
    xlsx = Path(xls).parent / '1.4 _ Площадь под покраску.xlsx'

    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
    df = excel_handler.read_excel(header_row=1)  # Читаем таблицу в dataframe

    df = df.rename(columns={'№ элемента': '№'}) # Переименовываем первый столбец
    # df['Кол-во, шт.'] = df[['Так', 'Наоборот']].fillna(0).sum(axis=1).astype(int) # Вычисляем сумму "Так" + "Наоборот"
    df = df[['№', 'Сечение', 'Кол-во, шт.', 'Длина, мм', 'Ширина, мм', 'Толщина, мм',
             'Площадь 1 эл., м²', 'Эскиз сечения', 'Тип объекта']]# Оставляем только нужные столбцы
    df = df.dropna(subset=['Сечение'])# Удаляем строки если в ячейке указанного столбца пусто

    df['Площадь 1 эл., м²'] = np.ceil((df['Площадь 1 эл., м²'] / (df['Длина, мм'] / 1000)) * 100) / 100 # с округлением до большего целого
    df.rename(columns={'Площадь 1 эл., м²': 'Площадь 1 м, м²/м'}, inplace=True)

    df_filtered = df[df['Эскиз сечения'].isin(['@016', '@137'])]# Отфильтруем строки, где в столбце 'Сечение' указаны значения '@016' т.е. пластины
    excel_handler.data = df_filtered # Обновляем данные в ExcelHandler перед вызовом
    df_filtered = excel_handler.line_joining_df(['Сечение', 'Тип объекта', 'Длина, мм', 'Ширина, мм',
                                                 'Толщина, мм', 'Площадь 1 м, м²/м'],
                                                ['Кол-во, шт.'])# Применяем функцию к отфильтрованному DataFrame

    # Оставляем строки не пластины
    mask = ~df['Эскиз сечения'].isin(['@016', '@137']) # Создание маски для строк, где 'Эскиз сечения' не равен '@016' и '@137'
    df_remaining = df[mask].copy()
    # df_remaining = df[(df['Эскиз сечения'] != '@016')].copy()  # Создаем явную копию
    df_remaining.loc[:, 'Длина, мм'] = df_remaining['Длина, мм'] * df_remaining['Кол-во, шт.']# Обрабатываем строки с полосами и перемножаем кол-во на длину
    df_remaining.loc[:, 'Кол-во, шт.'] = 1# Меняем количество на 1

    excel_handler.data = df_remaining  # Обновляем данные в ExcelHandler перед вызовом
    df_remaining = excel_handler.line_joining_df(['Сечение', 'Площадь 1 м, м²/м', 'Тип объекта'],
                                                 ['Длина, мм'],
                                                 None, None, None)# Применяем функцию к оставшимся строкам

    df = pd.concat([df_filtered, df_remaining])# Объединяем обратно обработанные и необработанные строки
    #
    df = df.sort_values(by='Сечение')# Сортируем по алфавиту в столбце

    df['Длина, мм'] = df['Длина, мм'] / 1000
    df['Ширина, мм'] = df['Ширина, мм']/1000
    df['Толщина, мм'] = df['Толщина, мм']

    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом
    df = excel_handler.clean_zeros_in_columns(['Сечение'])  # Указываем столбцы, в которых нужно удалить 0

    df['№'] = None# Очищаем значение столбцов
    # Добавляем новый столбец 'Площадь 1, м2'
    # # df['Площадь 1 м, м2'] = None  # Инициализируем столбец пустыми значениями
    df['Итого, м2'] = None  # Инициализируем столбец пустыми значениями
    df = df[['№', 'Сечение', 'Кол-во, шт.', 'Длина, мм', 'Ширина, мм', 'Толщина, мм',
             'Площадь 1 м, м²/м','Итого, м2', 'Эскиз сечения', 'Тип объекта']]# Отсортируем столбцы

    # df['Площадь 1 м, м2'] = df['Сечение из Компас'].map(df_base.set_index('Наименование профиля')['Площадь 1 м, м2'])# Обновление значения в df['Площадь 1 м, м2'] в зависимости от df_base
    # df['Площадь 1 м, м2'] = df.apply(lambda row: calculate_area_1m(row, df_base), axis=1)
    # df['Итого, м2'] = df['Площадь 1 м, м2'] * df['Длина, мм'] / 1000 * df['Кол-во, шт.']
    #
    # # df.to_excel(xlsx, sheet_name="Площадь под покраску", index=False)
    df.to_excel(xlsx, sheet_name="Площадь под покраску", index=False)  # Создадим файл отчета и запишем данные в него

    wb = openpyxl.open(xlsx, data_only=True)
    ws = wb['Площадь под покраску']
    ws.insert_rows(1)  # Вставим строку
    ws["A1"] = f'{code_project}. Площадь под покраску'

    ws["C2"] = "Кол-во, шт."
    ws["B2"] = "Сечение"
    ws["D2"] = "Длина, м"
    ws["E2"] = "Ширина, м"
    ws["F2"] = "Толщина, мм"

    excel_handler.format_columns(ws, ['D', 'E', 'G', 'H'], 1, 3)  # Округление до n знаков после запятой

### Прописываем площади элементам не из базы
    for row in range(3, ws.max_row + 1):
        e_value = ws[f'E{row}'].value
        f_value = ws[f'F{row}'].value

        ws[f'A{row}'].value = f'=ROW()-2'

        if e_value is not None and f_value is not None: # Если E и F не пусты, применяем формулу для J
            formula = f'=C{row} * 2 * (D{row} * E{row} + (D{row} * F{row} + E{row} * F{row}) * 10 ^ -3 )'
            ws[f'H{row}'].value = formula  # Записываем формулу в столбец J

        else:
            formula = f'=(D{row})*G{row}'
            ws[f'H{row}'].value = formula

    excel_handler.auto_dimensions(ws)  # Автоподбор ширины столбцов
    excel_handler.fix_dimensions(ws, ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'], width=12)  # Фиксированная ширина столбцов
    excel_handler.fix_dimensions(ws, ['B'], width=30)  # Фиксированная ширина столбцов

    ws.row_dimensions[1].height = 30  # Измените высоту первой строки

    # Включите перенос текста по словам и выравнивание по центру для ячеек в первой строке
    for cell in ws[2]:  # Итерируем по ячейкам во второй строке
        cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

        # Создание маппинга выравниваний для столбцов
    alignment_map = {
        **{letter: Alignment(horizontal='center', vertical='center') for letter in 'ACDEFGHI'},
        **{letter: Alignment(horizontal='left', vertical='center') for letter in 'B'}
    }
    # Применяем выравнивание к каждой ячейке в соответствии с заданным маппингом
    for row in ws.iter_rows(min_row=3):  # Начинаем со второй строки, чтобы пропустить заголовки
        for cell in row:
            column_letter = openpyxl.utils.get_column_letter(cell.column)
            if column_letter in alignment_map:
                cell.alignment = alignment_map[column_letter]

        # Скроем ненужные столбцы
        for col in ['I', 'J']:
            ws.column_dimensions[col].hidden = True


    ###Оформления заголовка
    ws.merge_cells(start_row=1, start_column=1, end_row=1,
                   end_column=ws.max_column)  # Объединить ячейки первой строки
    cell = ws.cell(row=1, column=1)
    cell.font = openpyxl.styles.Font(bold=True)
    cell.alignment = openpyxl.styles.Alignment(horizontal='left', vertical='center')

    ws.auto_filter.ref = 'A2:{}'.format(openpyxl.utils.get_column_letter(ws.max_column) + '2')  # Автофильтр на вторую строку

    excel_handler.check_empty_rows_in_cell_column(ws, 3,'E, F, I')  # Проверка таблицы на пустые ячейки в ячейках с третей строки и выделяем их цветом

    last_row = ws.max_row
    # Устанавливаем текст 'Итого' в столбец 'I' для последней строки
    cell = ws[f'G{last_row + 2}']  # Обращаемся к ячейке по имени столбца
    cell.value = 'Итого'
    cell.font = Font(bold=True)# Применяем форматирование (жирный шрифт)
    cell.alignment = Alignment(horizontal='right')# Выравниваем содержимое ячейки вправо

    # Устанавливаем формулу с округлением до большего целого в столбец 'J' для последней строки
    cell = ws[f'H{last_row + 2}']  # Обращаемся к ячейке по имени столбца
    cell.value = f'=ROUNDUP(SUM(H3:H{last_row}), 0)'
    # Применяем форматирование (жирный шрифт)
    cell.font = Font(bold=True)
    # Устанавливаем пользовательский числовой формат для ячейки
    cell.number_format = '0 "м²"'

    wb.save(xlsx)  # Сохраняем изменения в файле Excel
    wb.close()

    log_message(f'Ведомость площадей проката - создана', 'ok')

if __name__ == "__main__":

    # xlsx = r'C:\Users\ik\Desktop\Primer\Отчёт\1.2 _ Ведомость элементов.xlsx'
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xlsx = easygui.fileopenbox(msg="Укажите файл 1.2 _ Ведомость элементов.xlsx", title="", default=f"{path}/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта

    sheet1_4(xlsx)
    input('\n\rРабота завершена.	\n')
