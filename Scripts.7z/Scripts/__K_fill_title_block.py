from __Kompas import *
import pandas as pd
from pathlib import Path
from collections import OrderedDict
from __Reed_file_settings import find_settings_file, parse_settings_file, cook_settings_for_stamp
from win32com.client import VARIANT
import pythoncom
from __Debug import *
import sys

from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, Optional, Tuple
import re

# ===== 1) ОПИСАНИЕ СТИЛЕЙ ШТАМПА =====

@dataclass(frozen=True)
class StampConf:
    # Любое поле можно не использовать -> ставим None
    idx_addr: Optional[int] = None        # «Адрес объекта»
    idx_name: Optional[int] = None        # «Наименование проекта»
    idx_code: Optional[int] = None        # «Шифр проекта»
    idx_stage: Optional[int] = None       # «Стадия проекта»
    idx_org: Optional[int] = None         # «Организация»
    # блок подписей (можно отключить любой колонкой = None)
    sign_base_role: Optional[int] = None  # база «Роль» (Разработал/Проверил/…)
    sign_base_fio:  Optional[int] = None  # база «ФИО»
    sign_base_date: Optional[int] = None  # база «Дата»
    sign_rows: int = 5

# СПДС: используем все поля как раньше
SPDS_CONF = StampConf(
    idx_addr=302, idx_name=303, idx_code=193, idx_stage=320, idx_org=9,
    sign_base_role=100, sign_base_fio=110, sign_base_date=130,
    sign_rows=6,
)

# ЕСКД: часть полей отсутствует -> ставим None
ESKD_CONF = StampConf(
    idx_addr=None, idx_name=None, idx_code=None, idx_stage=None,  # не заполняем эти поля
    idx_org=9,                         # «Организация» есть
    sign_base_role=100, sign_base_fio=110, sign_base_date=130,    # подписи есть
    sign_rows=6,
)

SPDS_STYLE_IDS = {1001, 1002, 1003, 1101, 1102}
ESKD_STYLE_IDS = {1}

CUSTOM_STYLE_OVERRIDES: Dict[int, StampConf] = {}


def doc_has_spds(iKompasDocument) -> bool:
    sheets = iKompasDocument.LayoutSheets
    cnt = int(getattr(sheets, "Count", 0))
    for i in range(cnt):
        sid = int(round(float(sheets.Item(i).LayoutStyleNumber)))
        if sid in SPDS_STYLE_IDS:
            return True
    return False

# ===== 2) ВСПОМОГАТЕЛЬНОЕ ДЛЯ ШТАМПА =====


def _idx_usable(iStamp, idx: Optional[int]) -> bool:
    """Проверяем, что индекс задан и реально существует в штампе."""
    if idx is None:
        return False
    try:
        _ = iStamp.Text(int(idx))  # вызов упадёт, если поле отсутствует
        return True
    except Exception:
        return False

def get_stamp_conf_for_style(style_id: int) -> StampConf:
    """
    Возвращает конфиг штампа для стиля листа.
    Порядок приоритета:
      1) Точное переопределение в CUSTOM_STYLE_OVERRIDES
      2) Входит в SPDS_STYLE_IDS → SPDS_CONF
      3) Входит в ESKD_STYLE_IDS → ESKD_CONF
      4) Иначе — SPDS_CONF как дефолт
    """
    # иногда LayoutStyleNumber приходит как float — на всякий:
    try:
        sid = int(style_id)
    except Exception:
        sid = style_id

    if sid in CUSTOM_STYLE_OVERRIDES:
        return CUSTOM_STYLE_OVERRIDES[sid]
    if sid in SPDS_STYLE_IDS:
        return SPDS_CONF
    if sid in ESKD_STYLE_IDS:
        return ESKD_CONF
    return SPDS_CONF  # разумный дефолт

# ==========================
# 2) ВСПОМОГАТЕЛЬНЫЕ ШТУКИ
# ==========================

def _to_float(value: Any, default: float = 3.0) -> float:
    try:
        return float(str(value).replace(",", "."))
    except Exception:
        return float(default)

def _get_text_and_height(data: Dict[str, Any], key: str, default_font: float = 3.0) -> Tuple[str, float]:
    """
    data[key] может быть либо (text, height), либо просто "text".
    """
    val = data.get(key, "")
    if isinstance(val, (tuple, list)) and len(val) >= 2:
        return str(val[0]), _to_float(val[1], default_font)
    return str(val or ""), float(default_font)

def _set_rich_singleline(iStamp, idx: int, text: str, font_height: float) -> None:
    """Очистить поле и записать одну строку с заданной высотой шрифта (для 302/303 и их аналогов)."""
    iText = iStamp.Text(idx)
    iText.Str = ""
    iTextLine = iText.Add()
    iTextItem = iTextLine.Add()
    iTextItem.ItemType = con0.ksTItString
    iTextItem.NewLine = True
    iTextItem.Str = text
    API7.ITextFont(iTextItem).Height = float(font_height)

def _set_simple(iStamp, idx: int, value: Any) -> None:
    iStamp.Text(idx).Str = "" if value is None else str(value)


KompasObject, iApplication, KompasVersion = get_kompas()
def file_settings(project_dir: str | Path) -> Dict[str, Any]:
    """
    Ищет и читает «Информация по проекту.txt», готовит словарь для штампа.
    Для 'Адрес объекта' и 'Наименование проекта' — возвращает (text, height).
    """
    file_name = "Информация по проекту.txt"
    file_path: Optional[Path] = find_settings_file(Path(project_dir), file_name)
    if not file_path:
        raise FileNotFoundError(f'Не найден файл настроек "{file_name}" от: {project_dir}')
    dic_raw = parse_settings_file(file_path)
    return cook_settings_for_stamp(dic_raw)

def get_marking(iKompasDocument):
    # Актуализируем отчеты
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iPropertyMng = API7.IPropertyMng(iApplication)
    iPropertyMarking = iPropertyMng.GetProperty(iKompasDocument, 4.0)
    iPropertyName = iPropertyMng.GetProperty(iKompasDocument, 5.0)
    iPropertyKeeper = API7.IPropertyKeeper(iKompasDocument2D)
    # iPropertyKeeper.SetPropertyValue(iPropertyMarking, VARIANT(pythoncom.VT_EMPTY, None), True)  # Включить по источнику свойство
    # iPropertyKeeper.SetPropertyValue(iPropertyName, VARIANT(pythoncom.VT_EMPTY, None), True)  # Включить по источнику свойство
    marking = iPropertyKeeper.GetPropertyValue(iPropertyMarking, 0, True)[1]  # Обозначение в штампе
    # marking = API7.IEmbodimentsManager(iView).GetCurrentEmbodimentMarking(-1, False) #Обозначение вида (вставленная деталь/сборка)
    name = iPropertyKeeper.GetPropertyValue(iPropertyName, 0, True)[1]  # Наименование в штампе
    return marking

def set_filter_iAssociationTable(iAssociationTable, index, prop_id, filter_condition, filter_value):
    # if not iAssociationTable.Actual:
    iReport = iAssociationTable.Report
    iReportFilter = iReport.ReportFilter
    # iReportFilter.Clear()
    iReportFilter.SetCondition(index, prop_id, filter_condition, filter_value)  # Установить фильтр Марка с заменой первого
    iReport.UseReportFilter = True
    # iAssociationTable = iAssociationTables.AssociationTable(n)  # Таблица
    iAssociationTable.Rebuild()  # Обновить фильтры
    # iReport.Rebuild()

def get_coordinate_table(iKompasDocument, iAssociationTable , sheet_height, sheet_width):
    '''Определяем привязку отчета к листу'''
    iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument)
    table_b, table_h, _, _, _, _ = get_gabarit_object(iAssociationTable, iKompasDocument2D1)  # Определяем габарит таблицы

    table_X = iAssociationTable.X + table_b / 2
    # table_Y = iAssociationTable.Y
    cumulative_width = 0  # Накопительная ширина всех листов
    adjusted_X = table_X  # Скорректированная координата X

    for num_of_sheets, width in sheet_width.items():  # Пройдем по всем листам, чтобы определить, где находится координата X
        width = float(width)  # Преобразуем в число
        cumulative_width += width  # Добавляем ширину текущего листа
        if table_X <= cumulative_width:  # Если X попала в этот лист
            adjusted_X = cumulative_width  # Корректируем X относительно текущего листа
            adjusted_Y = float(sheet_height[num_of_sheets])  # Получаем высоту соответствующего листа
            break

    if adjusted_X < 0:  # Если X отрицательное, то ставим координаты первого листа
        adjusted_X = float(sheet_width["1"])
        adjusted_Y = float(sheet_height["1"])

    # Если координата X выходит за пределы всех листов, установим её равной сумме всех ширин
    total_width = sum(float(width) for width in sheet_width.values())
    if adjusted_X > total_width:
        adjusted_X = total_width
        adjusted_Y = float(sheet_height[list(sheet_height.keys())[-1]])
    return adjusted_X, adjusted_Y, table_b, table_h

def fill_stamp_fields(iStamp, data, keys, values, conf: StampConf) -> None:
    # 302/303 (или их аналоги) — только если индексы есть
    addr_text, addr_h = _get_text_and_height(data, 'Адрес объекта', default_font=3.0)
    name_text, name_h = _get_text_and_height(data, 'Наименование проекта', default_font=3.0)

    if _idx_usable(iStamp, conf.idx_addr):
        _set_rich_singleline(iStamp, conf.idx_addr, addr_text, addr_h)
    if _idx_usable(iStamp, conf.idx_name):
        _set_rich_singleline(iStamp, conf.idx_name, name_text, name_h)

    # Простые поля
    if _idx_usable(iStamp, conf.idx_code):
        _set_simple(iStamp, conf.idx_code,  data.get('Шифр проекта', ''))
    if _idx_usable(iStamp, conf.idx_stage):
        _set_simple(iStamp, conf.idx_stage, data.get('Стадия проекта', ''))
    if _idx_usable(iStamp, conf.idx_org):
        _set_simple(iStamp, conf.idx_org,   data.get('Организация', ''))

    # Подписи: отрабатываем только те колонки, у которых есть базовые индексы
    keys_list   = list(keys)
    values_list = list(values)
    month_val   = data.get('Месяц сдачи проекта', '')

    for row in range(conf.sign_rows):
        idx = row + 5  # ваша текущая модель
        role = keys_list[idx] if (idx < len(keys_list) and idx < len(values_list) and values_list[idx]) else ""
        fio  = values_list[idx].replace("!", "") if idx < len(values_list) else ""
        date = month_val if fio else ""

        if _idx_usable(iStamp, conf.sign_base_role):
            _set_simple(iStamp, conf.sign_base_role + row, role)
        if _idx_usable(iStamp, conf.sign_base_fio):
            _set_simple(iStamp, conf.sign_base_fio  + row, fio)
        if _idx_usable(iStamp, conf.sign_base_date):
            _set_simple(iStamp, conf.sign_base_date + row, date)

    iStamp.Update()

def fill_title_block(data: Dict[str, Any], iKompasDocument):
    """
    Заполняет основную надпись активного документа KOMPAS-3D на всех листах.
    Возвращает: (ok:bool, df, sheet_height:dict, sheet_width:dict)
    """
    keys, values = zip(*data.items()) if data else ([], [])

    marking = get_marking(iKompasDocument)

    iLayoutSheets = iKompasDocument.LayoutSheets
    num_of_sheets = int(getattr(iLayoutSheets, "Count", 0))

    sheet_height: Dict[str, str] = {}
    sheet_width:  Dict[str, str] = {}
    rows: list[list[Any]] = []

    for i in range(num_of_sheets):
        iLayoutSheet = iLayoutSheets.Item(i)
        sheet_height[str(i + 1)] = str(iLayoutSheet.Format.FormatHeight)
        sheet_width[str(i + 1)]  = str(iLayoutSheet.Format.FormatWidth)

        iStamp = iLayoutSheet.Stamp

        name_sheet = " ".join(iStamp.Text(1001).Str.splitlines()) # имя листа без переносов
        rows.append([i + 1, name_sheet, ""])

        # стиль листа → конфиг
        style_id = int(round(float(iLayoutSheet.LayoutStyleNumber)))
        conf = get_stamp_conf_for_style(style_id)

        fill_stamp_fields(iStamp, data, keys, values, conf)

    df = pd.DataFrame(rows, columns=["Лист", "Наименование", "Примечание"])
    return True, df, sheet_height, sheet_width, marking

def update_position_tables(iKompasDocument, settings, df, sheet_height, sheet_width, need_report_update=True):
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
    iViews = iViewsAndLayersManager.Views  # Возвращает коллекцию видов
    # for i in range(iViews.Count): # Количество видов
    iView = iViews.View(0)  # Выбираем системный вид
    # iAssociationView = API7.IAssociationView(iView)
    iSymbols2DContainer = API7.ISymbols2DContainer(iView)
    iAssociationTables = iSymbols2DContainer.AssociationTables

    # Для отчётов
    final_assembly = None
    if iAssociationTables.Count > 0:
        final_assembly = Path(settings['Путь до итоговой сборки'])
        if not final_assembly.is_file():
            iApplication.MessageBoxEx(f'Не найден файл итоговой сборки\n{final_assembly}\nПуть до файла итоговой сборки должен быть записан в файл "Информация по проекту.txt" в папке с проектом','', 0)
            final_assembly = None
    # Замена ссылок на документы
    if final_assembly:
        new_path = iKompasDocument.PathName
        old_path = r'C:\OiSMK\К101.a3d'
        iKompasDocument1 = API7.IKompasDocument1(iKompasDocument)
        iKompasDocument1.ReplaceExternalFilesNames(True, old_path, new_path)  # Заменяем путь до источника отчета True/False? Изменяем путь до файла источника
        old_path = r'C:\OiSMK\_ Итоговая сборка.a3d'
        iKompasDocument1.ReplaceExternalFilesNames(True, old_path, final_assembly)  # Заменяем путь до источника отчета True/False? Изменяем путь до файла источника

    # Список условий фильтров и их порядок обработки
    report_filters = OrderedDict([
        ('Форма 2.1 Ведомость отправочных элементов схемы', {'prop_id': 273169036789.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '*'}),
        ('Форма 2.2 Ведомость отправочных элементов схемы (всего)', {'prop_id': 273169036789.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '*'}),
        ('Форма 4. Ведомость на отправочный элемент', {'prop_id': 297771548672.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '*'}),
        ('Форма 3.1 Ведомость монтажных метизов', [{'prop_id': 273169036789.0, 'filter_condition': con0.ksFilterConditionContain, 'filter_value': '*'},
                                                   {'prop_id': 297771548672.0, 'filter_condition': con0.ksFilterConditionContain, 'filter_value': '*'}]),
        ('Форма 5. Требуется изготовить', {'prop_id': 4.0, 'filter_condition': con0.ksFilterConditionEqual, 'filter_value': get_marking(iKompasDocument)}),
        ('Форма 5.1 Требуется изготовить элементов', {'prop_id': 4.0, 'filter_condition': con0.ksFilterConditionEqual, 'filter_value': get_marking(iKompasDocument)}),
        ('Форма 5.2 Требуется изготовить по маркам', [{'prop_id': 4.0, 'filter_condition': con0.ksFilterConditionEqual, 'filter_value': get_marking(iKompasDocument)},
                                                      {'prop_id': 297771548672.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '*'}]),
        ('Выборка металла для профилей', [{'prop_id': 276039607982.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '@016'},
                                          {'prop_id': 276039607982.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '@137'},
                                          {'prop_id': 297771548672.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '*'}]),
        ('Выборка листового металла', [{'prop_id': 276039607982.0, 'filter_condition': con0.ksFilterConditionContain, 'filter_value': '@016'},
                                          {'prop_id': 276039607982.0, 'filter_condition': con0.ksFilterConditionContain, 'filter_value': '@137'},
                                          {'prop_id': 297771548672.0, 'filter_condition': con0.ksFilterConditionNotContain, 'filter_value': '*'}])
    ])

    iAssociationTable_dict = {} # Словарь для хранения ссылок на iAssociationTable
    x1 = y1 = None  # Объявляем переменные заранее
    for form_name in report_filters:
        for n in range(iAssociationTables.Count):
            iAssociationTable = iAssociationTables.AssociationTable(n)
            iReport = iAssociationTable.Report
            if iReport.CurrentReportStyle.Name == form_name:
                iAssociationTable_dict[form_name] = iAssociationTable
                break  # Нашли нужную таблицу — выходим из внутреннего цикл
    # for n in range(iAssociationTables.Count):
    #     iAssociationTable = iAssociationTables.AssociationTable(n)  # Таблица отчета
    #     iReport = iAssociationTable.Report
    #     iReport.UseReportFilter = True
    #     report_style_name = iReport.CurrentReportStyle.Name  # Имя текущего стиля отчета
    #
    #     # Если стиль отчета присутствует в списке, сохраняем его таблицу
    #     if report_style_name in report_filters:
    #         iAssociationTable_dict[report_style_name] = iAssociationTable  # Сохраняем таблицу
            # filter_data = report_filters[report_style_name] # Получаем фильтр

        if need_report_update:
            iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument)
            iKompasDocument2D1.RebuildDocument
            for form_name, iAssociationTable in iAssociationTable_dict.items():
                filter_data = report_filters.get(form_name)
                if iAssociationTable and filter_data:  # Проверяем, что таблица и фильтр существуют
                    if isinstance(filter_data, list):# Проверяем, является ли filter_data списком
                        for i, single_filter in enumerate(filter_data): # Если filter_data является списком, проходим по каждому фильтру
                            set_filter_iAssociationTable(iAssociationTable, i, single_filter['prop_id'], single_filter['filter_condition'], single_filter['filter_value'])
                    else:
                        set_filter_iAssociationTable(iAssociationTable, 0, filter_data['prop_id'], filter_data['filter_condition'], filter_data['filter_value'])# Если это не список, применяем один фильтр как раньше

        # Расставляем таблицы по порядку, используя порядок из OrderedDict
        sheet_X_4 = sheet_X_met = None
        for form_name, filter_data in report_filters.items():
            iAssociationTable = iAssociationTable_dict.get(form_name)
            if iAssociationTable is None:
                continue



            # Получаем размеры таблицы и задаём характерную точку
            if form_name in ['Форма 2.2 Ведомость отправочных элементов схемы (всего)',
                             'Форма 3.1 Ведомость монтажных метизов',
                             'Форма 5. Требуется изготовить']:
                # print(f'Блок 1 {form_name}')
                # table_b, table_h = get_gabarit_object(iKompasDocument, iAssociationTable)
                sheet_X, sheet_Y, table_b, table_h = get_coordinate_table(iKompasDocument, iAssociationTable, sheet_height, sheet_width)
                iAssociationTable.TablePlaceType = con0.ksTPLeftUp

            elif form_name in ['Форма 4. Ведомость на отправочный элемент']:
                sheet_X_4, sheet_Y_4, table_b_4, table_h_4 = get_coordinate_table(iKompasDocument, iAssociationTable, sheet_height, sheet_width)

            else:
                # print(f'Блок 2 {form_name}')
                sheet_X, sheet_Y, table_b, table_h = get_coordinate_table(iKompasDocument, iAssociationTable, sheet_height, sheet_width)
                iAssociationTable.TablePlaceType = con0.ksTPRightUp  # Тип привязки: из перечисления ksTablePointEnum
                # print(sheet_X)

            # Логика для форм, где нужно только изменить y1 или обе координаты
            if form_name in ['Форма 2.2 Ведомость отправочных элементов схемы (всего)',
                             'Форма 3.1 Ведомость монтажных метизов',
                             'Форма 5. Требуется изготовить'
                             ]:
                if x1 is not None and y1 is not None:
                    y1 = y1 - table_h + 4
                else:
                    x1 = sheet_X - table_b - 1
                    y1 = sheet_Y - table_h - 1
### Выборка металла
            # elif form_name in ['Выборка металла для профилей',
            #                  'Выборка листового металла']:

            elif form_name  in ['Выборка металла для профилей']:
                if sheet_X_4 is not None:
                    x1 = sheet_X_4 - table_b - 1
                    y1 = sheet_Y_4 - table_h_4 - table_h + 3
                    sheet_X_met, sheet_Y_met = x1, y1
                else:
                    x1 = sheet_X - table_b - 1
                    y1 = sheet_Y - table_h - 1

            elif form_name in ['Выборка листового металла']:
                if sheet_X_met:
                    x1 = sheet_X_met
                    y1 = sheet_Y_met - table_h + 4
                else:
                    if sheet_X_4 is not None:
                        x1 = sheet_X_4 - table_b - 1
                        y1 = sheet_Y_4 - table_h_4 - table_h + 3
                    else:
                        x1 = sheet_X - table_b - 1
                        y1 = sheet_Y - table_h - 1

            elif form_name in ['Форма 4. Ведомость на отправочный элемент']:
                x1 = sheet_X_4 - table_b_4 - 1
                y1 = sheet_Y_4 - table_h_4 - 1

            # Логика для других форм, где необходимо установить координаты
            elif form_name in ['Форма 2.1 Ведомость отправочных элементов схемы',
                               'Форма 4. Ведомость на отправочный элемент',
                               'Форма 5.1 Требуется изготовить элементов'
                               ]:
                x1 = sheet_X - table_b - 1
                y1 = sheet_Y - table_h - 1

            elif form_name in ['Форма 5.2 Требуется изготовить по маркам']:
                if x1 is not None and y1 is not None:
                    y1 = y1 - table_h + 4
                    x1 = sheet_X - table_b - 1
                else:
                    x1 = sheet_X - table_b - 1
                    y1 = sheet_Y - table_h - 1

            iAssociationTable.X, iAssociationTable.Y = x1, y1  # Ставим таблицу на место
            iAssociationTable.Update()

    # Для таблицы Ведомость рабочих чертежей
    iDrawingTables = iSymbols2DContainer.DrawingTables
    num_sheet_list_working = None
    for i in range(iDrawingTables.Count):
        iDrawingTable = iDrawingTables.DrawingTable(i)
        iTable = API7.ITable(iDrawingTable)
        iTableCell = iTable.Cell(0, 0)
        iText = API7.IText(iTableCell.Text)
        text_cell = iText.Str
        if text_cell == 'Ведомость рабочих чертежей':
            num_sheet_list_working = i
            rows_count = iTable.RowsCount
            break

    if not num_sheet_list_working==None:
        quantity_actual = rows_count # Фактическое кол-во строк в таблице
        quantity_required = df.shape[0] #Количество строк в df
        quantity_difference = quantity_actual - quantity_required - 2 #Разница в количестве

        if quantity_difference > 0:# Если строк в таблице больше чем в df
            for i in range(quantity_actual - 1, quantity_actual - quantity_difference - 1, -1):
                print('Удаляю строку')
                iTable.DeleteRow(i - 1)

        if quantity_difference < 0:#Если строк в таблице меньше чем в df
            for i in range(abs(quantity_difference)):
                # print('Добавляю строку')
                iTable.AddRow(quantity_actual-1, False)

        cell_number = 6 #Первая строка для заполнения
        # Проход по строкам и столбцам DataFrame
        for row_index in range(df.shape[0]):  # Количество строк
            for col_index in range(df.shape[1]):  # Количество столбцов
                cell_number += 1
                iTableCell = iTable.CellById(cell_number)  # Номер ячейки
                iText = API7.IText(iTableCell.Text)
                cell_value = df.iat[row_index, col_index] # Проверяем, не является ли значение в df пустым
                if pd.isna(cell_value) or cell_value == "":
                    continue  # Пропускаем итерацию, если ячейка в df пустая
                iText.Str = cell_value
                iDrawingTable.Update()

        _, sheet_Y, _, _ = get_coordinate_table(iKompasDocument, iDrawingTable, sheet_height, sheet_width)
        x1 = 20
        y1 = sheet_Y - 5
        iDrawingTable.X, iDrawingTable.Y = x1, y1  # Ставим таблицу на место
        iDrawingTable.Update()

    iKompasDocument2D.Save()


if __name__ == "__main__":
    iKompasDocument = iApplication.ActiveDocument
    iApplication.MessageBoxEx('Заполняем основную надпись активного чертежа', '', 0x0 | 0x40)

    project_path = getattr(iKompasDocument, "Path", None) or "."
    settings = file_settings(project_path)

    status, df, sheet_height, sheet_width, marking = fill_title_block(settings, iKompasDocument)

    # Если есть хотя бы один лист SPDS — спрашиваем про обновление отчётов.
    # Если все листы ЕСКД — ничего не спрашиваем и не обновляем.
    if doc_has_spds(iKompasDocument):
        need_report_update = iApplication.MessageBoxEx('Обновить отчёты?', 'Вопрос', 4 | 0x00000020)
        if need_report_update in (2, 7):   # No/Cancel
            update_position_tables(iKompasDocument, settings, df, sheet_height, sheet_width, need_report_update=False)
            print(iKompasDocument.PathName + " - Готово")
        elif need_report_update == 6:       # Yes
            update_position_tables(iKompasDocument, settings, df, sheet_height, sheet_width, need_report_update=True)
    iApplication.MessageBoxEx('Готово', '', 0x0 | 0x40)
