
import sys, easygui, os.path, os, time, re
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent / '_Service_func'))
from __Kompas import *
from __Reed_file_settings import find_settings_file, parse_settings_file, cook_settings_for_stamp



'''Заполняет основную надпись чертежей в папке. Данные берутся из файла настроек'''
title = 'Заполнить основную надпись для чертежей в указанной папке'
print(title + '\n')

# Настройка
recursion = 1 # Рекурсивно да - 1 и 0 - нет

# Функция для обработки текста и преобразования его в кортеж строк
def process_text_to_tuple(file_path):
    # Чтение текста из файла
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()

    # Замена символов новой строки на &/
    processed_text = text.replace('\n', '&/')

    # Создаём список строк, разбив текст на &/
    lines = processed_text.split('&/')

    # Удаляем &/ в начале и в конце строки, если они рядом с **
    lines = [re.sub(r'^\&/\*\*|\&/\*\*$|^\&/|\&/$', '', line).strip() for line in lines]

    # Приводим результат к кортежу строк
    result = tuple(lines)

    return result
def run_fast_scandir(dirr, ext):  # dirr: str, ext: list

    subfolders, files = [], []
    for f in os.scandir(dirr):
        if f.is_dir():
            subfolders.append(f.path)
        if f.is_file():
            if os.path.splitext(f.name)[1].lower() in ext:
                files.append(f.path)

    for subfolder in subfolders:
        sf, fl = run_fast_scandir(subfolder, ext)
        subfolders.extend(sf)
        files.extend(fl)
    return subfolders, files
# №№№
KompasObject, iApplication, KompasVersion = get_kompas()
application = KompasObject.ksGetApplication7()

try:
    # Получим путь до файла активного документа
    iKompasDocument = iApplication.ActiveDocument
    path = iKompasDocument.Path
except Exception:
    # path = "\\\\Server\\документы\\" # Если активного документа нет, тогда путь по умолчанию такой
    path = "\\\\Server\\i\\LIBRARY\\99 _ Application\\00 _ Python\\Для КОМПАС 3d\\"

# Получаем путь до обрабатываемой папки
path = easygui.diropenbox(msg="Укажите обрабатываемую папку", title="", default= f"{path}")

# Ищем файл настроек
file_name = "ТТ.txt"  # имя файла для поиска
file_settings = find_settings_file(path, file_name)

text_tt = process_text_to_tuple(file_settings)

# Читаем файл настроек

application.HideMessage = con0.ksHideMessageYes # если потребуется гасить диалоги, то раскомментировать
s_time = time.time()  # Запускаем таймер

# №№№
if recursion == 1:
    subfolders, file_list = run_fast_scandir(path, ".cdw")  # (".cdw", ".a3d")
else:
    file_list = os.listdir(path)
# №№№

# for file in os.listdir(path):
for file in file_list:
    if file.endswith(".cdw"):
        file = (os.path.join(path, file))

        iDocuments = iApplication.Documents
        iKompasDocument = iDocuments.Open(file, False, False)

        if iKompasDocument:

            iLayoutSheets = iKompasDocument.LayoutSheets
            iLayoutSheet = iLayoutSheets.Item(0)
            iSheetFormat = iLayoutSheet.Format
            sheet_height = iSheetFormat.FormatHeight
            sheet_width = iSheetFormat.FormatWidth

            #  Создай технические требования
            iDrawingDocument = API7.IDrawingDocument(iKompasDocument)
            iTechnicalDemand = iDrawingDocument.TechnicalDemand
            # iTechnicalDemand.AutoPlacement
            iTechnicalDemand.Delete()  # Удаляем текущие тех. требования

            text = iTechnicalDemand.Text
            text.Style = con0.ksTSSpecifications

            for line in text_tt:

                # Проверяем, содержит ли строка символы ** (жирный текст)
                if '**' in line:
                    # Удаляем символы ** из строки
                    line = line.replace('**', '')
                    text_line = text.Add()
                    text_line.Style = con0.ksTSSpecifications
                    text_line.Step = 1.0
                    # text_line.Align = con0.ksAlignRight
                    text_line.IndentedLine = 5.0  # Красная строка
                    # text_line.StepBeforeParagraph = 0.0 #Дополнительный шаг перед абзацем
                    # text_line.StepAfterParagraph = 0.0 #Дополнительный шаг после абзаца
                    # text_line.LeftEdge = 0.0 #Отступ слева
                    # text_line.RightEdge = 0.0 #Отступ справа
                    # text_line.Level = 0 #Уровень вложенности нумерации
                    # text_line.Numbering = con0.ksTNumbNoNumber #Тип нумерации абзаца
                    # text_line.NewPage = False #Признак начала абзаца с новой страницы

                    text_item = text_line.Add()
                    text_item.ItemType = con0.ksTItString  # Тип компонента текста - Строка
                    # text_item.NewLine = True #Признак начала строки
                    # text1 = str('1. * - Размер для справки')
                    text_item.Str = line

                    text_font = API7.ITextFont(text_item)
                    text_font.FontName = "GOST Type AU"
                    text_font.Height = 3.5
                    text_font.WidthFactor = 1.0
                    text_font.Color = 0
                    text_font.Bold = True
                    text_font.Italic = False
                    text_font.Underline = False
                    text_font.TextLineStep = 0.0
                    text_item.Update()


                else:

                    text_line = text.Add()
                    text_line.Style = con0.ksTSSpecifications
                    text_line.Step = 1.0
                    # text_line.Align = con0.ksAlignRight
                    text_line.IndentedLine = 5.0  # Красная строка
                    # text_line.StepBeforeParagraph = 0.0 #Дополнительный шаг перед абзацем
                    # text_line.StepAfterParagraph = 0.0 #Дополнительный шаг после абзаца
                    # text_line.LeftEdge = 0.0 #Отступ слева
                    # text_line.RightEdge = 0.0 #Отступ справа
                    # text_line.Level = 0 #Уровень вложенности нумерации
                    # text_line.Numbering = con0.ksTNumbNoNumber #Тип нумерации абзаца
                    # text_line.NewPage = False #Признак начала абзаца с новой страницы

                    text_item = text_line.Add()
                    text_item.ItemType = con0.ksTItString  # Тип компонента текста - Строка
                    # text_item.NewLine = True #Признак начала строки
                    text_item.Str = line

                    text_font = API7.ITextFont(text_item)
                    text_font.FontName = "GOST Type AU"
                    text_font.Height = 3.5
                    text_font.WidthFactor = 1.0
                    text_font.Color = 0
                    text_font.Bold = False
                    text_font.Italic = False
                    text_font.Underline = False
                    text_font.TextLineStep = 0.0
                    text_item.Update()

            tt_width = 180.0  # требуемая ширина по условию

            # Размеры листа
            x_sheet = sheet_width
            y_sheet = sheet_height

            # Координаты по условиям:
            # ширина ТТ = 200 мм => x1 = sheet_width - 200, x2 = sheet_width
            x1_new = x_sheet - tt_width - 5
            x2_new = x_sheet - 10

            # y1 = sheet_height - 60; y2 = y1 + фактическая высота ТТ
            y1_new = 60  # y_sheet - 60.0
            y2_new = y_sheet - 10

            # Фиксируем положение блока
            iTechnicalDemand.AutoPlacement = False
            iTechnicalDemand.BlocksGabarits = (x1_new, y1_new, x2_new, y2_new)
            iTechnicalDemand.Update()

            text_line.Align = con0.ksAlignDecimal
            iTechnicalDemand.Update()

            iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument)
            iKompasDocument2D1.RebuildDocument
            iKompasDocument.Close(1)

            print(file + " - Готово")
            i = 0
# если потребуется гасить диалоги, то раскомментарить строку ниже
application.HideMessage = con0.ksShowMessage

e_time = time.time()  # Останавливаем таймер
ex_time = (e_time - s_time)//60
print("На обработку файлов потрачено: " + str(ex_time) + " минут")
input('\nРабота завершена.')