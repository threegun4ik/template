import sys
import pandas as pd
import numpy as np
import re
import unicodedata
import easygui
from colorama import init, Fore, Style
from pathlib import Path
from __Kompas import get_kompas, get_active_doc_path, log_message
from __ExcelHandler import ExcelHandler
import _Config

# # Получаем объект Kompas, версию и приложение
# KompasObject, iApplication, KompasVersion = get_kompas()

# Константы
STEEL_DENSITY = 7850  # кг/м³ — плотность стали

def parse_plate_section(row):
    """
    Парсит толщину и ширину для сечений @016 и @137.
    Пример: @01610,0x200 → Толщина=10.0, Ширина=200.0
    Спокойно пропускает строки без нужного эскиза или с NaN в 'Сечение из Компас'.
    """
    # Обрабатываем только плоские сечения
    sketch = str(row.get('Эскиз сечения') or '').strip()
    if sketch not in ('@016', '@137'):
        return row

    sec = row.get('Сечение из Компас')
    # Если значение отсутствует — тихо выходим (никаких логов)
    if pd.isna(sec) or str(sec).strip() == '':
        return row

    text = str(sec).strip()

    # Ищем @016/@137Толщина x Ширина
    m = re.match(r'^@(016|137)\s*([\d.,]+)\s*[xXхХ]\s*([\d.,]+)', text)
    if not m:
        # Если формат не распознан — тоже молча выходим
        return row

    # Заполняем только пустые поля
    if pd.isna(row.get('Толщина, мм')):
        row['Толщина, мм'] = float(m.group(2).replace(',', '.'))
    if pd.isna(row.get('Ширина, мм')):
        row['Ширина, мм'] = float(m.group(3).replace(',', '.'))

    return row


def update_profile_names(df, df_base, printed_cache=None):
    """
    Обновляет 'Наименование профиля ГОСТ, ТУ' по словарю, собранному из v21 и v23.
    Приоритет — первая встреченная запись (можно поменять на нужную логику).
    """
    if printed_cache is None:
        printed_cache = set()

    # 1) Строим lookup из обоих столбцов
    # Приводим к строке/обрезаем пробелы и выбрасываем NaN
    def _norm(s):
        return s.astype(str).str.strip()

    base = df_base.copy()
    base['v21'] = _norm(base['v21'])
    base['v23'] = _norm(base['v23'])
    base['Наименование профиля ГОСТ, ТУ'] = _norm(base['Наименование профиля ГОСТ, ТУ'])

    melted = pd.melt(
        base,
        id_vars=['Наименование профиля ГОСТ, ТУ'],
        value_vars=['v21', 'v23', 'Наименование профиля ГОСТ, ТУ'],
        var_name='ver',
        value_name='key'
    )
    # оставляем только непустые ключи
    melted = melted[melted['key'].notna() & (melted['key'] != '')]

    # Если один и тот же ключ встречается несколько раз — берём первую запись
    melted = melted.drop_duplicates(subset=['key'], keep='first')

    lookup = dict(zip(melted['key'], melted['Наименование профиля ГОСТ, ТУ']))

    # 2) Применяем маппинг к df
    col = 'Наименование профиля ГОСТ, ТУ'
    src = df[col].astype(str).str.strip().fillna('')

    mapped = src.map(lookup)

    # 3) Логируем и обновляем только найденные
    to_update = mapped.notna() & (mapped != '') & (mapped != src)
    for old_val, new_val in zip(src[to_update], mapped[to_update]):
        cache_key = f"updated_{old_val}"
        if cache_key not in printed_cache:
            log_message(f"Обновлено '{col}' для {old_val}: [{new_val}]")
            printed_cache.add(cache_key)

    df.loc[to_update, col] = mapped[to_update]

    # Предупреждения для тех, кого не нашли
    for missing in sorted(set(src[~mapped.notna()])):
        if missing:  # не трогаем пустые
            log_message(f"Не найдено соответствие '{col}' для профиля [{missing}]", "warn")

    return df

def calculate_section_properties(row, df_base, compare_columns, return_columns, printed_cache=None):
    """
    Универсально ищет значения по сечению и наименованию профиля и возвращает массу и площадь для разных типов сечений.
    Логирует только уникальные профили, чтобы избежать дублирования сообщений.
    Функция поддерживает расчеты для круглых труб, профильных труб и пластин.
    """

    # --- НОВОЕ: пропускаем сборочные единицы ---
    obj_type = str(row.get('Тип объекта') or '').strip()
    if obj_type == "Сборочная единица":
        # Ничего не считаем, просто пропускаем
        return None, None
    # -------------------------------------------

    # Получаем значения из строки для различных столбцов, связанных с сечением
    sketch = str(row.get('Эскиз сечения', "")) if pd.notna(row.get('Эскиз сечения')) else ""
    profile_name_k = str(row.get('Сечение из Компас', "")) if pd.notna(row.get('Сечение из Компас')) else ""
    profile_name = str(row.get('Сечение', "")) if pd.notna(row.get('Сечение')) else ""

    # Проверяем, какой тип сечения
    is_round_pipe = sketch in ['@090', '@130']  # Круглая труба
    is_square_pipe = sketch == '@131'          # Квадратная труба
    is_plate = sketch in ['@016', '@137']      # Пластина

    # === Поиск в базе данных для актуализации значений на основе "Наименование профиля ГОСТ, ТУ" ===
    if not is_plate:
        # Создаем маску для фильтрации данных по столбцам compare_columns
        mask = pd.Series([True] * len(df_base))

        # Фильтруем по столбцам из compare_columns
        for col in compare_columns:
            if col == 'Наименование профиля ГОСТ, ТУ':  # Сначала ищем по наименованию профиля
                mask &= df_base['Наименование профиля ГОСТ, ТУ'] == row.get(col)
            else:
                mask &= df_base[col] == row.get(col)  # Затем по остальным столбцам из compare_columns

        # Применяем маску к базе данных
        filtered_df = df_base[mask]

        if not filtered_df.empty:
            # Берем значения из первой строки по указанным столбцам
            values = tuple(filtered_df.iloc[0][col] for col in return_columns)

            # Преобразуем и округляем значения для массы и площади
            rounded_values = [
                round(float(val), 2) if isinstance(val, (int, float, np.floating)) else val
                for val in values
            ]

            # Формируем ключ для кэширования
            cache_key = ("db", profile_name_k, tuple(rounded_values))
            if printed_cache is None or cache_key not in printed_cache:
                mass_text = f"m={rounded_values[0]} кг/м"
                area_text = f"S={rounded_values[1]} м²/м"
                log_message(f"Найдено в базе: {profile_name} → {mass_text}, {area_text}")

                if printed_cache is not None:
                    printed_cache.add(cache_key)

            return values  # Возвращаем значения для массы и площади

        # Если не нашли, логируем кандидатов
        cache_key = ("not_found", profile_name_k)
        if printed_cache is None or cache_key not in printed_cache:
            log_message(f"Не найдено в базе по {compare_columns} → {[row.get(c) for c in compare_columns]}", "warn")
            if printed_cache is not None:
                printed_cache.add(cache_key)

    # === Геометрический расчёт для различных типов сечений ===
    match = re.search(r'^@(\d{3})\s*([\d.,]+)(?:[xXхХ]\s*([\d.,]+))?(?:[xXхХ]\s*([\d.,]+))?', profile_name_k)
    if match:
        code = match.group(1)  # эскиз сечения
        n2 = match.group(2)    # первый размер
        n3 = match.group(3)    # второй размер (если есть)
        n4 = match.group(4)    # третий размер (если есть)

        def mm(s):
            return float(s.replace(',', '.')) / 1000 if s else None

        if code == '131' and n2 and n3 and n4:
            B = mm(n2)
            H = mm(n3)
            t = mm(n4)
            section_area = B * H - (B - 2 * t) * (H - 2 * t)
            surface_area = 2 * (B + H)
            mass_1m = section_area * STEEL_DENSITY
            return mass_1m, surface_area

        if code == '130' and n2 and n3:
            D = mm(n2)
            t = mm(n3)
            section_area = 3.14159 * ((D ** 2 - (D - 2 * t) ** 2) / 4)
            surface_area = 3.14159 * D
            mass_1m = section_area * STEEL_DENSITY
            return mass_1m, surface_area

        if code in ('016', '137') and row.get('Ширина, мм') and row.get('Толщина, мм'):
            width = float(row['Ширина, мм']) / 1000
            thick = float(row['Толщина, мм']) / 1000
            section_area = width * thick
            surface_area = 2 * (width + thick)
            mass_1m = section_area * STEEL_DENSITY
            return mass_1m, surface_area

    log_message(f"Не удалось определить свойства для {profile_name}", "error")
    return None, None


# def calculate_section_properties(row, df_base, compare_columns, return_columns, printed_cache=None):
#     """
#     Универсально ищет значения по сечению и наименованию профиля и возвращает массу и площадь для разных типов сечений.
#     Логирует только уникальные профили, чтобы избежать дублирования сообщений.
#     Функция поддерживает расчеты для круглых труб, профильных труб и пластин.
#     """
#
#     # Получаем значения из строки для различных столбцов, связанных с сечением
#     sketch = str(row.get('Эскиз сечения', "")) if pd.notna(row.get('Эскиз сечения')) else ""
#     profile_name_k = str(row.get('Сечение из Компас', "")) if pd.notna(row.get('Сечение из Компас')) else ""
#     profile_name = str(row.get('Сечение', "")) if pd.notna(row.get('Сечение')) else ""
#
#     # Проверяем, какой тип сечения
#     is_round_pipe = sketch in ['@090', '@130']  # Круглая труба
#     is_square_pipe = sketch == '@131'  # Квадратная труба
#     is_plate = sketch in ['@016', '@137']  # Пластина
#
#     # === Поиск в базе данных для актуализации значений на основе "Наименование профиля ГОСТ, ТУ" ===
#     if not is_plate:
#         # Создаем маску для фильтрации данных по столбцам compare_columns
#         mask = pd.Series([True] * len(df_base))
#
#         # Фильтруем по столбцам из compare_columns
#         for col in compare_columns:
#             if col == 'Наименование профиля ГОСТ, ТУ':  # Сначала ищем по наименованию профиля
#                 mask &= df_base['Наименование профиля ГОСТ, ТУ'] == row.get(col)
#             else:
#                 mask &= df_base[col] == row.get(col) # Затем по остальным столбцам из compare_columns
#
#         # Применяем маску к базе данных
#         filtered_df = df_base[mask]
#
#         if not filtered_df.empty:
#             # Берем значения из первой строки по указанным столбцам
#             values = tuple(filtered_df.iloc[0][col] for col in return_columns)
#
#             # Преобразуем и округляем значения для массы и площади
#             rounded_values = [
#                 round(float(val), 2) if isinstance(val, (int, float, np.floating)) else val
#                 for val in values
#             ]
#
#             # Формируем ключ для кэширования
#             cache_key = ("db", profile_name_k, tuple(rounded_values))
#             if printed_cache is None or cache_key not in printed_cache:
#                 mass_text = f"m={rounded_values[0]} кг/м"
#                 area_text = f"S={rounded_values[1]} м²/м"
#                 log_message(f"Найдено в базе: {profile_name} → {mass_text}, {area_text}")
#
#                 if printed_cache is not None:
#                     printed_cache.add(cache_key)
#
#             return values  # Возвращаем значения для массы и площади
#
#         # Если не нашли, логируем кандидатов
#         cache_key = ("not_found", profile_name_k)
#         if printed_cache is None or cache_key not in printed_cache:
#             log_message(f"Не найдено в базе по {compare_columns} → {[row.get(c) for c in compare_columns]}", "warn")
#             if printed_cache is not None:
#                 printed_cache.add(cache_key)
#
#     # === Геометрический расчёт для различных типов сечений ===
#     # Используем регулярное выражение для поиска размеров сечения
#     match = re.search(r'^@(\d{3})\s*([\d.,]+)(?:[xXхХ]\s*([\d.,]+))?(?:[xXхХ]\s*([\d.,]+))?', profile_name_k)
#     if match:
#         code = match.group(1) # эскиз сечения
#         n2 = match.group(2)  # первый размер
#         n3 = match.group(3)  # второй размер (если есть)
#         n4 = match.group(4)  # третий размер (если есть)
#
#         def mm(s):
#             return float(s.replace(',', '.')) / 1000 if s else None
#
#         if code == '131' and n2 and n3 and n4:
#             # Профильная труба прямоугольная: @131BxHxT, напр. @131100x80x4
#             B = mm(n2);
#             H = mm(n3);
#             t = mm(n4)
#             section_area = B * H - (B - 2 * t) * (H - 2 * t)  # м²
#             surface_area = 2 * (B + H)  # периметр наружный (м) — если нужен
#             mass_1m = section_area * STEEL_DENSITY  # кг/м
#             return mass_1m, surface_area
#
#         if code == '130' and n2 and n3:
#             # Круглая труба: @130DxT
#             D = mm(n2)
#             t = mm(n3)
#             section_area = 3.14159 * ((D ** 2 - (D - 2 * t) ** 2) / 4)
#             surface_area = 3.14159 * D
#             mass_1m = section_area * STEEL_DENSITY
#             return mass_1m, surface_area
#
#         if code in ('016', '137') and row.get('Ширина, мм') and row.get('Толщина, мм'):
#             # Пластина — уже есть отдельная ветка выше, но оставлю как запасной путь
#             width = float(row['Ширина, мм']) / 1000
#             thick = float(row['Толщина, мм']) / 1000
#             section_area = width * thick
#             surface_area = 2 * (width + thick)
#             mass_1m = section_area * STEEL_DENSITY
#             return mass_1m, surface_area
#
#     log_message(f"Не удалось определить свойства для {profile_name}", "error")
#     return None, None

def get_user_input(prompt, default_value, field_name):
    """
    Функция для запроса ввода у пользователя с предложением дефолтного значения.
    Если пользователь не вводит значение, используется дефолт.
    """
    user_input = input(f'{prompt} [{default_value}]: ').strip()
    if not user_input:
        user_input = default_value
    if not user_input:
        print(f"[WARN] Вы не ввели значение для {field_name}. Пропускаем строку.")
    return user_input

def handle_nonstandard_sheet(row, apply_to_all_flags):
    """
    Обработка строк с 'Нестандартный лист'. Если пользователь подтверждает автозаполнение,
    заполняет все 3 поля: профиль, марку металла и марку стали.
    """
    name = str(row['Наименование']) if pd.notna(row['Наименование']) else ""
    current_profile = str(row['Наименование профиля ГОСТ, ТУ']) if pd.notna(
        row['Наименование профиля ГОСТ, ТУ']) else ""

    # Если текущий профиль "Нестандартный лист"
    if current_profile == "Нестандартный лист":
        # Если уже выбрали "для всех", данные должны быть записаны, если они отсутствуют в строке
        if apply_to_all_flags.get('profile_all'):
            # Записываем данные, если поле пустое или содержит "Нестандартный лист"
            if pd.isna(row['Наименование профиля ГОСТ, ТУ']) or row['Наименование профиля ГОСТ, ТУ'] == "Нестандартный лист":
                row['Наименование профиля ГОСТ, ТУ'] = apply_to_all_flags['profile_value']
            if pd.isna(row['Наименование или марка металла ГОСТ, ТУ']) or row['Наименование или марка металла ГОСТ, ТУ'] == "Нестандартный лист":
                row['Наименование или марка металла ГОСТ, ТУ'] = apply_to_all_flags['metal_value']

            # Автоизвлечение марки стали
            steel_match = re.search(r'(С\d+)', apply_to_all_flags['metal_value'])
            if pd.isna(row['Марка стали']) and steel_match:
                row['Марка стали'] = steel_match.group(1)
            if pd.isna(row['Наименование материала']) and steel_match:
                row['Наименование материала'] = steel_match.group(1)

            return row

        log_message(f'У элемента {row["№ элемента"]} {row["Сечение"]}:', "how")

        # Вопрос 1: Наименование профиля
        profile_value = get_user_input(
            'В "Наименование профиля ГОСТ, ТУ" записано "Нестандартный лист" — записать',
            "Прокат листовой г/к ГОСТ 19903-2015", "Наименование профиля ГОСТ, ТУ"
        )
        row['Наименование профиля ГОСТ, ТУ'] = profile_value

        # Вопрос 2: Наименование или марка металла
        metal_value = get_user_input(
            'В "Наименование или марка металла ГОСТ, ТУ" записать',
            "С245 ГОСТ 27772-2021", "Наименование или марка металла ГОСТ, ТУ"
        )
        row['Наименование или марка металла ГОСТ, ТУ'] = metal_value

        # Автоизвлечение марки стали
        steel_match = re.search(r'(С\d+)', metal_value)
        if steel_match:
            row['Марка стали'] = steel_match.group(1)
            row['Наименование материала'] = steel_match.group(1)

        # Вопрос 3: Принять для всех
        apply_all = input('Принять введенные данные для всех элементов? [Enter=Да / n=Нет]: ').strip()
        if apply_all.lower() in ["", "y", "да"]:
            apply_to_all_flags['profile_all'] = True
            apply_to_all_flags['profile_value'] = profile_value
            apply_to_all_flags['metal_value'] = metal_value
        else:
            apply_to_all_flags['profile_all'] = False  # Сброс флага для следующей строки
            apply_to_all_flags['profile_value'] = None
            apply_to_all_flags['metal_value'] = None

    return row

def fill_missing_profile_data(row, apply_to_all_flags, printed_cache=None):
    """
    Заполняет только пустые ячейки:
    - 'Марка стали'
    - 'Наименование или марка металла ГОСТ, ТУ'
    - 'Наименование профиля ГОСТ, ТУ'
    """
    num = str(row['№ элемента']) if pd.notna(row['№ элемента']) else ""
    name = str(row['Наименование']) if pd.notna(row['Наименование']) else ""
    sketch = str(row['Эскиз сечения']) if pd.notna(row['Эскиз сечения']) else ""

    # Если эскиз пустой — ничего не делаем
    if not sketch:
        return row

    # Словарь дефолтов по эскизам
    default_values_by_sketch = {
        "@016": {
            "profile": "Прокат листовой г/к ГОСТ 19903-2015",
            "metal": "С245 ГОСТ 27772-2021",
            "steel": "С245",
        },
        "@137": {
            "profile": "Прокат сортовой стальной горячекатанный полосовой ГОСТ 103-2006",
            "metal": "Ст3пс ГОСТ 380-2005",
            "steel": "Ст3пс",
        },
        "@130": {
            "profile": "Трубы стальные водогазопроводные ГОСТ 3262-75",
            "metal": "Сталь 10 ГОСТ 1050-2013",
            "steel": "Сталь 10",
        },
        "@131": {
            "profile": "Профили стальные гнутые сварные квадратные и прямоугольные для строительных конструкций ГОСТ 30245-2003",
            "metal": "С245 ГОСТ 27772-2021",
            "steel": "С245",
        },
        "@136": {
            "profile": "Труба стальные профильные для металлоконструкций ГОСТ 32931-2015",
            "metal": "С245 ГОСТ 27772-2021",
            "steel": "С245",
        },
        "@140": {
            "profile": "Уголоки стальные горячекатаные неравнополочный ГОСТ 8510-86",
            "metal": "С245 ГОСТ 27772-2021",
            "steel": "С245",
        },
        "@142": {
            "profile": "Двутавры стальные горячекатаные с параллельными гранями полок ГОСТ Р 57837-2017",
            "metal": "С255 ГОСТ 27772-2021",
            "steel": "С255",
        },
        "@143": {
            "profile": "Швеллеры стальные горячекатанные ГОСТ 8240-97",
            "metal": "С245 ГОСТ 27772-2021",
            "steel": "С245",
        }
    }

    # Глобальные дефолты, если эскиз отсутствует в словаре
    global_defaults = {
        "profile": "Прокат листовой г/к ГОСТ 19903-2015",
        "metal": "С245 ГОСТ 27772-2021",
        "steel": "С245",
    }
    defaults = default_values_by_sketch.get(sketch, global_defaults)

    # Дублируем значение из 'Наименование материала' в 'Марка стали'
    if pd.notna(row['Наименование материала']) and str(row['Наименование материала']).strip() != "":
        row['Марка стали'] = row['Наименование материала']

    # Список пустых колонок для обработки
    empty_cols = []
    for col in ['Марка стали', 'Наименование или марка металла ГОСТ, ТУ', 'Наименование профиля ГОСТ, ТУ', 'Наименование материала']:
        if pd.isna(row[col]) or str(row[col]).strip() == "":
            empty_cols.append(col)

    if not empty_cols:
        return row

    # --- 1. Автоприменение, если есть сохранённые значения для этого эскиза
    if sketch in apply_to_all_flags:
        vals = apply_to_all_flags[sketch]
        for col, key in zip(
                ['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Марка стали', 'Наименование материала'],
                ['profile_value', 'metal_value', 'steel_value']):
            if col in empty_cols:
                row[col] = vals[key]
        log_message(f"[OK] Автоприменение ранее введённых данных для эскиза {sketch}", "info")
        return row

    # --- 2. Попытка восстановления из 'Наименование'
    restored = {}
    # Словарь для хранения информации о том, были ли столбцы пустыми до обработки
    initial_empty_cols = {}

    if 'Марка стали' in empty_cols:
        initial_empty_cols['Марка стали'] = True
    else:
        initial_empty_cols['Марка стали'] = False

    if 'Наименование материала' in empty_cols:
        initial_empty_cols['Наименование материала'] = True
    else:
        initial_empty_cols['Наименование материала'] = False

    if 'Наименование или марка металла ГОСТ, ТУ' in empty_cols:
        initial_empty_cols['Наименование или марка металла ГОСТ, ТУ'] = True
    else:
        initial_empty_cols['Наименование или марка металла ГОСТ, ТУ'] = False

    if 'Наименование профиля ГОСТ, ТУ' in empty_cols:
        initial_empty_cols['Наименование профиля ГОСТ, ТУ'] = True
    else:
        initial_empty_cols['Наименование профиля ГОСТ, ТУ'] = False


    if 'Марка стали' in empty_cols:
        steel_match = re.search(r'(С\d+)', name)
        if steel_match:
            steel_value = steel_match.group(1)
            # print(f'[OK] ["Марка стали"] - извлекли из наименования {steel_value}')
            row['Марка стали'] = steel_value
            restored['Марка стали'] = steel_value

    if 'Наименование материала' in empty_cols:
        steel_match = re.search(r'(С\d+)', name)
        if steel_match:
            steel_value = steel_match.group(1)
            # print(f'[OK] ["Наименование материала"] - извлекли из наименования {steel_value}')
            row['Наименование материала'] = steel_value
            restored['Наименование материала'] = steel_value

    if 'Наименование или марка металла ГОСТ, ТУ' in empty_cols:
        metal_match = re.search(r'(С\d+\s+ГОСТ\s+\d{4,5}-\d{2,4})', name)
        if metal_match:
            # print(f'[OK] ["Наименование или марка металла ГОСТ, ТУ"] - извлекли из наименования {metal_match.group(1)}')
            row['Наименование или марка металла ГОСТ, ТУ'] = metal_match.group(1)
            restored['Наименование или марка металла ГОСТ, ТУ'] = metal_match.group(1)

    if 'Наименование профиля ГОСТ, ТУ' in empty_cols:
        row['Наименование профиля ГОСТ, ТУ'] = defaults["profile"]
        restored['Наименование профиля ГОСТ, ТУ'] = defaults["profile"]

    if restored:
        cache_key = f"restored_{num}_{sketch}_{restored.get('Марка стали', '')}_{restored.get('Наименование или марка металла ГОСТ, ТУ', '')}_{restored.get('Наименование профиля ГОСТ, ТУ', '')}"

        # Формируем строку для лога с ключами и их значениями
        restored_info = [f'{key}: {value}' for key, value in restored.items()]

        if printed_cache is None or cache_key not in printed_cache:
            log_message(f'Обрабатываем элемент {num}', "magenta")
            log_message(f"[OK] Восстановлено для \"{num} {name}\": {', '.join(restored_info)}", "info")

            if printed_cache is not None:
                printed_cache.add(cache_key)
        return row

    # --- 3. Ручной ввод с дефолтами
    log_message(f"[WARN] Не удалось восстановить данные → {row['№ элемента']} {name}", "warn")

    # Предлагаем значения только для пустых ячеек
    if 'Наименование профиля ГОСТ, ТУ' in empty_cols:
        profile_value = input(
            f'Элемент {row["№ элемента"]} {row["Сечение"]} с пустым "Наименование профиля ГОСТ, ТУ" → [{defaults["profile"]}]: [Enter=Да / своё]: '
        ).strip() or defaults["profile"]
        row['Наименование профиля ГОСТ, ТУ'] = profile_value
    else:
        profile_value = row['Наименование профиля ГОСТ, ТУ']

    if 'Наименование или марка металла ГОСТ, ТУ' in empty_cols:
        metal_value = input(
            f'Элемент {row["№ элемента"]} {row["Сечение"]} с пустым "Наименование или марка металла ГОСТ, ТУ" → [{defaults["metal"]}]: [Enter=Да / своё]:'
        ).strip() or defaults["metal"]
        row['Наименование или марка металла ГОСТ, ТУ'] = metal_value
    else:
        metal_value = row['Наименование или марка металла ГОСТ, ТУ']

    if 'Марка стали' in empty_cols:
        steel_match = re.search(r'(\S+)(?=\s+ГОСТ)', metal_value)
        if steel_match:
            # steel_value = steel_match.group(1) if steel_match else defaults["steel"]
            steel_value = input(f'Элемент {row["№ элемента"]} {row["Сечение"]} с пустым "Марка стали" → [{steel_match.group(1)}]: [Enter=Да / своё]:'
            ).strip() or steel_match.group(1)
            row['Марка стали'] = steel_value
        else:
            steel_value = input(f'Элемент {row["№ элемента"]} {row["Сечение"]} с пустым "Марка стали" → [С245]: [Enter=Да / своё]:').strip() or "С245"
            # sys.exit()

    else:
        steel_value = row['Марка стали']

    # --- 4. Принять для всех
    # Собираем информацию только для тех столбцов, которые были пустыми до обработки
    output_info = []
    if initial_empty_cols['Наименование профиля ГОСТ, ТУ']:
        output_info.append(f'    "Наименование профиля ГОСТ, ТУ": [{profile_value}]')
    if initial_empty_cols['Наименование или марка металла ГОСТ, ТУ']:
        output_info.append(f'    "Наименование или марка металла ГОСТ, ТУ": [{metal_value}]')
    if initial_empty_cols['Марка стали']:
        output_info.append(f'    "Марка стали": [{steel_value}]')

    print("Итого:")
    print("\n".join(output_info))

    apply_all = input(f'Принять эти данные для всех элементов с эскизом "{sketch}"? [Enter=Да / n=Нет]: ').strip()
    if apply_all.lower() in ["", "y", "да"]:
        apply_to_all_flags[sketch] = {
            "profile_value": profile_value,
            "metal_value": metal_value,
            "steel_value": steel_value
        }

    # Кэширование для уникальных сообщений
    cache_key = f"restored_{sketch}_{profile_value}_{metal_value}_{steel_value}"
    if printed_cache is None or cache_key not in printed_cache:
        log_message(f"Восстановлено для сечения {sketch}: {profile_value}, {metal_value}, {steel_value}", "info")
        if printed_cache is not None:
            printed_cache.add(cache_key)

    return row

def sheet0(file_path: str):
    """
    Готовит новый 'Общий отчёт.xlsx' с колонками:
    - Сечение (читаемое имя)
    - Масса 1 м, кг
    - Площадь 1 м, м²
    """
    print()
    log_message(f'Выполняю предварительную обработку отчёта после Компас 3d...', 'title')
    excel_handler = ExcelHandler(file_path)
    df = excel_handler.read_excel(header_row=0)

    # --- ПРОВЕРКА: есть ли вообще заполненные значения в "Сечение" ---
    sec = df['Сечение'].astype('string')  # сохраняет <NA>, не делает "nan"
    mask_section_filled = sec.notna() & (sec.str.strip() != '')

    if not mask_section_filled.any():
        log_message('Похоже полученый отчёт выгружен не из активной модели, а из модели открытой в фоне', 'error')
        log_message('Переключитесь на другую вкладку и вновь на требуемую сборку, либо (лучше) перезапустите Компас', 'warn')
        input('Нажмите Enter, чтобы завершить…')
        return None

    # нормализуем пробелы/неразрывные пробелы и тримим
    df.columns = (df.columns.astype(str)
                  .str.replace('\u00A0', ' ', regex=False)
                  .str.replace(r'\s+', ' ', regex=True)
                  .str.strip())

    # мирно решаем коллизию "Сечение" vs "Сечение из Компас"
    if 'Сечение' in df.columns and 'Сечение из Компас' in df.columns:
        df['Сечение из Компас'] = df['Сечение из Компас'].where(
            df['Сечение из Компас'].astype(str).str.strip() != '', df['Сечение']
        )
        df = df.drop(columns=['Сечение'])
    elif 'Сечение' in df.columns:
        df = df.rename(columns={'Сечение': 'Сечение из Компас'})

    # Переименуем столбцы
    df = df.rename(columns={
        'КМД. Общий отчет по металлоконструкциям': '№ элемента', 'Количество': 'Кол-во, шт.',
        'Длина': 'Длина, мм', 'Ширина': 'Ширина, мм', 'Толщина': 'Толщина, мм',
        'Масса элемента': 'Масса элемента, кг', 'Масса элементов':'Масса элементов, кг',
        'Сечение': 'Сечение из Компас'
    })

    # Нормализация всех текстовых столбцов ТОЛЬКО для строк с непустым "Эскиз сечения"
    exclude_cols = {'Полное имя файла', '№ элемента'}  # сюда добавь поля, которые трогать не надо

    # маска строк, где "Эскиз сечения" не пустой
    if 'Эскиз сечения' in df.columns:
        _esk = df['Эскиз сечения'].astype('string')
        mask_sketch = _esk.notna() & (_esk.str.strip() != '')
    else:
        mask_sketch = pd.Series(False, index=df.index)

    # берём все текстовые столбцы (object или pandas StringDtype), кроме исключений
    obj_cols = [
        c for c in df.columns
        if c not in exclude_cols and (pd.api.types.is_string_dtype(df[c]) or df[c].dtype == 'object')
    ]

    for col in obj_cols:
        s = df.loc[mask_sketch, col].astype('string')  # <NA> сохраняется, не превращается в "nan"
        s = (
            s.str.replace('\u00A0', ' ', regex=False)  # неразрывные пробелы -> пробел
            .str.replace('—', '-', regex=False).str.replace('–', '-', regex=False)  # тире -> '-'
            # x/×/х только между цифрами: 75 х 75 × 6 -> 75x75x6
            .str.replace(r'(?<=\d)\s*[×хХXx]\s*(?=\d)', 'x', regex=True)
            # убрать пробелы вокруг дефиса только в числовых диапазонах: 20 - 40 -> 20-40
            .str.replace(r'(?<=\d)\s*-\s*(?=\d)', '-', regex=True)
            # десятичная запятая только в числах: 12,50 -> 12.50
            .str.replace(r'(?<=\d),(?=\d)', '.', regex=True)
            # срезать хвостовые нули в дробях: 12.500 -> 12.5
            .str.replace(r'(?<=\d)\.(\d*[1-9])0+\b', r'.\1', regex=True)
            # убрать .0 / .00 в конце: 6.0 -> 6
            .str.replace(r'(?<=\d)\.0+\b', '', regex=True)
            .str.replace(r'\s+', ' ', regex=True)  # схлопнуть пробелы
            .str.strip()
        )
        df.loc[mask_sketch, col] = s

    if 'Сечение из Компас' in df.columns:
        df.loc[mask_sketch, 'Сечение из Компас'] = (
            df.loc[mask_sketch, 'Сечение из Компас']
            .astype('string')
            .map(lambda x: unicodedata.normalize('NFKC', x))  # 0) Unicode NFKC
            .str.replace('[\u00A0\u202F\u2007]', ' ', regex=True)  # 1) спец-пробелы → пробел
            .str.replace('—', '-', regex=False).str.replace('–', '-', regex=False)
            .str.replace(',00', '', regex=False)  # 2) хвостовое ,00
            .str.replace('х', 'x').str.replace('Х', 'x')  # 3) кир. х/Х → лат. x
            .str.replace(r'\s+', ' ', regex=True).str.strip()  # 4) схлопнуть пробелы
            .str.replace(r'(?<=\S)\s+(?=\S)', '', regex=True)  # 5) убрать внутренние пробелы
            .str.replace('B', 'Б').str.replace('b', 'б')  # 6) лат. B/b → кир. Б/б
            .str.replace(r'^@(\d{3})(.*)$',
                         lambda m: '@' + m.group(1) + m.group(2).upper(),
                         regex=True)  # 7) суффикс после @### → UPPER
            .str.replace(r'(?<=\d)X(?=\d)', 'x', regex=True)
        )

    # === Маска для строк с непустым эскизом ===
    mask_sketch = df['Эскиз сечения'].notna() & (df['Эскиз сечения'].astype(str).str.strip() != '')

    # Обработка столбца "Наименование" (только очистка пробелов)
    df['Наименование'] = (df['Наименование'].astype(str).str.replace(r'\s+', ' ', regex=True).str.strip())

    # Проверяем наличие обозначения и наименования у элементов
    not_empty_sketch = df['Эскиз сечения'].notna() & (df['Эскиз сечения'] != '')# Фильтр строк, где Эскиз сечения не пустой

    # Проверка на пропуски в "№ элемента" или "Наименование" среди этих строк
    mask = not_empty_sketch & (df['№ элемента'].astype(str).str.strip().eq('') | df['Наименование'].astype(str).str.strip().eq(''))

    if mask.any():
        # Получаем проблемные строки с нужными столбцами
        bad_rows_df = df.loc[mask, ['№ элемента', 'Наименование', 'Полное имя файла']]

        log_message(f'Обнаружены строки с пустыми значениями в "Обозначение" или "Наименование"', 'error')
        log_message(f'Файлы с проблемными строками:', 'warn')

        # Вывод уникальных файлов
        for filename in bad_rows_df['Полное имя файла'].dropna().unique():
            print(f" - {filename}")

        # Вывод подробной информации
        print("\nПодробности по проблемным строкам:")
        for _, row in bad_rows_df.iterrows():
            print(f"Строка: | № элемента: {row['№ элемента']} | Наименование: {row['Наименование']} | {row['Полное имя файла']}")

        input(log_message(f'Следует исправить ошибки', 'error'))

    # Вычисляем "Кол-во, шт." только для строк с эскизом
    df.loc[mask_sketch, 'Кол-во, шт.'] = (df.loc[mask_sketch, ['Так', 'Наоборот']].fillna(0).sum(axis=1).astype(int))

    # Создаем колонку "Сечение" с заменой кодов профилей
    excel_handler.data = df
    df['Сечение'] = df['Сечение из Компас']
    df = excel_handler.replace_symbols('Сечение')

    # === Извлекаем толщину и ширину для пластин @016 и @137 ===
    mask_plate = df['Эскиз сечения'].isin(['@016', '@137'])
    df.loc[mask_plate] = df.loc[mask_plate].apply(parse_plate_section, axis=1)

    # === Заполняем профили и марки стали для нестандартных листов ===
    apply_to_all_flags = {'profile_all': False}
    df = df.apply(lambda row: handle_nonstandard_sheet(row, apply_to_all_flags), axis=1)

    # Восстанавливаем ГОСТ на сталь и ГОСТ на профиль для остальных из наименования
    apply_to_all_flags = {} # сюда будут сохраняться значения "для всех" по эскизам
    printed_cache = set() # Создаём пустой set для кэширования сообщений

    # Применяем функцию к каждой строке DataFrame и передаем printed_cache для хранения уникальных сообщений
    df = df.apply(lambda row: fill_missing_profile_data(row, apply_to_all_flags, printed_cache=printed_cache),axis=1)

    # Загружаем базу
    excel_handler_base = ExcelHandler(_Config.xlsx_base)
    df_base = excel_handler_base.read_excel()

    printed_cache = set()  # Инициализируем кэш
    # Создаём маску для строк у которых не пусто в в 'Эскиз сечения'
    mask_sketch = df['Эскиз сечения'].notna() & (df['Эскиз сечения'].astype(str).str.strip() != '')
    # Актуализируем столбец "Наименование профиля ГОСТ, ТУ" только к строкам с непустым "Эскиз сечения"
    df.loc[mask_sketch] = update_profile_names(df.loc[mask_sketch], df_base, printed_cache)

    # Выполняем поиск массы 1 м кг и м2
    log_message('Заполняем значения массы и площади 1 м', 'magenta')

    # Добавляем новые столбцы
    df['Масса 1 м, кг'] = np.nan
    df['Площадь 1 м, м²'] = np.nan

    # Маска: обрабатываем только непустые сечения
    mask = df['Сечение'].notna() & (df['Сечение'].astype(str).str.strip() != '')

    printed_cache = set()  # Кэш уже напечатанных профилей

    def wrapper(row):
        # Вызов функции calculate_section_properties и обновление значений на основе полученных данных
        mass, area = calculate_section_properties(
            row,
            df_base,
            ['Наименование профиля ГОСТ, ТУ', 'Сечение из Компас'],
            ['Масса 1 м, кг', 'Площадь 1 м, м2'],
            printed_cache=printed_cache
        )

        # Возвращаем все три значения как Series для обновления столбцов
        return pd.Series([mass, area])

    # Применяем wrapper ко всем строкам, где mask = True
    calc_df = df.loc[mask].apply(wrapper, axis=1)

    # Устанавливаем имена колонок
    calc_df.columns = ['Масса 1 м, кг', 'Площадь 1 м, м²']

    # Записываем вычисленные значения обратно в DataFrame
    df.loc[mask, ['Масса 1 м, кг', 'Площадь 1 м, м²']] = calc_df.values

    # print_df(df, 'Наименование профиля ГОСТ, ТУ')
    # sys.exit()

    new_path = Path(file_path).with_suffix('.xlsx')
    df.to_excel(new_path, index=False)
    print(f'Файл подготовлен: {new_path}')
    return new_path

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    # xls = r"C:\Users\ik\Desktop\!!2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\!01 _ CAD!\Материалы\Общий отчёт.xls"
    xls = easygui.fileopenbox(msg="Укажите файл отчета", title="",
                              default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта

    # print_df(df, ['Марка стали', 'Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Наименование материала'])
    # # sys.exit()
    sheet0(xls)

