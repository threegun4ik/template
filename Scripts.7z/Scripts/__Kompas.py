import _Config, sys, subprocess, os
from traceback import format_exc
from pathlib import Path
from __Debug import log_message

try:
    from pythoncom import connect, VT_EMPTY
    from win32com.client import gencache, VARIANT
    con0 = gencache.EnsureModule('{75C9F5D0-B5B8-4526-8681-9903C567D2ED}', 0, 1, 0).constants  # kompas6_constants
    con3 = gencache.EnsureModule('{2CAF168C-7961-4B90-9DA2-701419BEEFE3}', 0, 1, 0).constants  # kompas6_constants_3d
    API5 = gencache.EnsureModule('{0422828C-F174-495E-AC5D-D31014DBBE87}', 0, 1, 0)  # kompas6_api5_module
    API7 = gencache.EnsureModule('{69AC2981-37C0-4379-84FD-5DD2F3C0A520}', 0, 1, 0)  # kompas_api7_module
except:
    input(log_message(f'Ошибка {format_exc()}', 'error'))
    sys.exit()

def get_kompas():
    """Гарантирует, что KompasConnector и KompasUtils активны."""
    global KompasObject, iApplication, KompasVersion
    KompasObject, iApplication = None, None
    try:
        KompasObject = API5.KompasObject(connect('Kompas.Application.5'))
        # created_kompas = False
    except:
        log_message(f'КОМПАС-3D не запущен. Запускаем...', 'warn')
        from pythoncom import CoCreateInstance, CLSCTX_SERVER, IID_IDispatch
        KompasObject = API5.KompasObject(CoCreateInstance('Kompas.Application.5', None, CLSCTX_SERVER, IID_IDispatch))
        KompasObject.Visible = True
        # created_kompas = True

    KompasVersion = KompasObject.ksGetSystemVersion(0, 0, 0, 0)[1]  # Получить номер версии системы
    iApplication = KompasObject.ksGetApplication7()
    return KompasObject, iApplication, KompasVersion

def check_access(script_name: str) -> bool:
    path_to_scripts = Path(_Config.path_to_scripts)
    LICENSE_CHECKER_PATH =  path_to_scripts / 'Scripts' / 'LicenseChecker.exe'
    # LICENSE_CHECKER_PATH = path_to_scripts / 'LicenseChecker.exe'
    result = subprocess.run(
        [LICENSE_CHECKER_PATH, "--script", script_name],
        capture_output=True,
        text=True
    )

    output = result.stdout.strip()
    return output == "OK"

def kompas_file_unlock(iApplication):
    """Обходной путь для разблокировки папки."""
    try:
        path_to_scripts = Path(_Config.path_to_scripts)
        file_test = path_to_scripts / 'Template' / 'Марка.a3t'
        iDocuments = iApplication.Documents
        iKompasDocument = iDocuments.Open(file_test, False, True)
        iKompasDocument.Close(0)
    except:
        print()

def get_active_doc_path(iApplication):
    """Получает путь к активному документу в Компас-3D."""
    if iApplication is None:
        print("Ошибка: iApplication не инициализирован.")
        return None
    try:
        iKompasDocument = iApplication.ActiveDocument
        return iKompasDocument.Path if iKompasDocument else None
    except Exception as e:
        print(f"Ошибка получения активного документа: {e}")
        return None

def delete_history(file_path):
    """Удаляет историю у указанного файла."""
    iDocuments = iApplication.Documents
    iKompasDocument = iDocuments.Open(file_path, False, False)
    iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
    iKompasDocument3D.DeleteHistory()
    iKompasDocument3D.Close(1)

def get_gabarit_object(object, iKompasDocument2D1):
    '''
    Args:
        object: Таблицы, виды, иные объекты
    Returns:
        Возвращает высоты и длину объекта
    '''
    if KompasVersion > 21:
    # if KompasVersion == 21:
        _, x1, y1, x2, y2 = iKompasDocument2D1.GetObjectsGabarit(object)
        shift = 0
        x1, y1, x2, y2 = (x1 + shift, y1 + shift, x2 - shift, y2 - shift)
        obg_X = x2 - x1
        obg_Y = y2 - y1
        return obg_X, obg_Y, x1, y1, x2, y2

    else:
        iDrawingObject = API7.IDrawingObject(object)
        reference = iDrawingObject.Reference
        rect_param = KompasObject.GetParamStruct(con0.ko_RectParam)
        iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument2D1)
        iDocument2D = KompasObject.TransferInterface(iKompasDocument2D, 1, 0)
        # iDocument2D = KompasObject.ActiveDocument2D()
        iDocument2D.ksGetObjGabaritRect(reference, rect_param)

        x1 = rect_param.GetpBot().x  # Получить параметры левой нижней точки прямоугольника
        y1 = rect_param.GetpBot().y  # Получить параметры левой нижней точки прямоугольника
        x2 = rect_param.GetpTop().x  # Получить параметры правой верхней точки прямоугольника
        y2 = rect_param.GetpTop().y  # Получить параметры правой верхней точки прямоугольника
        obg_X = x2 - x1
        obg_Y = y2 - y1
        return obg_X, obg_Y, x1, y1, x2, y2
    return None

def get_gabarit_geom(iView, iKompasDocument2D1):
    """Выдает габаритный прямоугольник без размеров"""
    iDrawingGroups = iKompasDocument2D1.DrawingGroups
    iDrawingContainer = API7.IDrawingContainer(iView)
    iDrawingGroup_tmp = iDrawingGroups.Add(True, f"TEMP")

    for c in [iDrawingContainer.LineSegments, iDrawingContainer.Circles, iDrawingContainer.Arcs]:
        for n in range(c.Count):
            iDrawingGroup_tmp.AddObjects(c.Item(n))
    obg_X, obg_Y, x1, y1, x2, y2 = get_gabarit_object(iDrawingGroup_tmp, iKompasDocument2D1)
    return {
        "x1": x1, "y1": y1,
        "x2": x2, "y2": y2,
        "width": obg_X, "height": obg_Y
    }

def get_gabarit_geom_and_dimension(iView, iKompasDocument2D1):
    """Выдает габаритный прямоугольник без размеров"""
    iDrawingGroups = iKompasDocument2D1.DrawingGroups
    iDrawingContainer = API7.IDrawingContainer(iView)

    iDrawingGroup_tmp = iDrawingGroups.Add(True, f"TEMP")

    for c in [iDrawingContainer.LineSegments, iDrawingContainer.Circles, iDrawingContainer.Arcs]:
        for n in range(c.Count):
            iDrawingGroup_tmp.AddObjects(c.Item(n))

    iSymbols2DContainer = API7.ISymbols2DContainer(iView)

    for c in [iSymbols2DContainer.LineDimensions, iSymbols2DContainer.DiametralDimensions, iSymbols2DContainer.RadialDimensions]:
        for n in range(c.Count):
            iDrawingGroup_tmp.AddObjects(c.Item(n))

    obg_X, obg_Y, x1, y1, x2, y2 = get_gabarit_object(iDrawingGroup_tmp, iKompasDocument2D1)

    return {
        "x1": x1, "y1": y1,
        "x2": x2, "y2": y2,
        "width": obg_X, "height": obg_Y
    }

def format_scale(scale: float) -> str:
    # Проверка на недопустимые значения (масштаб не может быть нулевым или отрицательным)
    if scale <= 0:
        raise ValueError("Масштаб должен быть положительным числом")

    if scale >= 1:
        # Левый операнд — scale, правый — 1
        left_value = scale
        right_value = 1.0
    else:
        # Если масштаб меньше 1, левый операнд — 1, правый — обратное число
        left_value = 1.0
        right_value = 1.0 / scale

    # Форматируем левый и правый операнд с одной десятичной цифрой
    left_str = f"{left_value:.1f}"
    right_str = f"{right_value:.1f}"

    # Удаляем незначащие ".0" в конце, если число целое
    if left_str.endswith(".0"):
        left_str = left_str[:-2]
    if right_str.endswith(".0"):
        right_str = right_str[:-2]

    return f"{left_str}:{right_str}"

def rgb_to_bgr_int(color_name=None, red=None, green=None, blue=None):
    """Преобразует RGB в формат BGR (int) для КОМПАС-3D."""
    color_dict = {
        "red": (255, 0, 0),
        "green": (0, 255, 0),
        "blue": (0, 0, 255),
        "yellow": (255, 255, 0)
    }
    if color_name:
        color_name = color_name.lower()
        if color_name in color_dict:
            red, green, blue = color_dict[color_name]
        else:
            raise ValueError(f"Неизвестное имя цвета: {color_name}")
    if red is not None and green is not None and blue is not None:
        return (blue << 16) | (green << 8) | red
    else:
        raise ValueError("Необходимо передать red, green и blue или имя цвета.")


if __name__ == "__main__":

    print("Это служебный скрипт, сам по себе он ничего не делает")
    KompasObject, iApplication, KompasVersion = get_kompas()  # Обязательно вызываем для проверки состояния Компаса при запуске скрипта

    # print((KompasObject.ksSystemPath(5) + r'\Pdf2d.dll'))
    # mod = gencache.EnsureModule('{69AC2981-37C0-4379-84FD-5DD2F3C0A520}', 0, 1, 0)
    # print(mod.__file__)  # Путь к .py-файлу с интерфейсами

    print(KompasVersion)
    # iKompasDocument = iApplication.ActiveDocument
    # iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    # iKompasDocument2D1 = API7.IKompasDocument2D1(iKompasDocument2D)
    # iViews = iKompasDocument2D.ViewsAndLayersManager.Views
    # iView = iViews.ActiveView
    # t = get_gabarit_geom_and_dimension(iView, iKompasDocument2D1)