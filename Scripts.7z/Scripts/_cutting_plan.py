import sys, os
import openpyxl
from openpyxl.styles import PatternFill, Border, Alignment, Side
import pandas as pd
import re
import random, easygui
import colorsys
from __Kompas import *
from _Config import *

def xls_to_cdw(df, cell_widths, row_heights, merge_cells, text_styles, x=0, y=0, iKompasDocument=None):
    n_x = df.shape[0]  # Количество строк
    n_y = df.shape[1]  # Количество столбцов

    documentType = iKompasDocument.DocumentType

    if documentType != 1:
        iApplication.MessageBoxEx('Активный документ не чертеж', 'Ошибка', 0)
        sys.exit()

    #  Создай графический объект "Таблица"
    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
    iViews = iViewsAndLayersManager.Views
    iView = iViews.ActiveView
    iSymbols2DContainer = API7.ISymbols2DContainer(iView)
    iDrawingTables = iSymbols2DContainer.DrawingTables
    iDrawingTable = iDrawingTables.Add(n_x, n_y, 30.0, 30.0, 1) #Тут размер таблицы
    iDrawingTable.X = x
    iDrawingTable.Y = y
    iDrawingTable.Angle = 0.0
    iDrawingTable.FixedCellsSize = False
    iDrawingTable.FixedRowCount = False
    iDrawingTable.FixedColumnCount = False
    iTable = API7.ITable(iDrawingTable)
    cell_number = 0
    # Перебор каждой ячейки таблицы

    # Проход по строкам и столбцам DataFrame
    for row_index in range(df.shape[0]):  # Количество строк
        for col_index in range(df.shape[1]):  # Количество столбцов
            # Получение значения ячейки
            # cell_value = cell_number  # Нумерация по порядку

            # Индекс для доступа к нужному элементу в списке text_param
            index = row_index * df.shape[1] + col_index

            horizontal_align, vertical_align, italic, bold = text_styles[index]
            # print(horizontal_align, vertical_align, italic, bold)
            alignments = {
                'Left': con0.ksAlignLeft,
                'Center': con0.ksAlignCenter,
                'Right': con0.ksAlignRight,
                'General': con0.ksAlignCenter
            }

            # print(f"Строка {row_index}, Столбец {col_index}: {horizontal_align}, {vertical_align}, Italic={italic}, Bold={bold}")
            cell_number += 1
            iTableCell = iTable.CellById(cell_number)  # Номер ячейки
            iCellFormat = API7.ICellFormat(iTableCell)
            iCellFormat.TextStyle = 10
            iCellFormat.ReadOnly = False
            iCellFormat.OneLine = False
            # iCellFormat.LeftEdge = 0.5
            # iCellFormat.RightEdge = -0.5
            # iCellFormat.SpaceBefore = 0.0
            # iCellFormat.SpaceAfter = 0.0
            iCellFormat.Width = cell_widths[cell_number - 1]
            iCellFormat.Height = row_heights[row_index] #Высота строки
            iCellFormat.HFormat = con0.ksHFormatDivision
            iCellFormat.VFormat = True

            iText = API7.IText(iTableCell.Text)
            iText.Style = con0.ksTSTableCell  # Текст для таблицы (ячейка)

            iTextLine = iText.Add()
            iTextLine.Style = con0.ksHFormatDivision
            iTextLine.Step = 1.0

            iTextLine.Align = alignments.get(horizontal_align, iTextLine.Align)
            iTextLine.IndentedLine = 0.0
            iTextLine.StepBeforeParagraph = 0.0
            iTextLine.StepAfterParagraph = 0.0
            iTextLine.LeftEdge = 1.0
            iTextLine.RightEdge = 1.0
            iTextLine.Level = 0
            # iTextLine.Numbering = con0.ksTNumbNoNumber
            # iTextLine.NewPage = False

            iTextItem = iTextLine.Add()
            iTextItem.ItemType = con0.ksTItString
            iTextItem.NewLine = True

            if pd.isna(df.iat[row_index, col_index]):
                iTextItem.Str = ""  # Если значение NaN, присваиваем пустую строку
            else:
                # Преобразуем значение в строку с заменой точки на запятую
                val = df.iat[row_index, col_index]
                iTextItem.Str = f"{val}".replace('.', ',') if isinstance(val, float) else str(val)

            iTextFont = API7.ITextFont(iTextItem)
            iTextFont.FontName = "GOST Type AU"
            iTextFont.Height = 2.5
            iTextFont.WidthFactor = 1.0
            iTextFont.Color = 0
            iTextFont.Bold = bool(bold)
            iTextFont.Italic = bool(italic)
            iTextFont.TextLineStep = 0.0
            iTextItem.Update()

    iDrawingTable.FixedCellsSize = True
    iDrawingTable.FixedColumnCount = True
    iDrawingTable.FixedRowCount = True
    iDrawingTable.Update()
    #Объединяем ячейки
    for merged_cell in merge_cells:
        row_start, col_start, row_end, col_end = merged_cell
        iTableRange = iTable.Range(row_start, col_start, row_end, col_end)
        iTableRange.CombineCells()
    iDrawingTable.Update()

def build_dataframe_and_segments(ws):

    fallback_colors = {}
    element_notes = {}
    element_note_ids = {}
    note_counter = 1

    def parse_geometry(cell_value):
        return re.findall(r"\((\d+)\s+(\d+)\)", str(cell_value))

    def generate_shuffled_distinct_colors(n):
        hues = [i / n for i in range(n)]
        shuffled_hues = sorted(hues, key=lambda h: abs((h * 2) % 1 - 0.5))
        random.shuffle(shuffled_hues)
        colors = []
        for hue in shuffled_hues:
            r, g, b = colorsys.hsv_to_rgb(hue, 0.4, 1.0)
            hex_color = '{:02X}{:02X}{:02X}'.format(int(r * 255), int(g * 255), int(b * 255))
            colors.append(hex_color)
        return colors

    def restore_symbols(profile):
        profile = str(profile)
        replacements = {
            'Пластина ': '@016',
            'Полоса ': '@137',
            'Уголок ': '@140',
            'Двутавр ': '@142',
            'Швеллер ': '@144',
            'Швеллер ': '@143',
            'Тавр ': '@141',
            'Труба профильная ': '@131',
            'Круг ': '@130',
            'Труба ': '@090',
            'Спаренный швеллер ': '@218',
        }
        for k, v in replacements.items():
            if profile.startswith(k):
                return profile.replace(k, v)
        return profile

    distinct_colors = generate_shuffled_distinct_colors(200)
    color_index = 0

    def get_random_color(element_id):
        nonlocal color_index
        if element_id not in fallback_colors:
            fallback_colors[element_id] = distinct_colors[color_index % len(distinct_colors)]
            color_index += 1
        return fallback_colors[element_id]

    df_rows = []
    geometry_map = {}

    headers = ["№", "Наименование профиля", "Длина заг. мм", "Кол-во заг. шт.", "Остаток, мм", "Элементы в раскрое", "Карта раскроя"]
    df_rows.append(headers)

    for row in ws.iter_rows(min_row=3, max_row=ws.max_row):
        row_index = row[0].row
        num_row = ws.cell(row=row_index, column=1).value
        profile_cell = restore_symbols(ws.cell(row=row_index, column=2).value or '')
        length_cell = ws.cell(row=row_index, column=3).value
        col_cell = ws.cell(row=row_index, column=4).value
        residue_cell = ws.cell(row=row_index, column=5).value
        geo_cell = ws.cell(row=row_index, column=6).value

        geometries = parse_geometry(geo_cell)

        counter_map = {}
        for length_str, elem_id in geometries:
            length = int(length_str)
            key = (elem_id, length)
            counter_map[key] = counter_map.get(key, 0) + 1

        breakdown_text = " ".join([
            f"<Д{eid} ({l}мм)-{n}шт> " for (eid, l), n in sorted(counter_map.items(), key=lambda x: int(x[0][0]))
        ])

        df_rows.append([num_row, profile_cell, length_cell, col_cell, residue_cell, breakdown_text, ""])

        if not geometries:
            continue

        segment_list = []
        used_length = 0

        for length_str, elem_id in geometries:
            length = int(length_str)
            color = get_random_color(elem_id)

            note_label = None
            if length < 300:
                if elem_id not in element_note_ids:
                    note_label = f"*&/{note_counter}"
                    element_note_ids[elem_id] = note_label
                    element_notes[note_label] = f"{note_label}. Деталь {elem_id} - {length}мм"
                    note_counter += 1
                else:
                    note_label = element_note_ids[elem_id]

            segment_list.append({
                "section": profile_cell,
                "length": length,
                "element": elem_id,
                "color": color,
                "note": note_label
            })
            used_length += length

        segment_list.insert(0, {
            "length": int(length_cell),
            "section": profile_cell,
            "element": "base",
            "color": "FFFFFF"
        })

        geometry_map[row_index - 2] = segment_list

    df = pd.DataFrame(df_rows, columns=headers)

    return df, geometry_map, element_notes

def prepare_table_formatting(df):
    n_rows, n_cols = df.shape
    cell_widths = [8.0, 30.0, 14.0, 14.0, 18.0, 60.0, 251.0] * n_rows
    merge_cells = []
    text_styles = []
    row_heights = [22.0] + [15.0] * (n_rows - 1)

    for row in range(n_rows):
        for col in range(n_cols):
            if col in [0, 2, 3]:
                align = ('Center', 'Center')
            elif col in [1, 5]:
                align = ('Left', 'Center')
            else:
                align = ('General', 'Center')

            if row == 0:
                text_styles.append(('Center', 'Center', False, True))  # Жёстко задаем центр и жирный
            else:
                bold = False
                text_styles.append((align[0], align[1], False, bold))

    return cell_widths, merge_cells, text_styles, row_heights

def draw_cut_map_segments(geometry_map, x_start, y_start, row_heights, scale=None, element_notes=None, iKompasDocument=None):

    def hex_to_rgb(hex_color):
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))

    iKompasDocument2D = API7.IKompasDocument2D(iKompasDocument)
    iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
    iViews = iViewsAndLayersManager.Views
    iView = iViews.ActiveView
    iDrawingContainer = API7.IDrawingContainer(iView)
    iRectangles = iDrawingContainer.Rectangles
    iColourings = iDrawingContainer.Colourings
    iDrawingTexts = iDrawingContainer.DrawingTexts

    if scale is None:
        max_length = 0
        for segments in geometry_map.values():
            total_length = sum(seg['length'] for seg in segments if seg['element'] == 'base')
            max_length = max(max_length, total_length)
        scale = 249 / max_length if max_length > 0 else 0.02

    y = y_start - 18.5

    used_notes = set()

    for row_idx, segments in geometry_map.items():
        if row_idx >= len(row_heights):
            continue
        if row_idx == 0:
            continue
        height = row_heights[row_idx]
        y -= height
        base_x = x_start + 145

        base_seg = next((s for s in segments if s['element'] == 'base'), None)

        if base_seg:
            base_width = base_seg['length'] * scale
            iRectangle = iRectangles.Add()
            iRectangle.Style = con0.ksCSThin
            iRectangle.X = base_x
            iRectangle.Y = y
            iRectangle.Width = base_width
            iRectangle.Height = 8.0
            iRectangle.Angle = 0.0
            iRectangle.Update()

            iColouring = iColourings.Add()
            iColouring.ColouringType = con0.ksColouringSolid
            iColouring.Color1 = 14211288
            iColouring.Color2 = 0
            iColouring.Transparency1 = 0
            iColouring.Transparency2 = 0
            iColouring.GradientType = True

            iBoundariesObject = API7.IBoundariesObject(iColouring)
            iBoundariesObject.AddBoundaries(iRectangle, False)
            iColouring.Update()

            iDrawingObject1 = API7.IDrawingObject1(iColouring)
            iDrawingObject1.Associate()

        current_x = base_x
        for seg in segments:
            if seg['element'] == 'base':
                continue
            width = seg['length'] * scale
            r, g, b = hex_to_rgb(seg['color'])

            iRectangle = iRectangles.Add()
            iRectangle.Style = con0.ksCSNormal
            iRectangle.X = current_x
            iRectangle.Y = y
            iRectangle.Width = width
            iRectangle.Height = 8.0
            iRectangle.Angle = 0.0
            iRectangle.Update()

            iColouring = iColourings.Add()
            iColouring.ColouringType = con0.ksColouringSolid
            iColouring.Color1 = (r << 16) + (g << 8) + b
            iColouring.Color2 = 0
            iColouring.Transparency1 = 0
            iColouring.Transparency2 = 0
            iColouring.GradientType = False

            iBoundariesObject = API7.IBoundariesObject(iColouring)
            iBoundariesObject.AddBoundaries(iRectangle, False)
            iColouring.Update()

            iDrawingObject1 = API7.IDrawingObject1(iColouring)
            iDrawingObject1.Associate()

            iDrawingText = iDrawingTexts.Add()
            iDrawingText.X = current_x + width / 2
            iDrawingText.Y = y + 4.306167
            iDrawingText.Angle = 0.0
            iDrawingText.HFormat = con0.ksHFormatNot
            iDrawingText.VFormat = False
            iDrawingText.Allocation = con0.ksAlCentre
            iDrawingText.MirrorSymmetry = False

            iText = API7.IText(iDrawingText)
            iText.Style = con0.ksTSDrawingAnnotation

            iTextLine = iText.Add()
            iTextLine.Style = con0.ksTSDrawingAnnotation
            iTextLine.Step = 1.0
            iTextLine.Align = con0.ksAlignCenter
            iTextLine.IndentedLine = 0.0
            iTextLine.StepBeforeParagraph = 0.0
            iTextLine.StepAfterParagraph = 0.0
            iTextLine.LeftEdge = 0.0
            iTextLine.RightEdge = 0.0
            iTextLine.Level = 0
            iTextLine.Numbering = con0.ksTNumbNoNumber
            iTextLine.NewPage = False

            iTextItem = iTextLine.Add()
            iTextItem.ItemType = con0.ksTItString
            iTextItem.NewLine = True

            if width >= 15:
                iTextItem.Str = f"Д.{seg['element']}&/{seg['length']}мм"
            else:
                note = seg.get('note')
                if note:
                    iTextItem.Str = note
                    used_notes.add(note)
                else:
                    iTextItem.Str = f"Д.{seg['element']}&/{seg['length']}мм"

            iTextFont = API7.ITextFont(iTextItem)
            iTextFont.FontName = "GOST Type AU"
            iTextFont.Height = 2.0
            iTextFont.WidthFactor = 1.0
            iTextFont.Color = 0
            iTextFont.Bold = True
            iTextFont.Italic = False
            iTextFont.Underline = False
            iTextFont.TextLineStep = 0.0

            iDrawingText.Update()

            current_x += width

    def extract_note_number(note):
        match = re.match(r"(\d+)\*", note)
        return int(match.group(1)) if match else float('inf')
    # Вставка блока примечаний (только используемые)
    if element_notes and used_notes:
        filtered_notes = [element_notes[n].replace('*&/', '') for n in sorted(used_notes, key=extract_note_number) if
                          n in element_notes]

        notes_text = "\n".join(sorted(filtered_notes, key=lambda s: int(s.split('.')[0])))

        iDrawingNote = iDrawingTexts.Add()
        iDrawingNote.X = x_start + 5
        iDrawingNote.Y = y - 8  # немного ниже последней строки
        iDrawingNote.Angle = 0.0
        iDrawingNote.HFormat = con0.ksHFormatNot
        iDrawingNote.VFormat = False
        iDrawingNote.Allocation = con0.ksAlLeft
        iDrawingNote.MirrorSymmetry = False

        iText = API7.IText(iDrawingNote)
        iText.Style = con0.ksTSDrawingAnnotation

        iTextLine = iText.Add()
        iTextLine.Style = con0.ksTSDrawingAnnotation
        iTextLine.Step = 1.0
        iTextLine.Align = con0.ksAlignLeft
        iTextLine.IndentedLine = 0.0
        iTextLine.LeftEdge = 0.0
        iTextLine.RightEdge = 0.0
        iTextLine.Level = 0

        iTextItem = iTextLine.Add()
        iTextItem.ItemType = con0.ksTItString
        iTextItem.NewLine = True
        iTextItem.Str = f'Примечание:&/{notes_text}'

        iTextFont = API7.ITextFont(iTextItem)
        iTextFont.FontName = "GOST Type AU"
        iTextFont.Height = 3.5
        iTextFont.WidthFactor = 1.0
        iTextFont.Color = 0
        iTextFont.Bold = False
        iTextFont.Italic = False
        iTextFont.TextLineStep = 0.0

        iDrawingNote.Update()

def process_all_tables(df, geometry_map, element_notes=None, table_limit=14, iKompasDocument=None):
    from math import ceil
    total_rows = df.shape[0] - 1  # исключаем заголовок
    chunks = ceil(total_rows / table_limit)
    iLayoutSheets = iKompasDocument.LayoutSheets

    iLayoutSheet = iLayoutSheets.Item(0)
    iStamp = iLayoutSheet.Stamp
    iStamp.Text(1001).Str = f'Карта раскроя&/Лист {1}'
    iStamp.Update()

    for i in range(chunks):
        print(f'Таблица {i+1}')

        if i+1 > iLayoutSheets.Count:
            iLayoutSheet = iLayoutSheets.Add()
            iSheetFormat = iLayoutSheet.Format
            iSheetFormat.Format = con0.ksFormatA3
            iLayoutSheet.Update()

            iStamp = iLayoutSheet.Stamp
            iStamp.Text(1001).Str = f'Карта раскроя&/Лист {i+1}'

            iStamp.Update()

        start = 1 + i * table_limit
        end = 1 + (i + 1) * table_limit

        df_chunk = pd.concat([df.iloc[[0]], df.iloc[start:end]])
        geometry_chunk = {
            k - start + 1: v for k, v in geometry_map.items() if start <= k < end
        }

        cell_widths, merge_cells, text_styles, row_heights = prepare_table_formatting(df_chunk)

        x_pos = 20 + i * 420
        y_pos = 292

        xls_to_cdw(df_chunk, cell_widths, row_heights, merge_cells, text_styles, x=x_pos, y=y_pos, iKompasDocument=iKompasDocument)

        draw_cut_map_segments(geometry_chunk, x_pos, y_pos, row_heights, element_notes=element_notes, iKompasDocument=iKompasDocument)

def create_cdw(xlsx, iDocuments):
    #Создаёт чертеж
    file_template = f'{path_to_scripts}\\Template\\05 _ СПДС Карта раскроя.cdt'
    layout_style_number = 1001.0
    format = con0.ksFormatA3
    vertical_orientation = False


    iKompasDocument = iDocuments.Open(file_template, False, True)

    # # Изменим параметры листа оформления
    iLayoutSheets = iKompasDocument.LayoutSheets
    iLayoutSheet = iLayoutSheets.Item(0)
    iSheetFormat = iLayoutSheet.Format
    iSheetFormat.FormatMultiplicity = 1
    iSheetFormat.VerticalOrientation = vertical_orientation
    iSheetFormat.Format = format
    iLayoutSheet.LayoutLibraryFileName = f'{path_to_scripts}\\Template\\Drawing_specification_styles.lyt'
    iLayoutSheet.LayoutStyleNumber = layout_style_number
    iLayoutSheet.SheetType = con0.ksDocumentSheet
    iLayoutSheet.Update()

    path = Path(xlsx)
    folder_path = path.parent  # Папка, где лежит файл на уровень выше
    path_cdw = folder_path / "Карта раскроя.cdw"
    iKompasDocument.SaveAs(path_cdw)
    iKompasDocument.Close(0)
    log_message(f'Создали файл карты раскроя в {path_cdw}')
    return path_cdw

def cutting_plan(xlsx):
    KompasObject, iApplication, KompasVersion = get_kompas()
    script = os.path.basename(__file__)
    if not check_access(script):
        log_message(f"Похоже вы не оплатили '{script.split('.')[0]}', пропускаем..", "error")
        return False
    iDocuments = iApplication.Documents

    wb = openpyxl.load_workbook(xlsx)
    ws = wb.active
    df, geometry_map, element_notes = build_dataframe_and_segments(ws)

    # cell_widths, merge_cells, text_styles, row_heights = prepare_table_formatting(df)
    if geometry_map:
        file_cdw = create_cdw(xlsx, iDocuments)
        iKompasDocument = iDocuments.Open(file_cdw, False, False)
        process_all_tables(df, geometry_map, element_notes, iKompasDocument=iKompasDocument)
        iKompasDocument.Close(1)


if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    iKompasDocument = iApplication.ActiveDocument
    # path = get_active_doc_path(iApplication)
    # xlsx = easygui.fileopenbox(msg="Укажите файл Карты раскроя...", title="",
    #                            default=f"{path}/*1.6 _ Карта раскроя*.xlsx")
    xlsx = r'C:\Users\ik\Desktop\Карта раскроя\1.6 _ Карта раскроя.xlsx'
    #
    # wb = openpyxl.load_workbook(xlsx)
    # ws = wb.active
    # df, geometry_map, element_notes = build_dataframe_and_segments(ws)
    #
    # # cell_widths, merge_cells, text_styles, row_heights = prepare_table_formatting(df)
    # process_all_tables(df, geometry_map, element_notes, iKompasDocument=iKompasDocument)
    script = os.path.basename('_cutting_plan.py')
    if not check_access(script):
        log_message(f'Похоже вы не оплатили "{script.split('.')[0]}", пропускаем...', 'error')
        input(f"")
        sys.exit()
    cutting_plan(xlsx)
    input('\n\rРабота завершена.\t\n')