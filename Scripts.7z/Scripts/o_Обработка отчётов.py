import sys, os
import easygui, pyperclip
import traceback
from pathlib import Path

from __ExcelHandler import ExcelHandler
from _Sheet0 import sheet0
from _Sheet1_0 import sheet1_0 #Ведомость металлопроката
from _Sheet1_1 import sheet1_1 #Ведомость марок
from _Sheet1_2 import sheet1_2 #Ведомость элементов
from _Sheet1_2_1 import sheet1_2_1 #Ведомость элементов по маркам
from _Sheet1_3 import sheet1_3 #Ведомость стандартных изделий
from _Sheet1_4 import sheet1_4 #Площади проката
from _Sheet1_5 import sheet1_5 #Требуемый прокат
from _Sheet1_6 import sheet1_6 #Карта раскроя
from _Sheet2_1 import sheet2_1 #Пластины
from _Sheet3_1 import sheet3_1 #Раскрой для импорта в RealCut
from __Kompas import *#get_kompas, get_active_doc_path, check_access
from CNC_2d_for_all import dxf_for_all
# from _Reed_file_settings import reed_file_settings, search_file_settings
from __Reed_file_settings import find_settings_file, parse_settings_file, cook_settings_for_stamp

from __Utils import Timer
import _Config
'''Универсальный скрипт обработки отчетов, запускает требуемый скрипт из _Sheet на основе значений в ячейке 1 и имени файла'''
# KompasObject, iApplication = get_kompas()
def handle_error(e, context=""):
    tb = traceback.format_exc()  # Получаем полный стек ошибки
    print(f"\nОшибка: {context}\n{e}\n{tb}")

def report_processing(path):
    if '.xls' not in str(path):
        xls = easygui.fileopenbox(msg="Укажите файл отчета ", title="", default=f"{path}/*.xls*")  # Путь до файла отчёта
    else:
        xls = path

    try:
        pyperclip.copy(os.path.dirname(xls))  # Запишем путь до папки с xlsx в буфер обмена

        if _Config.file_settings:
            file_settings = find_settings_file(os.path.dirname(xls), "Информация по проекту.txt") # Ищем файл настроек
            dict = parse_settings_file(file_settings) # Читаем файл настроек
            code_project = f"{dict['Шифр проекта']} _ {dict['Наименование проекта'][0].replace('&/', ' ')}"  # Формируем поле Шифр _ Наименование проекта

        else:
            code_project = f""  # Формируем поле Шифр _ Наименование проекта

        if "1.0 _ Ведомость металлопроката.xlsx" in str(xls):
            xls = Path(xls).with_name("Общий отчёт.xlsx")
            if xls.exists():
                sheet1_0(xls,"", code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета Общий отчёт.xlsx", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
                sheet1_0(xls, "", code_project)
                sys.exit()

        if "1.1 _ Ведомость марок.xlsx" in str(xls):
            xls = Path(xls).with_name("Общий отчёт.xlsx")
            if xls.exists():
                sheet1_1(xls, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета из Компас 3D", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
                sheet1_1(xls, code_project)
                sys.exit()

        if "1.2 _ Ведомость элементов.xlsx" in str(xls):
            xls = Path(xls).with_name("Общий отчёт.xlsx")
            if xls.exists():
                sheet1_2(xls, _Config.format_cnc, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета из Компас 3D", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
                sheet1_2(xls, _Config.format_cnc, code_project)
                sys.exit()

        if "1.2.1 _ Ведомость элементов по маркам.xlsx" in str(xls):
            xls = Path(xls).with_name("Общий отчёт.xlsx")
            if xls.exists():
                sheet1_2_1(xls, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета из Компас 3D", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
                sheet1_2(xls, code_project)
                sys.exit()

        if "1.3 _ Стандартные и покупные изделия.xlsx" in str(xls):
            xls = Path(xls).with_name("Общий отчёт.xlsx")
            if xls.exists():
                sheet1_3(xls, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета из Компас 3D", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
                sheet1_3(xls, code_project)
                sys.exit()

        if "1.4 _ Площадь под покраску.xlsx" in str(xls):
            xls = Path(xls).with_name("1.2 _ Ведомость элементов.xlsx")
            if xls.exists():
                sheet1_4(xls, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета 1.2 _ Ведомость элементов.xlsx", title="", default=f"{path}/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
                sheet1_4(xls, code_project)
                sys.exit()

        if "1.5 _ Требуемый прокат.xlsx" in str(xls):
            xls = easygui.fileopenbox(msg="Укажите файл Статистика... после RealCut", title="",
                                       default=f"{path}/*Статистика*.xlsx")
            sheet1_5(xls, code_project)
            sys.exit()

        if "1.6 _ Карта раскроя.xlsx" in str(xls):
            xls = easygui.fileopenbox(msg="Укажите файл Карты раскроя... после RealCut", title="",
                                      default=f"{path}/*Карта*.xlsx")
            sheet1_6(xls, code_project)
            sys.exit()

        if "2.1 _ Пластины.xlsx" in str(xls):
            xls = Path(xls).with_name("1.2 _ Ведомость элементов.xlsx")
            if xls.exists():
                xls_plate = sheet2_1(xls,_Config.format_cnc, code_project)
                dxf_for_all(xls_plate, _Config.format_cnc, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета 1.2 _ Ведомость элементов.xlsx", title="", default=f"{path}/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
                xls_plate = sheet2_1(xls, _Config.format_cnc, code_project)
                dxf_for_all(xls_plate, _Config.format_cnc, code_project)
                sys.exit()

        if "3.1 _ Раскрой.xlsx" in str(xls) or "3.2 _ Склад.xlsx" in str(xls):
            xls = Path(xls).with_name("1.2 _ Ведомость элементов.xlsx")
            if xls.exists():
                sheet3_1(xls, code_project)
                sys.exit()
            else:
                xls = easygui.fileopenbox(msg="Укажите файл отчета 1.2 _ Ведомость элементов.xlsx", title="", default=f"{path}/*1.2 _ Ведомость элементов.xlsx")  # Путь до файла отчёта
                sheet3_1(xls, code_project)
                sys.exit()

        # if "Общий отчёт.xls" in str(xls):
        if str(xls).endswith("Общий отчёт.xls"):
            xls = sheet0(xls)
            print()
            log_message('Формирую все отчеты по элементам металлоконструкций', 'title')
            sheet1_1(xls, code_project)
            xls_elem, mode = sheet1_2(xls, _Config.format_cnc, code_project)
            xls_elem_mark = sheet1_2_1(xls, code_project)
            sheet1_3(xls, code_project)
            if xls_elem:
                sheet1_0(xls, 1, code_project)
                sheet1_4(xls_elem, code_project)
                sheet3_1(xls_elem, code_project)
            xls_plate = sheet2_1(xls_elem, _Config.format_cnc, code_project)
            if xls_plate and mode:
                print(xls_plate)
                # input()
                # # sys.exit()
                dxf_for_all(xls_plate, _Config.format_cnc, code_project)
            sys.exit()

        if str(xls).endswith("Общий отчёт.xlsx"):
            # xls = sheet0(xls)
            # print()
            log_message('Формирую все отчеты по элементам металлоконструкций', 'title')
            sheet1_1(xls, code_project)
            xls_elem, mode = sheet1_2(xls, _Config.format_cnc, code_project)
            xls_elem_mark = sheet1_2_1(xls, code_project)
            sheet1_3(xls, code_project)
            if xls_elem:
                sheet1_0(xls, 1, code_project)
                sheet1_4(xls_elem, code_project)
                sheet3_1(xls_elem, code_project)
            xls_plate = sheet2_1(xls_elem, _Config.format_cnc, code_project)
            if xls_plate and mode:
                dxf_for_all(xls_plate, _Config.format_cnc, code_project)
            sys.exit()

        else:
            excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
            df = excel_handler.read_excel()  # Читаем таблицу в dataframe

            if df.columns[0] == 'КМД. Общий отчет по металлоконструкциям':
                print('\nФормирую отчеты по элементам металлоконструкций')
                sheet1_1(xls, code_project)
                xls_elem, mode = sheet1_2(xls, _Config.format_cnc, code_project)
                sheet1_3(xls, code_project)
                if xls_elem:
                    sheet1_0(xls, 1, code_project)
                    sheet1_4(xls_elem, code_project)
                    sheet3_1(xls_elem, code_project)
                xls_plate = sheet2_1(xls_elem, _Config.format_cnc, code_project)
                if xls_plate and mode != 'f':
                    dxf_for_all(xls_plate, _Config.format_cnc, code_project)
                sys.exit()


            elif df.columns[0] == '#':
                print('\nФормирую карту раскроя')
                sheet1_6(xls, code_project)

            elif df.columns[0] == 'Использованные полосы':
                print('\nФорматирую карту требуемого проката')
                sheet1_5(xls, code_project)

            else:
                print('\nТаблица не подходящая. Завершаю выполнение программы.')
                sys.exit(1)  # Завершение программы с кодом ошибки

    except Exception as e:
        handle_error(e, "При обработке отчета")
    finally:
        try:
            print(f'\n{timer.stop()}')
            input('\n\rРабота завершена.\n')
        except:
            input('\n\rРабота завершена.\n')

def getting_reports(path):

    try:
        log_message(f'Создаю отчет из активной сборки', 'title')
        path_folder = easygui.diropenbox(msg="Укажите папку для сохранения отчетов или нажмите 'Отмена' для обработки сущ. отчета", title="", default=f"{path}")
        if path_folder:
            if "Материалы" in path_folder:
                path_folder = Path(path_folder)  # Если "Материалы" уже указано, просто преобразуем в Path
            else:
                path_folder = Path(path_folder) / "Материалы"  # Если нет, добавляем подпапку "Материалы"
            path_folder.mkdir(parents=True, exist_ok=True)  # Создаем папку
            path_to_scripts = Path(_Config.path_to_scripts)
            path_report_style = path_to_scripts / "Template" / "Отчеты Заказ материалов.lrt"  # Путь до файла со стилями отчётов

            path_report_to_save = path_folder / 'Общий отчёт.xls'
            KompasObject, iApplication, KompasVersion = get_kompas()

            iPropertyMng = API7.IPropertyMng(iApplication)
            iKompasDocument = iApplication.ActiveDocument
            iReport = iPropertyMng.GetReport(iKompasDocument, con0.ksRTPropertiesReport)
            iReportStyle = iReport.AddStyle(path_report_style, 315608966869.0) # Добавляем стиль отчета

            iStylesCount = iReport.StylesCount #Количество стилей
            for i in range(iStylesCount): # Установить индекс стиля отчета текущим
                iReport.CurrentStyleIndex = i
                report_name  = iReport.CurrentReportStyle.Name
                if report_name == 'КМД. Общий отчет по металлоконструкциям':
                    break
            iReport.Rebuild() # Перестроить отчет.
            iReport.SaveAs(str(path_report_to_save))
            log_message(f'Отчёт получен силами API, не забудьте перезапустить Компас 3D','error')
            report_processing(str(path_report_to_save))
            return str(path_report_to_save)
        else:
            report_processing(path)

    except Exception as e:
        handle_error(e, f"При обработке отчета")

if __name__ == "__main__":
    timer = Timer()
    timer.start()  # Запускаем таймер
    # xls = r'C:\Users\ik\Desktop\Тесты\сборка\Материалы\Общий отчет.xls'
    script = os.path.basename('o_Обработка отчётов.py')
    if not check_access(script):
        input(log_message(f"Похоже вы не оплатили 'Обработку отчётов', пропускаем...", "error"))
        sys.exit()

    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    # path = r'C:\Users\ik\Desktop\Тесты\сборка\Материалы\Общий отчёт.xls'
    getting_reports(path) # Создать новый
    # report_processing(path) # Обработать сущ
