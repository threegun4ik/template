"""
Скрипт формирования ведомости металлопроката из файла 'Общий отчёт.xlsx'.
На выходе: 1.0 _ Ведомость металлопроката.xlsx

Функции:
- Чтение и предобработка данных из Excel
- Вычисление массы элементов по базе профилей и геометрии
- Формирование итоговой спецификации и сохранение в новый Excel
- Автоматическое форматирование Excel файла
"""

# ===== Стандартная библиотека =====
import re
import math
import sys

import easygui
import warnings
from pathlib import Path

# ===== Сторонние библиотеки =====
import pandas as pd
import openpyxl
from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.styles import PatternFill, Alignment, Font, NamedStyle
from openpyxl.styles import Border, Side

# ===== Локальные модули =====
from __ExcelHandler import ExcelHandler
from __Kompas import get_kompas, get_active_doc_path, log_message
from __Reed_file_settings import find_settings_file

# Игнорируем предупреждения Pandas
warnings.simplefilter(action='ignore', category=FutureWarning)

# === Константы ===
STEEL_DENSITY = 7850  # кг/м³ — плотность стали

def format_number(num) -> str:
    """Форматирует число: 2.0 → 2, 2.5 → 2,5"""
    if pd.isna(num):
        return ''
    num = float(num)
    return str(int(num)) if num.is_integer() else str(num).replace('.', ',')

def parse_size_key(value: str):
    """Извлекает числовой ключ сортировки из строки для убывания"""
    if not isinstance(value, str):
        return (0,)
    nums = re.findall(r'\d+', value)
    nums = [int(n) for n in nums]
    return tuple([-n for n in nums]) if nums else (0,)

def parse_letters_numbers(value, group_discharge=None, as_sort_key=False):
    if not isinstance(value, str):
        return (value, float('inf')) if as_sort_key else value

    match = re.match(r"([^\d]+)(\d+)", value)
    if not match:
        return (value, float('inf')) if as_sort_key else value

    letters, numbers = match.groups()

    if as_sort_key:
        return (letters, int(numbers))

    if group_discharge is None:
        # Полная марка
        return value
    elif group_discharge == 0:
        # Только буквы
        return letters
    else:
        # Буквы + первые group_discharge цифр
        return letters + numbers[:group_discharge]

def round_up(value, decimals=3):
    factor = 10 ** decimals
    return math.ceil(value * factor) / factor if pd.notna(value) else value

def insert_summary_rows(df, group_column, profile_column):
        new_df = pd.DataFrame(columns=df.columns)  # Создаём новый DataFrame для результата
        unique_values = df[group_column].unique()  # Получаем уникальные значения в столбце для группировки

        for value in unique_values:
            group_df = df[df[group_column] == value]  # Фильтруем строки для текущего значения группы
            new_df = pd.concat([new_df, group_df], ignore_index=True)  # Добавляем строки группы в новый DataFrame
            sum_row = group_df.select_dtypes(include=['number']).sum()  # Вычисляем суммы для числовых столбцов
            sum_row[group_column] = value + 0.1  # Присваиваем значение для столбца с номером как дробь, например 1.1, 2.1 и т.д.
            sum_row['Наименование или марка металла ГОСТ, ТУ'] = 'Итого профиля'  # Заполняем строку с текстом 'Итого профиля'
            summary_row = pd.Series(sum_row, index=new_df.columns)  # Создаём новую строку с суммами
            new_df = pd.concat([new_df, pd.DataFrame([summary_row])], ignore_index=True)  # Добавляем строку с суммами

        # Добавляем итоговую строку в конец таблицы
        last_num = new_df['№'].max() + 10 if not pd.isna(new_df['№'].max()) else 10  # Последний номер + 10
        total_profile_df = new_df[new_df['Наименование или марка металла ГОСТ, ТУ'] == 'Итого профиля']
        total_sum_row = total_profile_df.select_dtypes(include=['number']).sum()  # Считаем сумму по строкам с 'Итого профиля'
        total_sum_row['№'] = last_num
        # total_sum_row[profile_column] = 'Всего масса металла:'
        total_sum_row['Наименование профиля ГОСТ, ТУ'] = 'Всего масса металла:'

        total_summary_row = pd.Series(total_sum_row, index=new_df.columns)  # Добавляем строку с 'Всего масса металла:'
        new_df = pd.concat([new_df, pd.DataFrame([total_summary_row])], ignore_index=True)

        # Собираем строки "В том числе" в список перед сортировкой
        metal_rows_list = []
        unique_metals = df['Наименование или марка металла ГОСТ, ТУ'].unique()  # Получаем уникальные марки металлов

        for metal in unique_metals:
            metal_df = df[df['Наименование или марка металла ГОСТ, ТУ'] == metal]  # Фильтруем строки по марке металла
            metal_sum = metal_df['Итого'].sum()  # Считаем сумму по 'Итого' для этой марки металла

            metal_row = {col: '' for col in df.columns}  # Создаём строку с текстом 'В том числе' и маркой металла
            metal_row[group_column] = last_num + 0.1
            # Обрезанная марка стали до ГОСТ
            name_before_gost = re.split(r'\bГОСТ\b', str(metal), maxsplit=1)[0].strip()

            # Заполняем нужные столбцы
            metal_row[profile_column] = name_before_gost
            metal_row['Итого'] = metal_sum
            metal_row['Наименование профиля ГОСТ, ТУ'] = "В том числе по маркам или наименованиям"
            metal_row['Наименование или марка металла ГОСТ, ТУ'] = "В том числе по маркам или наименованиям"

            metal_rows_list.append(metal_row)

            # === Убираем дубликаты и суммируем «Итого» ===
            metal_df_final = pd.DataFrame(metal_rows_list)
            metal_df_final = (
                metal_df_final
                .groupby([
                    'Наименование профиля ГОСТ, ТУ',
                    'Наименование или марка металла ГОСТ, ТУ',
                    profile_column
                ], as_index=False)
                .agg({'Итого': 'sum'})
            )

            # Преобразуем обратно в список словарей
            metal_rows_list = metal_df_final.to_dict(orient='records')

        # Сортируем список по названию металла
        metal_rows_list.sort(key=lambda x: x[profile_column])

        # Добавляем отсортированные строки в DataFrame
        new_df = pd.concat([new_df, pd.DataFrame(metal_rows_list)], ignore_index=True)

        return new_df

def update_element_mass(df, kMasE: float, rel_tol: float = 1e-2, abs_tol: float = 1e-2):
    """
    Обновляет df['Масса элементов, кг'] на основе df['Масса 1 м, кг'] и длины.
    rel_tol — относительный допуск
    abs_tol — абсолютный допуск
    """

    for idx, row in df.iterrows():
        mass_1m = row['Масса 1 м, кг']
        length_m = row['Длина, мм'] / 1000 if pd.notna(row['Длина, мм']) else 0
        qty = row['Кол-во, шт.'] if pd.notna(row['Кол-во, шт.']) else 1

        # Если нет длины или массы на метр — пропускаем
        if pd.isna(mass_1m) or length_m == 0:
            continue

        # Масса 1 м по отчёту (для одного элемента)
        mass_model = row['Масса элемента, кг'] / length_m
        # Расчётная масса 1 м (для одного элемента)
        mass_calc = mass_1m * kMasE

        # Проверка на "равенство" с учётом допуска
        if math.isclose(mass_model, mass_calc, rel_tol=rel_tol, abs_tol=abs_tol):
            max_mass = max(mass_model, mass_calc)
            df.at[idx, 'Масса элементов, кг'] = round_up(max_mass * length_m * qty, 3)
            continue

        # Если масса из отчёта больше
        if mass_model > mass_calc:
            print(f"\n[WARN] Элемент {row['№ элемента']} {row['Сечение']} {row['Длина, мм']:.15g} мм в\n{row['Полное имя файла']}:")
            print(f"  Масса по отчету: {mass_model:.3f} кг/м")
            print(f"  Масса расчетная: ({mass_1m} кг/м * {kMasE}) = {mass_calc:.3f} кг/м")

            user_input = input("Оставить массу из отчета × Кол-во (Enter) или ввести 'расч' для расчетной? ").strip().lower()
            if user_input == "расч":
                df.at[idx, 'Масса элементов, кг'] = round_up(mass_calc * length_m * qty, 3)
            else:
                df.at[idx, 'Масса элементов, кг'] = round_up(mass_model * length_m * qty, 3)
        else:
            # Расчетная масса больше
            df.at[idx, 'Масса элементов, кг'] = round_up(mass_calc * length_m * qty, 3)

    return df


def insert_padding_and_merge(ws, col_idx: int, cols_to_merge=(1, 2), header_rows: int = 2,
                             min_group_len: int = 3, sort_column: str = 'B'):
    """
    1. Вставляет строки в конце группы, если группа меньше min_group_len
    2. Дублирует значения группы в указанных столбцах
    3. Сортирует строки внутри группы по указанному столбцу
    4. Объединяет последовательные одинаковые значения в столбце B внутри группы
    5. Для строк с "В том числе..." объединяет ячейки в столбцах A и B
    6. Для строк с "Всего масса металла:" объединяет ячейки в столбцах A и B без вставки строк
    7. Объединяет ячейки группы в столбцах cols_to_merge
    """
    col_letter = get_column_letter(col_idx)
    sort_col_letter = get_column_letter(sort_column) if isinstance(sort_column, int) else sort_column.upper()
    start_row = header_rows + 1
    end_row = ws.max_row
    row = start_row

    while row <= end_row:
        current_value = ws[f"{col_letter}{row}"].value
        if not current_value:
            row += 1
            continue

        # Определяем границы группы
        group_start = row
        while row <= end_row and ws[f"{col_letter}{row}"].value == current_value:
            row += 1
        group_end = row - 1
        group_len = group_end - group_start + 1

        # Проверяем специальные условия
        is_special_case = "В том числе по маркам или наименованиям" in str(current_value)
        is_total_case = "Всего масса металла:" in str(current_value)

        # Вставка строк (если нужно, пропускаем для специальных случаев)
        if not is_special_case and not is_total_case and group_len < min_group_len:
            need_to_insert = min_group_len - group_len
            insert_pos = group_end + 1

            for _ in range(need_to_insert):
                ws.insert_rows(insert_pos)
                end_row += 1
                for merge_col in cols_to_merge:
                    merge_letter = get_column_letter(merge_col)
                    ws[f"{merge_letter}{insert_pos}"].value = ws[f"{merge_letter}{group_start}"].value
                insert_pos += 1

            group_end += need_to_insert
            row = group_end + 1
        else:
            row = group_end + 1

        # Сортировка строк внутри группы (пропускаем для специальных случаев)
        if group_start < group_end and not is_special_case and not is_total_case:
            group_rows = []
            for r in range(group_start, group_end + 1):
                row_data = {}
                for c in range(1, ws.max_column + 1):
                    row_data[get_column_letter(c)] = ws[f"{get_column_letter(c)}{r}"].value
                group_rows.append((ws[f"{sort_col_letter}{r}"].value, r, row_data))

            group_rows.sort(key=lambda x: x[0] or "")

            for idx, (_, original_r, row_data) in enumerate(group_rows, start=group_start):
                for col, value in row_data.items():
                    ws[f"{col}{idx}"].value = value

        # Объединение последовательных одинаковых значений в столбце B (пропускаем для специальных случаев)
        if group_start < group_end and not is_special_case and not is_total_case:
            current_b_value = ws[f"B{group_start}"].value
            merge_start = group_start

            for r in range(group_start + 1, group_end + 1):
                if ws[f"B{r}"].value == current_b_value:
                    continue
                else:
                    if merge_start < r - 1:
                        ws.merge_cells(f"B{merge_start}:B{r - 1}")
                    current_b_value = ws[f"B{r}"].value
                    merge_start = r

            if merge_start < group_end:
                ws.merge_cells(f"B{merge_start}:B{group_end}")

        # Специальное объединение для разных случаев
        if is_special_case:
            # Для "В том числе..." объединяем A и B для всей группы
            ws.merge_cells(f"A{group_start}:B{group_end}")
        elif is_total_case:
            # Для "Всего масса металла:" объединяем A и B только для текущей строки
            ws.merge_cells(f"A{group_start}:B{group_start}")
        else:
            # Стандартное объединение для столбца A
            if group_start != group_end:
                ws.merge_cells(f"A{group_start}:A{group_end + 1}")



def merge_AB_for_totals(ws, target_value="В том числе по маркам или наименованиям"):
    """
    Объединяет ячейки столбцов A и B в единый прямоугольник,
    если их значения равны target_value.
    Старые объединения в A и B удаляются, чтобы не портить файл.
    """
    to_merge = []

    for row in range(3, ws.max_row + 1):
        val_a = ws[f"A{row}"].value
        val_b = ws[f"B{row}"].value

        if val_a == target_value and val_b == target_value:
            range_a = None
            range_b = None

            # Ищем диапазоны объединения для A и B
            for merged_range in ws.merged_cells.ranges:
                if f"A{row}" in merged_range:
                    range_a = merged_range
                if f"B{row}" in merged_range:
                    range_b = merged_range

            if range_a and range_b:
                min_row = min(range_a.min_row, range_b.min_row)
                max_row = max(range_a.max_row, range_b.max_row)
                to_merge.append((min_row, max_row))

    # Удаляем старые объединения, которые пересекаются с нашими диапазонами
    for merged_range in list(ws.merged_cells.ranges):
        for min_row, max_row in to_merge:
            if merged_range.min_row >= min_row and merged_range.max_row <= max_row and merged_range.min_col in (1, 2):
                ws.unmerge_cells(str(merged_range))

    # Создаем новые объединения A:B
    for min_row, max_row in to_merge:
        ws.merge_cells(start_row=min_row, start_column=1, end_row=max_row, end_column=2)

def print_df(df, column):
    # Печать столбца без ограничений
    pd.set_option('display.max_colwidth', None)  # показывать полные значения ячеек
    print("\n🔹(полный вывод):")
    print(df[f'{column}'].to_string(index=False))
    # print(df[['Элемент марки', 'group']].head(20)) # напечатать строки

def sheet1_0(xls, group_discharge=None, code_project=''):
    log_message(f'Подготавливаю ведомость металлопроката', "title")

    kMasE = None  # Инициализируем переменную
    oismk_conf = find_settings_file(Path(xls).parent, "OiSMK.txt")

    with open(oismk_conf, "r", encoding="utf-8") as file:  # Открываем файл
        for line in file:
            if line.startswith("kMasE"):  # Ищем строку, начинающуюся с kMasE
                kMasE = float(line.split("=")[1].strip())  # Берём значение и преобразуем в float
            if line.startswith("kMasE"):  # Ищем строку, начинающуюся с kMasE
                kMasM = float(line.split("=")[1].strip())  # Берём значение и преобразуем в float
                break  # Прерываем цикл, так как нашли нужное значение

    xlsx = Path(xls).parent / '1.0 _ Ведомость металлопроката.xlsx'

    if group_discharge is None or group_discharge == '':
        try:
            group_discharge = int(input(f'\nВведите кол-во знаков после букв наименования марок для группировки: '))
        except ValueError:
            log_message(f"Ошибка: необходимо ввести только цифры.", "error")
            return

    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler
    df = excel_handler.read_excel(header_row=0).dropna(subset=['Эскиз сечения'])  # Читаем и сразу удаляем пустые строки

    df = df[['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Сечение из Компас', 'Сечение',
             'Масса элемента, кг', 'Масса элементов, кг', 'Элемент марки', 'Толщина, мм', 'Эскиз сечения',
             'Ширина, мм', 'Длина, мм', 'Кол-во, шт.','№ элемента', 'Масса 1 м, кг', 'Полное имя файла']] # Отсортируем таблицу

    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом

    df = update_element_mass(df, kMasE)

    df = df[['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Сечение из Компас',
             'Масса элементов, кг', 'Элемент марки', 'Толщина, мм', 'Эскиз сечения', 'Ширина, мм', 'Длина, мм',
             'Кол-во, шт.']] # Отсортируем таблицу

    # Маска для строк, где нужно переписать сечения на толщину
    mask = df['Эскиз сечения'].astype(str).str.contains('@016|@137', na=False)
    # Теперь формируем Сечение из Компас вида t2 или t2,5
    # Добавляем 't' к толщинам пластин
    df.loc[mask, 'Сечение из Компас'] = df.loc[mask, 'Толщина, мм'].apply(
        lambda x: f"t{int(float(x))}" if str(x).replace(',', '.').replace(' ', '') != '' and float(x).is_integer()
        else f"t{str(x).replace('.', ',')}"
    )

    excel_handler.data = df # Обновляем данные в ExcelHandler перед вызовом
    df = excel_handler.replace_symbols('Сечение из Компас')  # Дополнительная обработка для замены эскиза сечения на наименование
    excel_handler.data = df  # Обновляем данные в ExcelHandler перед вызовом

    # df = excel_handler.line_joining_df(
    #     compare_columns=['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ',
    #                      'Сечение из Компас', 'Толщина, мм', 'Эскиз сечения'],
    #     sum_columns=['Масса элементов, кг'],
    #     concatenate_columns=None,  # Если есть столбцы для объединения строк, добавь сюда
    #     ignore_column=['Элемент марки'],  # Если есть столбцы, которые нужно исключить, добавь сюда
    #     ignore_value=None
    # )

    df = excel_handler.line_joining_df(
        compare_columns=[
            'Наименование профиля ГОСТ, ТУ',
            'Наименование или марка металла ГОСТ, ТУ',
            'Сечение из Компас',
            'Толщина, мм',  # оставить, если нужна дифференциация по толщине
            'Элемент марки',          # убрать, если не нужен разрез по маркам
            # 'Эскиз сечения',          # чаще всего мешает склейке
        ],
        sum_columns=['Масса элементов, кг'],
        coerce_numeric_compare=True,  # ВКЛ — приведёт compare-числа и округлит
        decimals=6,
    )


    df = df[['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Сечение из Компас', 'Масса элементов, кг',
             'Элемент марки', 'Толщина, мм', 'Эскиз сечения']] # Отсортируем таблицу

    df = df.sort_values(
        by=['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Сечение из Компас'],
        key=lambda col: col.map(parse_size_key) if col.name == 'Сечение из Компас' else col,
        ascending=[True, True, True]
    ).reset_index(drop=True)

    # Создаем новый столбец для группировки марок элементов на основе group_discharge
    df['group'] = df['Элемент марки'].apply(lambda x: parse_letters_numbers(x, group_discharge=group_discharge))

    # Группировка по значениям из столбцов A, B, C и новому столбцу 'group', суммирование масс
    grouped = df.groupby(
        ['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ', 'Сечение из Компас',
         'Эскиз сечения','group'], sort=False)['Масса элементов, кг'].sum().reset_index()

    # # Округление значений в столбце 'Масса элементов' до 3 знака после запятой
    grouped['Масса элементов, кг'] = grouped['Масса элементов, кг'].apply(lambda x: round_up(x, 3))

    # Создаем сводную таблицу, где массы распределены по столбцу 'group'
    pivot = grouped.pivot_table(index=['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ',
                                       'Сечение из Компас', 'Эскиз сечения'], sort=False,
                                columns='group', values='Масса элементов, кг', aggfunc='sum', fill_value=0).reset_index()

    # Список фиксированных столбцов
    fixed_cols = ['Наименование профиля ГОСТ, ТУ', 'Наименование или марка металла ГОСТ, ТУ',
                  'Сечение из Компас', 'Эскиз сечения']

    # Определим групповые столбцы (все, что не в fixed_cols)
    group_cols = [col for col in pivot.columns if col not in fixed_cols]

    # Сортируем групповые столбцы
    group_cols_sorted = sorted(group_cols, key=lambda x: parse_letters_numbers(x, as_sort_key=True))

    # Формируем итоговый порядок столбцов (без 'Итого', т.к. он будет добавлен позже)
    pivot = pivot[fixed_cols + group_cols_sorted]

    # Добавление столбца с суммой всех сгруппированных масс
    pivot['Итого'] = pivot.iloc[:, 3:].apply(pd.to_numeric, errors='coerce').sum(axis=1)

    # Удаление исходного столбца "Элемент марки" (F) и 'group' в исходном df, так как они больше не требуются
    df.drop(columns=['Элемент марки', 'group'], inplace=True)

    # Получение уникальных профилей и их эскизов
    unique_profiles = pivot[['Наименование профиля ГОСТ, ТУ', 'Эскиз сечения']].drop_duplicates()

    # Профили с эскизами, кроме @016 и @137
    mask_sheet = unique_profiles['Эскиз сечения'].isin(['@016', '@137'])
    mask_no_at = ~unique_profiles['Эскиз сечения'].astype(str).str.contains('@')

    non_sheet_profiles = unique_profiles[~mask_sheet & ~mask_no_at]['Наименование профиля ГОСТ, ТУ'].tolist()
    no_at_profiles = unique_profiles[mask_no_at]['Наименование профиля ГОСТ, ТУ'].tolist()
    sheet_profiles = unique_profiles[mask_sheet]['Наименование профиля ГОСТ, ТУ'].tolist()
    # Объединяем группы в правильном порядке
    all_profiles = non_sheet_profiles + no_at_profiles + sheet_profiles
    # Создаем сопоставление профилей с номерами
    profile_mapping = {profile: i + 1 for i, profile in enumerate(all_profiles)}
    # Применяем к pivot
    pivot['№'] = pivot['Наименование профиля ГОСТ, ТУ'].map(profile_mapping)

    # Сортируем сохраняя предыдущую сортировку по сечению
    # pivot['sort_key'] = pivot['Сечение из Компас'].map(parse_size_key)
    # pivot.sort_values(by=['№', 'sort_key'], ascending=[True, True], inplace=True)
    # pivot.drop(columns=['sort_key'], inplace=True)

    # Приведение данных к единому формату для сортировки
    pivot['metal_sort_key'] = pivot['Наименование или марка металла ГОСТ, ТУ'].map(parse_size_key)
    pivot['section_sort_key'] = pivot['Сечение из Компас'].map(parse_size_key)

    # Сортировка по нескольким столбцам
    pivot.sort_values(by=['№', 'metal_sort_key', 'section_sort_key'], ascending=[True, True, True], inplace=True)

    # Удаляем временные столбцы сортировки
    pivot.drop(columns=['metal_sort_key', 'section_sort_key'], inplace=True)

    #####
    # # Добавим сортировку по столбцу 'Наименование или марка металла ГОСТ, ТУ' и 'Сечение из Компас'
    # pivot['metal_sort_key'] = pivot['Наименование или марка металла ГОСТ, ТУ'].map(parse_size_key)
    # pivot['section_sort_key'] = pivot['Сечение из Компас'].map(parse_size_key)
    # # Сортируем сначала по '№', затем по 'metal_sort_key', затем по 'section_sort_key'
    # pivot.sort_values(by=['№', 'metal_sort_key', 'section_sort_key'], ascending=[True, True, True], inplace=True)
    # # Удалим временные ключи сортировки
    # pivot.drop(columns=['metal_sort_key', 'section_sort_key'], inplace=True)

    # Вставляем столбец '№' на четвертую позицию
    pivot.insert(3, '№', pivot.pop('№'))

    pivot = insert_summary_rows(pivot, '№', 'Сечение из Компас')

    pivot.replace(0, '', inplace=True) # Удалим 0

    df = pivot.drop(columns=['Эскиз сечения'])# Удалим столбец 'Эскиз сечения'

    # Сортировка столбцов с 5-го по предпоследний, оставляя последний на месте
    df = df[df.columns[:4].tolist() + sorted(df.columns[4:-1].tolist()) + [df.columns[-1]]]

    # Сохранение в новый Excel файл
    with pd.ExcelWriter(xlsx, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Спецификация металлопроката')
        ws = writer.sheets['Спецификация металлопроката']

        ws.freeze_panes = ws['E4']# Закрепление первой строки и первого столбца

        # --- Проверка на количество столбцов между E и последним ---
        start_col = 5  # E
        last_col = ws.max_column #Всего столбцов
        between_cols = last_col - start_col

        min_required = 4  # Минимум столбцов между E и последним

        if between_cols < min_required:
            to_insert = min_required - between_cols
            ws.insert_cols(last_col, amount=to_insert)# Вставляем пустые столбцы перед последним столбцом
            last_col = ws.max_column  # Обновляем последний столбец после вставки

        max_col = ws.max_column  # Определяем количество столбцов (уже после вставок)
        last_col_letter = get_column_letter(max_col)
        first_data_col = 5  # E
        last_data_col = max_col - 1  # предпоследний

        ws.insert_rows(1, amount=2) # Вставляем две строки сверху
        ws.merge_cells(f"A1:{last_col_letter}1") # Объединяем A1:End1 — название таблицы

        ws["A1"].value = f"{code_project}Спецификация металлопроката"
        ws["A1"].alignment = Alignment(horizontal="left", vertical="center")

        # Вертикальное объединение A2:A3, B2:B3, ... E2:E3
        for col in range(1, 5):  # A..E
            letter = get_column_letter(col)
            ws.merge_cells(f"{letter}2:{letter}3")
            cell = ws[f"{letter}2"]
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        # Горизонтальное объединение E2:предпоследний столбец
        if first_data_col <= last_data_col:
            start_letter = get_column_letter(first_data_col)
            end_letter = get_column_letter(last_data_col)
            ws.merge_cells(f"{start_letter}2:{end_letter}2")
            ws[f"{start_letter}2"].value = "Масса металла по элементам конструкций, кг"
            ws[f"{start_letter}2"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        # Последний столбец объединяем на 2 строки
        ws.merge_cells(f"{last_col_letter}2:{last_col_letter}3")
        ws[f"{last_col_letter}2"].value = "Общая масса, кг"
        ws[f"{last_col_letter}2"].alignment = Alignment(horizontal="center", vertical="center")

        # --- Вставляем строку с номерами столбцов ---
        ws.insert_rows(4)  # Сдвигаем всё вниз, чтобы новая строка была между 3 и 4
        for col_idx in range(1, ws.max_column + 1):
            col_letter = get_column_letter(col_idx)
            # ws[f"{col_letter}4"].value = col_idx  # номер столбца
            ws[f"{col_letter}4"].value = "=COLUMN()"
            ws[f"{col_letter}4"].alignment = Alignment(horizontal="center", vertical="center")


        ###Название таблицы
        ws["A2"] = "Наименование профиля ГОСТ, ТУ"
        ws["B2"] = "Наименование или марка металла ГОСТ, ТУ"
        ws["C2"] = "Номер и размеры профиля, мм"
        ws["D2"] = "№"

        # --- Вызываем функцию вставки пустых строк и объединения---
        insert_padding_and_merge(ws, col_idx=1, cols_to_merge=(1, 2), header_rows=4, min_group_len=3)
        # merge_AB_for_totals(ws) # Объединим ячейки "В том числе по маркам или наименованиям"

        # Номера строк в столбце D
        for r in range(5, ws.max_row + 1):
            ws[f"D{r}"].value = "=ROW()-4"

        # --- Formulas for "Итого профиля": vertical sums E..penultimate + row total into last column ---
        sum_fn = "SUM"  # английские имена функций Excel

        first_data_row = 5
        first_data_col = 5  # E
        last_data_col = max_col - 1  # предпоследний
        last_col_letter = get_column_letter(max_col)

        for r_sum in range(first_data_row, ws.max_row + 1):
            if str(ws[f"B{r_sum}"].value).strip() == "Итого профиля":
                # верхняя граница блока: до предыдущего "Итого профиля" или до first_data_row
                r_top = r_sum - 1
                while r_top >= first_data_row and str(ws[f"B{r_top}"].value).strip() != "Итого профиля":
                    r_top -= 1

                data_start = first_data_row if r_top < first_data_row else r_top + 1
                data_end = r_sum - 1

                if data_end >= data_start:
                    # Вертикальные суммы в E..предпоследний
                    for c in range(first_data_col, last_data_col + 1):
                        col_letter = get_column_letter(c)
                        vrng = f"{col_letter}{data_start}:{col_letter}{data_end}"
                        ws[f"{col_letter}{r_sum}"].value = f'=IF({sum_fn}({vrng})=0,"",{sum_fn}({vrng}))'

        # --- Last column: row-wise total for ALL rows (E..penultimate); blank if zero ---
        # Горизонтальная сумма по строке в последний столбец "Общая масса, кг"
        for r in range(first_data_row, ws.max_row + 1):
            row_rng = f"{get_column_letter(first_data_col)}{r}:{get_column_letter(last_data_col)}{r}"
            ws[f"{last_col_letter}{r}"].value = f'=IF({sum_fn}({row_rng})=0,"",{sum_fn}({row_rng}))'

        # --- "Всего масса металла:" — SUMIF по строкам с B="Итого профиля" (E..последний) ---
        # найти строку "Всего масса металла:" в колонке A
        total_row = None
        for r in range(first_data_row, ws.max_row + 1):
            if str(ws[f"A{r}"].value).strip() == "Всего масса металла:":
                total_row = r
                break

        if total_row:
            crit_col_range = f"$B${first_data_row}:$B${total_row - 1}"  # критерий по B
            for c in range(first_data_col, max_col + 1):  # E..последний
                col_letter = get_column_letter(c)
                sum_col_range = f"{col_letter}{first_data_row}:{col_letter}{total_row - 1}"
                # =IF(SUMIF($B$5:$B$N,"Итого профиля",E5:EN)=0,"",SUMIF(...))
                ws[f"{col_letter}{total_row}"].value = (
                    f'=IF(SUMIF({crit_col_range},"Итого профиля",{sum_col_range})=0,"",'
                    f'SUMIF({crit_col_range},"Итого профиля",{sum_col_range}))'
                )

        #-#
        ws.row_dimensions[1].height = 18  # Установка высоты 1 строки 10 мм
        ws.row_dimensions[2].height = 18  # Установка высоты 2 строки 10 мм
        ws.row_dimensions[3].height = 36 # Установка высоты 2 строки 20 мм
        ws.row_dimensions[4].height = 9 # Установка высоты 3 строки 5


        # Установка ширины столбцов
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 30
        ws.column_dimensions['C'].width = 30
        ws.column_dimensions['D'].width = 10

        # Установка ширины столбцов с "E" до последнего столбца
        for col in range(column_index_from_string('E'), max_col + 1):  # Начиная с "E" до последнего столбца
            col_letter = openpyxl.utils.get_column_letter(col)
            ws.column_dimensions[col_letter].width = 15

        # Установка ширины последнего столбца на 25
        last_col_letter = openpyxl.utils.get_column_letter(max_col)
        ws.column_dimensions[last_col_letter].width = 25

        # Выравнивание всех ячеек в таблице по центру
        for row in ws.iter_rows(min_row=3, max_row=ws.max_row, min_col=1, max_col=max_col):
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')

        # Выравнивание столбцов по горизонтали влево
        for col in ['A', 'B', 'C']:
            # Применяем выравнивание для всех строк
            for row in range(2, ws.max_row + 1):
                cell = ws[f'{col}{row}']
                cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)

        # Перенос текста во второй строке (заголовки)
        for cell in ws[2]:
            cell.alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')

        # Выделение первой строки жирным шрифтом
        bold_font = Font(bold=True)
        for col in range(1, max_col + 1):
            ws.cell(row=1, column=col).font = bold_font# Применяем жирный шрифт к первой строке

        # # Создаём стиль с форматом чисел до целого знака после запятой
        # round_one_decimal = NamedStyle(name="round_one_decimal", number_format="0")
        # round_one_decimal.alignment = Alignment(horizontal="center", vertical="center")
        #
        # # Применяем стиль к нужным строкам и столбцам
        # for row in ws.iter_rows(min_row=4):
        #     for cell in row:
        #         if isinstance(cell.value, (int, float)): # проверка, является ли значение числом
        #             cell.style = round_one_decimal
        numfmt = "0"  # или '#,##0.000' если нужны три знака
        for row in ws.iter_rows(min_row=4, max_row=ws.max_row, min_col=5, max_col=ws.max_column):  # E..последний
            for cell in row:
                cell.number_format = numfmt  # работает и для формул
                cell.alignment = Alignment(horizontal="center", vertical="center")

        ###Оформления заголовка
        # ws.merge_cells(start_row=1, start_column=1, end_row=1,end_column=ws.max_column)  # Объединить ячейки первой строки
        cell = ws.cell(row=1, column=1)
        cell.font = openpyxl.styles.Font(bold=True)
        cell.alignment = Alignment(horizontal='left', vertical='center')

        for cell in ws[2]:  # Итерируем по ячейкам в строке
            cell.alignment = Alignment(wrapText=True, horizontal="center", vertical="center")

        # Настройка формата: серый цвет и жирный шрифт
        gray_fill = PatternFill(start_color="C0C0C0", end_color="C0C0C0", fill_type="solid")
        bold_font = Font(bold=True)
        center_alignment = Alignment(horizontal="center", vertical="center")
        right_alignment = Alignment(horizontal="right", vertical="center")

        # Перебор строк, начиная с третьей
        for row in ws.iter_rows(min_row=3):
            for cell in row:
                # Проверка, содержит ли ячейка слово "Итого"
                if cell.value and "Итого" in str(cell.value):
                    for cell_in_row in row: # Применение формата к всей строке
                        cell_in_row.fill = gray_fill
                        cell_in_row.font = bold_font
                        cell_in_row.alignment = center_alignment# Установка выравнивания по центру для всех ячеек строки
                    cell.alignment = right_alignment# Установка выравнивания вправо только для ячейки с "Итого"
                    break  # Прекращаем проверку остальных ячеек в строке, если нашли "Итого"

        # Создаём стиль рамки (тонкая линия) границы таблицы
        thin = Side(border_style="thin", color="000000")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)

        # Определяем диапазон таблицы
        min_row, max_row = 1, ws.max_row
        min_col, max_col = 1, ws.max_column

        # Применяем рамку к каждой ячейке
        for row in ws.iter_rows(min_row=min_row, max_row=max_row,
                                min_col=min_col, max_col=max_col):
            for cell in row:
                cell.border = border

    log_message(f'Ведомость металлопроката - создана', 'ok')

if __name__ == "__main__":

    KompasObject, iApplication, KompasVersion = get_kompas()
    path = get_active_doc_path(iApplication)
    xls = easygui.fileopenbox(msg="Укажите файл отчета Общий отчёт.xls", title="", default=f"{path}/*Общий отчёт.xlsx")  # Путь до файла отчёта
    sheet1_0(xls)
    input('\n\rРабота завершена.\n')

    # Для отладки
    # xls = r"C:\Users\ik\Desktop\Пример\Общий отчёт.xlsx"
    # sheet1_0(xls, 0)

    # Печать столбца без ограничений
    # pd.set_option('display.max_colwidth', None)  # показывать полные значения ячеек
    # print("\n🔹 Секция из Компас (полный вывод):")
    # print(pivot['Сечение из Компас'].to_string(index=False))
    # print(df[['Элемент марки', 'group']].head(20)) # напечатать строки