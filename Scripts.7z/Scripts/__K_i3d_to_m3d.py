from pathlib import Path
from time import sleep

from __Kompas import *
""""Импорт из igs или step в k3d"""

def get_gabarit(iPart7):
    KompasObject, iApplication, KompasVersion = get_kompas()
    if KompasVersion >= 23:
        bool, x1, y1, z1, x2, y2, z2 = iPart7.GetGabarit(False, False)

    else:
        iFeature7 = API7.IFeature7(iPart7)
        iBody7 = iFeature7.ResultBodies
        bool, x1, y1, z1, x2, y2, z2 = iBody7.GetGabarit()

    obj_X = x2 - x1 #'габаритный размер по оси X
    obj_Y = x2 - x1 #'габаритный размер по оси Y
    obj_Z = x2 - x1 #'габаритный размер по оси Z

    return obj_X, obj_Y, obj_Z, x1, y1, z1, x2, y2, z2

def get_centering_shift(iPart7_top, tolerance=1e-6):
    """
    Вычисляет смещение (dx, dy, dz), необходимое для перемещения ЛСК
    в геометрический центр габаритного прямоугольника тела.

    :param iPart7_top: объект тела (IKompasPart7)
    :param tolerance: допустимая погрешность, при которой смещение считается ненужным
    :return: кортеж (dx, dy, dz)
    """
    obj_X, obj_Y, obj_Z, x1, y1, z1, x2, y2, z2 = get_gabarit(iPart7_top)

    # Вычисляем центр габарита относительно текущей ЛСК
    center_x = (x1 + x2) / 2
    center_y = (y1 + y2) / 2
    center_z = (z1 + z2) / 2

    # Проверяем, находится ли центр уже в начале координат
    if abs(center_x) < tolerance and abs(center_y) < tolerance and abs(center_z) < tolerance:
        # print("✅ Тело уже центрировано по ЛСК — смещения не требуется")
        return 0.0, 0.0, 0.0
    # Вычисляем требуемое смещение
    dx = -center_x
    dy = -center_y
    dz = -center_z

    # print(f"❗ Требуется смещение: dx={dx:.2f}, dy={dy:.2f}, dz={dz:.2f}")
    return dx, dy, dz

def i3d_to_m3d(file_to_import, KompasObject):
    # print(f'file_to_import:{file_to_import}'
    ksDocument3D = KompasObject.Document3D()
    file_to_import = Path(file_to_import)  # Преобразуем строку в объект Path
    file_m3d = file_to_import.with_suffix('.m3d')  # Замена расширения на .m3d
    if file_m3d.exists(): # Если файл существует, удалить его
        file_m3d.unlink()  # Удаляем файл

    ksDocument3D.Create(True, True)  # Создать документ-модель (невидимый режим, деталь)
    ksAdditionFormatParam = ksDocument3D.AdditionFormatParam()

    # Импорт из нужного формата
    format_map = {'.stp': -3, '.igs': -4}
    if file_to_import.suffix in format_map:
        ksAdditionFormatParam.format = format_map[file_to_import.suffix]
        ksDocument3D.LoadFromAdditionFormat(file_to_import, ksAdditionFormatParam)

    ksDocument3D.Save()
    ksDocument3D.close()
    # iKompasDocument3D = KompasObject.TransferInterface(ksDocument3D, 2, 0)
    # iPart7_top = iKompasDocument3D.TopPart
    #
    # dx, dy, dz = get_centering_shift(iPart7_top)
    #
    # iFeature7 = API7.IFeature7(iPart7_top)
    # iBody7 = iFeature7.ResultBodies
    #
    # iModelContainer = API7.IModelContainer(iPart7_top)
    # iBodyRepositions = iModelContainer.BodyRepositions
    # iBodyReposition = iBodyRepositions.Add()
    #
    # iBodyReposition.RepositionBody = iBody7
    # iLocalCoordinateSystem = iBodyReposition.Position
    # iLocalCoordinateSystem.X = dx
    # iLocalCoordinateSystem.Y = dy
    # iLocalCoordinateSystem.Z = dz
    # iBodyReposition.Update()
    # #
    # # # iKompasDocument3D.DeleteHistory()
    # #
    # ksDocument3D.Save()
    # ksDocument3D.close()

    # print(f'{file_to_import} - готово')
    return file_m3d

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    file_to_import = r'C:\Users\ik\Desktop\!2060.1-60-009-КМД _ МК1 и МК2\03 _ Design\!01 _ CAD\part\Пластины\igs\2033.igs'
    i3d_to_m3d(file_to_import, KompasObject)


