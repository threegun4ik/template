import sys, easygui
from pathlib import Path
import math

from __Kompas import *
import _Config

from __Debug import *

"""Вставляем в m3d маркировку"""

def marking_3d(filename_m3d, marking, iApplication):
    filename_m3d = str(filename_m3d)
    iDocuments = iApplication.Documents
    iKompasDocument, opened = iDocuments.Item(filename_m3d), True  # Проверяем, открыт ли документ

    try:
        if not iKompasDocument:
            iKompasDocument = iDocuments.Open(filename_m3d, False, False)
            opened = False  # Документ был открыт в этом скрипте
        if not iKompasDocument:
            log_message('Ошибка: не удалось открыть файл {filename_m3d}', 'error')
            return


        iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)

        iPart7 = iKompasDocument3D.TopPart # Верхний компонент (сам документ)
        iModelContainer = API7.IModelContainer(iPart7) # Интерфейс контейнера трехмерных объектов
        iFaces = iModelContainer.Objects(con3.o3d_face)# Грани детали

        EPSILON = 1e-6  # Допуск для сравнения площадей
        area = -1
        face_max_list = []

        # Проходим по всем граням
        for iFace in iFaces:
            iMathSurface3D = iFace.MathSurface

            paramUMax = round(iMathSurface3D.ParamUMax)
            paramVMax = round(iMathSurface3D.ParamVMax)
            paramUMin = round(iMathSurface3D.ParamUMin)
            paramVMin = round(iMathSurface3D.ParamVMin)

            _, Nx, Ny, Nz = (round(val) for val in iMathSurface3D.GetNormal(paramUMax, paramVMax)) #получаем нормаль
            _, x_1, y_1, z_1, x_2, y_2, z_2 = (round(val) for val in iMathSurface3D.GetGabarit()) #получаем габарит поверхности
            surface_type = iMathSurface3D.Surface3DType # Тип поверхности
            iFace_area = iFace.GetArea(3)  # Площадь грани

            if iFace_area > area + EPSILON:  # Новый максимум
                area = iFace_area
                face_max_list = [(iFace, x_1, y_1, z_1, x_2, y_2, z_2, surface_type, Nx, Ny, Nz)]

            elif abs(iFace_area - area) < EPSILON:  # Добавлять только такие же площади
                face_max_list.append((iFace, x_1, y_1, z_1, x_2, y_2, z_2, iMathSurface3D.Surface3DType, Nx, Ny, Nz))

        # Убираем дубли площадей
        max_distance_y_oz = -float('inf')
        max_distance_x_oy = -float('inf')

        # Итерируем в обратном порядке, чтобы не пропускать элементы после удаления
        i = len(face_max_list) - 1
        while i >= 0:
            iFace, x_1, y_1, z_1, x_2, y_2, z_2, surface_type, Nx, Ny, Nz = face_max_list[i]

            # Проверяем нормаль и вычисляем расстояние от плоскости YOZ
            if Nx == 1 or Nx == -1:  # Параллельно плоскости YOZ
                distance = max(abs(x_1), abs(x_2))
                if distance < max_distance_y_oz:  # Удаляем элементы, не на максимальном расстоянии
                    face_max_list.pop(i)
                else:
                    max_distance_y_oz = distance

            # Проверяем нормаль и вычисляем расстояние от плоскости XOY
            elif Ny == 1 or Ny == -1:  # Параллельно плоскости XOY
                distance = max(abs(y_1), abs(y_2))
                if distance < max_distance_x_oy:  # Удаляем элементы, не на максимальном расстоянии
                    face_max_list.pop(i)
                else:
                    max_distance_x_oy = distance

            i -= 1  # Переходим к предыдущему элементу

        #Делаем окончательный выбор
        def select_parallel_face(face_max_list):
            priority_order = [
                ((1, 0, 0), "+YOZ"),  # Параллельно YOZ, Nx > 0
                ((0, 1, 0), "+XOZ"),  # Параллельно XOY, Ny > 0
                ((0, 0, 1), "+XOZ"),  # Параллельно XOZ, Nz > 0
                ((-1, 0, 0), "-YOZ"),  # Параллельно YOZ, Nx < 0
                ((0, -1, 0), "-XOZ"),  # Параллельно XOY, Ny < 0
                ((0, 0, -1), "-XOZ")  # Параллельно XOZ, Nz < 0
            ]

            EPSILON = 1e-6  # Допустимая погрешность для нормалей

            # Перебор приоритетных нормалей
            for (Nx_cond, Ny_cond, Nz_cond), plane_label in priority_order:
                max_abs_coord = float('-inf')
                best_face = None

                # Перебор всех граней
                for iFace in face_max_list:
                    _, x1, y1, z1, x2, y2, z2, surface_type, Nx, Ny, Nz = iFace
                    # Проверка на нормаль
                    if (math.isclose(Nx, Nx_cond, abs_tol=EPSILON) and
                            math.isclose(Ny, Ny_cond, abs_tol=EPSILON) and
                            math.isclose(Nz, Nz_cond, abs_tol=EPSILON)):

                        # Выбор по максимальной координате
                        coord = abs(x1) if Nx != 0 else abs(y1) if Ny != 0 else abs(z1)
                        if coord > max_abs_coord or (coord == max_abs_coord and x1 > 0):
                            max_abs_coord = coord
                            # Добавляем метку плоскости в iFace
                            best_face = (*iFace, plane_label)  # Добавляем plane_label в кортеж
                # Если найдено лучшее совпадение, возвращаем найденную грань с меткой
                if best_face:
                    return best_face  # Возвращаем грань с меткой плоскости

            return None  # Если не нашли подходящих граней

        iFace_max = select_parallel_face(face_max_list)  # Выбираем плоскость
        # print(iFace_max)
        if iFace_max:
            iFace, x_1, y_1, z_1, x_2, y_2, z_2, surface_type, Nx, Ny, Nz, plane_label = iFace_max
        else:
            log_message('Не удалось выбрать грань в файле {filename_m3d}', 'warn')
            return None

        # print('Выбрали грань')
        # print(f'{iFace}: x1={x_1}, y1={y_1}, z1={z_1}, x2={x_2}, y2={y_2}, z2={z_2}, Нормаль: {plane_label}({Nx}, {Ny}, {Nz})')

        size_x = abs(x_2 - x_1)
        size_y = abs(y_2 - y_1)
        size_z = abs(z_2 - z_1)
        # print(size_x, size_y, size_z)

        if plane_label == '+YOZ':
            # print('+YOZ')
            h_font = min(abs(size_z) // 2, _Config.max_h_font)
            text_angle = 0.0
            text_shift_X = 0.0
            text_shift_Y = -h_font/2

        if plane_label == '-YOZ':
            # print('-YOZ')
            h_font = min(abs(size_y) // 2, _Config.max_h_font)
            text_angle = 0.0
            text_shift_X = 0.0
            text_shift_Y = h_font / 2

        if plane_label == '+XOZ':
            # print('+XOZ')
            h_font = min(abs(size_z // 2), _Config.max_h_font)
            text_angle = -90.0
            text_shift_X = -h_font/2
            text_shift_Y = 0.0

        if plane_label == '-XOZ':
            # print('-XOZ')
            h_font = min(abs(size_z // 2), _Config.max_h_font)

            if surface_type == 4:
                text_angle = 0.0
                text_shift_X = 0.0
                text_shift_Y = -h_font / 2
            else:
                text_angle = 90.0
                text_shift_X = h_font / 2
                text_shift_Y = 0.0


        if surface_type == 4:
            #  Создай объект модели "Касательная плоскость"
            iAuxiliaryGeomContainer = API7.IAuxiliaryGeomContainer(iPart7)
            planes_3d = iAuxiliaryGeomContainer.Planes3D
            iPlane3DTangentToFace = API7.IPlane3DTangentToFace(planes_3d.Add(con3.o3d_planeTangent))
            iPlane3D1 = API7.IPlane3D1(iPlane3DTangentToFace)
            iPlane3D1.ScaleGabarit = False
            iPlane3D1.ShowName = False
            iPlane3DTangentToFace.Face = iFace
            iPlane3DTangentToFace.Plane = iPart7.DefaultObject(con3.o3d_planeXOZ)
            iPlane3DTangentToFace.Angle = 0.0
            iPlane3DTangentToFace.Orientation = False
            iPlane3DTangentToFace.Name = "Маркировка"
            iPlane3DTangentToFace.Hidden = False
            iPlane3DTangentToFace.Update()
            model_object_1 = iPlane3DTangentToFace
            iFace = iPlane3DTangentToFace.Face

        # Вставляем эскиз
        iSketchs = iModelContainer.Sketchs
        iSketch = iSketchs.Add()
        iSketch.DirectingObject(con3.o3d_axisOX)
        if surface_type == 4:
            iSketch.Plane = iPlane3DTangentToFace
        else:
            iSketch.Plane = iFace
        iSketch.Name = marking
        iSketch.Hidden = False
        iSketch.Angle = -90.0

        iSketch.LeftHandedCS = False
        iSketch.Update()

        iFragmentDocument = iSketch.BeginEdit() # Войди в режим редактирования эскиза
        #  Создай графический объект текст
        iKompasDocument2D = API7.IKompasDocument2D(iFragmentDocument)
        iViewsAndLayersManager = iKompasDocument2D.ViewsAndLayersManager
        iViews = iViewsAndLayersManager.Views
        iView = iViews.ActiveView

        iDrawingContainer = API7.IDrawingContainer(iView)
        iDrawingTexts = iDrawingContainer.DrawingTexts
        iDrawingText = iDrawingTexts.Add()
        iDrawingText.X = text_shift_X
        iDrawingText.Y = text_shift_Y
        iDrawingText.Angle = text_angle
        iDrawingText.HFormat = con0.ksHFormatNot
        iDrawingText.VFormat = False
        iDrawingText.Allocation = con0.ksAlCentre
        iDrawingText.MirrorSymmetry = False
        iDrawingText.LayerNumber = 1
        iDrawingText.Update()

        iText = API7.IText(iDrawingText)
        iText.Style = con0.ksTSDrawingAnnotation

        iTextLine = iText.Add()
        iTextLine.Style = con0.ksTSDrawingAnnotation
        iTextLine.Step = 1.0
        iTextLine.Align = con0.ksAlignLeft
        iTextLine.IndentedLine = 0.0
        iTextLine.StepBeforeParagraph = 0.0
        iTextLine.StepAfterParagraph = 0.0
        iTextLine.LeftEdge = 0.0
        iTextLine.RightEdge = 0.0
        iTextLine.Level = 0
        iTextLine.Numbering = con0.ksTNumbNoNumber
        iTextLine.NewPage = False

        iTextItem = iTextLine.Add()
        iTextItem.ItemType = con0.ksTItString
        iTextItem.NewLine = True
        iTextItem.Str = marking

        iTextFont = API7.ITextFont(iTextItem)
        iTextFont.FontName = "GOST type AU"
        iTextFont.Height = h_font
        iTextFont.WidthFactor = 1.0
        iTextFont.Color = 0
        iTextFont.Bold = False
        iTextFont.Italic = False
        iTextFont.Underline = False
        iTextFont.TextLineStep = 0.0
        iTextItem.Update()
        iDrawingText.Update()

        iSketch.EndEdit() #  Выйди из режима редактирования эскиза

        IModelContainer = API7.IModelContainer(iPart7)

        if surface_type == 4:
            # print('Труба')
            #  Создай объект модели "Вырезать выдавливанием" до поверхности
            iExtrusions = IModelContainer.Extrusions
            iExtrusion = API7.IExtrusion(iExtrusions.Add(con3.o3d_cutExtrusion))
            iExtrusion.Direction = con3.dtNormal
            iExtrusion.Name = "Маркировка"
            iExtrusion.Hidden = False
            iExtrusion.SetExtrusionType(True, con3.etUpToSurfaceFrom)
            iExtrusion.SetDraftOutward(True, False)
            iExtrusion.SetDraftValue(True, 0.0)
            iExtrusion.SetDepth(True, 0.1)
            iExtrusion.SetDepthObject(True, iFace)
            iExtrusion1 = API7.IExtrusion1(iExtrusion)
            iExtrusion1.OperationResult = con3.ksOperationCut
            iExtrusion1.Profile = iSketch
            iExtrusion1.DirectionObject = iSketch
            iExtrusion.Update()
            model_object_1 = iExtrusion

        if surface_type == 2:
            #  Создай объект модели "Вырезать выдавливанием"
            iExtrusions = iModelContainer.Extrusions
            iExtrusion = API7.IExtrusion(iExtrusions.Add(con3.o3d_cutExtrusion))
            iExtrusion.Direction = con3.dtBoth #Тип направления выдавливания в обе стороны
            iExtrusion.Name = f"Элемент выдавливания:{marking}"
            iExtrusion.Hidden = False
            iExtrusion.SetExtrusionType(True, con3.etBlind) #Выдавливание на глубину
            iExtrusion.SetDraftOutward(True, False)
            iExtrusion.SetDraftValue(True, 0.0)
            iExtrusion.SetDepth(True, 0.1) #Глубина выдавливания
            iExtrusion.SetExtrusionType(False, con3.etBlind)
            iExtrusion.SetDraftOutward(False, False)
            iExtrusion.SetDraftValue(False, 0.0)
            iExtrusion.SetDepth(False, 0.1)
            iExtrusion1 = API7.IExtrusion1(iExtrusion)
            iExtrusion1.OperationResult = con3.ksOperationCut
            iExtrusion1.Profile = iSketch #Эскиз выдавливания
            iExtrusion1.DirectionObject = iSketch
            iExtrusion.Update()

        iColorParam7 = API7.IColorParam7(iExtrusion)
        iColorParam7.Color = rgb_to_bgr_int(color_name='red')
        iColorParam7.UseColor = 0
        iExtrusion.Update()

    except:
        log_message(f'Не смогли промаркировать элемент {marking}, элемент пропущен', 'warn')
    finally:
        if not opened and iKompasDocument:
                iKompasDocument.Close(1)

if __name__ == "__main__":
    KompasObject, iApplication, KompasVersion = get_kompas()
    filename_m3d = None
    # path = k_path_active_doc()
    # filename_m3d = easygui.fileopenbox(msg="Укажите файл модели m3d", title="", default=f"{path}/*.m3d")

    if filename_m3d:
        folder_i3d = Path(filename_m3d).parent
        marking_3d(filename_m3d, '2001')
    else:
        print('debug')
        iKompasDocument = iApplication.ActiveDocument
        filename_m3d = iKompasDocument.PathName #Полный путь до файла
        # filename_m3d = r'C:\Users\ik\Desktop\Primer\КМ1\КМ1\Материалы\3d parts\m3d\303_Швеллер 16П_L250мм_С255_20(т)шт.m3d'
        marking_3d(filename_m3d, '2001', iApplication)