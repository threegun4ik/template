import os, sys
import pandas as pd


def printatr(obj):
    attributes = dir(obj)
    for attr in attributes:
        try:
            value = getattr(obj, attr)
            print(f"{attr}: {value}")
        except Exception as e:
            print(f"{attr}: <не удалось получить значение> ({e})")

# Создать библиотеку типов через gencache
def printprop(i):	# i - интерфейс
    print(i.__doc__)
    for _ in sorted(i._prop_map_get_):
        print(_, getattr(i, _))

# --- Настройка цветов ---
if sys.getwindowsversion().build >= 18363:  # Windows 1909+ поддерживает ANSI
    os.system('')  # Включаем ANSI
    COLORS = {
        'default': '\033[0m',
        'black': '\033[90m',
        'red': '\033[91m❌',           # error
        'green': '\033[32m✅',         # ok
        'yellow': '\033[33m⚠️',        # warn
        'blue': '\033[34m\033[1m\033[4m🔹',  # title
        'magenta': '\033[95m',
        'cyan': '\033[36m',
        'white': '\033[97m',
        'fallen': '\033[91m☠️',
        'blue2': '\033[34m',
    }
else:
    # Без цветов
    COLORS = {name: '' for name in [
        'default', 'black', 'red', 'green', 'yellow', 'blue',
        'magenta', 'cyan', 'white', 'fallen', 'blue2'
    ]}

def log_message(message: str, status: str = "default"):
    """
    Выводит сообщение в консоль с цветом по статусу.
    status:
        - "title" → синий с 🔹
        - "ok"    → зелёный с ✅
        - "warn"  → жёлтый с ⚠️
        - "error" → красный с ❌
        - "norm"  → фиолетовый
        - "how"  → фиолетовый
        - иначе без цвета
    """
    color_map = {
        'title': COLORS['blue'],
        'ok': COLORS['green'],
        'warn': COLORS['yellow'],
        'error': COLORS['red'],
		'magenta': COLORS['magenta'],
        'how': COLORS['cyan'],
    }
    color = color_map.get(status, COLORS['default'])
    print(f"{color}{message}{COLORS['default']}")

def print_full_columns(df: pd.DataFrame, *columns):
    """
    Печатает выбранные столбцы DataFrame без обрезки содержимого.

    :param df: DataFrame
    :param columns: имена столбцов (строки)
    """
    with pd.option_context('display.max_colwidth', None,
                           'display.max_rows', None,
                           'display.max_columns', None):
        if columns:
            print(df[list(columns)])
        else:
            print(df)

# help(i)
def print_df(df, columns):
    """
    Печать нескольких столбцов в виде таблицы.
    Принимает список столбцов и выводит их содержимое в виде таблицы.
    """
    pd.set_option('display.max_colwidth', None)  # Показывать полные значения ячеек
    pd.set_option('display.width', 1000)  # Устанавливаем максимальную ширину вывода
    pd.set_option('display.max_columns', None)  # Показываем все столбцы

    print("\n🔹(полный вывод):")

    # Проверяем, что все переданные столбцы существуют в DataFrame
    missing_columns = [col for col in columns if col not in df.columns]
    if missing_columns:
        print(f"Предупреждение: Столбцы {', '.join(missing_columns)} не найдены в DataFrame.")

    # Отбираем только те столбцы, которые есть в DataFrame
    df_to_print = df[columns] if all(col in df.columns for col in columns) else df[columns]

    # Выводим таблицу
    print(df_to_print)

if __name__ == "__main__":
    log_message('ttt','title')
    # data = {
    #     "Путь до i3d": [
    #         r"C:\\Projects\\Kompas\\Models\\Assembly\\VeryLongFileName_With_Many_Characters_And_Some_More_To_See_If_Truncated.i3d",
    #         r"D:\\Archive\\CAD\\AnotherExample_With_Long_Path_To_File_For_Testing_Pandas_Display.i3d",
    #         r"E:\\Work\\Temp\\TestFile_With_Extremely_Long_Name_To_Check_Full_Display_Without_Truncation.i3d",
    #     ],
    #     "Имя файла": ["Assembly1.i3d", "Archive2.i3d", "TestFile3.i3d"]
    # }
    #
    # df = pd.DataFrame(data)
    #
    # # напечатает весь столбец "Путь до i3d" без обрезки
    # print_full_columns(df, 'Путь до i3d')
    #
    # # можно несколько сразу
    # print_full_columns(df, 'Путь до i3d', 'Имя файла')