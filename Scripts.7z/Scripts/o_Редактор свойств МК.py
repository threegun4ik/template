from openpyxl.styles.builtins import percent
from __Kompas import *
from __ExcelHandler import ExcelHandler
import pandas as pd
import copy
import easygui
from __Utils import Timer

# ======================== Очистка свойств после ОиСМК =========================
# "excel" - обрабатываем данные из excel
# "extra" - обрабатываем словарь EXTRA_PROPS
# Какие строки обрабатываются: только те, где в обычных колонках Excel уже есть !!!.
# Какие свойства применяются: и «обычные» (где вы правили Excel), и EXTRA (если их ID занесены в EXTRA_PROPS).
EXTRA_PROPS_SCOPE = "excel"  # или "extra"

EXTRA_PROPS = {
    4.0: "!!!",                  # Обозначение
    15.0: "!!!",                 # Позиция
    273169036789.0: "!!!",       # Марка
    297771548672.0: "!!!",       # Марка элемента
    208346387948.0: "!!!",       # Масса марки
    330369994241.0: "!!!",       # Масса элемента
    238175427236.0: "!!!",       # Так
    255901398516.0: "!!!",       # Наоборот
}

# ========================= EXTRA PROPS END ==========================

dict_m3d = {}
dict_a3d = {}

# --- вверху файла (рядом с импортами) ---
def _vt_empty_variant():
    """Вернёт настоящий 'пустой' VARIANT:
       - comtypes: VARIANT(VT_EMPTY, None)
       - иначе: pythoncom.Empty
       - крайний случай: None
    """
    try:
        from comtypes.automation import VARIANT, VT_EMPTY as CT_VT_EMPTY
        return VARIANT(CT_VT_EMPTY, None)
    except Exception:
        try:
            import pythoncom  # pywin32
            return pythoncom.Empty
        except Exception:
            return None  # fallback

def _to_variant_for_set(v):
    # Пустая строка => очистка свойства (VT_EMPTY / Empty / None)
    if isinstance(v, str) and v.strip() == "":
        return _vt_empty_variant()
    return v

def build_nested_dict(df, prop_id):
    """
    Преобразует DataFrame в словарь вида:
        {
          <значение_первого_столбца>: {
             <ID_свойства_или_имя_колонки>: <значение_без_маркера_!!!>,
             ...
          },
          ...
        }

    Правила:
    - В исходных данных учитываются только ячейки, содержащие подстроку "!!!".
    - Из значений удаляется "!!!"; если после удаления строка пустая/пробельная — такое свойство пропускается.
    - Название колонки маппится в числовой ID из prop_id; если соответствия нет — остаётся исходное имя колонки.
    - Ключ верхнего уровня — значение из первого столбца строки (часто это "№ элемента"), у которого отрезается хвост ".0".
    """
    result_dict = {}  # итоговая структура для возврата

    # По строкам датафрейма
    for _, row in df.iterrows():
        # Ключ верхнего уровня — значение 1-й колонки (часто "№ элемента").
        # .replace('.0','') нужен, если это число пришло как строка '123.0'.
        main_value = str(row[df.columns[0]]).replace('.0', '')

        nested_dict = {}  # сюда соберём пары {prop_id: value} для одной строки

        # Идём по всем колонкам, кроме первой (первую уже забрали как ключ)
        for col in df.columns[1:]:
            val = row[col]

            # Берём только ячейки, где что-то есть, это строка не пустая,
            # и явно помечена маркером "!!!" (признак, что поле нужно обрабатывать).
            if pd.notna(val) and str(val).strip() and '!!!' in str(val):
                # Преобразуем имя колонки в ID свойства (если есть сопоставление)
                clean_key = prop_id.get(col, col)

                # Убираем служебный маркер "!!!" из значения
                clean_val = str(val).replace('!!!', '')

                # Если после удаления маркера значение стало пустым —
                # пропускаем такую пару (не будем чистить свойство).
                if str(clean_val).strip() == "":
                    continue

                # Сохраняем пару в словарь свойств для текущей строки
                nested_dict[clean_key] = clean_val

        # Если по строке нашлись свойства — добавляем её в результат
        if nested_dict:
            result_dict[main_value] = nested_dict

    return result_dict



def set_prop(file_path, markings_prop_dict):

    print(f"file_path:{file_path}")
    iDocuments = iApplication.Documents
    iKompasDocument = iDocuments.Open(file_path, False, False)
    iKompasDocument3D = API7.IKompasDocument3D(iKompasDocument)
    iPart7 = iKompasDocument3D.TopPart  # Верхний компонент (сам документ)
    iEmbodimentsManager = API7.IEmbodimentsManager(iPart7)
    iEmbodimentsManager.SetCurrentEmbodiment(0)
    iPropertyMng = API7.IPropertyMng(iApplication)  # интерфейс Менеджера свойств
    for i in range(iEmbodimentsManager.EmbodimentCount):
        iEmbodimentsManager.SetCurrentEmbodiment(i)
        iEmbodiment = iEmbodimentsManager.Embodiment
        iPart7 = iKompasDocument3D.TopPart  # Верхний компонент (сам документ)
        iModelObject = API7.IModelObject(iPart7)
        iModelObject.Update()
        iPropertyKeeper = API7.IPropertyKeeper(iPart7)  # интерфейс получения/редактирования значения свойств
        detail = iPart7.Detail  # если деталь - возвращает True, если сборка - False
        log_message(f'Обрабатываем файл {file_path}')
        if detail:
            iKompasDocument3D.RebuildDocument()
            for marking, properties in markings_prop_dict.items():# Проходим по каждому ключу и значению в словаре dict_marking
                print(f'Обрабатываем {marking}')

                for prop_id, prop_value in properties.items():
                    # Теперь у нас есть prop_id и prop_value
                    print(f'Для {marking} устанавливаем свойство {prop_id}: {prop_value}')
                    iPropertyName = iPropertyMng.GetProperty(iKompasDocument, prop_id)
                    iPropertyKeeper.SetPropertyValue(iPropertyName, _to_variant_for_set(prop_value), True)

        if not detail:
            iKompasDocument3D.RebuildDocument()
            # iPart7.RebuildModel(True)
            iFeature7 = API7.IFeature7(iPart7)  # Интерфейс объекта Дерева построения
            result_bodies = iFeature7.ResultBodies  # Массив тел

            # Приводим result_bodies к списку, если это одиночный объект
            if not isinstance(result_bodies, (list, tuple)):
                result_bodies = [result_bodies]

            for marking, properties in markings_prop_dict.items():  # Проходим по каждому ключу и значению в словаре
                print(f'Обрабатываем {marking}')

                for iBody7 in result_bodies:
                    if iBody7.Marking == marking:
                        iPropertyKeeper = API7.IPropertyKeeper(iBody7)  # Интерфейс работы со свойствами

                        for prop_id, prop_value in properties.items():
                            print(f'Для {marking} устанавливаем свойство {prop_id}: {prop_value}')
                            iPropertyName = iPropertyMng.GetProperty(iKompasDocument, prop_id)
                            # iPropertyKeeper.SetPropertyValue(iPropertyName, prop_value, True)
                            iPropertyKeeper.SetPropertyValue(iPropertyName, _to_variant_for_set(prop_value), True)
            iKompasDocument.Save()
    iKompasDocument.Close(1)

if __name__ == "__main__":
    input(f'Чтобы скрипт понял, какие ячейки таблицы 1.2 _ Ведомость элементов.xlsx были отредактированы - следует данные ячейки заканчивать символами "!!!"')

    timer = Timer()
    KompasObject, iApplication, KompasVersion = get_kompas()
    prop_id = {'№ элемента' : 4.0, 'Обозначение' : 4.0, 'Так': 238175427236.0, 'Наоборот': 255901398516.0,
               'Длина, мм': 235833998283.0, 'Ширина, мм': 334229340093.0, 'Толщина, мм': 226778862707.0,
               'Марка стали' : 290108629069.0, 'Масса элемента, кг' : 330369994241.0, 'Масса марки' : 208346387948.0,
               'Элемент марки' : 297771548672.0, 'Примечание': 7.0,
               'Наименование профиля ГОСТ, ТУ' : 289516577711.0, 'Наименование или марка металла ГОСТ, ТУ': 276893548975.0
               }

    path = get_active_doc_path(iApplication)
    xls = easygui.fileopenbox(msg="Укажите файл отчета 1.2 _ Ведомость элементов.xlsx", title="",
                              default=f"{path}/*1.2 _ Ведомость элементов.xlsx")
    # xls = r'C:\Users\ik\Desktop\Примеры\Модель\Материалы\1.2 _ Ведомость элементов.xlsx'

    timer.start()  # Запускаем таймер
    excel_handler = ExcelHandler(xls)  # Создаем экземпляр ExcelHandler для марок
    df = excel_handler.read_excel(header_row=1)  # Читаем таблицу в dataframe
    df = df.astype(str)  # Преобразуем весь df в строки

    # оставляем только строки с непустым номером элемента
    df = df[
        df['№ элемента'].astype(str).str.strip().ne('') &
        df['№ элемента'].astype(str).str.lower().ne('nan') &
        df['№ элемента'].astype(str).str.lower().ne('none')
        ]

    # ======================== EXTRA PROPS WIRING (упрощённо) ========================
    USE_EXTRA = (EXTRA_PROPS_SCOPE == 'extra')

    # Маска «отредактированных» строк по реальным (не-EXTRA) колонкам
    excel_cols = [c for c in df.columns if not c.startswith("__EXTRA__")]
    edited_mask = df[excel_cols].apply(lambda row: row.astype(str).str.contains("!!!").any(), axis=1)

    if USE_EXTRA:
        # Регистрируем EXTRA-колонки и добавляем их в prop_id
        for pid, trigger in EXTRA_PROPS.items():
            colname = f"__EXTRA__{int(pid)}"
            prop_id[colname] = float(pid)
            df[colname] = str(trigger)

        # Оставляем только ключевые колонки и EXTRA, чтобы реальные правки Excel не влияли
        KEY_COLS = {'№ элемента', 'Путь до марки'}
        for c in list(df.columns):
            if c in KEY_COLS or c.startswith("__EXTRA__"):
                continue
            df[c] = ""  # обнуляем все «обычные» колонки

        final_mask = pd.Series(True, index=df.index)  # берём все строки с валидным № элемента

    else:
        # Полностью игнорируем EXTRA: не добавляем __EXTRA__ и не меняем prop_id
        final_mask = edited_mask  # только строки, где в «обычных» колонках есть !!!

    # Итоговый срез строк к обработке
    df = df[final_mask]
    # ================================================================================

    required_columns = list(prop_id.keys()) + ['Путь до марки'] + ['Номер элемента']
    df = df[[col for col in required_columns if col in df.columns]]

    # df = df[df.apply(lambda row: row.astype(str).str.contains("!!!").any(), axis=1)] # Оставляем только строки, в которых хотя бы в одной ячейке содержится "!!!"
    dict_a3d = {} # Создаём словарь, где ключ - это 'Путь до марки', а значение - список '№ элемента'
    for path_group, group_df in df.groupby('Путь до марки'):
        # Разбиваем пути по ;
        if isinstance(path_group, str) and ';' in path_group:
            paths = [p.strip() for p in path_group.split(';')]
        else:
            paths = [str(path_group).strip()]

        # Готовим подмножество данных: столбец '№ элемента' должен быть первым
        cols_order = ['№ элемента'] + [col for col in group_df.columns if col != '№ элемента']
        group_df = group_df[cols_order]

        # Получаем словарь элементов для этой группы путей
        nested_data = build_nested_dict(group_df, prop_id)

        # Добавляем к каждому пути с созданием независимой копии
        for path in paths:
            data_copy = copy.deepcopy(nested_data)
            if path in dict_a3d:
                dict_a3d[path].update(data_copy)
            else:
                dict_a3d[path] = data_copy

    columns_to_keep = []
    # Добавляем только те столбцы из prop_id, которые есть в df
    for column in prop_id.keys():
        if column in df.columns:
            columns_to_keep.append(column)

    df = df[columns_to_keep]# Оставляем только нужные столбцы в DataFrame

    df.iloc[:, 1:] = df.iloc[:, 1:].copy().astype(str).apply(lambda col: col.map(lambda x: x if "!!!" in x else "")) # Очищаем все ячейки (кроме первого столбца), в которых нет "!!!"

    dict_edit_prop = build_nested_dict(df, prop_id)# Словарь {'1101': {290108629069.0: 'Сталь новая!!!'}}

    # print(f'dict_edit_prop {dict_edit_prop}')
    KompasObject, iApplication, KompasVersion = get_kompas()

    # print(f'Список компонентов для редактирвоания {dict_check}') # {4.0: ['2416', '2425']}
    # print(f'Список деталей для редактирвоания {dict_m3d}') #
    # print(f'Список тел для редактирвоания {dict_a3d}') # {'C:\\Users\\ik\\Desktop\\Primer\\20250221-КМ _ Площадка!\\03 _ Design\\01 _ CAD\\part\\Л101.a3d': ['2425', '2416']}
    # print(f'Словарь для внесения свойств {dict_edit_prop}') # {'2416': {290108629069.0: 'C245', 7.0: '50 кг'}, '2425': {290108629069.0: 'C245'}}


    # print(dict_a3d)
    # dict_a3d = dict(sorted(dict_a3d.items(), key=lambda x: x[0].count('\\'), reverse=True)) #Сортируем по вложенности сборок
    # dict_a3d[path] = dict(sorted(dict_a3d[path].items(), key=lambda item: int(item[0]))) #отсортировать по возрастанию ключей

    dict_a3d = {
        path: dict(sorted(elements.items(), key=lambda item: (not str(item[0]).isdigit(), str(item[0]))))
        for path, elements in sorted(dict_a3d.items(), key=lambda x: x[0].count('\\'), reverse=True)
    }

    def expand_semicolon_keys(d: dict) -> dict:
        """Ключи вида 'path1; path2; ...' разворачиваем в отдельные записи."""
        out = {}
        for k, v in d.items():
            if isinstance(k, str) and ';' in k:
                for p in (s.strip() for s in k.split(';')):
                    if p:
                        out[p] = v  # если один путь встретится несколько раз — последняя запись победит
            else:
                out[k] = v
        return out


    # 1) развернуть пути
    dict_a3d = expand_semicolon_keys(dict_a3d)


    # 2) упорядочить пути от «листьев» к «корню» (по глубине папок)
    def depth(p: str) -> int:
        # нормализуем, затем считаем количество компонентов пути
        return len(Path(os.path.normpath(p)).parts)


    ordered_items = sorted(dict_a3d.items(), key=lambda kv: depth(kv[0]), reverse=True)

    # 3) применить к каждому файлу его набор свойств
    for file_path, markings_prop_dict in ordered_items:
        print(f'{file_path}: {markings_prop_dict}')
        set_prop(file_path, markings_prop_dict)


    print(f'\n{timer.stop()}')
    input('\n\rРабота завершена.\n')
